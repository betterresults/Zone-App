-- Add training_times column to fitness_settings to store time per selected weekday
ALTER TABLE public.fitness_settings
ADD COLUMN IF NOT EXISTS training_times jsonb NOT NULL DEFAULT '{}'::jsonb;