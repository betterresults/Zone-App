-- Create habit sessions table for tracking time-based habits
CREATE TABLE public.habit_sessions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  habit_id UUID NOT NULL,
  session_date DATE NOT NULL DEFAULT CURRENT_DATE,
  started_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  ended_at TIMESTAMP WITH TIME ZONE,
  target_duration_minutes INTEGER, -- Target duration from habit description
  actual_duration_minutes INTEGER, -- Calculated when ended
  notes TEXT,
  is_completed BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.habit_sessions ENABLE ROW LEVEL SECURITY;

-- Create policies for habit sessions
CREATE POLICY "Users can view their own habit sessions" 
ON public.habit_sessions 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own habit sessions" 
ON public.habit_sessions 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own habit sessions" 
ON public.habit_sessions 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own habit sessions" 
ON public.habit_sessions 
FOR DELETE 
USING (auth.uid() = user_id);

-- Add trigger for automatic timestamp updates
CREATE TRIGGER update_habit_sessions_updated_at
BEFORE UPDATE ON public.habit_sessions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create index for better performance
CREATE INDEX idx_habit_sessions_user_date ON public.habit_sessions(user_id, session_date);
CREATE INDEX idx_habit_sessions_habit_id ON public.habit_sessions(habit_id);

-- Function to automatically calculate duration when session ends
CREATE OR REPLACE FUNCTION public.calculate_habit_session_duration()
RETURNS TRIGGER AS $$
BEGIN
  -- If ended_at is being set and it wasn't set before, calculate duration
  IF NEW.ended_at IS NOT NULL AND OLD.ended_at IS NULL THEN
    NEW.actual_duration_minutes := EXTRACT(EPOCH FROM (NEW.ended_at - NEW.started_at)) / 60;
    NEW.is_completed := true;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for automatic duration calculation
CREATE TRIGGER calculate_habit_session_duration_trigger
BEFORE UPDATE ON public.habit_sessions
FOR EACH ROW
EXECUTE FUNCTION public.calculate_habit_session_duration();