-- Enable pg_cron extension for scheduled jobs
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Schedule the notification processing function to run every minute
SELECT cron.schedule(
  'process-notifications',
  '* * * * *', -- Run every minute
  $$
  SELECT
    net.http_post(
      url := 'https://cmznrqtrtwohclokilkv.supabase.co/functions/v1/process-scheduled-notifications',
      headers := '{"Content-Type": "application/json", "Authorization": "Bearer ' || current_setting('app.jwt_secret') || '"}'::jsonb,
      body := '{"scheduled": true}'::jsonb
    ) as request_id;
  $$
);