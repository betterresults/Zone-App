-- Fix scheduled_notifications table structure and policies

-- Change reference_id from UUID to TEXT to allow custom identifiers like 'fasting_123', 'habit_456', etc.
ALTER TABLE scheduled_notifications 
ALTER COLUMN reference_id TYPE TEXT;

-- Drop existing INSERT policy
DROP POLICY IF EXISTS "Users can create their own scheduled notifications" ON scheduled_notifications;

-- Create proper INSERT policy with WITH CHECK condition
CREATE POLICY "Users can create their own scheduled notifications" 
ON scheduled_notifications 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);