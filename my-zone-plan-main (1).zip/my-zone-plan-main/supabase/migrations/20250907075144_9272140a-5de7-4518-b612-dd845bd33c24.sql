-- Правим user_id nullable за системни порции
ALTER TABLE public.favorite_portions ALTER COLUMN user_id DROP NOT NULL;

-- Обновяваме RLS политиките да включват системни порции
DROP POLICY "Users can view their own favorite portions" ON public.favorite_portions;

CREATE POLICY "Users can view their own favorite portions and public portions" 
ON public.favorite_portions 
FOR SELECT 
USING (auth.uid() = user_id OR user_id IS NULL);

-- Добавяме системни порции за авокадо
INSERT INTO public.favorite_portions (user_id, product_id, portion_name, grams)
SELECT NULL, p.id, 'Малка порция', 50
FROM public.products p
WHERE p.name = 'Авокадо' AND p.is_public = true;

INSERT INTO public.favorite_portions (user_id, product_id, portion_name, grams)
SELECT NULL, p.id, 'Половин авокадо', 75
FROM public.products p
WHERE p.name = 'Авокадо' AND p.is_public = true;

INSERT INTO public.favorite_portions (user_id, product_id, portion_name, grams)
SELECT NULL, p.id, 'Цяло авокадо', 150
FROM public.products p
WHERE p.name = 'Авокадо' AND p.is_public = true;