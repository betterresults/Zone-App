-- Enable pg_cron extension if not already enabled
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Grant permissions to use cron
GRANT USAGE ON SCHEMA cron TO postgres;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA cron TO postgres;

-- Schedule the process-daily-habits function to run every day at 00:05 AM
-- This will process yesterday's habits and roll over important tasks
SELECT cron.schedule(
  'process-daily-habits',
  '5 0 * * *', -- At 00:05 every day
  $$
  SELECT
    net.http_post(
      url := 'https://cmznrqtrtwohclokilkv.supabase.co/functions/v1/process-daily-habits',
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        'Authorization', 'Bearer ' || current_setting('app.settings.service_role_key', true)
      ),
      body := '{}'::jsonb
    ) as request_id;
  $$
);

-- Create a function to manually trigger the daily habits processing (for testing)
CREATE OR REPLACE FUNCTION public.trigger_daily_habits_processing()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result jsonb;
BEGIN
  -- Only admins can trigger this
  IF NOT public.is_admin(auth.uid()) THEN
    RAISE EXCEPTION 'Only admins can trigger daily habits processing';
  END IF;
  
  -- Call the edge function
  SELECT content::jsonb INTO result
  FROM net.http_post(
    url := 'https://cmznrqtrtwohclokilkv.supabase.co/functions/v1/process-daily-habits',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer ' || current_setting('app.settings.service_role_key', true)
    ),
    body := '{}'::jsonb
  );
  
  RETURN result;
END;
$$;