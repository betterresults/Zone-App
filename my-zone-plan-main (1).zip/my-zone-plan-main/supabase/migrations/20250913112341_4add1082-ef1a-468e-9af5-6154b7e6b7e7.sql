-- Add notification settings to fitness_settings table
ALTER TABLE public.fitness_settings 
ADD COLUMN notifications_enabled BOOLEAN DEFAULT false,
ADD COLUMN notification_minutes INTEGER DEFAULT 30;