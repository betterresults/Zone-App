-- Add habit_type enum and column to habits table
CREATE TYPE public.habit_type AS ENUM ('habit', 'task');

-- Add habit_type column to habits table
ALTER TABLE public.habits 
ADD COLUMN habit_type public.habit_type NOT NULL DEFAULT 'habit';

-- Update existing records to be habits by default
UPDATE public.habits SET habit_type = 'habit' WHERE habit_type IS NULL;