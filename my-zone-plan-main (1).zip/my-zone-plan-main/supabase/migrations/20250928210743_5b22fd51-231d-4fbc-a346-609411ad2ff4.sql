-- Create user habit categories table
CREATE TABLE public.user_habit_categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  color TEXT NOT NULL DEFAULT '#8B5CF6',
  icon TEXT NOT NULL DEFAULT 'Circle',
  is_default BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, name),
  CHECK (length(name) > 0 AND length(name) <= 50)
);

-- Enable RLS
ALTER TABLE public.user_habit_categories ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view their own habit categories" 
ON public.user_habit_categories 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own habit categories" 
ON public.user_habit_categories 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own habit categories" 
ON public.user_habit_categories 
FOR UPDATE 
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own habit categories" 
ON public.user_habit_categories 
FOR DELETE 
USING (auth.uid() = user_id);

-- Add trigger for updated_at
CREATE TRIGGER update_user_habit_categories_updated_at
BEFORE UPDATE ON public.user_habit_categories
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default categories for existing users
INSERT INTO public.user_habit_categories (user_id, name, color, icon, is_default)
SELECT DISTINCT 
  p.user_id,
  'Здраве',
  '#22C55E',
  'Heart',
  true
FROM public.profiles p
WHERE NOT EXISTS (
  SELECT 1 FROM public.user_habit_categories uhc 
  WHERE uhc.user_id = p.user_id AND uhc.name = 'Здраве'
);

INSERT INTO public.user_habit_categories (user_id, name, color, icon, is_default)
SELECT DISTINCT 
  p.user_id,
  'Фитнес',
  '#3B82F6',
  'Dumbbell',
  true
FROM public.profiles p
WHERE NOT EXISTS (
  SELECT 1 FROM public.user_habit_categories uhc 
  WHERE uhc.user_id = p.user_id AND uhc.name = 'Фитнес'
);

INSERT INTO public.user_habit_categories (user_id, name, color, icon, is_default)
SELECT DISTINCT 
  p.user_id,
  'Учене',
  '#8B5CF6',
  'BookOpen',
  true
FROM public.profiles p
WHERE NOT EXISTS (
  SELECT 1 FROM public.user_habit_categories uhc 
  WHERE uhc.user_id = p.user_id AND uhc.name = 'Учене'
);

INSERT INTO public.user_habit_categories (user_id, name, color, icon, is_default)
SELECT DISTINCT 
  p.user_id,
  'Общо',
  '#6B7280',
  'Circle',
  true
FROM public.profiles p
WHERE NOT EXISTS (
  SELECT 1 FROM public.user_habit_categories uhc 
  WHERE uhc.user_id = p.user_id AND uhc.name = 'Общо'
);