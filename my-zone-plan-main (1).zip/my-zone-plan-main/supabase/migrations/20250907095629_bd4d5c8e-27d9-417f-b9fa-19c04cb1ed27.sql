-- Update profiles table to include hydration_enabled and fasting_enabled with proper defaults
UPDATE public.profiles 
SET hydration_enabled = true, fasting_enabled = true 
WHERE hydration_enabled IS NULL OR fasting_enabled IS NULL;