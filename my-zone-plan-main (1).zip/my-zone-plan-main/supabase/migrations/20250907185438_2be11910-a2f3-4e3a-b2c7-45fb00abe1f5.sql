-- First, drop the existing check constraint that's causing the issue
ALTER TABLE meals DROP CONSTRAINT IF EXISTS meal_has_product_or_recipe;

-- Add a new check constraint that includes dish_id as well
ALTER TABLE meals ADD CONSTRAINT meal_has_product_recipe_or_dish 
CHECK (
  (product_id IS NOT NULL AND recipe_id IS NULL AND dish_id IS NULL) OR
  (product_id IS NULL AND recipe_id IS NOT NULL AND dish_id IS NULL) OR
  (product_id IS NULL AND recipe_id IS NULL AND dish_id IS NOT NULL)
);