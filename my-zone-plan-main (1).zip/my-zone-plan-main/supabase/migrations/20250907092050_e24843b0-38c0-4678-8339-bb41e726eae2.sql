-- Create dishes table for individual meal portions
CREATE TABLE public.dishes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  meal_type meal_type NOT NULL DEFAULT 'lunch',
  is_public BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.dishes ENABLE ROW LEVEL SECURITY;

-- Create policies for dishes
CREATE POLICY "Users can create their own dishes" 
ON public.dishes 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view public dishes and their own dishes" 
ON public.dishes 
FOR SELECT 
USING ((is_public = true) OR (auth.uid() = user_id));

CREATE POLICY "Users can update their own dishes" 
ON public.dishes 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own dishes" 
ON public.dishes 
FOR DELETE 
USING (auth.uid() = user_id);

-- Create dish_ingredients table for dish ingredients
CREATE TABLE public.dish_ingredients (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  dish_id UUID NOT NULL,
  product_id UUID NOT NULL,
  grams NUMERIC NOT NULL DEFAULT 100,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security for dish_ingredients
ALTER TABLE public.dish_ingredients ENABLE ROW LEVEL SECURITY;

-- Create policies for dish_ingredients
CREATE POLICY "Users can manage ingredients for their own dishes" 
ON public.dish_ingredients 
FOR ALL 
USING (EXISTS (
  SELECT 1 FROM dishes 
  WHERE dishes.id = dish_ingredients.dish_id 
  AND dishes.user_id = auth.uid()
));

CREATE POLICY "Users can view dish ingredients for accessible dishes" 
ON public.dish_ingredients 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM dishes 
  WHERE dishes.id = dish_ingredients.dish_id 
  AND (dishes.is_public = true OR dishes.user_id = auth.uid())
));

-- Add trigger for automatic timestamp updates on dishes
CREATE TRIGGER update_dishes_updated_at
BEFORE UPDATE ON public.dishes
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Update meals table to support both recipes and dishes
ALTER TABLE public.meals ADD COLUMN dish_id UUID;