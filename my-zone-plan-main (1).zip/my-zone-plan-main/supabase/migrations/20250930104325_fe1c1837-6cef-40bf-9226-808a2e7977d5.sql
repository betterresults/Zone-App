-- Add exercise_order column to workout_exercises table
ALTER TABLE public.workout_exercises
ADD COLUMN exercise_order INTEGER DEFAULT 0;

-- Update existing records to have sequential order based on created_at
WITH ordered_exercises AS (
  SELECT 
    id,
    ROW_NUMBER() OVER (
      PARTITION BY user_id, created_at::date
      ORDER BY created_at
    ) - 1 AS new_order
  FROM public.workout_exercises
)
UPDATE public.workout_exercises we
SET exercise_order = oe.new_order
FROM ordered_exercises oe
WHERE we.id = oe.id;