-- Drop the unnecessary admin_notifications table and related objects
DROP TRIGGER IF EXISTS create_admin_notification_trigger ON public.user_activities;
DROP FUNCTION IF EXISTS public.create_admin_notification_for_activity();
DROP TABLE IF EXISTS public.admin_notifications;