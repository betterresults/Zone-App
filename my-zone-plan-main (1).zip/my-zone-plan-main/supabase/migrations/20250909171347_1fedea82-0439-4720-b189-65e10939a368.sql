-- Update RLS policy to allow users to create products with proper user_id constraint
DROP POLICY IF EXISTS "Users can create their own products" ON public.products;

CREATE POLICY "Users can create their own products" 
ON public.products 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);