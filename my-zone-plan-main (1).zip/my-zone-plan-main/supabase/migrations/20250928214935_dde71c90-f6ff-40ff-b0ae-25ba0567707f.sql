-- Add duration field to habits table
ALTER TABLE public.habits 
ADD COLUMN duration_minutes integer;