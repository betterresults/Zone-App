-- Create fitness_settings table for user fitness preferences
CREATE TABLE public.fitness_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  training_days_per_week INTEGER NOT NULL DEFAULT 3,
  training_days JSONB NOT NULL DEFAULT '[]'::jsonb, -- Array of weekdays [0-6] where 0=Monday
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create fitness_sessions table for tracking workouts
CREATE TABLE public.fitness_sessions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  session_date DATE NOT NULL DEFAULT CURRENT_DATE,
  completed BOOLEAN NOT NULL DEFAULT false,
  calories_burned INTEGER,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, session_date)
);

-- Enable Row Level Security
ALTER TABLE public.fitness_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fitness_sessions ENABLE ROW LEVEL SECURITY;

-- Create policies for fitness_settings
CREATE POLICY "Users can create their own fitness settings" 
ON public.fitness_settings 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own fitness settings" 
ON public.fitness_settings 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own fitness settings" 
ON public.fitness_settings 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own fitness settings" 
ON public.fitness_settings 
FOR DELETE 
USING (auth.uid() = user_id);

-- Create policies for fitness_sessions
CREATE POLICY "Users can create their own fitness sessions" 
ON public.fitness_sessions 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own fitness sessions" 
ON public.fitness_sessions 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own fitness sessions" 
ON public.fitness_sessions 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own fitness sessions" 
ON public.fitness_sessions 
FOR DELETE 
USING (auth.uid() = user_id);

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_fitness_settings_updated_at
BEFORE UPDATE ON public.fitness_settings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_fitness_sessions_updated_at
BEFORE UPDATE ON public.fitness_sessions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();