-- Add template and archive columns to shopping_lists table
ALTER TABLE public.shopping_lists 
ADD COLUMN is_template boolean DEFAULT false,
ADD COLUMN template_name text,
ADD COLUMN is_archived boolean DEFAULT false,
ADD COLUMN archived_at timestamp with time zone;