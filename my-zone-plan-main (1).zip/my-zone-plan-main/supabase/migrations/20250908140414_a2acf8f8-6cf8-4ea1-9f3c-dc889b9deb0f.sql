-- Create recipe-images storage bucket if not exists
INSERT INTO storage.buckets (id, name, public)
SELECT 'recipe-images', 'recipe-images', true
WHERE NOT EXISTS (
  SELECT 1 FROM storage.buckets WHERE id = 'recipe-images'
);

-- Create policy for recipe image uploads
CREATE POLICY IF NOT EXISTS "Users can upload recipe images"
ON storage.objects
FOR INSERT 
WITH CHECK (
  bucket_id = 'recipe-images' AND 
  auth.uid()::text = (storage.foldername(name))[1]
);

-- Create policy for public recipe image access
CREATE POLICY IF NOT EXISTS "Recipe images are publicly accessible"
ON storage.objects
FOR SELECT
USING (bucket_id = 'recipe-images');