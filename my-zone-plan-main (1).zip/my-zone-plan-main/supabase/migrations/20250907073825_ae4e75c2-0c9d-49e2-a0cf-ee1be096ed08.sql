
-- Публичен каталог с често ползвани храни (макроси на 100 г)
-- Всяка INSERT използва WHERE NOT EXISTS, за да е идемпотентно

-- ПЛОДОВЕ
INSERT INTO public.products (name, category, calories_per_100g, protein_per_100g, carbs_per_100g, fiber_per_100g, fat_per_100g, default_serving_grams, is_public, user_id)
SELECT 'Ябълка', 'fruits', 52, 0.3, 14.0, 2.4, 0.2, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Ябълка') AND is_public=true);

INSERT INTO public.products (name, category, calories_per_100g, protein_per_100g, carbs_per_100g, fiber_per_100g, fat_per_100g, default_serving_grams, is_public, user_id)
SELECT 'Банан', 'fruits', 89, 1.1, 22.8, 2.6, 0.3, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Банан') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Портокал', 'fruits', 47, 0.9, 11.8, 2.4, 0.1, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Портокал') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Ягода', 'fruits', 32, 0.7, 7.7, 2.0, 0.3, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Ягода') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Боровинка', 'fruits', 57, 0.7, 14.5, 2.4, 0.3, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Боровинка') AND is_public=true);

-- ЗЕЛЕНЧУЦИ
INSERT INTO public.products (...) 
SELECT 'Домати', 'vegetables', 18, 0.9, 3.9, 1.2, 0.2, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Домати') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Краставица', 'vegetables', 15, 0.7, 3.6, 0.5, 0.1, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Краставица') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Червена чушка', 'vegetables', 31, 1.0, 6.0, 2.1, 0.3, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Червена чушка') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Морков', 'vegetables', 41, 0.9, 9.6, 2.8, 0.2, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Морков') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Броколи', 'vegetables', 34, 2.8, 6.6, 2.6, 0.4, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Броколи') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Спанак', 'vegetables', 23, 2.9, 3.6, 2.2, 0.4, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Спанак') AND is_public=true);

-- ПРОТЕИНИ
INSERT INTO public.products (...) 
SELECT 'Пилешко филе', 'protein', 165, 31.0, 0, 0, 3.6, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Пилешко филе') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Пуешко филе', 'protein', 135, 29.0, 0, 0, 1.0, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Пуешко филе') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Говеждо постно', 'protein', 170, 26.0, 0, 0, 7.0, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Говеждо постно') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Свинско филе', 'protein', 143, 26.0, 0, 0, 3.6, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Свинско филе') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Яйца', 'protein', 155, 13.0, 1.1, 0, 11.0, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Яйца') AND is_public=true);

-- МЛЕЧНИ
INSERT INTO public.products (...) 
SELECT 'Кисело мляко 2%', 'dairy', 61, 4.0, 4.7, 0, 2.0, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Кисело мляко 2%') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Кисело мляко 0.1%', 'dairy', 36, 3.5, 4.0, 0, 0.1, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Кисело мляко 0.1%') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Сирене бяло (саламурено)', 'dairy', 264, 14.2, 4.1, 0, 21.3, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Сирене бяло (саламурено)') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Кашкавал', 'dairy', 356, 25.0, 2.0, 0, 27.0, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Кашкавал') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Мляко 1.5%', 'dairy', 46, 3.4, 4.9, 0, 1.5, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Мляко 1.5%') AND is_public=true);

-- ЗЪРНЕНИ/ХЛЯБ
INSERT INTO public.products (...) 
SELECT 'Овесени ядки', 'grains', 389, 16.9, 66.3, 10.6, 6.9, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Овесени ядки') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Хляб пълнозърнест', 'grains', 247, 13.0, 41.0, 7.0, 4.0, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Хляб пълнозърнест') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Ориз бял (суров)', 'grains', 365, 7.1, 80.0, 1.3, 0.6, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Ориз бял (суров)') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Ориз кафяв (суров)', 'grains', 370, 7.5, 77.0, 3.5, 2.7, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Ориз кафяв (суров)') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Киноа (сурова)', 'grains', 368, 14.1, 64.2, 7.0, 6.1, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Киноа (сурова)') AND is_public=true);

-- ВАРИВА
INSERT INTO public.products (...) 
SELECT 'Леща (суха)', 'legumes', 353, 25.8, 60.0, 30.5, 1.1, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Леща (суха)') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Нахут (сух)', 'legumes', 364, 19.3, 60.7, 17.4, 6.0, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Нахут (сух)') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Боб бял (сух)', 'legumes', 333, 21.4, 60.0, 15.2, 0.8, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Боб бял (сух)') AND is_public=true);

-- ЯДКИ/МАСЛА
INSERT INTO public.products (...) 
SELECT 'Бадеми', 'nuts', 579, 21.2, 21.7, 12.5, 49.9, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Бадеми') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Орехи', 'nuts', 654, 15.2, 13.7, 6.7, 65.2, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Орехи') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Фъстъчено масло (натурално)', 'nuts', 588, 25.0, 20.0, 6.0, 50.0, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Фъстъчено масло (натурално)') AND is_public=true);

-- МАЗНИНИ/ДРУГИ
INSERT INTO public.products (...) 
SELECT 'Зехтин (extra virgin)', 'fats', 884, 0, 0, 0, 100.0, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Зехтин (extra virgin)') AND is_public=true);

INSERT INTO public.products (...) 
SELECT 'Авокадо', 'fats', 160, 2.0, 9.0, 7.0, 15.0, 100, true, NULL
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE lower(name)=lower('Авокадо') AND is_public=true);
