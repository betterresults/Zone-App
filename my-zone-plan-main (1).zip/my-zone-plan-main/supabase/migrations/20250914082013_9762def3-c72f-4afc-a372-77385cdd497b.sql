-- Add fitness_template_id column to habits table to link habits with fitness templates
ALTER TABLE public.habits 
ADD COLUMN fitness_template_id uuid REFERENCES public.fitness_settings(id) ON DELETE SET NULL;