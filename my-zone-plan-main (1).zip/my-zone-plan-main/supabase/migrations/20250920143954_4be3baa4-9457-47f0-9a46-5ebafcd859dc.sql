-- Fix the cron job with proper JSON formatting
SELECT cron.unschedule('process-scheduled-notifications');

-- Recreate with proper JSON formatting
SELECT cron.schedule(
  'process-scheduled-notifications',
  '* * * * *', -- every minute
  $$
  SELECT net.http_post(
    url := 'https://cmznrqtrtwohclokilkv.supabase.co/functions/v1/process-scheduled-notifications',
    headers := '{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNtem5ycXRydHdvaGNsb2tpbGt2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTcxNzY1MTMsImV4cCI6MjA3Mjc1MjUxM30.0KRvJiaVibJbhKLzWEtV3pdAXqPkv6bXoawuHFKLvwA"}'::jsonb,
    body := jsonb_build_object('time', to_char(now(), 'YYYY-MM-DD"T"HH24:MI:SS"Z"'))
  );
  $$
);