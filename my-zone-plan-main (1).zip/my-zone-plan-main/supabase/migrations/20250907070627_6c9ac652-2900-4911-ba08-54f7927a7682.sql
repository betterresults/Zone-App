-- Add Zone configuration columns to profiles table
ALTER TABLE public.profiles 
ADD COLUMN height_cm integer,
ADD COLUMN weight_kg numeric(5,2),
ADD COLUMN age integer,
ADD COLUMN gender text CHECK (gender IN ('male', 'female')),
ADD COLUMN activity_level text CHECK (activity_level IN ('sedentary', 'light', 'moderate', 'very_active', 'extra_active')),
ADD COLUMN daily_blocks integer DEFAULT 11,
ADD COLUMN calculated_at timestamp with time zone;

-- Add comment explaining the daily_blocks default
COMMENT ON COLUMN public.profiles.daily_blocks IS 'Number of Zone blocks needed per day. Default 11 is for average sedentary woman.';
COMMENT ON COLUMN public.profiles.calculated_at IS 'When the Zone blocks were last calculated based on user parameters.';

-- Add index for better performance on zone calculations
CREATE INDEX idx_profiles_zone_config ON public.profiles(user_id, daily_blocks) WHERE daily_blocks IS NOT NULL;