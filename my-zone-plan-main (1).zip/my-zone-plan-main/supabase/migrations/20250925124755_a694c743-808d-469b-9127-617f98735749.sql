-- Add fasting notification templates
INSERT INTO notification_templates (template_type, template_name, title_template, message_template, time_of_day, is_active) VALUES
('event', 'fasting_completed_morning', '🎉 Фастинг завършен!', 'Честито, {name}! Успешно завърши фастинг от {hours} часа. Време е да нарушиш поста с полезна храна! 💪', 'morning', true),
('event', 'fasting_completed_afternoon', '🎉 Отлично постижение!', 'Браво, {name}! {hours} часа фастинг са зад теб. Подхрани се с нещо здравословно! 🥗', 'afternoon', true),
('event', 'fasting_completed_evening', '🎉 Фастинг завършен успешно!', 'Чудесна работа, {name}! Завърши {hours}ч фастинг. Време е за хранене - избери нещо лесно за стомаха! 🍲', 'evening', true),
('event', 'fasting_completed_any', '🎉 Успешен фастинг!', 'Поздравления, {name}! Завърши {hours} часа фастинг. Сега внимателно нарушавай поста! 💚', 'any', true);