-- Create comprehensive user activity tracking table
CREATE TABLE public.user_activities (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  activity_type text NOT NULL,
  activity_category text NOT NULL, -- cooking, products, recipes, dishes, calendar, referral, settings, etc.
  activity_description text NOT NULL,
  activity_data jsonb DEFAULT '{}'::jsonb, -- Additional data about the activity
  ip_address text,
  user_agent text,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.user_activities ENABLE ROW LEVEL SECURITY;

-- Create policies for user activity tracking
CREATE POLICY "Users can create their own activities" 
ON public.user_activities 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own activities" 
ON public.user_activities 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all activities" 
ON public.user_activities 
FOR SELECT 
USING (public.is_admin(auth.uid()));

-- Create indexes for better performance
CREATE INDEX idx_user_activities_user_id ON public.user_activities(user_id);
CREATE INDEX idx_user_activities_category ON public.user_activities(activity_category);
CREATE INDEX idx_user_activities_type ON public.user_activities(activity_type);
CREATE INDEX idx_user_activities_created_at ON public.user_activities(created_at DESC);
CREATE INDEX idx_user_activities_user_created ON public.user_activities(user_id, created_at DESC);

-- Enable real-time for the table
ALTER TABLE public.user_activities REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.user_activities;