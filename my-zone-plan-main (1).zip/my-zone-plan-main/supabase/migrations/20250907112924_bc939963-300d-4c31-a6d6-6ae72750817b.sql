-- Create weekly_meal_plans table for storing weekly meal planning
CREATE TABLE public.weekly_meal_plans (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  week_start_date DATE NOT NULL,
  day_of_week INTEGER NOT NULL CHECK (day_of_week >= 0 AND day_of_week <= 6), -- 0=Monday, 6=Sunday
  meal_type meal_type NOT NULL,
  recipe_id UUID REFERENCES public.recipes(id) ON DELETE CASCADE,
  product_id UUID REFERENCES public.products(id) ON DELETE CASCADE,
  dish_id UUID REFERENCES public.dishes(id) ON DELETE CASCADE,
  grams NUMERIC,
  servings NUMERIC DEFAULT 1,
  is_completed BOOLEAN NOT NULL DEFAULT false,
  completed_at TIMESTAMP WITH TIME ZONE,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  
  -- Ensure only one of recipe_id, product_id, or dish_id is set
  CONSTRAINT weekly_meal_plans_source_check CHECK (
    (recipe_id IS NOT NULL AND product_id IS NULL AND dish_id IS NULL) OR
    (recipe_id IS NULL AND product_id IS NOT NULL AND dish_id IS NULL) OR
    (recipe_id IS NULL AND product_id IS NULL AND dish_id IS NOT NULL)
  )
);

-- Enable Row Level Security
ALTER TABLE public.weekly_meal_plans ENABLE ROW LEVEL SECURITY;

-- Create policies for weekly_meal_plans
CREATE POLICY "Users can view their own weekly meal plans" 
ON public.weekly_meal_plans 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own weekly meal plans" 
ON public.weekly_meal_plans 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own weekly meal plans" 
ON public.weekly_meal_plans 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own weekly meal plans" 
ON public.weekly_meal_plans 
FOR DELETE 
USING (auth.uid() = user_id);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_weekly_meal_plans_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_weekly_meal_plans_updated_at
BEFORE UPDATE ON public.weekly_meal_plans
FOR EACH ROW
EXECUTE FUNCTION public.update_weekly_meal_plans_updated_at();

-- Create index for better performance
CREATE INDEX idx_weekly_meal_plans_user_week ON public.weekly_meal_plans(user_id, week_start_date);
CREATE INDEX idx_weekly_meal_plans_day_type ON public.weekly_meal_plans(day_of_week, meal_type);