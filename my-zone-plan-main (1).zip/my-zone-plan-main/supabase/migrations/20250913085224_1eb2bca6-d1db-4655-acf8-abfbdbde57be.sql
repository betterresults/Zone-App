-- Create universal function for logging user activities
CREATE OR REPLACE FUNCTION public.log_user_activity()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  activity_category text;
  activity_type text;
  activity_description text;
  activity_data_obj jsonb := '{}';
  record_name text;
BEGIN
  -- Only log activities for authenticated users
  IF auth.uid() IS NULL THEN
    RETURN COALESCE(NEW, OLD);
  END IF;

  -- Determine category and type based on table name and operation
  CASE TG_TABLE_NAME
    WHEN 'products' THEN
      activity_category := 'products';
      CASE TG_OP
        WHEN 'INSERT' THEN 
          activity_type := 'add_product';
          record_name := NEW.name;
          activity_description := 'Добавен нов продукт: ' || record_name;
          activity_data_obj := jsonb_build_object('product_id', NEW.id, 'product_name', record_name);
        WHEN 'UPDATE' THEN 
          activity_type := 'edit_product';
          record_name := NEW.name;
          activity_description := 'Редактиран продукт: ' || record_name;
          activity_data_obj := jsonb_build_object('product_id', NEW.id, 'product_name', record_name);
        WHEN 'DELETE' THEN 
          activity_type := 'delete_product';
          record_name := OLD.name;
          activity_description := 'Изтрит продукт: ' || record_name;
          activity_data_obj := jsonb_build_object('product_id', OLD.id, 'product_name', record_name);
      END CASE;

    WHEN 'recipes' THEN
      activity_category := 'recipes';
      CASE TG_OP
        WHEN 'INSERT' THEN 
          activity_type := 'add_recipe';
          record_name := NEW.name;
          activity_description := 'Добавена нова рецепта: ' || record_name;
          activity_data_obj := jsonb_build_object('recipe_id', NEW.id, 'recipe_name', record_name);
        WHEN 'UPDATE' THEN 
          activity_type := 'edit_recipe';
          record_name := NEW.name;
          activity_description := 'Редактирана рецепта: ' || record_name;
          activity_data_obj := jsonb_build_object('recipe_id', NEW.id, 'recipe_name', record_name);
          -- Check if recipe was made public/private
          IF OLD.is_public != NEW.is_public THEN
            IF NEW.is_public THEN
              activity_type := 'make_public';
              activity_description := 'Рецепта направена публична: ' || record_name;
            ELSE
              activity_type := 'make_private';
              activity_description := 'Рецепта направена частна: ' || record_name;
            END IF;
          END IF;
        WHEN 'DELETE' THEN 
          activity_type := 'delete_recipe';
          record_name := OLD.name;
          activity_description := 'Изтрита рецепта: ' || record_name;
          activity_data_obj := jsonb_build_object('recipe_id', OLD.id, 'recipe_name', record_name);
      END CASE;

    WHEN 'dishes' THEN
      activity_category := 'dishes';
      CASE TG_OP
        WHEN 'INSERT' THEN 
          activity_type := 'add_dish';
          record_name := NEW.name;
          activity_description := 'Добавено нowo ястие: ' || record_name;
          activity_data_obj := jsonb_build_object('dish_id', NEW.id, 'dish_name', record_name);
          -- Check if created from recipe
          IF NEW.source_recipe_id IS NOT NULL THEN
            activity_type := 'create_from_recipe';
            activity_description := 'Създадено ястие от рецепта: ' || record_name;
            activity_data_obj := activity_data_obj || jsonb_build_object('source_recipe_id', NEW.source_recipe_id);
          END IF;
        WHEN 'UPDATE' THEN 
          activity_type := 'edit_dish';
          record_name := NEW.name;
          activity_description := 'Редактирано ястие: ' || record_name;
          activity_data_obj := jsonb_build_object('dish_id', NEW.id, 'dish_name', record_name);
        WHEN 'DELETE' THEN 
          activity_type := 'delete_dish';
          record_name := OLD.name;
          activity_description := 'Изтрито ястие: ' || record_name;
          activity_data_obj := jsonb_build_object('dish_id', OLD.id, 'dish_name', record_name);
      END CASE;

    WHEN 'meals' THEN
      activity_category := 'calendar';
      CASE TG_OP
        WHEN 'INSERT' THEN 
          activity_type := 'add_meal';
          activity_description := 'Добавено хранене за ' || NEW.meal_type::text || ' на ' || NEW.date::text;
          activity_data_obj := jsonb_build_object('meal_id', NEW.id, 'meal_type', NEW.meal_type, 'date', NEW.date);
        WHEN 'UPDATE' THEN 
          activity_type := 'edit_meal';
          activity_description := 'Редактирано хранене за ' || NEW.meal_type::text || ' на ' || NEW.date::text;
          activity_data_obj := jsonb_build_object('meal_id', NEW.id, 'meal_type', NEW.meal_type, 'date', NEW.date);
        WHEN 'DELETE' THEN 
          activity_type := 'delete_meal';
          activity_description := 'Изтрито хранене за ' || OLD.meal_type::text || ' на ' || OLD.date::text;
          activity_data_obj := jsonb_build_object('meal_id', OLD.id, 'meal_type', OLD.meal_type, 'date', OLD.date);
      END CASE;

    WHEN 'weekly_meal_plans' THEN
      activity_category := 'weekly_menu';
      CASE TG_OP
        WHEN 'INSERT' THEN 
          activity_type := 'add_weekly_meal';
          activity_description := 'Добавено планирано хранене в седмичното меню';
          activity_data_obj := jsonb_build_object('plan_id', NEW.id, 'meal_type', NEW.meal_type, 'day_of_week', NEW.day_of_week);
        WHEN 'UPDATE' THEN 
          activity_type := 'edit_weekly_meal';
          activity_description := 'Редактирано планирано хранене в седмичното меню';
          activity_data_obj := jsonb_build_object('plan_id', NEW.id, 'meal_type', NEW.meal_type, 'day_of_week', NEW.day_of_week);
        WHEN 'DELETE' THEN 
          activity_type := 'delete_weekly_meal';
          activity_description := 'Изтрито планирано хранене от седмичното меню';
          activity_data_obj := jsonb_build_object('plan_id', OLD.id, 'meal_type', OLD.meal_type, 'day_of_week', OLD.day_of_week);
      END CASE;

    WHEN 'weekly_menu_templates' THEN
      activity_category := 'weekly_menu';
      CASE TG_OP
        WHEN 'INSERT' THEN 
          activity_type := 'create_template';
          activity_description := 'Създаден шаблон за седмично меню: ' || NEW.template_name;
          activity_data_obj := jsonb_build_object('template_id', NEW.id, 'template_name', NEW.template_name);
        WHEN 'UPDATE' THEN 
          activity_type := 'edit_template';
          activity_description := 'Редактиран шаблон за седмично меню: ' || NEW.template_name;
          activity_data_obj := jsonb_build_object('template_id', NEW.id, 'template_name', NEW.template_name);
        WHEN 'DELETE' THEN 
          activity_type := 'delete_template';
          activity_description := 'Изтрит шаблон за седмично меню: ' || OLD.template_name;
          activity_data_obj := jsonb_build_object('template_id', OLD.id, 'template_name', OLD.template_name);
      END CASE;

    WHEN 'hydration_intakes' THEN
      activity_category := 'hydration';
      CASE TG_OP
        WHEN 'INSERT' THEN 
          activity_type := 'log_hydration';
          activity_description := 'Записан прием на течности: ' || NEW.volume_ml || 'мл ' || NEW.beverage_type::text;
          activity_data_obj := jsonb_build_object('intake_id', NEW.id, 'volume_ml', NEW.volume_ml, 'beverage_type', NEW.beverage_type);
        WHEN 'DELETE' THEN 
          activity_type := 'delete_hydration';
          activity_description := 'Изтрит запис за прием на течности';
          activity_data_obj := jsonb_build_object('intake_id', OLD.id, 'volume_ml', OLD.volume_ml, 'beverage_type', OLD.beverage_type);
      END CASE;

    WHEN 'fitness_sessions' THEN
      activity_category := 'fitness';
      CASE TG_OP
        WHEN 'INSERT' THEN 
          IF NEW.completed THEN
            activity_type := 'complete_workout';
            activity_description := 'Завършена тренировка за ' || NEW.session_date::text;
          ELSE
            activity_type := 'add_training_day';
            activity_description := 'Добавен ден за тренировка: ' || NEW.session_date::text;
          END IF;
          activity_data_obj := jsonb_build_object('session_id', NEW.id, 'session_date', NEW.session_date, 'completed', NEW.completed);
        WHEN 'UPDATE' THEN 
          IF OLD.completed = false AND NEW.completed = true THEN
            activity_type := 'complete_workout';
            activity_description := 'Завършена тренировка за ' || NEW.session_date::text;
          ELSIF OLD.calories_burned IS DISTINCT FROM NEW.calories_burned THEN
            activity_type := 'log_calories';
            activity_description := 'Записани изгорени калории: ' || COALESCE(NEW.calories_burned::text, '0');
          ELSE
            activity_type := 'update_workout';
            activity_description := 'Обновена тренировка за ' || NEW.session_date::text;
          END IF;
          activity_data_obj := jsonb_build_object('session_id', NEW.id, 'session_date', NEW.session_date, 'completed', NEW.completed);
        WHEN 'DELETE' THEN 
          activity_type := 'remove_training_day';
          activity_description := 'Премахнат ден за тренировка: ' || OLD.session_date::text;
          activity_data_obj := jsonb_build_object('session_id', OLD.id, 'session_date', OLD.session_date);
      END CASE;

    WHEN 'fasting_sessions' THEN
      activity_category := 'fasting';
      CASE TG_OP
        WHEN 'INSERT' THEN 
          activity_type := 'start_fast';
          activity_description := 'Започнато гладуване';
          activity_data_obj := jsonb_build_object('session_id', NEW.id, 'start_at', NEW.start_at, 'target_hours', NEW.target_hours);
        WHEN 'UPDATE' THEN 
          IF OLD.end_at IS NULL AND NEW.end_at IS NOT NULL THEN
            activity_type := 'end_fast';
            activity_description := 'Приключено гладуване';
          ELSE
            activity_type := 'update_fast';
            activity_description := 'Обновено гладуване';
          END IF;
          activity_data_obj := jsonb_build_object('session_id', NEW.id, 'start_at', NEW.start_at, 'end_at', NEW.end_at);
        WHEN 'DELETE' THEN 
          activity_type := 'delete_fast';
          activity_description := 'Изтрито гладуване';
          activity_data_obj := jsonb_build_object('session_id', OLD.id, 'start_at', OLD.start_at);
      END CASE;

    WHEN 'weight_history' THEN
      activity_category := 'weight';
      CASE TG_OP
        WHEN 'INSERT' THEN 
          activity_type := 'log_weight';
          activity_description := 'Записано тегло: ' || NEW.weight_kg || 'кг';
          activity_data_obj := jsonb_build_object('weight_id', NEW.id, 'weight_kg', NEW.weight_kg, 'recorded_at', NEW.recorded_at);
        WHEN 'UPDATE' THEN 
          activity_type := 'update_weight';
          activity_description := 'Обновено тегло: ' || NEW.weight_kg || 'кг';
          activity_data_obj := jsonb_build_object('weight_id', NEW.id, 'weight_kg', NEW.weight_kg, 'recorded_at', NEW.recorded_at);
        WHEN 'DELETE' THEN 
          activity_type := 'delete_weight';
          activity_description := 'Изтрито тегло: ' || OLD.weight_kg || 'кг';
          activity_data_obj := jsonb_build_object('weight_id', OLD.id, 'weight_kg', OLD.weight_kg);
      END CASE;

    WHEN 'profiles' THEN
      activity_category := 'settings';
      activity_type := 'update_profile';
      activity_description := 'Обновен профил';
      activity_data_obj := jsonb_build_object('profile_id', NEW.id);
      -- Check for specific profile changes
      IF OLD.hydration_enabled != NEW.hydration_enabled THEN
        activity_category := 'hydration';
        IF NEW.hydration_enabled THEN
          activity_type := 'enable_hydration';
          activity_description := 'Активирано проследяване на хидратацията';
        ELSE
          activity_type := 'disable_hydration'; 
          activity_description := 'Деактивирано проследяване на хидратацията';
        END IF;
      ELSIF OLD.fasting_enabled != NEW.fasting_enabled THEN
        activity_category := 'fasting';
        IF NEW.fasting_enabled THEN
          activity_type := 'enable_fasting';
          activity_description := 'Активирано проследяване на гладуване';
        ELSE
          activity_type := 'disable_fasting';
          activity_description := 'Деактивирано проследяване на гладуване';
        END IF;
      ELSIF OLD.fitness_enabled != NEW.fitness_enabled THEN
        activity_category := 'fitness';
        IF NEW.fitness_enabled THEN
          activity_type := 'enable_fitness';
          activity_description := 'Активирано проследяване на фитнес';
        ELSE
          activity_type := 'disable_fitness';
          activity_description := 'Деактивирано проследяване на фитнес';
        END IF;
      ELSIF OLD.zone_enabled != NEW.zone_enabled THEN
        activity_category := 'zone';
        IF NEW.zone_enabled THEN
          activity_type := 'enable_zone';
          activity_description := 'Активирано зоново хранене';
        ELSE
          activity_type := 'disable_zone';
          activity_description := 'Деактивирано зоново хранене';
        END IF;
      ELSIF OLD.daily_calorie_target IS DISTINCT FROM NEW.daily_calorie_target THEN
        activity_type := 'update_targets';
        activity_description := 'Обновена дневна цел за калории: ' || COALESCE(NEW.daily_calorie_target::text, 'премахната');
      ELSIF OLD.daily_water_goal_ml != NEW.daily_water_goal_ml THEN
        activity_category := 'hydration';
        activity_type := 'update_hydration_goal';
        activity_description := 'Обновена цел за вода: ' || NEW.daily_water_goal_ml || 'мл';
      ELSIF OLD.fasting_goal_hours != NEW.fasting_goal_hours THEN
        activity_category := 'fasting';
        activity_type := 'update_fast_goal';
        activity_description := 'Обновена цел за гладуване: ' || NEW.fasting_goal_hours || 'ч';
      END IF;

    ELSE
      -- Skip unknown tables
      RETURN COALESCE(NEW, OLD);
  END CASE;

  -- Insert the activity record
  INSERT INTO public.user_activities (
    user_id,
    activity_category,
    activity_type,
    activity_description,
    activity_data,
    user_agent
  ) VALUES (
    auth.uid(),
    activity_category,
    activity_type,
    activity_description,
    activity_data_obj,
    current_setting('request.headers', true)::json->>'user-agent'
  );

  RETURN COALESCE(NEW, OLD);
EXCEPTION
  WHEN OTHERS THEN
    -- Log error but don't fail the original operation
    RAISE WARNING 'Failed to log user activity: %', SQLERRM;
    RETURN COALESCE(NEW, OLD);
END;
$$;

-- Create triggers for all relevant tables

-- Products
DROP TRIGGER IF EXISTS products_activity_trigger ON public.products;
CREATE TRIGGER products_activity_trigger
  AFTER INSERT OR UPDATE OR DELETE ON public.products
  FOR EACH ROW
  EXECUTE FUNCTION public.log_user_activity();

-- Recipes  
DROP TRIGGER IF EXISTS recipes_activity_trigger ON public.recipes;
CREATE TRIGGER recipes_activity_trigger
  AFTER INSERT OR UPDATE OR DELETE ON public.recipes
  FOR EACH ROW
  EXECUTE FUNCTION public.log_user_activity();

-- Dishes
DROP TRIGGER IF EXISTS dishes_activity_trigger ON public.dishes;
CREATE TRIGGER dishes_activity_trigger
  AFTER INSERT OR UPDATE OR DELETE ON public.dishes
  FOR EACH ROW
  EXECUTE FUNCTION public.log_user_activity();

-- Meals
DROP TRIGGER IF EXISTS meals_activity_trigger ON public.meals;
CREATE TRIGGER meals_activity_trigger
  AFTER INSERT OR UPDATE OR DELETE ON public.meals
  FOR EACH ROW
  EXECUTE FUNCTION public.log_user_activity();

-- Weekly meal plans
DROP TRIGGER IF EXISTS weekly_meal_plans_activity_trigger ON public.weekly_meal_plans;
CREATE TRIGGER weekly_meal_plans_activity_trigger
  AFTER INSERT OR UPDATE OR DELETE ON public.weekly_meal_plans
  FOR EACH ROW
  EXECUTE FUNCTION public.log_user_activity();

-- Weekly menu templates
DROP TRIGGER IF EXISTS weekly_menu_templates_activity_trigger ON public.weekly_menu_templates;
CREATE TRIGGER weekly_menu_templates_activity_trigger
  AFTER INSERT OR UPDATE OR DELETE ON public.weekly_menu_templates
  FOR EACH ROW
  EXECUTE FUNCTION public.log_user_activity();

-- Hydration intakes
DROP TRIGGER IF EXISTS hydration_intakes_activity_trigger ON public.hydration_intakes;
CREATE TRIGGER hydration_intakes_activity_trigger
  AFTER INSERT OR DELETE ON public.hydration_intakes
  FOR EACH ROW
  EXECUTE FUNCTION public.log_user_activity();

-- Fitness sessions
DROP TRIGGER IF EXISTS fitness_sessions_activity_trigger ON public.fitness_sessions;
CREATE TRIGGER fitness_sessions_activity_trigger
  AFTER INSERT OR UPDATE OR DELETE ON public.fitness_sessions
  FOR EACH ROW
  EXECUTE FUNCTION public.log_user_activity();

-- Fasting sessions
DROP TRIGGER IF EXISTS fasting_sessions_activity_trigger ON public.fasting_sessions;
CREATE TRIGGER fasting_sessions_activity_trigger
  AFTER INSERT OR UPDATE OR DELETE ON public.fasting_sessions
  FOR EACH ROW
  EXECUTE FUNCTION public.log_user_activity();

-- Weight history
DROP TRIGGER IF EXISTS weight_history_activity_trigger ON public.weight_history;
CREATE TRIGGER weight_history_activity_trigger
  AFTER INSERT OR UPDATE OR DELETE ON public.weight_history
  FOR EACH ROW
  EXECUTE FUNCTION public.log_user_activity();

-- Profiles (for settings changes)
DROP TRIGGER IF EXISTS profiles_activity_trigger ON public.profiles;
CREATE TRIGGER profiles_activity_trigger
  AFTER UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.log_user_activity();