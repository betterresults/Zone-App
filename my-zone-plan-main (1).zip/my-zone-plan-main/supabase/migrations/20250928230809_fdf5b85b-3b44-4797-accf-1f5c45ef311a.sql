-- Enable pg_cron extension if not already enabled
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Enable pg_net extension for HTTP requests if not already enabled
CREATE EXTENSION IF NOT EXISTS pg_net;

-- Create a cron job to process scheduled notifications every minute
SELECT cron.schedule(
  'process-scheduled-notifications',
  '* * * * *', -- every minute
  $$
  SELECT
    net.http_post(
        url:='https://cmznrqtrtwohclokilkv.supabase.co/functions/v1/process-scheduled-notifications',
        headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNtem5ycXRydHdvaGNsb2tpbGt2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTcxNzY1MTMsImV4cCI6MjA3Mjc1MjUxM30.0KRvJiaVibJbhKLzWEtV3pdAXqPkv6bXoawuHFKLvwA"}'::jsonb,
        body:=concat('{"time": "', now(), '"}')::jsonb
    ) as request_id;
  $$
);