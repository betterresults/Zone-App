-- Drop old push notification tables
DROP TABLE IF EXISTS push_subscriptions CASCADE;
DROP TABLE IF EXISTS device_push_tokens CASCADE;
DROP TABLE IF EXISTS scheduled_notifications CASCADE;