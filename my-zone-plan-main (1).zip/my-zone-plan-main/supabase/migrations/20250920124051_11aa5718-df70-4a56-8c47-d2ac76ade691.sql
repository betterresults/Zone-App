-- SECURE RPC to count beta testers regardless of RLS
CREATE OR REPLACE FUNCTION public.get_beta_testers_count()
RETURNS integer
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT count(*)::int
  FROM public.subscribers
  WHERE subscription_source = 'beta' AND subscribed = true;
$$;

-- Ensure owner is postgres (Supabase default) and grant execution
REVOKE ALL ON FUNCTION public.get_beta_testers_count() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_beta_testers_count() TO anon, authenticated;
