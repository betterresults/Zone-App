-- Enable cron extension if not already enabled
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Schedule the process-daily-habits function to run every day at 23:59
SELECT cron.schedule(
  'process-daily-habits',
  '59 23 * * *', -- every day at 23:59
  $$
  SELECT
    net.http_post(
        url:='https://cmznrqtrtwohclokilkv.supabase.co/functions/v1/process-daily-habits',
        headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNtem5ycXRydHdvaGNsb2tpbGt2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTcxNzY1MTMsImV4cCI6MjA3Mjc1MjUxM30.0KRvJiaVibJbhKLzWEtV3pdAXqPkv6bXoawuHFKLvwA"}'::jsonb,
        body:=concat('{"scheduled_at": "', now(), '"}')::jsonb
    ) as request_id;
  $$
);