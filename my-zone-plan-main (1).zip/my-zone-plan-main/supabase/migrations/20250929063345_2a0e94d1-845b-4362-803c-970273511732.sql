-- Add is_important field to habits table for tasks
ALTER TABLE habits 
ADD COLUMN is_important BOOLEAN DEFAULT false;