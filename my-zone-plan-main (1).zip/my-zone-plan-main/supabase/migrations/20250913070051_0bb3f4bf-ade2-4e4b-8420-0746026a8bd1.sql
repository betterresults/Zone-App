-- Enable real-time for user_activities table
ALTER TABLE public.user_activities REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.user_activities;

-- Create admin notifications table for real-time notifications
CREATE TABLE IF NOT EXISTS public.admin_notifications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  activity_id UUID NOT NULL REFERENCES public.user_activities(id) ON DELETE CASCADE,
  notification_type TEXT NOT NULL DEFAULT 'activity',
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  is_read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on admin_notifications
ALTER TABLE public.admin_notifications ENABLE ROW LEVEL SECURITY;

-- Create policy for admins to manage notifications
CREATE POLICY "Admins can manage all notifications" 
ON public.admin_notifications 
FOR ALL 
USING (is_admin(auth.uid()));

-- Enable real-time for admin_notifications
ALTER TABLE public.admin_notifications REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.admin_notifications;

-- Create function to auto-generate admin notifications for user activities
CREATE OR REPLACE FUNCTION public.create_admin_notification_for_activity()
RETURNS TRIGGER AS $$
BEGIN
  -- Create notification for admins when any user activity is logged
  INSERT INTO public.admin_notifications (
    activity_id,
    notification_type,
    title,
    message
  ) VALUES (
    NEW.id,
    'activity',
    CASE 
      WHEN NEW.activity_category = 'cooking' THEN 'Готвене активност'
      WHEN NEW.activity_category = 'products' THEN 'Продукти активност'
      WHEN NEW.activity_category = 'recipes' THEN 'Рецепти активност'
      WHEN NEW.activity_category = 'dishes' THEN 'Ястия активност'
      WHEN NEW.activity_category = 'calendar' THEN 'Календар активност'
      WHEN NEW.activity_category = 'referral' THEN 'Реферал активност'
      WHEN NEW.activity_category = 'settings' THEN 'Настройки активност'
      WHEN NEW.activity_category = 'subscription' THEN 'Абонамент активност'
      WHEN NEW.activity_category = 'fitness' THEN 'Фитнес активност'
      WHEN NEW.activity_category = 'zone' THEN 'Зона активност'
      WHEN NEW.activity_category = 'weight' THEN 'Тегло активност'
      WHEN NEW.activity_category = 'hydration' THEN 'Хидратация активност'
      WHEN NEW.activity_category = 'fasting' THEN 'Фастинг активност'
      WHEN NEW.activity_category = 'weekly_menu' THEN 'Седмично меню активност'
      ELSE 'Потребителска активност'
    END,
    NEW.activity_description
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create trigger to auto-generate admin notifications
CREATE TRIGGER create_admin_notification_trigger
  AFTER INSERT ON public.user_activities
  FOR EACH ROW
  EXECUTE FUNCTION public.create_admin_notification_for_activity();

-- Add updated_at trigger for admin_notifications
CREATE TRIGGER update_admin_notifications_updated_at
  BEFORE UPDATE ON public.admin_notifications
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();