-- Create exercises table
CREATE TABLE public.exercises (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  category TEXT NOT NULL DEFAULT 'strength',
  muscle_groups TEXT[] DEFAULT '{}',
  equipment TEXT,
  difficulty_level TEXT DEFAULT 'beginner',
  instructions TEXT,
  tips TEXT,
  image_url TEXT,
  video_url TEXT,
  is_public BOOLEAN DEFAULT true,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create workout_exercises table to track exercise logs
CREATE TABLE public.workout_exercises (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id),
  fitness_session_id UUID REFERENCES public.fitness_sessions(id),
  exercise_id UUID NOT NULL REFERENCES public.exercises(id),
  sets INTEGER DEFAULT 1,
  reps INTEGER,
  weight_kg NUMERIC,
  duration_seconds INTEGER,
  distance_meters NUMERIC,
  rest_seconds INTEGER DEFAULT 60,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.exercises ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.workout_exercises ENABLE ROW LEVEL SECURITY;

-- Policies for exercises
CREATE POLICY "Everyone can view public exercises" 
ON public.exercises 
FOR SELECT 
USING (is_public = true OR created_by = auth.uid());

CREATE POLICY "Users can create their own exercises" 
ON public.exercises 
FOR INSERT 
WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Users can update their own exercises" 
ON public.exercises 
FOR UPDATE 
USING (auth.uid() = created_by);

CREATE POLICY "Users can delete their own exercises" 
ON public.exercises 
FOR DELETE 
USING (auth.uid() = created_by);

-- Policies for workout_exercises  
CREATE POLICY "Users can view their own workout exercises" 
ON public.workout_exercises 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own workout exercises" 
ON public.workout_exercises 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own workout exercises" 
ON public.workout_exercises 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own workout exercises" 
ON public.workout_exercises 
FOR DELETE 
USING (auth.uid() = user_id);

-- Add triggers for updated_at
CREATE TRIGGER update_exercises_updated_at
  BEFORE UPDATE ON public.exercises
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_workout_exercises_updated_at
  BEFORE UPDATE ON public.workout_exercises
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Insert some basic exercises
INSERT INTO public.exercises (name, description, category, muscle_groups, equipment, difficulty_level, instructions, tips) VALUES
('Клякания', 'Базово упражнение за долната част на тялото', 'strength', '{"legs", "glutes"}', 'bodyweight', 'beginner', 'Застанете с краката на ширина рамене. Спуснете се надолу сякаш сядате на стол. Върнете се в изходна позиция.', 'Внимавайте коленете да не излизат напред пред пръстите на краката'),
('Лицови опори', 'Упражнение за горната част на тялото', 'strength', '{"chest", "shoulders", "triceps"}', 'bodyweight', 'beginner', 'Легнете по корем, поставете дланите под рамената. Вдигнете тялото нагоре, запазвайки права линия.', 'Запазвайте тялото в права линия от главата до петите'),
('Планка', 'Упражнение за коремните мускули', 'core', '{"core", "shoulders"}', 'bodyweight', 'beginner', 'Застанете в позиция като при лицови опори, но се подпрете на лактите. Задръжте позицията.', 'Не вдигайте задника нагоре, запазвайте тялото право'),
('Бягане', 'Кардио упражнение', 'cardio', '{"legs", "cardio"}', 'none', 'beginner', 'Бягайте в умерено темпо за желаното време или разстояние.', 'Започнете с по-къси разстояния и постепенно увеличавайте'),
('Коремни преси', 'Упражнение за корема', 'core', '{"core"}', 'bodyweight', 'beginner', 'Легнете по гръб, сгънете коленете. Вдигнете горната част на тялото към коленете.', 'Не дърпайте врата, използвайте коремните мускули'),
('Скокове с разтваряне', 'Кардио упражнение за цялото тяло', 'cardio', '{"legs", "shoulders", "cardio"}', 'bodyweight', 'beginner', 'Застанете изправени. Скочете и разтворете крака и ръце. Върнете се в изходна позиция.', 'Кацайте меко на пръстите на краката'),
('Мостче', 'Упражнение за гълтите', 'strength', '{"glutes", "hamstrings"}', 'bodyweight', 'beginner', 'Легнете по гръб с гърчени колене. Вдигнете таза нагоре, натискайки с петите.', 'Стегнете гълтите в горната позиция'),
('Бърпита', 'Комплексно упражнение за цялото тяло', 'cardio', '{"full_body", "cardio"}', 'bodyweight', 'intermediate', 'Клякане, скок назад в планка, лицов опор, скок напред, скок нагоре.', 'Движете се плавно между позициите');