-- Fix security issue: Set search_path for the function
DROP FUNCTION IF EXISTS public.calculate_habit_session_duration();

CREATE OR REPLACE FUNCTION public.calculate_habit_session_duration()
RETURNS TRIGGER 
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  -- If ended_at is being set and it wasn't set before, calculate duration
  IF NEW.ended_at IS NOT NULL AND OLD.ended_at IS NULL THEN
    NEW.actual_duration_minutes := EXTRACT(EPOCH FROM (NEW.ended_at - NEW.started_at)) / 60;
    NEW.is_completed := true;
  END IF;
  
  RETURN NEW;
END;
$$;