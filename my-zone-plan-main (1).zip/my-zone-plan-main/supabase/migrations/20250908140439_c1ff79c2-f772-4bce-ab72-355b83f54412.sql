-- Create storage policies for recipe images

-- Policy for uploading recipe images
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Users can upload recipe images'
  ) THEN
    CREATE POLICY "Users can upload recipe images"
    ON storage.objects
    FOR INSERT 
    WITH CHECK (
      bucket_id = 'recipe-images' AND 
      auth.uid() IS NOT NULL
    );
  END IF;
END $$;

-- Policy for viewing recipe images
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Recipe images are publicly accessible'
  ) THEN
    CREATE POLICY "Recipe images are publicly accessible"
    ON storage.objects
    FOR SELECT
    USING (bucket_id = 'recipe-images');
  END IF;
END $$;