-- Rollover missed important tasks from yesterday to today
WITH yesterday AS (
  SELECT (CURRENT_DATE - INTERVAL '1 day')::date as date
),
missed_important_tasks AS (
  SELECT DISTINCT h.*
  FROM habits h
  CROSS JOIN yesterday y
  WHERE h.habit_type = 'task'
    AND h.is_important = true
    AND h.is_active = true
    AND h.one_time_date = y.date
    AND NOT EXISTS (
      SELECT 1 FROM habit_completions hc
      WHERE hc.habit_id = h.id
      AND hc.completion_date = y.date
    )
),
today_important_count AS (
  SELECT user_id, COUNT(*) as count
  FROM habits
  WHERE habit_type = 'task'
    AND is_important = true
    AND is_active = true
    AND one_time_date = CURRENT_DATE
  GROUP BY user_id
)
INSERT INTO habits (
  user_id,
  name,
  description,
  habit_type,
  is_important,
  one_time_date,
  color,
  category,
  repeat_days,
  is_active
)
SELECT
  m.user_id,
  '📋 ' || m.name as name,
  'Автоматично преместено от ' || TO_CHAR(m.one_time_date, 'DD.MM.YYYY') as description,
  'task'::habit_type,
  true,
  CURRENT_DATE,
  '#ef4444', -- Red color
  COALESCE(m.category, 'important'),
  '[]'::jsonb,
  true
FROM missed_important_tasks m
LEFT JOIN today_important_count t ON t.user_id = m.user_id
WHERE COALESCE(t.count, 0) < 3
RETURNING id, name, user_id;