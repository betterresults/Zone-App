-- Add subscription_source to subscribers table
ALTER TABLE public.subscribers ADD COLUMN subscription_source TEXT DEFAULT 'stripe';

-- Create feedback_type enum
CREATE TYPE public.feedback_type AS ENUM ('like', 'dislike', 'bug', 'improvement', 'other');

-- Create feedback_status enum  
CREATE TYPE public.feedback_status AS ENUM ('new', 'in_progress', 'resolved', 'closed');

-- Create feedback_priority enum
CREATE TYPE public.feedback_priority AS ENUM ('low', 'medium', 'high', 'critical');

-- Create beta_feedback table
CREATE TABLE public.beta_feedback (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  feedback_type feedback_type NOT NULL,
  category TEXT,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  status feedback_status DEFAULT 'new',
  priority feedback_priority DEFAULT 'medium',
  admin_notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS on beta_feedback
ALTER TABLE public.beta_feedback ENABLE ROW LEVEL SECURITY;

-- RLS policies for beta_feedback
CREATE POLICY "Users can create their own feedback"
ON public.beta_feedback 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own feedback"
ON public.beta_feedback 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all feedback"
ON public.beta_feedback 
FOR ALL 
USING (is_admin(auth.uid()));

-- Create trigger for updated_at
CREATE TRIGGER update_beta_feedback_updated_at
  BEFORE UPDATE ON public.beta_feedback
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();