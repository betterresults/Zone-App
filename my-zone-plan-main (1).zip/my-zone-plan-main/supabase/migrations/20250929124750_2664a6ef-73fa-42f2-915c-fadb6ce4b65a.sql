-- Add rest_between_exercises setting to fitness_settings table
ALTER TABLE public.fitness_settings 
ADD COLUMN rest_between_exercises_seconds INTEGER DEFAULT 120;