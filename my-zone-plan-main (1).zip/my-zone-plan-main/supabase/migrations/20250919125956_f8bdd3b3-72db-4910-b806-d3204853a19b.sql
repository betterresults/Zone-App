-- First, let's create subscription records for existing beta users who don't have them
-- We'll identify beta users as those who don't have a subscription record yet

INSERT INTO public.subscribers (user_id, email, subscribed, subscription_tier, subscription_end, subscription_source)
SELECT 
  p.user_id, 
  p.email,
  true,
  'pro',
  NOW() + INTERVAL '6 months',
  'beta'
FROM public.profiles p
LEFT JOIN public.subscribers s ON p.user_id = s.user_id
WHERE s.user_id IS NULL  -- Users without subscription records
  AND p.created_at >= '2025-09-01'::date  -- Recent signups (adjust date as needed)
  AND p.user_id IS NOT NULL;

-- Also, let's clean up any orphaned subscriber records (with null user_id)
DELETE FROM public.subscribers WHERE user_id IS NULL;