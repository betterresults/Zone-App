-- Add 'cooked' category to product_category enum
ALTER TYPE public.product_category ADD VALUE 'cooked';