-- Check and fix RLS policies for admin subscription management

-- First, let's see current policies (for reference)
-- The issue is that admins can't update user subscriptions due to RLS

-- Add admin policy for subscription management  
CREATE POLICY IF NOT EXISTS "Admins can update all subscriptions" 
ON public.subscribers
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles ur 
    WHERE ur.user_id = auth.uid() 
    AND ur.role = 'admin'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.user_roles ur 
    WHERE ur.user_id = auth.uid() 
    AND ur.role = 'admin'
  )
);

-- Also allow admins to INSERT new subscription records
CREATE POLICY IF NOT EXISTS "Admins can insert subscriptions"
ON public.subscribers
FOR INSERT  
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.user_roles ur 
    WHERE ur.user_id = auth.uid() 
    AND ur.role = 'admin'
  )
);