-- Add hydration_enabled and fasting_enabled columns to profiles table
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS hydration_enabled BOOLEAN NOT NULL DEFAULT true;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS fasting_enabled BOOLEAN NOT NULL DEFAULT true;