-- Добавяме системни порции за авокадо
INSERT INTO public.favorite_portions (user_id, product_id, portion_name, grams)
SELECT NULL, p.id, 'Малка порция (50г)', 50
FROM public.products p
WHERE p.name = 'Авокадо' AND p.is_public = true;

INSERT INTO public.favorite_portions (user_id, product_id, portion_name, grams)
SELECT NULL, p.id, 'Половин авокадо (75г)', 75
FROM public.products p
WHERE p.name = 'Авокадо' AND p.is_public = true;

INSERT INTO public.favorite_portions (user_id, product_id, portion_name, grams)
SELECT NULL, p.id, 'Цяло авокадо (150г)', 150
FROM public.products p
WHERE p.name = 'Авокадо' AND p.is_public = true;

-- Добавяме системни порции за други често използвани продукти
INSERT INTO public.favorite_portions (user_id, product_id, portion_name, grams)
SELECT NULL, p.id, 'Средна ябълка (180г)', 180
FROM public.products p
WHERE p.name = 'Ябълка' AND p.is_public = true;

INSERT INTO public.favorite_portions (user_id, product_id, portion_name, grams)
SELECT NULL, p.id, 'Среден банан (120г)', 120
FROM public.products p
WHERE p.name = 'Банан' AND p.is_public = true;

INSERT INTO public.favorite_portions (user_id, product_id, portion_name, grams)
SELECT NULL, p.id, 'Пилешка гърда (150г)', 150
FROM public.products p
WHERE p.name = 'Пилешко филе' AND p.is_public = true;

INSERT INTO public.favorite_portions (user_id, product_id, portion_name, grams)
SELECT NULL, p.id, 'Едно яйце (50г)', 50
FROM public.products p
WHERE p.name = 'Яйца' AND p.is_public = true;