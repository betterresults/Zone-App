-- Add milk to beverage types
ALTER TYPE hydration_beverage_type ADD VALUE 'milk';

-- Add product_id column to hydration_intakes for caloric beverages
ALTER TABLE public.hydration_intakes 
ADD COLUMN product_id uuid REFERENCES public.products(id);

-- Add index for better performance
CREATE INDEX idx_hydration_intakes_product_id ON public.hydration_intakes(product_id);