-- Add one_time_date field to habits table for single-time habits
ALTER TABLE habits ADD COLUMN one_time_date date;