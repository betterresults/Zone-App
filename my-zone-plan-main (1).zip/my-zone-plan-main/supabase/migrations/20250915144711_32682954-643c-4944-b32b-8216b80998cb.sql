-- Add is_consumed field to meals table to distinguish planned vs consumed meals
ALTER TABLE public.meals 
ADD COLUMN is_consumed boolean NOT NULL DEFAULT true;

-- Add week planning fields to meals table to support weekly menu functionality
ALTER TABLE public.meals 
ADD COLUMN week_start_date date;

-- Create index for better performance when querying weekly meals
CREATE INDEX idx_meals_week_planning ON public.meals(user_id, week_start_date, meal_type) WHERE week_start_date IS NOT NULL;