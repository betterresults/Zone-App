-- Create table for habit day overrides
CREATE TABLE public.habit_day_overrides (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  habit_id UUID NOT NULL,
  override_date DATE NOT NULL,
  override_type TEXT NOT NULL CHECK (override_type IN ('skip', 'change_time')),
  new_time TIME WITHOUT TIME ZONE NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  
  -- Ensure one override per habit per day
  UNIQUE(habit_id, override_date)
);

-- Enable Row Level Security
ALTER TABLE public.habit_day_overrides ENABLE ROW LEVEL SECURITY;

-- Create policies for user access
CREATE POLICY "Users can view their own habit overrides" 
ON public.habit_day_overrides 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own habit overrides" 
ON public.habit_day_overrides 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own habit overrides" 
ON public.habit_day_overrides 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own habit overrides" 
ON public.habit_day_overrides 
FOR DELETE 
USING (auth.uid() = user_id);

-- Add updated_at trigger
CREATE TRIGGER update_habit_day_overrides_updated_at
  BEFORE UPDATE ON public.habit_day_overrides
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();