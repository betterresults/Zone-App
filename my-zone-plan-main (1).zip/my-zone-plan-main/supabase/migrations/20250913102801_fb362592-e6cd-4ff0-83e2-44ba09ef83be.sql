-- Add measurement unit to products table
ALTER TABLE public.products 
ADD COLUMN package_unit_type text DEFAULT 'пакет';

-- Update existing products to use appropriate units based on category
UPDATE public.products 
SET package_unit_type = CASE 
  WHEN category IN ('fruits', 'vegetables') THEN 'брой'
  WHEN category IN ('dairy', 'beverages') THEN 'литър'
  WHEN category = 'meat' THEN 'пакет'
  WHEN category = 'grains' THEN 'пакет'
  ELSE 'пакет'
END;

-- Make the column not null after setting defaults
ALTER TABLE public.products 
ALTER COLUMN package_unit_type SET NOT NULL;