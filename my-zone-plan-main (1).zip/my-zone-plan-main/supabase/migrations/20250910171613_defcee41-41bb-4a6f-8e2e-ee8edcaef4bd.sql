-- Clean up completely and try a simpler approach
DELETE FROM public.user_roles WHERE user_id IN (
  SELECT id FROM auth.users WHERE email = 'admin@myzone.life'
);

DELETE FROM public.profiles WHERE email = 'admin@myzone.life';

DELETE FROM auth.users WHERE email = 'admin@myzone.life';

-- Drop the temporary table we don't need
DROP TABLE IF EXISTS public.admin_setup;

-- Now create the admin user step by step with proper error handling
DO $$
DECLARE
  new_user_id uuid;
  existing_user_id uuid;
BEGIN
  -- Check if user already exists
  SELECT id INTO existing_user_id FROM auth.users WHERE email = 'admin@myzone.life';
  
  IF existing_user_id IS NOT NULL THEN
    RAISE NOTICE 'User already exists, using existing user: %', existing_user_id;
    new_user_id := existing_user_id;
  ELSE
    -- Create new user
    new_user_id := gen_random_uuid();
    
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      created_at,
      updated_at,
      raw_app_meta_data,
      raw_user_meta_data
    ) VALUES (
      '00000000-0000-0000-0000-000000000000',
      new_user_id,
      'authenticated',
      'authenticated',
      'admin@myzone.life',
      crypt('123456', gen_salt('bf')),
      now(),
      now(),
      now(),
      '{"provider":"email","providers":["email"]}',
      '{"display_name":"System Admin"}'
    );
    
    RAISE NOTICE 'Created new user: %', new_user_id;
  END IF;
  
  -- Create or update profile
  INSERT INTO public.profiles (user_id, email, display_name)
  VALUES (new_user_id, 'admin@myzone.life', 'System Admin')
  ON CONFLICT (user_id) DO UPDATE SET
    email = EXCLUDED.email,
    display_name = EXCLUDED.display_name;
  
  -- Create or update admin role
  INSERT INTO public.user_roles (user_id, role, created_by)
  VALUES (new_user_id, 'admin', new_user_id)
  ON CONFLICT (user_id, role) DO NOTHING;
  
  RAISE NOTICE 'Admin setup completed for user: %', new_user_id;
  
END $$;