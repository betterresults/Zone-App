-- Add reminder fields to calendar_events table
ALTER TABLE public.calendar_events 
ADD COLUMN reminder_enabled boolean DEFAULT false,
ADD COLUMN reminder_minutes_before integer DEFAULT 15;

-- Create scheduled_notifications table
CREATE TABLE public.scheduled_notifications (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  notification_type text NOT NULL, -- 'event' or 'habit'
  reference_id uuid NOT NULL, -- calendar_event_id or habit_id
  scheduled_for timestamp with time zone NOT NULL,
  title text NOT NULL,
  message text NOT NULL,
  is_sent boolean DEFAULT false,
  sent_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create notification_templates table
CREATE TABLE public.notification_templates (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  template_type text NOT NULL, -- 'event' or 'habit'
  template_name text NOT NULL,
  title_template text NOT NULL,
  message_template text NOT NULL,
  time_of_day text, -- 'morning', 'afternoon', 'evening', 'any'
  is_active boolean DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.scheduled_notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notification_templates ENABLE ROW LEVEL SECURITY;

-- RLS policies for scheduled_notifications
CREATE POLICY "Users can view their own scheduled notifications" 
ON public.scheduled_notifications 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own scheduled notifications" 
ON public.scheduled_notifications 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own scheduled notifications" 
ON public.scheduled_notifications 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own scheduled notifications" 
ON public.scheduled_notifications 
FOR DELETE 
USING (auth.uid() = user_id);

-- RLS policies for notification_templates (read-only for users, manage by admins)
CREATE POLICY "Everyone can view active notification templates" 
ON public.notification_templates 
FOR SELECT 
USING (is_active = true);

CREATE POLICY "Admins can manage notification templates" 
ON public.notification_templates 
FOR ALL 
USING (is_admin(auth.uid()));

-- Insert default notification templates
INSERT INTO public.notification_templates (template_type, template_name, title_template, message_template, time_of_day) VALUES
-- Event templates
('event', 'default_event', 'Напомняне за събитие', 'Здравей, {name}! След {minutes} минути имате {event_title}.', 'any'),
('event', 'morning_event', 'Добро утро!', 'Добро утро, {name}! След {minutes} минути имате {event_title}.', 'morning'),
('event', 'afternoon_event', 'Напомняне', 'Здравей, {name}! След {minutes} минути имате {event_title}.', 'afternoon'),
('event', 'evening_event', 'Добър вечер!', 'Добър вечер, {name}! След {minutes} минути имате {event_title}.', 'evening'),

-- Habit templates
('habit', 'default_habit', 'Напомняне за навик', 'Здравей, {name}! Не забравяйте да {habit_name} днес.', 'any'),
('habit', 'morning_habit', 'Добро утро!', 'Добро утро, {name}! Време е да {habit_name}.', 'morning'),
('habit', 'afternoon_habit', 'Обедна пауза', 'Здравей, {name}! Само напомняне да {habit_name}.', 'afternoon'),
('habit', 'evening_habit', 'Добър вечер!', 'Добър вечер, {name}! Не забравяйте да {habit_name} преди лягане.', 'evening'),
('habit', 'streak_motivation', 'Запазете темпото!', 'Отлично, {name}! Вече {streak_count} дни подред {habit_name}. Продължавайте така!', 'any');

-- Create indexes for performance
CREATE INDEX idx_scheduled_notifications_user_scheduled FOR idx_scheduled_notifications_user_scheduled ON public.scheduled_notifications(user_id, scheduled_for) WHERE is_sent = false;
CREATE INDEX idx_scheduled_notifications_pending ON public.scheduled_notifications(scheduled_for) WHERE is_sent = false;

-- Create trigger for updated_at
CREATE TRIGGER update_scheduled_notifications_updated_at
BEFORE UPDATE ON public.scheduled_notifications
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_notification_templates_updated_at
BEFORE UPDATE ON public.notification_templates
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();