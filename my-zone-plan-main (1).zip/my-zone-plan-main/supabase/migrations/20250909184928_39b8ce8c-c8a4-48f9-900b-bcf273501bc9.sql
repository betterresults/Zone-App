-- Add source_recipe_id column to dishes table
ALTER TABLE public.dishes 
ADD COLUMN source_recipe_id UUID REFERENCES public.recipes(id) ON DELETE SET NULL;

-- Create index for better performance
CREATE INDEX idx_dishes_source_recipe_id ON public.dishes(source_recipe_id);

-- Function to sync dish details from recipe
CREATE OR REPLACE FUNCTION public.sync_dish_from_recipe(dish_id UUID, recipe_id UUID)
RETURNS VOID AS $$
DECLARE
  recipe_record RECORD;
BEGIN
  -- Get recipe details
  SELECT name, description, meal_type, servings
  INTO recipe_record
  FROM public.recipes
  WHERE id = recipe_id;
  
  IF recipe_record IS NOT NULL THEN
    -- Update dish details
    UPDATE public.dishes
    SET 
      name = recipe_record.name,
      description = recipe_record.description,
      meal_type = recipe_record.meal_type,
      updated_at = now()
    WHERE id = dish_id;
    
    -- Delete existing dish ingredients
    DELETE FROM public.dish_ingredients WHERE dish_id = dish_id;
    
    -- Copy recipe ingredients to dish ingredients (scaled by servings)
    INSERT INTO public.dish_ingredients (dish_id, product_id, grams)
    SELECT 
      dish_id,
      ri.product_id,
      ri.grams * recipe_record.servings
    FROM public.recipe_ingredients ri
    WHERE ri.recipe_id = recipe_id;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Function to update all linked dishes when recipe changes
CREATE OR REPLACE FUNCTION public.update_linked_dishes()
RETURNS TRIGGER AS $$
BEGIN
  -- Update all dishes linked to this recipe
  PERFORM public.sync_dish_from_recipe(d.id, NEW.id)
  FROM public.dishes d
  WHERE d.source_recipe_id = NEW.id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Trigger to automatically update linked dishes when recipe is updated
CREATE TRIGGER trigger_update_linked_dishes
  AFTER UPDATE ON public.recipes
  FOR EACH ROW
  WHEN (OLD.* IS DISTINCT FROM NEW.*)
  EXECUTE FUNCTION public.update_linked_dishes();

-- Function to update linked dishes when recipe ingredients change
CREATE OR REPLACE FUNCTION public.update_linked_dishes_on_ingredients()
RETURNS TRIGGER AS $$
BEGIN
  -- Update all dishes linked to this recipe
  PERFORM public.sync_dish_from_recipe(d.id, COALESCE(NEW.recipe_id, OLD.recipe_id))
  FROM public.dishes d
  WHERE d.source_recipe_id = COALESCE(NEW.recipe_id, OLD.recipe_id);
  
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Triggers for recipe ingredients changes
CREATE TRIGGER trigger_update_linked_dishes_on_ingredient_change
  AFTER INSERT OR UPDATE OR DELETE ON public.recipe_ingredients
  FOR EACH ROW
  EXECUTE FUNCTION public.update_linked_dishes_on_ingredients();