-- Add unique constraint on user_id for fitness_settings
ALTER TABLE public.fitness_settings 
ADD CONSTRAINT fitness_settings_user_id_unique UNIQUE (user_id);