-- Update existing empty referral codes with generated ones
UPDATE public.user_referral_codes 
SET referral_code = public.generate_referral_code(), 
    updated_at = now()
WHERE referral_code = '' OR referral_code IS NULL;