-- Create the admin user account and assign admin role
-- First, we need to insert into auth.users (this is a special case for admin setup)
INSERT INTO auth.users (
  instance_id,
  id,
  aud,
  role,
  email,
  encrypted_password,
  email_confirmed_at,
  created_at,
  updated_at,
  confirmation_token,
  email_change,
  email_change_token_new,
  recovery_token
) VALUES (
  '00000000-0000-0000-0000-000000000000',
  gen_random_uuid(),
  'authenticated',
  'authenticated',
  'admin@myzone.life',
  crypt('123456', gen_salt('bf')),
  now(),
  now(),
  now(),
  '',
  '',
  '',
  ''
);

-- Get the created user ID and create profile and admin role
DO $$
DECLARE
  admin_user_id uuid;
BEGIN
  -- Get the user ID we just created
  SELECT id INTO admin_user_id FROM auth.users WHERE email = 'admin@myzone.life';
  
  -- Create profile for the admin user
  INSERT INTO public.profiles (user_id, email, display_name)
  VALUES (admin_user_id, 'admin@myzone.life', 'System Admin');
  
  -- Assign admin role
  INSERT INTO public.user_roles (user_id, role, created_by)
  VALUES (admin_user_id, 'admin', admin_user_id);
END $$;