-- Fix scheduled_notifications table structure and policies

-- Change reference_id from UUID to TEXT to allow custom identifiers like 'fasting_123', 'habit_456', etc.
ALTER TABLE scheduled_notifications 
ALTER COLUMN reference_id TYPE TEXT;

-- Drop existing INSERT policy
DROP POLICY IF EXISTS "Users can create their own scheduled notifications" ON scheduled_notifications;

-- Create proper INSERT policy with WITH CHECK condition
CREATE POLICY "Users can create their own scheduled notifications" 
ON scheduled_notifications 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Ensure notification_templates table exists with proper RLS
CREATE TABLE IF NOT EXISTS notification_templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  template_type TEXT NOT NULL CHECK (template_type IN ('event', 'habit')),
  template_name TEXT NOT NULL,
  title_template TEXT NOT NULL,
  message_template TEXT NOT NULL,
  time_of_day TEXT NOT NULL CHECK (time_of_day IN ('morning', 'afternoon', 'evening', 'any')),
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on notification_templates
ALTER TABLE notification_templates ENABLE ROW LEVEL SECURITY;

-- Create policy for reading notification templates (everyone can read active templates)
CREATE POLICY "Anyone can view active notification templates" 
ON notification_templates 
FOR SELECT 
USING (is_active = true);

-- Insert default notification templates if they don't exist
INSERT INTO notification_templates (template_type, template_name, title_template, message_template, time_of_day) 
VALUES 
  ('event', 'Morning Event Reminder', '🌅 Напомняне за събитие', 'Добро утро, {name}! Имаш {event_title} след {minutes} минути.', 'morning'),
  ('event', 'Afternoon Event Reminder', '☀️ Напомняне за събитие', 'Здравей, {name}! Не забравяй за {event_title} след {minutes} минути.', 'afternoon'),
  ('event', 'Evening Event Reminder', '🌙 Напомняне за събитие', 'Добра вечер, {name}! Предстои ти {event_title} след {minutes} минути.', 'evening'),
  ('event', 'General Event Reminder', '📅 Напомняне за събитие', 'Здравей, {name}! Имаш {event_title} след {minutes} минути.', 'any'),
  ('habit', 'Morning Habit Reminder', '🌅 Време за навик', 'Добро утро, {name}! Време е за {habit_name}. Поддържаш серия от {streak_count} дни!', 'morning'),
  ('habit', 'Afternoon Habit Reminder', '☀️ Време за навик', 'Здравей, {name}! Не забравяй за {habit_name}. Серията ти е {streak_count} дни!', 'afternoon'),
  ('habit', 'Evening Habit Reminder', '🌙 Време за навик', 'Добра вечер, {name}! Време е за {habit_name}. Продължавай серията от {streak_count} дни!', 'evening'),
  ('habit', 'General Habit Reminder', '💪 Време за навик', 'Здравей, {name}! Време е за {habit_name}. Серията ти е {streak_count} дни!', 'any')
ON CONFLICT DO NOTHING;