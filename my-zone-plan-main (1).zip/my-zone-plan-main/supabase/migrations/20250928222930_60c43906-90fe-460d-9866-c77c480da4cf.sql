-- Add Zone compliance field to recipes table
ALTER TABLE public.recipes 
ADD COLUMN is_zone_compliant boolean DEFAULT false;

-- Create function to calculate if a recipe is Zone compliant
CREATE OR REPLACE FUNCTION public.calculate_recipe_zone_compliance(recipe_id_param uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  total_protein numeric := 0;
  total_carbs numeric := 0;
  total_fat numeric := 0;
  protein_blocks numeric;
  carbs_blocks numeric;
  fat_blocks numeric;
  min_blocks numeric;
  max_blocks numeric;
  tolerance numeric := 0.15; -- 15% tolerance for Zone compliance
BEGIN
  -- Calculate total macros from recipe ingredients
  SELECT 
    COALESCE(SUM(p.protein_per_100g * (ri.grams / 100.0)), 0),
    COALESCE(SUM(p.carbs_per_100g * (ri.grams / 100.0)), 0),
    COALESCE(SUM(p.fat_per_100g * (ri.grams / 100.0)), 0)
  INTO total_protein, total_carbs, total_fat
  FROM public.recipe_ingredients ri
  JOIN public.products p ON ri.product_id = p.id
  WHERE ri.recipe_id = recipe_id_param;
  
  -- If no ingredients or no macros, not Zone compliant
  IF total_protein = 0 OR total_carbs = 0 OR total_fat = 0 THEN
    RETURN false;
  END IF;
  
  -- Calculate blocks (Zone diet: 7g protein = 9g carbs = 1.5g fat = 1 block)
  protein_blocks := total_protein / 7.0;
  carbs_blocks := total_carbs / 9.0;
  fat_blocks := total_fat / 1.5;
  
  -- Find min and max blocks
  min_blocks := LEAST(protein_blocks, carbs_blocks, fat_blocks);
  max_blocks := GREATEST(protein_blocks, carbs_blocks, fat_blocks);
  
  -- Recipe is Zone compliant if all blocks are within tolerance of each other
  -- and the recipe has at least 0.5 blocks worth of macros
  RETURN (min_blocks >= 0.5 AND (max_blocks - min_blocks) / min_blocks <= tolerance);
END;
$$;

-- Create trigger to automatically update Zone compliance when recipe ingredients change
CREATE OR REPLACE FUNCTION public.update_recipe_zone_compliance()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  -- Update the recipe's Zone compliance
  UPDATE public.recipes
  SET is_zone_compliant = public.calculate_recipe_zone_compliance(COALESCE(NEW.recipe_id, OLD.recipe_id))
  WHERE id = COALESCE(NEW.recipe_id, OLD.recipe_id);
  
  RETURN COALESCE(NEW, OLD);
END;
$$;

-- Create trigger for recipe ingredients changes
CREATE TRIGGER trigger_update_recipe_zone_compliance
  AFTER INSERT OR UPDATE OR DELETE ON public.recipe_ingredients
  FOR EACH ROW
  EXECUTE FUNCTION public.update_recipe_zone_compliance();

-- Create trigger to update Zone compliance when recipe is updated
CREATE OR REPLACE FUNCTION public.update_recipe_zone_compliance_on_recipe_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  -- Update Zone compliance when recipe is modified
  NEW.is_zone_compliant = public.calculate_recipe_zone_compliance(NEW.id);
  RETURN NEW;
END;
$$;

-- Create trigger for recipe changes
CREATE TRIGGER trigger_update_recipe_zone_compliance_on_recipe_change
  BEFORE UPDATE ON public.recipes
  FOR EACH ROW
  EXECUTE FUNCTION public.update_recipe_zone_compliance_on_recipe_change();

-- Update existing recipes to calculate their Zone compliance
UPDATE public.recipes
SET is_zone_compliant = public.calculate_recipe_zone_compliance(id);