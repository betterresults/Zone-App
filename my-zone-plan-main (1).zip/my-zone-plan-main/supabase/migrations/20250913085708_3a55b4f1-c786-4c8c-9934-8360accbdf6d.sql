-- Update the log_user_activity function to track who made the change
CREATE OR REPLACE FUNCTION public.log_user_activity()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  activity_category text;
  activity_type text;
  activity_description text;
  activity_data_obj jsonb := '{}';
  record_name text;
  current_user_id uuid := auth.uid();
  target_user_id uuid;
  is_admin_action boolean := false;
BEGIN
  -- Only log activities for authenticated users
  IF current_user_id IS NULL THEN
    RETURN COALESCE(NEW, OLD);
  END IF;

  -- Determine target user and if this is an admin action
  CASE TG_TABLE_NAME
    WHEN 'profiles', 'subscribers' THEN
      target_user_id := COALESCE(NEW.user_id, OLD.user_id);
    ELSE
      target_user_id := COALESCE(NEW.user_id, OLD.user_id);
  END CASE;

  -- Check if this is an admin action (someone else performing action on behalf of another user)
  IF target_user_id IS NOT NULL AND current_user_id != target_user_id THEN
    -- Check if current user is admin
    IF EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = current_user_id AND role = 'admin') THEN
      is_admin_action := true;
    END IF;
  END IF;

  -- Determine category and type based on table name and operation
  CASE TG_TABLE_NAME
    WHEN 'products' THEN
      activity_category := 'products';
      CASE TG_OP
        WHEN 'INSERT' THEN 
          activity_type := 'add_product';
          record_name := NEW.name;
          activity_description := 'Добавен нов продукт: ' || record_name;
          activity_data_obj := jsonb_build_object('product_id', NEW.id, 'product_name', record_name);
        WHEN 'UPDATE' THEN 
          activity_type := 'edit_product';
          record_name := NEW.name;
          activity_description := 'Редактиран продукт: ' || record_name;
          activity_data_obj := jsonb_build_object('product_id', NEW.id, 'product_name', record_name);
        WHEN 'DELETE' THEN 
          activity_type := 'delete_product';
          record_name := OLD.name;
          activity_description := 'Изтрит продукт: ' || record_name;
          activity_data_obj := jsonb_build_object('product_id', OLD.id, 'product_name', record_name);
      END CASE;

    WHEN 'recipes' THEN
      activity_category := 'recipes';
      CASE TG_OP
        WHEN 'INSERT' THEN 
          activity_type := 'add_recipe';
          record_name := NEW.name;
          activity_description := 'Добавена нова рецепта: ' || record_name;
          activity_data_obj := jsonb_build_object('recipe_id', NEW.id, 'recipe_name', record_name);
        WHEN 'UPDATE' THEN 
          activity_type := 'edit_recipe';
          record_name := NEW.name;
          activity_description := 'Редактирана рецепта: ' || record_name;
          activity_data_obj := jsonb_build_object('recipe_id', NEW.id, 'recipe_name', record_name);
          -- Check if recipe was made public/private
          IF OLD.is_public != NEW.is_public THEN
            IF NEW.is_public THEN
              activity_type := 'make_public';
              activity_description := 'Рецепта направена публична: ' || record_name;
            ELSE
              activity_type := 'make_private';
              activity_description := 'Рецепта направена частна: ' || record_name;
            END IF;
          END IF;
        WHEN 'DELETE' THEN 
          activity_type := 'delete_recipe';
          record_name := OLD.name;
          activity_description := 'Изтрита рецепта: ' || record_name;
          activity_data_obj := jsonb_build_object('recipe_id', OLD.id, 'recipe_name', record_name);
      END CASE;

    WHEN 'dishes' THEN
      activity_category := 'dishes';
      CASE TG_OP
        WHEN 'INSERT' THEN 
          activity_type := 'add_dish';
          record_name := NEW.name;
          activity_description := 'Добавено ново ястие: ' || record_name;
          activity_data_obj := jsonb_build_object('dish_id', NEW.id, 'dish_name', record_name);
          -- Check if created from recipe
          IF NEW.source_recipe_id IS NOT NULL THEN
            activity_type := 'create_from_recipe';
            activity_description := 'Създадено ястие от рецепта: ' || record_name;
            activity_data_obj := activity_data_obj || jsonb_build_object('source_recipe_id', NEW.source_recipe_id);
          END IF;
        WHEN 'UPDATE' THEN 
          activity_type := 'edit_dish';
          record_name := NEW.name;
          activity_description := 'Редактирано ястие: ' || record_name;
          activity_data_obj := jsonb_build_object('dish_id', NEW.id, 'dish_name', record_name);
        WHEN 'DELETE' THEN 
          activity_type := 'delete_dish';
          record_name := OLD.name;
          activity_description := 'Изтрито ястие: ' || record_name;
          activity_data_obj := jsonb_build_object('dish_id', OLD.id, 'dish_name', record_name);
      END CASE;

    WHEN 'meals' THEN
      activity_category := 'calendar';
      CASE TG_OP
        WHEN 'INSERT' THEN 
          activity_type := 'add_meal';
          activity_description := 'Добавено хранене за ' || NEW.meal_type::text || ' на ' || NEW.date::text;
          activity_data_obj := jsonb_build_object('meal_id', NEW.id, 'meal_type', NEW.meal_type, 'date', NEW.date);
        WHEN 'UPDATE' THEN 
          activity_type := 'edit_meal';
          activity_description := 'Редактирано хранене за ' || NEW.meal_type::text || ' на ' || NEW.date::text;
          activity_data_obj := jsonb_build_object('meal_id', NEW.id, 'meal_type', NEW.meal_type, 'date', NEW.date);
        WHEN 'DELETE' THEN 
          activity_type := 'delete_meal';
          activity_description := 'Изтрито хранене за ' || OLD.meal_type::text || ' на ' || OLD.date::text;
          activity_data_obj := jsonb_build_object('meal_id', OLD.id, 'meal_type', OLD.meal_type, 'date', OLD.date);
      END CASE;

    WHEN 'weekly_meal_plans' THEN
      activity_category := 'weekly_menu';
      CASE TG_OP
        WHEN 'INSERT' THEN 
          activity_type := 'add_weekly_meal';
          activity_description := 'Добавено планирано хранене в седмичното меню';
          activity_data_obj := jsonb_build_object('plan_id', NEW.id, 'meal_type', NEW.meal_type, 'day_of_week', NEW.day_of_week);
        WHEN 'UPDATE' THEN 
          activity_type := 'edit_weekly_meal';
          activity_description := 'Редактирано планирано хранене в седмичното меню';
          activity_data_obj := jsonb_build_object('plan_id', NEW.id, 'meal_type', NEW.meal_type, 'day_of_week', NEW.day_of_week);
        WHEN 'DELETE' THEN 
          activity_type := 'delete_weekly_meal';
          activity_description := 'Изтрито планирано хранене от седмичното меню';
          activity_data_obj := jsonb_build_object('plan_id', OLD.id, 'meal_type', OLD.meal_type, 'day_of_week', OLD.day_of_week);
      END CASE;

    WHEN 'weekly_menu_templates' THEN
      activity_category := 'weekly_menu';
      CASE TG_OP
        WHEN 'INSERT' THEN 
          activity_type := 'create_template';
          activity_description := 'Създаден шаблон за седмично меню: ' || NEW.template_name;
          activity_data_obj := jsonb_build_object('template_id', NEW.id, 'template_name', NEW.template_name);
        WHEN 'UPDATE' THEN 
          activity_type := 'edit_template';
          activity_description := 'Редактиран шаблон за седмично меню: ' || NEW.template_name;
          activity_data_obj := jsonb_build_object('template_id', NEW.id, 'template_name', NEW.template_name);
        WHEN 'DELETE' THEN 
          activity_type := 'delete_template';
          activity_description := 'Изтрит шаблон за седмично меню: ' || OLD.template_name;
          activity_data_obj := jsonb_build_object('template_id', OLD.id, 'template_name', OLD.template_name);
      END CASE;

    WHEN 'hydration_intakes' THEN
      activity_category := 'hydration';
      CASE TG_OP
        WHEN 'INSERT' THEN 
          activity_type := 'log_hydration';
          activity_description := 'Записан прием на течности: ' || NEW.volume_ml || 'мл ' || NEW.beverage_type::text;
          activity_data_obj := jsonb_build_object('intake_id', NEW.id, 'volume_ml', NEW.volume_ml, 'beverage_type', NEW.beverage_type);
        WHEN 'DELETE' THEN 
          activity_type := 'delete_hydration';
          activity_description := 'Изтрит запис за прием на течности';
          activity_data_obj := jsonb_build_object('intake_id', OLD.id, 'volume_ml', OLD.volume_ml, 'beverage_type', OLD.beverage_type);
      END CASE;

    WHEN 'fitness_sessions' THEN
      activity_category := 'fitness';
      CASE TG_OP
        WHEN 'INSERT' THEN 
          IF NEW.completed THEN
            activity_type := 'complete_workout';
            activity_description := 'Завършена тренировка за ' || NEW.session_date::text;
          ELSE
            activity_type := 'add_training_day';
            activity_description := 'Добавен ден за тренировка: ' || NEW.session_date::text;
          END IF;
          activity_data_obj := jsonb_build_object('session_id', NEW.id, 'session_date', NEW.session_date, 'completed', NEW.completed);
        WHEN 'UPDATE' THEN 
          IF OLD.completed = false AND NEW.completed = true THEN
            activity_type := 'complete_workout';
            activity_description := 'Завършена тренировка за ' || NEW.session_date::text;
          ELSIF OLD.calories_burned IS DISTINCT FROM NEW.calories_burned THEN
            activity_type := 'log_calories';
            activity_description := 'Записани изгорени калории: ' || COALESCE(NEW.calories_burned::text, '0');
          ELSE
            activity_type := 'update_workout';
            activity_description := 'Обновена тренировка за ' || NEW.session_date::text;
          END IF;
          activity_data_obj := jsonb_build_object('session_id', NEW.id, 'session_date', NEW.session_date, 'completed', NEW.completed);
        WHEN 'DELETE' THEN 
          activity_type := 'remove_training_day';
          activity_description := 'Премахнат ден за тренировка: ' || OLD.session_date::text;
          activity_data_obj := jsonb_build_object('session_id', OLD.id, 'session_date', OLD.session_date);
      END CASE;

    WHEN 'fasting_sessions' THEN
      activity_category := 'fasting';
      CASE TG_OP
        WHEN 'INSERT' THEN 
          activity_type := 'start_fast';
          activity_description := 'Започнато гладуване';
          activity_data_obj := jsonb_build_object('session_id', NEW.id, 'start_at', NEW.start_at, 'target_hours', NEW.target_hours);
        WHEN 'UPDATE' THEN 
          IF OLD.end_at IS NULL AND NEW.end_at IS NOT NULL THEN
            activity_type := 'end_fast';
            activity_description := 'Приключено гладуване';
          ELSE
            activity_type := 'update_fast';
            activity_description := 'Обновено гладуване';
          END IF;
          activity_data_obj := jsonb_build_object('session_id', NEW.id, 'start_at', NEW.start_at, 'end_at', NEW.end_at);
        WHEN 'DELETE' THEN 
          activity_type := 'delete_fast';
          activity_description := 'Изтрито гладуване';
          activity_data_obj := jsonb_build_object('session_id', OLD.id, 'start_at', OLD.start_at);
      END CASE;

    WHEN 'weight_history' THEN
      activity_category := 'weight';
      CASE TG_OP
        WHEN 'INSERT' THEN 
          activity_type := 'log_weight';
          activity_description := 'Записано тегло: ' || NEW.weight_kg || 'кг';
          activity_data_obj := jsonb_build_object('weight_id', NEW.id, 'weight_kg', NEW.weight_kg, 'recorded_at', NEW.recorded_at);
        WHEN 'UPDATE' THEN 
          activity_type := 'update_weight';
          activity_description := 'Обновено тегло: ' || NEW.weight_kg || 'кг';
          activity_data_obj := jsonb_build_object('weight_id', NEW.id, 'weight_kg', NEW.weight_kg, 'recorded_at', NEW.recorded_at);
        WHEN 'DELETE' THEN 
          activity_type := 'delete_weight';
          activity_description := 'Изтрито тегло: ' || OLD.weight_kg || 'кг';
          activity_data_obj := jsonb_build_object('weight_id', OLD.id, 'weight_kg', OLD.weight_kg);
      END CASE;

    WHEN 'subscribers' THEN
      activity_category := 'subscription';
      CASE TG_OP
        WHEN 'INSERT' THEN 
          activity_type := 'subscribe';
          activity_description := 'Нов абонамент: ' || COALESCE(NEW.subscription_tier, 'неизвестен');
          activity_data_obj := jsonb_build_object('subscriber_id', NEW.id, 'tier', NEW.subscription_tier, 'subscribed', NEW.subscribed);
        WHEN 'UPDATE' THEN 
          IF OLD.subscribed != NEW.subscribed THEN
            IF NEW.subscribed THEN
              activity_type := 'subscribe';
              activity_description := 'Активиран абонамент: ' || COALESCE(NEW.subscription_tier, 'неизвестен');
            ELSE
              activity_type := 'unsubscribe';
              activity_description := 'Деактивиран абонамент';
            END IF;
          ELSE
            activity_type := 'update_subscription';
            activity_description := 'Обновен абонамент: ' || COALESCE(NEW.subscription_tier, 'неизвестен');
          END IF;
          activity_data_obj := jsonb_build_object('subscriber_id', NEW.id, 'tier', NEW.subscription_tier, 'subscribed', NEW.subscribed);
        WHEN 'DELETE' THEN 
          activity_type := 'unsubscribe';
          activity_description := 'Изтрит абонамент';
          activity_data_obj := jsonb_build_object('subscriber_id', OLD.id, 'tier', OLD.subscription_tier);
      END CASE;

    WHEN 'profiles' THEN
      activity_category := 'settings';
      activity_type := 'update_profile';
      activity_description := 'Обновен профил';
      activity_data_obj := jsonb_build_object('profile_id', NEW.id);
      -- Check for specific profile changes
      IF OLD.hydration_enabled != NEW.hydration_enabled THEN
        activity_category := 'hydration';
        IF NEW.hydration_enabled THEN
          activity_type := 'enable_hydration';
          activity_description := 'Активирано проследяване на хидратацията';
        ELSE
          activity_type := 'disable_hydration'; 
          activity_description := 'Деактивирано проследяване на хидратацията';
        END IF;
      ELSIF OLD.fasting_enabled != NEW.fasting_enabled THEN
        activity_category := 'fasting';
        IF NEW.fasting_enabled THEN
          activity_type := 'enable_fasting';
          activity_description := 'Активирано проследяване на гладуване';
        ELSE
          activity_type := 'disable_fasting';
          activity_description := 'Деактивирано проследяване на гладуване';
        END IF;
      ELSIF OLD.fitness_enabled != NEW.fitness_enabled THEN
        activity_category := 'fitness';
        IF NEW.fitness_enabled THEN
          activity_type := 'enable_fitness';
          activity_description := 'Активирано проследяване на фитнес';
        ELSE
          activity_type := 'disable_fitness';
          activity_description := 'Деактивирано проследяване на фитнес';
        END IF;
      ELSIF OLD.zone_enabled != NEW.zone_enabled THEN
        activity_category := 'zone';
        IF NEW.zone_enabled THEN
          activity_type := 'enable_zone';
          activity_description := 'Активирано зоново хранене';
        ELSE
          activity_type := 'disable_zone';
          activity_description := 'Деактивирано зоново хранене';
        END IF;
      ELSIF OLD.daily_calorie_target IS DISTINCT FROM NEW.daily_calorie_target THEN
        activity_type := 'update_targets';
        activity_description := 'Обновена дневна цел за калории: ' || COALESCE(NEW.daily_calorie_target::text, 'премахната');
      ELSIF OLD.daily_water_goal_ml != NEW.daily_water_goal_ml THEN
        activity_category := 'hydration';
        activity_type := 'update_hydration_goal';
        activity_description := 'Обновена цел за вода: ' || NEW.daily_water_goal_ml || 'мл';
      ELSIF OLD.fasting_goal_hours != NEW.fasting_goal_hours THEN
        activity_category := 'fasting';
        activity_type := 'update_fast_goal';
        activity_description := 'Обновена цел за гладуване: ' || NEW.fasting_goal_hours || 'ч';
      ELSIF OLD.blocked IS DISTINCT FROM NEW.blocked THEN
        activity_category := 'settings';
        IF NEW.blocked THEN
          activity_type := 'block_user';
          activity_description := 'Блокиран потребител' || COALESCE(': ' || NEW.blocked_reason, '');
        ELSE
          activity_type := 'unblock_user';
          activity_description := 'Отблокиран потребител';
        END IF;
      END IF;

    ELSE
      -- Skip unknown tables
      RETURN COALESCE(NEW, OLD);
  END CASE;

  -- Add admin action info to activity data if applicable
  IF is_admin_action THEN
    activity_data_obj := activity_data_obj || jsonb_build_object(
      'admin_action', true,
      'performed_by_admin', current_user_id,
      'target_user', target_user_id
    );
    -- Modify description to show it was admin action
    activity_description := '[АДМИН] ' || activity_description;
  END IF;

  -- Insert the activity record
  INSERT INTO public.user_activities (
    user_id,
    activity_category,
    activity_type,
    activity_description,
    activity_data,
    user_agent
  ) VALUES (
    COALESCE(target_user_id, current_user_id),
    activity_category,
    activity_type,
    activity_description,
    activity_data_obj,
    current_setting('request.headers', true)::json->>'user-agent'
  );

  RETURN COALESCE(NEW, OLD);
EXCEPTION
  WHEN OTHERS THEN
    -- Log error but don't fail the original operation
    RAISE WARNING 'Failed to log user activity: %', SQLERRM;
    RETURN COALESCE(NEW, OLD);
END;
$$;

-- Add trigger for subscribers table to track subscription changes
DROP TRIGGER IF EXISTS subscribers_activity_trigger ON public.subscribers;
CREATE TRIGGER subscribers_activity_trigger
  AFTER INSERT OR UPDATE OR DELETE ON public.subscribers
  FOR EACH ROW
  EXECUTE FUNCTION public.log_user_activity();