-- Fix the UPDATE policy for fitness_settings to include WITH CHECK
DROP POLICY IF EXISTS "Users can update their own fitness settings" ON public.fitness_settings;

CREATE POLICY "Users can update their own fitness settings" 
ON public.fitness_settings 
FOR UPDATE 
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);