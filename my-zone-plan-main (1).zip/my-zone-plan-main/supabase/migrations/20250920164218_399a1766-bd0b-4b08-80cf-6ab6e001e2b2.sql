-- Device push tokens for native iOS/Android apps (Capacitor)
CREATE TABLE IF NOT EXISTS public.device_push_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  token text NOT NULL,
  platform text NOT NULL CHECK (platform IN ('ios','android')),
  is_active boolean NOT NULL DEFAULT true,
  last_used_at timestamptz,
  device_info jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.device_push_tokens ENABLE ROW LEVEL SECURITY;

-- RLS policies
CREATE POLICY "Users can insert their own device tokens"
ON public.device_push_tokens
FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own device tokens"
ON public.device_push_tokens
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own device tokens"
ON public.device_push_tokens
FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own device tokens"
ON public.device_push_tokens
FOR DELETE
USING (auth.uid() = user_id);

-- Indexes
CREATE UNIQUE INDEX IF NOT EXISTS idx_device_tokens_token ON public.device_push_tokens(token);
CREATE INDEX IF NOT EXISTS idx_device_tokens_user ON public.device_push_tokens(user_id);

-- Updated_at trigger
CREATE TRIGGER update_device_push_tokens_updated_at
BEFORE UPDATE ON public.device_push_tokens
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();