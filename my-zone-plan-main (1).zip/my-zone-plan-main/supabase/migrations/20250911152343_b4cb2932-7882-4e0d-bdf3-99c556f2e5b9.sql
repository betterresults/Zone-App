-- Update product image URLs to use correct public paths
UPDATE products SET image_url = '/products/beef-lean.jpg' WHERE name = 'Говеждо постно';
UPDATE products SET image_url = '/products/onions.jpg' WHERE name = 'Лук';
UPDATE products SET image_url = '/products/carrots.jpg' WHERE name = 'Моркови';
UPDATE products SET image_url = '/products/eggplants.jpg' WHERE name = 'Патладжани';
UPDATE products SET image_url = '/products/turkey-fillet.jpg' WHERE name = 'Пуешко филе';
UPDATE products SET image_url = '/products/zucchini.jpg' WHERE name = 'Тиквички';