-- Ensure one-to-one mapping between profiles and auth users for joins
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'profiles_user_id_unique'
  ) THEN
    ALTER TABLE public.profiles
    ADD CONSTRAINT profiles_user_id_unique UNIQUE (user_id);
  END IF;
END $$;

-- Add FK so PostgREST can infer relationship for embedded selects
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'user_activities_user_id_fkey'
  ) THEN
    ALTER TABLE public.user_activities
    ADD CONSTRAINT user_activities_user_id_fkey
    FOREIGN KEY (user_id) REFERENCES public.profiles(user_id)
    ON DELETE CASCADE;
  END IF;
END $$;

-- Helpful index for activity feed queries
CREATE INDEX IF NOT EXISTS idx_user_activities_created_at ON public.user_activities (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_user_activities_user_id ON public.user_activities (user_id);
