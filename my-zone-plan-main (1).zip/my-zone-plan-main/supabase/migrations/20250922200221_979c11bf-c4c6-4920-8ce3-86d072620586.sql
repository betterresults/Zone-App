-- Add status column to calendar_events
ALTER TABLE public.calendar_events 
ADD COLUMN status text NOT NULL DEFAULT 'upcoming' 
CHECK (status IN ('upcoming', 'ongoing', 'completed'));

-- Create function to update event status based on current time
CREATE OR REPLACE FUNCTION public.update_event_status()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Update events to completed if they are past their end time
  UPDATE public.calendar_events
  SET status = 'completed'
  WHERE status != 'completed'
    AND (
      -- All day events that are past today
      (all_day = true AND event_date < CURRENT_DATE)
      OR
      -- Timed events where end time has passed
      (all_day = false 
       AND end_time IS NOT NULL 
       AND (event_date::timestamp + end_time) < NOW())
      OR 
      -- Events without end time but start time has passed (default 1 hour duration)
      (all_day = false 
       AND end_time IS NULL 
       AND start_time IS NOT NULL
       AND (event_date::timestamp + start_time + INTERVAL '1 hour') < NOW())
    );

  -- Update events to ongoing if they are currently happening  
  UPDATE public.calendar_events
  SET status = 'ongoing'
  WHERE status = 'upcoming'
    AND (
      -- All day events happening today
      (all_day = true AND event_date = CURRENT_DATE)
      OR
      -- Timed events currently happening
      (all_day = false 
       AND start_time IS NOT NULL
       AND end_time IS NOT NULL
       AND (event_date::timestamp + start_time) <= NOW()
       AND (event_date::timestamp + end_time) > NOW())
      OR
      -- Events without end time that have started (default 1 hour duration)
      (all_day = false 
       AND start_time IS NOT NULL
       AND end_time IS NULL
       AND (event_date::timestamp + start_time) <= NOW()
       AND (event_date::timestamp + start_time + INTERVAL '1 hour') > NOW())
    );
END;
$$;

-- Create trigger to automatically update status when events are inserted/updated
CREATE OR REPLACE FUNCTION public.trigger_update_event_status()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Update the status of the current event
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
    -- Determine status for the new/updated event
    IF NEW.all_day = true THEN
      IF NEW.event_date < CURRENT_DATE THEN
        NEW.status = 'completed';
      ELSIF NEW.event_date = CURRENT_DATE THEN
        NEW.status = 'ongoing';
      ELSE
        NEW.status = 'upcoming';
      END IF;
    ELSE
      -- For timed events
      IF NEW.end_time IS NOT NULL THEN
        IF (NEW.event_date::timestamp + NEW.end_time) < NOW() THEN
          NEW.status = 'completed';
        ELSIF (NEW.event_date::timestamp + NEW.start_time) <= NOW() 
              AND (NEW.event_date::timestamp + NEW.end_time) > NOW() THEN
          NEW.status = 'ongoing';
        ELSE
          NEW.status = 'upcoming';
        END IF;
      ELSIF NEW.start_time IS NOT NULL THEN
        -- Events without end time (default 1 hour duration)
        IF (NEW.event_date::timestamp + NEW.start_time + INTERVAL '1 hour') < NOW() THEN
          NEW.status = 'completed';
        ELSIF (NEW.event_date::timestamp + NEW.start_time) <= NOW() 
              AND (NEW.event_date::timestamp + NEW.start_time + INTERVAL '1 hour') > NOW() THEN
          NEW.status = 'ongoing';
        ELSE
          NEW.status = 'upcoming';
        END IF;
      END IF;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger on calendar_events
CREATE TRIGGER update_calendar_event_status
  BEFORE INSERT OR UPDATE ON public.calendar_events
  FOR EACH ROW
  EXECUTE FUNCTION public.trigger_update_event_status();

-- Create a cron job to update event statuses every hour
SELECT cron.schedule(
  'update-event-status-hourly',
  '0 * * * *', -- Every hour at minute 0
  $$
  SELECT public.update_event_status();
  $$
);

-- Update existing events to have correct status
SELECT public.update_event_status();