-- Add fitness_enabled and zone_enabled columns to profiles table
ALTER TABLE public.profiles 
ADD COLUMN fitness_enabled boolean NOT NULL DEFAULT true,
ADD COLUMN zone_enabled boolean NOT NULL DEFAULT true;