-- Add personal data fields and calorie target to profiles
ALTER TABLE public.profiles 
ADD COLUMN daily_calorie_target INTEGER,
ADD COLUMN weight_goal TEXT CHECK (weight_goal IN ('lose', 'maintain', 'gain'));