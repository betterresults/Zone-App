
  -- Таблица за оценки на рецепти
  create table if not exists public.recipe_ratings (
    id uuid primary key default gen_random_uuid(),
    recipe_id uuid not null references public.recipes(id) on delete cascade,
    user_id uuid not null references auth.users(id) on delete cascade,
    rating integer not null check (rating >= 1 and rating <= 5),
    comment text,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    unique (recipe_id, user_id)
  );

  -- Индекс за по-бързи агрегации по рецепта
  create index if not exists idx_recipe_ratings_recipe_id on public.recipe_ratings(recipe_id);

  -- RLS
  alter table public.recipe_ratings enable row level security;

  -- Преглед: виждам оценки за публични рецепти, за мои рецепти или моите собствени оценки
  create policy "View ratings for public recipes or mine"
    on public.recipe_ratings
    for select
    using (
      (exists (
        select 1
        from public.recipes r
        where r.id = recipe_ratings.recipe_id
          and (r.is_public = true or r.user_id = auth.uid())
      ))
      or (recipe_ratings.user_id = auth.uid())
    );

  -- Въвеждане: мога да оценявам само публични рецепти и не моите
  create policy "Rate public recipes (not my own)"
    on public.recipe_ratings
    for insert
    with check (
      exists (
        select 1
        from public.recipes r
        where r.id = recipe_ratings.recipe_id
          and r.is_public = true
          and r.user_id <> auth.uid()
      )
    );

  -- Обновяване: мога да обновявам само моята собствена оценка
  create policy "Users can update their own ratings"
    on public.recipe_ratings
    for update
    using (user_id = auth.uid());

  -- Изтриване: мога да изтрия само моята собствена оценка
  create policy "Users can delete their own ratings"
    on public.recipe_ratings
    for delete
    using (user_id = auth.uid());

  -- Изтриване: собственикът на рецептата може да модерира (трие) оценки по своя рецепта
  create policy "Recipe owners can delete ratings on their recipes"
    on public.recipe_ratings
    for delete
    using (
      exists (
        select 1 from public.recipes r
        where r.id = recipe_ratings.recipe_id
          and r.user_id = auth.uid()
      )
    );

  -- Тригер за updated_at
  drop trigger if exists set_timestamp_recipe_ratings on public.recipe_ratings;
  create trigger set_timestamp_recipe_ratings
    before update on public.recipe_ratings
    for each row
    execute function public.update_updated_at_column();
  