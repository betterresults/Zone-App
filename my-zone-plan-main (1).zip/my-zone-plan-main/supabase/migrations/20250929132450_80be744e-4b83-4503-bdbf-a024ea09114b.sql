-- Create habit daily stats table for tracking completion status
CREATE TABLE public.habit_daily_stats (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  habit_id UUID NOT NULL,
  date DATE NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('completed', 'missed', 'skipped')),
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  
  -- Ensure one record per habit per day per user
  UNIQUE(user_id, habit_id, date)
);

-- Enable RLS
ALTER TABLE public.habit_daily_stats ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view their own habit stats" 
ON public.habit_daily_stats 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own habit stats" 
ON public.habit_daily_stats 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own habit stats" 
ON public.habit_daily_stats 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own habit stats" 
ON public.habit_daily_stats 
FOR DELETE 
USING (auth.uid() = user_id);

-- Add trigger for updated_at
CREATE TRIGGER update_habit_daily_stats_updated_at
BEFORE UPDATE ON public.habit_daily_stats
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create index for performance
CREATE INDEX idx_habit_daily_stats_user_date ON public.habit_daily_stats(user_id, date);
CREATE INDEX idx_habit_daily_stats_habit_date ON public.habit_daily_stats(habit_id, date);