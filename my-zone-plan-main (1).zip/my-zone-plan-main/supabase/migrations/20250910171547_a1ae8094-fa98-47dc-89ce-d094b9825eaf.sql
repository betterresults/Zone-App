-- Enable RLS on the admin_setup table and create appropriate policies
ALTER TABLE public.admin_setup ENABLE ROW LEVEL SECURITY;

-- Only admins should be able to access this table, but since we're setting up the first admin,
-- we'll allow access for now and can restrict it later
CREATE POLICY "Temporary setup access" ON public.admin_setup FOR ALL USING (true);

-- Now let's create the admin user directly using a function approach
-- We'll create a user via the auth system and then make them admin
DO $$
DECLARE
  new_user_id uuid;
  user_metadata jsonb;
BEGIN
  -- Create the user in auth.users with proper structure
  new_user_id := gen_random_uuid();
  user_metadata := jsonb_build_object('display_name', 'System Admin');
  
  -- Insert into auth.users with required fields
  INSERT INTO auth.users (
    instance_id,
    id,
    aud,
    role,
    email,
    encrypted_password,
    email_confirmed_at,
    invited_at,
    confirmation_token,
    confirmation_sent_at,
    recovery_token,
    recovery_sent_at,
    email_change_token_new,
    email_change,
    email_change_sent_at,
    last_sign_in_at,
    raw_app_meta_data,
    raw_user_meta_data,
    is_super_admin,
    created_at,
    updated_at,
    phone,
    phone_confirmed_at,
    phone_change,
    phone_change_token,
    phone_change_sent_at,
    email_change_token_current,
    email_change_confirm_status,
    banned_until,
    reauthentication_token,
    reauthentication_sent_at,
    is_sso_user,
    deleted_at
  ) VALUES (
    '00000000-0000-0000-0000-000000000000',
    new_user_id,
    'authenticated',
    'authenticated',
    'admin@myzone.life',
    crypt('123456', gen_salt('bf')),
    now(),
    now(),
    '',
    now(),
    '',
    NULL,
    '',
    '',
    NULL,
    now(),
    '{"provider":"email","providers":["email"]}',
    user_metadata,
    false,
    now(),
    now(),
    NULL,
    NULL,
    '',
    '',
    NULL,
    '',
    0,
    NULL,
    '',
    NULL,
    false,
    NULL
  );
  
  -- Create profile
  INSERT INTO public.profiles (user_id, email, display_name)
  VALUES (new_user_id, 'admin@myzone.life', 'System Admin');
  
  -- Assign admin role
  INSERT INTO public.user_roles (user_id, role, created_by)
  VALUES (new_user_id, 'admin', new_user_id);
  
  RAISE NOTICE 'Admin user created successfully with ID: %', new_user_id;
  
END $$;