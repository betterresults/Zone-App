-- Add Partnero customer id to profiles
ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS partnero_customer_id text;

-- Index for faster lookup by user_id
CREATE INDEX IF NOT EXISTS idx_profiles_user_id ON public.profiles (user_id);

-- Optional: unique constraint on partnero_customer_id if Partnero IDs are unique across users
-- Note: Use DEFERRABLE to avoid conflicts during backfill
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'uniq_partnero_customer_id'
  ) THEN
    ALTER TABLE public.profiles
    ADD CONSTRAINT uniq_partnero_customer_id UNIQUE (partnero_customer_id);
  END IF;
END$$;
