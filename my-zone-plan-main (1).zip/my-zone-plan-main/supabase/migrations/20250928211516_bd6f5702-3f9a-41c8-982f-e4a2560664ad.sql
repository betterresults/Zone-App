-- Update existing categories to allow deletion of most categories
-- Only keep "Общо" as a default category that cannot be deleted
UPDATE public.user_habit_categories 
SET is_default = false 
WHERE name != 'Общо';