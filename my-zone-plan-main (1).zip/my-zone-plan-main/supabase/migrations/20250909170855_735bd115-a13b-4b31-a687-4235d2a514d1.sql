-- Add basic vegetables with accurate nutritional information
INSERT INTO public.products (
  name, 
  calories_per_100g, 
  protein_per_100g, 
  carbs_per_100g, 
  fat_per_100g, 
  fiber_per_100g, 
  category, 
  is_public,
  user_id
) VALUES 
  ('Лук', 40, 1.1, 9.3, 0.1, 1.7, 'vegetables', true, null),
  ('Моркови', 41, 0.9, 9.6, 0.2, 2.8, 'vegetables', true, null),
  ('Патладжани', 25, 1.0, 6.0, 0.2, 3.0, 'vegetables', true, null),
  ('Тиквички', 17, 1.2, 3.1, 0.3, 1.0, 'vegetables', true, null);