-- Add Keto diet support to profiles table
ALTER TABLE public.profiles 
ADD COLUMN keto_enabled boolean NOT NULL DEFAULT false,
ADD COLUMN daily_carbs_limit integer DEFAULT 30;

-- Add Keto-friendly marking to recipes
ALTER TABLE public.recipes 
ADD COLUMN is_keto_friendly boolean DEFAULT false;

-- Create function to calculate if a recipe is keto-friendly
-- A recipe is keto-friendly if it has less than 10g net carbs per serving
CREATE OR REPLACE FUNCTION public.calculate_recipe_keto_friendly(recipe_id_param uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  total_carbs numeric := 0;
  total_fiber numeric := 0;
  net_carbs numeric := 0;
  recipe_servings integer := 1;
BEGIN
  -- Get recipe servings
  SELECT servings INTO recipe_servings
  FROM public.recipes
  WHERE id = recipe_id_param;
  
  -- Calculate total carbs and fiber from recipe ingredients
  SELECT 
    COALESCE(SUM(p.carbs_per_100g * (ri.grams / 100.0)), 0),
    COALESCE(SUM(p.fiber_per_100g * (ri.grams / 100.0)), 0)
  INTO total_carbs, total_fiber
  FROM public.recipe_ingredients ri
  JOIN public.products p ON ri.product_id = p.id
  WHERE ri.recipe_id = recipe_id_param;
  
  -- Calculate net carbs per serving
  net_carbs := (total_carbs - total_fiber) / recipe_servings;
  
  -- Recipe is keto-friendly if it has less than 10g net carbs per serving
  RETURN (net_carbs < 10);
END;
$$;

-- Create trigger to update recipe keto-friendly status when ingredients change
CREATE OR REPLACE FUNCTION public.update_recipe_keto_friendly()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  -- Update the recipe's Keto-friendly status
  UPDATE public.recipes
  SET is_keto_friendly = public.calculate_recipe_keto_friendly(COALESCE(NEW.recipe_id, OLD.recipe_id))
  WHERE id = COALESCE(NEW.recipe_id, OLD.recipe_id);
  
  RETURN COALESCE(NEW, OLD);
END;
$$;

-- Create trigger to update keto-friendly status when recipe is modified
CREATE OR REPLACE FUNCTION public.update_recipe_keto_friendly_on_recipe_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  -- Update Keto-friendly status when recipe is modified
  NEW.is_keto_friendly = public.calculate_recipe_keto_friendly(NEW.id);
  RETURN NEW;
END;
$$;

-- Create triggers for recipe ingredients changes
CREATE TRIGGER update_recipe_keto_friendly_on_ingredients_change
  AFTER INSERT OR UPDATE OR DELETE ON public.recipe_ingredients
  FOR EACH ROW EXECUTE FUNCTION public.update_recipe_keto_friendly();

-- Create trigger for recipe changes
CREATE TRIGGER update_recipe_keto_friendly_on_recipe_update
  BEFORE UPDATE ON public.recipes
  FOR EACH ROW EXECUTE FUNCTION public.update_recipe_keto_friendly_on_recipe_change();

-- Update existing recipes to calculate their keto-friendly status
UPDATE public.recipes 
SET is_keto_friendly = public.calculate_recipe_keto_friendly(id);

-- Add constraint to ensure only one diet mode is enabled at a time
ALTER TABLE public.profiles 
ADD CONSTRAINT check_single_diet_mode 
CHECK (
  (zone_enabled::int + keto_enabled::int) <= 1
);