-- Add package_size to products table for better quantity calculations
ALTER TABLE public.products 
ADD COLUMN package_size_grams numeric DEFAULT NULL,
ADD COLUMN package_size_unit text DEFAULT 'г';

-- Create shopping_lists table
CREATE TABLE public.shopping_lists (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  name text NOT NULL,
  week_start_date date NOT NULL,
  week_end_date date NOT NULL,
  total_items_count integer DEFAULT 0,
  completed_items_count integer DEFAULT 0,
  is_completed boolean DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create shopping_list_items table
CREATE TABLE public.shopping_list_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  shopping_list_id UUID NOT NULL,
  product_id UUID NOT NULL,
  quantity_grams numeric NOT NULL,
  estimated_packages numeric DEFAULT 1,
  is_purchased boolean DEFAULT false,
  is_available boolean DEFAULT false, -- user already has this item
  notes text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.shopping_lists ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.shopping_list_items ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for shopping_lists
CREATE POLICY "Users can create their own shopping lists" 
ON public.shopping_lists 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own shopping lists" 
ON public.shopping_lists 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own shopping lists" 
ON public.shopping_lists 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own shopping lists" 
ON public.shopping_lists 
FOR DELETE 
USING (auth.uid() = user_id);

-- Create RLS policies for shopping_list_items
CREATE POLICY "Users can manage items for their shopping lists" 
ON public.shopping_list_items 
FOR ALL 
USING (EXISTS (
  SELECT 1 FROM public.shopping_lists sl 
  WHERE sl.id = shopping_list_items.shopping_list_id 
  AND sl.user_id = auth.uid()
));

-- Create triggers for updated_at
CREATE TRIGGER update_shopping_lists_updated_at
  BEFORE UPDATE ON public.shopping_lists
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_shopping_list_items_updated_at
  BEFORE UPDATE ON public.shopping_list_items
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Function to update shopping list counters
CREATE OR REPLACE FUNCTION public.update_shopping_list_counters()
RETURNS TRIGGER AS $$
BEGIN
  -- Update the shopping list counters
  UPDATE public.shopping_lists 
  SET 
    total_items_count = (
      SELECT COUNT(*) 
      FROM public.shopping_list_items sli 
      WHERE sli.shopping_list_id = COALESCE(NEW.shopping_list_id, OLD.shopping_list_id)
    ),
    completed_items_count = (
      SELECT COUNT(*) 
      FROM public.shopping_list_items sli 
      WHERE sli.shopping_list_id = COALESCE(NEW.shopping_list_id, OLD.shopping_list_id)
      AND (sli.is_purchased = true OR sli.is_available = true)
    ),
    updated_at = now()
  WHERE id = COALESCE(NEW.shopping_list_id, OLD.shopping_list_id);
  
  -- Update is_completed status
  UPDATE public.shopping_lists 
  SET is_completed = (total_items_count > 0 AND total_items_count = completed_items_count)
  WHERE id = COALESCE(NEW.shopping_list_id, OLD.shopping_list_id);
  
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create triggers for counter updates
CREATE TRIGGER shopping_list_items_counter_update
  AFTER INSERT OR UPDATE OR DELETE ON public.shopping_list_items
  FOR EACH ROW
  EXECUTE FUNCTION public.update_shopping_list_counters();

-- Add activity logging trigger
CREATE TRIGGER log_shopping_list_activity 
  AFTER INSERT OR UPDATE OR DELETE ON public.shopping_lists
  FOR EACH ROW 
  EXECUTE FUNCTION public.log_user_activity();

CREATE TRIGGER log_shopping_list_items_activity 
  AFTER INSERT OR UPDATE OR DELETE ON public.shopping_list_items
  FOR EACH ROW 
  EXECUTE FUNCTION public.log_user_activity();