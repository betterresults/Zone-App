
-- 1) Enum for beverage types
DO $$ BEGIN
  CREATE TYPE public.hydration_beverage_type AS ENUM ('water','tea','coffee','juice','soup','other');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- 2) Hydration intakes table
CREATE TABLE IF NOT EXISTS public.hydration_intakes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  beverage_type public.hydration_beverage_type NOT NULL DEFAULT 'water',
  volume_ml INTEGER NOT NULL CHECK (volume_ml > 0),
  intake_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.hydration_intakes ENABLE ROW LEVEL SECURITY;

-- RLS: only owner can access
CREATE POLICY "Users can view their own hydration intakes"
  ON public.hydration_intakes
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own hydration intakes"
  ON public.hydration_intakes
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own hydration intakes"
  ON public.hydration_intakes
  FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own hydration intakes"
  ON public.hydration_intakes
  FOR DELETE
  USING (auth.uid() = user_id);

-- updated_at trigger
DROP TRIGGER IF EXISTS set_updated_at_hydration_intakes ON public.hydration_intakes;
CREATE TRIGGER set_updated_at_hydration_intakes
  BEFORE UPDATE ON public.hydration_intakes
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Index for fast lookups by user and date
CREATE INDEX IF NOT EXISTS hydration_intakes_user_date_idx
  ON public.hydration_intakes (user_id, intake_at DESC);

-- 3) Fasting sessions table
CREATE TABLE IF NOT EXISTS public.fasting_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  start_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  end_at TIMESTAMPTZ,
  target_hours NUMERIC,
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.fasting_sessions ENABLE ROW LEVEL SECURITY;

-- RLS: only owner can access
CREATE POLICY "Users can view their own fasting sessions"
  ON public.fasting_sessions
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own fasting sessions"
  ON public.fasting_sessions
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own fasting sessions"
  ON public.fasting_sessions
  FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own fasting sessions"
  ON public.fasting_sessions
  FOR DELETE
  USING (auth.uid() = user_id);

-- updated_at trigger
DROP TRIGGER IF EXISTS set_updated_at_fasting_sessions ON public.fasting_sessions;
CREATE TRIGGER set_updated_at_fasting_sessions
  BEFORE UPDATE ON public.fasting_sessions
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Validation trigger: end_at > start_at and no overlapping active fasts
CREATE OR REPLACE FUNCTION public.validate_fasting_session()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  active_count INTEGER;
BEGIN
  -- If end_at is provided, it must be after start_at
  IF NEW.end_at IS NOT NULL AND NEW.end_at <= NEW.start_at THEN
    RAISE EXCEPTION 'end_at must be after start_at';
  END IF;

  -- Ensure there is at most one active (end_at IS NULL) session per user
  IF NEW.end_at IS NULL THEN
    SELECT COUNT(*) INTO active_count
    FROM public.fasting_sessions fs
    WHERE fs.user_id = NEW.user_id
      AND fs.end_at IS NULL
      AND (TG_OP = 'INSERT' OR fs.id <> NEW.id);

    IF active_count > 0 THEN
      RAISE EXCEPTION 'You already have an active fasting session';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS validate_fasting_session_biu ON public.fasting_sessions;
CREATE TRIGGER validate_fasting_session_biu
  BEFORE INSERT OR UPDATE ON public.fasting_sessions
  FOR EACH ROW EXECUTE FUNCTION public.validate_fasting_session();

-- Indexes for range queries
CREATE INDEX IF NOT EXISTS fasting_sessions_user_start_idx
  ON public.fasting_sessions (user_id, start_at DESC);

CREATE INDEX IF NOT EXISTS fasting_sessions_user_end_idx
  ON public.fasting_sessions (user_id, end_at);

-- 4) Profile defaults for goals
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS daily_water_goal_ml INTEGER NOT NULL DEFAULT 2000;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS fasting_goal_hours INTEGER NOT NULL DEFAULT 16;
