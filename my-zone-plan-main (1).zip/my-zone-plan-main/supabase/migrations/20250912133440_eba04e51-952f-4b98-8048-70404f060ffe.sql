-- Drop old referral system completely with correct order

-- Drop triggers that depend on functions first
DROP TRIGGER IF EXISTS create_referral_code_on_profile_creation ON profiles;
DROP TRIGGER IF EXISTS create_referral_code_trigger ON profiles;

-- Drop functions
DROP FUNCTION IF EXISTS public.generate_referral_code() CASCADE;
DROP FUNCTION IF EXISTS public.create_user_referral_code() CASCADE;
DROP FUNCTION IF EXISTS public.calculate_referral_rewards(uuid) CASCADE;

-- Drop tables (in correct order due to foreign keys)
DROP TABLE IF EXISTS public.referral_rewards CASCADE;
DROP TABLE IF EXISTS public.referrals CASCADE;  
DROP TABLE IF EXISTS public.user_referral_codes CASCADE;