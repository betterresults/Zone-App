-- Add missing foreign key constraints for dish_ingredients table
ALTER TABLE dish_ingredients 
ADD CONSTRAINT dish_ingredients_dish_id_fkey 
FOREIGN KEY (dish_id) REFERENCES dishes(id) ON DELETE CASCADE;

ALTER TABLE dish_ingredients 
ADD CONSTRAINT dish_ingredients_product_id_fkey 
FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE;

-- Also add foreign key constraint for weekly_meal_plans dish_id if it doesn't exist
DO $$
BEGIN
    -- Check if constraint already exists for weekly_meal_plans
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.table_constraints 
        WHERE constraint_name = 'weekly_meal_plans_dish_id_fkey'
    ) THEN
        ALTER TABLE weekly_meal_plans 
        ADD CONSTRAINT weekly_meal_plans_dish_id_fkey 
        FOREIGN KEY (dish_id) REFERENCES dishes(id) ON DELETE CASCADE;
    END IF;
END $$;