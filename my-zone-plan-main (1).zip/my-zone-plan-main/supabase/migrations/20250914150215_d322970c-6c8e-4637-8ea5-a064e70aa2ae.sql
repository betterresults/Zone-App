-- Add bananas as a public product
INSERT INTO public.products (
  name,
  brand,
  category,
  calories_per_100g,
  protein_per_100g,
  carbs_per_100g,
  fat_per_100g,
  fiber_per_100g,
  default_serving_grams,
  package_size_grams,
  package_unit_type,
  package_size_unit,
  is_public,
  user_id
) VALUES (
  'Банани',
  'Общ',
  'fruits',
  89,
  1.1,
  22.8,
  0.3,
  2.6,
  100,
  1000,
  'килограм',
  'г',
  true,
  null
);