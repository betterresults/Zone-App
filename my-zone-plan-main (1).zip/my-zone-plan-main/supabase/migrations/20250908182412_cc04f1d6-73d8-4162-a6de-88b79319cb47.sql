-- Security fixes for comprehensive security review

-- 1. Add unique index on profiles.user_id to prevent duplicate profiles
CREATE UNIQUE INDEX IF NOT EXISTS idx_profiles_user_id_unique ON public.profiles(user_id);

-- 2. Create trigger function to protect admin-controlled fields
CREATE OR REPLACE FUNCTION public.protect_admin_fields()
RETURNS TRIGGER AS $$
BEGIN
  -- Only admins can modify blocked status, blocked_reason, blocked_by, blocked_at
  IF NOT public.is_admin(auth.uid()) THEN
    -- Prevent users from unblocking themselves
    IF OLD.blocked IS DISTINCT FROM NEW.blocked THEN
      NEW.blocked = OLD.blocked;
    END IF;
    
    -- Prevent users from modifying admin fields
    IF OLD.blocked_reason IS DISTINCT FROM NEW.blocked_reason THEN
      NEW.blocked_reason = OLD.blocked_reason;
    END IF;
    
    IF OLD.blocked_by IS DISTINCT FROM NEW.blocked_by THEN
      NEW.blocked_by = OLD.blocked_by;
    END IF;
    
    IF OLD.blocked_at IS DISTINCT FROM NEW.blocked_at THEN
      NEW.blocked_at = OLD.blocked_at;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- 3. Add trigger to profiles table
CREATE TRIGGER protect_admin_fields_trigger
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.protect_admin_fields();

-- 4. Create function to prevent users from making private data public
CREATE OR REPLACE FUNCTION public.prevent_unauthorized_public_access()
RETURNS TRIGGER AS $$
BEGIN
  -- Only allow the owner or admin to make content public
  IF NEW.is_public = true AND OLD.is_public = false THEN
    IF NOT (auth.uid() = NEW.user_id OR public.is_admin(auth.uid())) THEN
      RAISE EXCEPTION 'Only the owner can make content public';
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- 5. Add triggers to prevent unauthorized public access
CREATE TRIGGER prevent_public_products_trigger
  BEFORE UPDATE ON public.products
  FOR EACH ROW
  EXECUTE FUNCTION public.prevent_unauthorized_public_access();

CREATE TRIGGER prevent_public_recipes_trigger
  BEFORE UPDATE ON public.recipes
  FOR EACH ROW
  EXECUTE FUNCTION public.prevent_unauthorized_public_access();

CREATE TRIGGER prevent_public_dishes_trigger
  BEFORE UPDATE ON public.dishes
  FOR EACH ROW
  EXECUTE FUNCTION public.prevent_unauthorized_public_access();

-- 6. Enhanced RLS policy to prevent user_id tampering
DROP POLICY IF EXISTS "Users can update their own products" ON public.products;
CREATE POLICY "Users can update their own products" ON public.products
  FOR UPDATE USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id AND auth.uid() = OLD.user_id);

DROP POLICY IF EXISTS "Users can update their own recipes" ON public.recipes;
CREATE POLICY "Users can update their own recipes" ON public.recipes
  FOR UPDATE USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id AND auth.uid() = OLD.user_id);

DROP POLICY IF EXISTS "Users can update their own dishes" ON public.dishes;
CREATE POLICY "Users can update their own dishes" ON public.dishes
  FOR UPDATE USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id AND auth.uid() = OLD.user_id);

-- 7. Add constraint to ensure weight_goal values are valid
ALTER TABLE public.profiles 
DROP CONSTRAINT IF EXISTS profiles_weight_goal_check;

ALTER TABLE public.profiles 
ADD CONSTRAINT profiles_weight_goal_check 
CHECK (weight_goal IN ('lose', 'maintain', 'gain'));