-- Update products with generated images
UPDATE products SET image_url = '/src/assets/products/beef-lean.jpg' WHERE name = 'Говеждо постно';
UPDATE products SET image_url = '/src/assets/products/onions.jpg' WHERE name = 'Лук';
UPDATE products SET image_url = '/src/assets/products/carrots.jpg' WHERE name = 'Моркови';
UPDATE products SET image_url = '/src/assets/products/eggplants.jpg' WHERE name = 'Патладжани';
UPDATE products SET image_url = '/src/assets/products/turkey-fillet.jpg' WHERE name = 'Пуешко филе';
UPDATE products SET image_url = '/src/assets/products/zucchini.jpg' WHERE name = 'Тиквички';