-- Add a flexible custom category field to allow user-defined categories
ALTER TABLE public.products
ADD COLUMN IF NOT EXISTS custom_category TEXT;

-- Optional: comment for docs
COMMENT ON COLUMN public.products.custom_category IS 'User-defined custom category label shown in UI; when set, it overrides enum category display.';