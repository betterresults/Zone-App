-- Create referral system tables for custom reward program

-- Table to track referral codes and relationships
CREATE TABLE public.referrals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  referrer_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  referred_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  referral_code TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'inactive')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  activated_at TIMESTAMP WITH TIME ZONE,
  last_activity_at TIMESTAMP WITH TIME ZONE,
  UNIQUE(referrer_id, referred_id)
);

-- Table to track user activity for determining "active" status
CREATE TABLE public.user_activity (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  activity_type TEXT NOT NULL CHECK (activity_type IN ('login', 'meal_logged', 'recipe_created', 'weight_tracked', 'subscription_created')),
  activity_date DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, activity_type, activity_date)
);

-- Table to track earned referral rewards
CREATE TABLE public.referral_rewards (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  reward_type TEXT NOT NULL CHECK (reward_type IN ('1_month_free', '3_months_free', '6_months_free', '1_year_free')),
  active_referrals_count INTEGER NOT NULL,
  pro_referrals_count INTEGER NOT NULL DEFAULT 0,
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'used', 'expired')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  used_at TIMESTAMP WITH TIME ZONE
);

-- Table to store user referral codes
CREATE TABLE public.user_referral_codes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE,
  referral_code TEXT NOT NULL UNIQUE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_activity ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.referral_rewards ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_referral_codes ENABLE ROW LEVEL SECURITY;

-- RLS Policies for referrals
CREATE POLICY "Users can view their own referrals as referrer" 
ON public.referrals FOR SELECT 
USING (auth.uid() = referrer_id);

CREATE POLICY "Users can view referrals where they are referred" 
ON public.referrals FOR SELECT 
USING (auth.uid() = referred_id);

CREATE POLICY "System can create referrals" 
ON public.referrals FOR INSERT 
WITH CHECK (true);

CREATE POLICY "System can update referral status" 
ON public.referrals FOR UPDATE 
USING (true);

-- RLS Policies for user_activity
CREATE POLICY "Users can create their own activity" 
ON public.user_activity FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own activity" 
ON public.user_activity FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "System can view all activity for referral tracking" 
ON public.user_activity FOR SELECT 
USING (true);

-- RLS Policies for referral_rewards
CREATE POLICY "Users can view their own rewards" 
ON public.referral_rewards FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "System can create rewards" 
ON public.referral_rewards FOR INSERT 
WITH CHECK (true);

CREATE POLICY "System can update rewards" 
ON public.referral_rewards FOR UPDATE 
USING (true);

-- RLS Policies for user_referral_codes
CREATE POLICY "Users can view their own referral code" 
ON public.user_referral_codes FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own referral code" 
ON public.user_referral_codes FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own referral code" 
ON public.user_referral_codes FOR UPDATE 
USING (auth.uid() = user_id);

-- Function to generate unique referral code
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  code TEXT;
  exists_check BOOLEAN;
BEGIN
  LOOP
    -- Generate 8 character alphanumeric code
    code := upper(substr(md5(random()::text), 1, 8));
    
    -- Check if code already exists
    SELECT EXISTS(SELECT 1 FROM public.user_referral_codes WHERE referral_code = code) INTO exists_check;
    
    EXIT WHEN NOT exists_check;
  END LOOP;
  
  RETURN code;
END;
$$;

-- Function to create referral code for new user
CREATE OR REPLACE FUNCTION public.create_user_referral_code()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.user_referral_codes (user_id, referral_code)
  VALUES (NEW.user_id, public.generate_referral_code());
  
  RETURN NEW;
END;
$$;

-- Trigger to create referral code when profile is created
CREATE TRIGGER create_referral_code_on_profile_creation
  AFTER INSERT ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.create_user_referral_code();

-- Function to check if user is active (has activity in last 30 days)
CREATE OR REPLACE FUNCTION public.is_user_active(user_uuid UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_activity 
    WHERE user_id = user_uuid 
    AND activity_date >= CURRENT_DATE - INTERVAL '30 days'
  );
$$;

-- Function to calculate and award referral rewards
CREATE OR REPLACE FUNCTION public.calculate_referral_rewards(referrer_uuid UUID)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  active_count INTEGER;
  pro_count INTEGER;
  reward_type TEXT;
  reward_months INTEGER;
BEGIN
  -- Count active referrals
  SELECT COUNT(*) INTO active_count
  FROM public.referrals r
  WHERE r.referrer_id = referrer_uuid
    AND r.status = 'active'
    AND public.is_user_active(r.referred_id);

  -- Count PRO referrals (users with active subscriptions)
  SELECT COUNT(*) INTO pro_count
  FROM public.referrals r
  JOIN public.subscribers s ON r.referred_id = s.user_id
  WHERE r.referrer_id = referrer_uuid
    AND r.status = 'active'
    AND s.subscribed = true
    AND (s.subscription_end IS NULL OR s.subscription_end > now())
    AND public.is_user_active(r.referred_id);

  -- Determine reward based on counts
  IF pro_count >= 5 THEN
    reward_type := '1_year_free';
    reward_months := 12;
  ELSIF active_count >= 10 THEN
    reward_type := '6_months_free';
    reward_months := 6;
  ELSIF active_count >= 5 THEN
    reward_type := '3_months_free';
    reward_months := 3;
  ELSIF active_count >= 3 THEN
    reward_type := '1_month_free';
    reward_months := 1;
  ELSE
    RETURN; -- No reward earned yet
  END IF;

  -- Check if this reward level already exists and is active
  IF NOT EXISTS (
    SELECT 1 FROM public.referral_rewards 
    WHERE user_id = referrer_uuid 
    AND reward_type = reward_type 
    AND status = 'active'
  ) THEN
    -- Create new reward
    INSERT INTO public.referral_rewards (
      user_id, 
      reward_type, 
      active_referrals_count, 
      pro_referrals_count,
      expires_at
    ) VALUES (
      referrer_uuid,
      reward_type,
      active_count,
      pro_count,
      now() + INTERVAL '1 year' -- Rewards expire after 1 year
    );
  END IF;
END;
$$;

-- Create indexes for better performance
CREATE INDEX idx_referrals_referrer_id ON public.referrals(referrer_id);
CREATE INDEX idx_referrals_referred_id ON public.referrals(referred_id);
CREATE INDEX idx_referrals_status ON public.referrals(status);
CREATE INDEX idx_user_activity_user_id ON public.user_activity(user_id);
CREATE INDEX idx_user_activity_date ON public.user_activity(activity_date);
CREATE INDEX idx_referral_rewards_user_id ON public.referral_rewards(user_id);
CREATE INDEX idx_referral_rewards_status ON public.referral_rewards(status);