-- Enable realtime for beta_feedback (idempotent)
ALTER TABLE public.beta_feedback REPLICA IDENTITY FULL;

DO $$
BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.beta_feedback;
EXCEPTION
  WHEN duplicate_object THEN
    NULL;
END $$;