-- Update exercise order and names
UPDATE exercises SET 
  name = 'Бягане',
  description = 'Кардио за издръжливост и горене на калории'
WHERE name = 'Бягане';

UPDATE exercises SET 
  name = 'Бърпита', 
  description = 'Интензивно цялостно упражнение'
WHERE name = 'Барпити';

UPDATE exercises SET 
  name = 'Каране на велосипед',
  description = 'Щадящо кардио упражнение'  
WHERE name = 'Каране на колело';

-- Let's also add a few more basic exercises
INSERT INTO exercises 
  (name, description, category, muscle_groups, equipment, difficulty_level, instructions, tips, is_public)
VALUES
  ('Ходене', 'Лека кардио активност', 'cardio', ARRAY['крака', 'сърдечно-съдова'], NULL, 'beginner', 'Поддържайте постоянно темпо', 'Започнете с 20-30 минути', true),
  ('Скачане на въже', 'Ефективно кардио', 'cardio', ARRAY['крака', 'сърдечно-съдова'], 'въже за скачане', 'intermediate', 'Скачайте на пръстите', 'Дръжте лактите близо до тялото', true)
ON CONFLICT (name) DO NOTHING;