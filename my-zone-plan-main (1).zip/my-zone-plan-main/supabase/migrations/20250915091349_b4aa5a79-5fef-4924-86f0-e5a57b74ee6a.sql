-- Add meal_group_id to weekly_meal_plans to support meal combinations
ALTER TABLE public.weekly_meal_plans 
ADD COLUMN meal_group_id uuid DEFAULT gen_random_uuid();

-- Create index for better performance when querying meal groups
CREATE INDEX idx_weekly_meal_plans_group_id ON public.weekly_meal_plans(meal_group_id);

-- Create a new dishes category for meal combinations
ALTER TYPE meal_type ADD VALUE IF NOT EXISTS 'combination';