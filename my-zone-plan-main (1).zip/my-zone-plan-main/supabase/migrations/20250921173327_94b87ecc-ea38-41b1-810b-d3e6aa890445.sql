-- Clean up duplicate push subscriptions, keeping only the newest one for each user+endpoint combination
WITH duplicates AS (
  SELECT id, 
         user_id, 
         endpoint,
         ROW_NUMBER() OVER (PARTITION BY user_id, endpoint ORDER BY created_at DESC) as rn
  FROM push_subscriptions 
  WHERE is_active = true
)
UPDATE push_subscriptions 
SET is_active = false 
WHERE id IN (
  SELECT id FROM duplicates WHERE rn > 1
);