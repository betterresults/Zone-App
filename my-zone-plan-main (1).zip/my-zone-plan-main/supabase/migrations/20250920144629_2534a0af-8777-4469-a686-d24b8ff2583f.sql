-- Add column to store how many minutes before the habit time to show reminder
ALTER TABLE public.habits 
ADD COLUMN reminder_minutes_before integer DEFAULT 15;