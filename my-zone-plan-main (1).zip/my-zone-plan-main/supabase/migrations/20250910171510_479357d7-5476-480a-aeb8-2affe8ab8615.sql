-- Clean up any partial admin user data first
DELETE FROM public.profiles WHERE email = 'admin@myzone.life';
DELETE FROM public.user_roles WHERE user_id IN (
  SELECT id FROM auth.users WHERE email = 'admin@myzone.life'
);

-- Use the existing make_user_admin function but first we need to create the user
-- Since we can't directly insert into auth.users, we'll create a simple admin setup
-- that can be triggered when the user signs up

-- Create a temporary admin setup record that we can use
CREATE TABLE IF NOT EXISTS admin_setup (
  email text PRIMARY KEY,
  password_hash text,
  created_at timestamp with time zone DEFAULT now()
);

-- Insert the admin credentials
INSERT INTO admin_setup (email, password_hash) 
VALUES ('admin@myzone.life', crypt('123456', gen_salt('bf')))
ON CONFLICT (email) DO UPDATE SET password_hash = EXCLUDED.password_hash;