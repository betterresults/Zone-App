-- Drop old referral system tables and functions completely

-- Drop triggers first
DROP TRIGGER IF EXISTS create_referral_code_trigger ON profiles;

-- Drop functions
DROP FUNCTION IF EXISTS public.generate_referral_code();
DROP FUNCTION IF EXISTS public.create_user_referral_code();
DROP FUNCTION IF EXISTS public.calculate_referral_rewards(uuid);

-- Drop tables (in correct order due to foreign keys)
DROP TABLE IF EXISTS public.referral_rewards CASCADE;
DROP TABLE IF EXISTS public.referrals CASCADE;  
DROP TABLE IF EXISTS public.user_referral_codes CASCADE;