-- Създаваме таблица за любими порции на продукти
CREATE TABLE public.favorite_portions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID, -- nullable за системни порции
  product_id UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  portion_name TEXT NOT NULL,
  grams NUMERIC NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.favorite_portions ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can view their own favorite portions and public portions" 
ON public.favorite_portions 
FOR SELECT 
USING (auth.uid() = user_id OR user_id IS NULL);

CREATE POLICY "Users can create their own favorite portions" 
ON public.favorite_portions 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own favorite portions" 
ON public.favorite_portions 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own favorite portions" 
ON public.favorite_portions 
FOR DELETE 
USING (auth.uid() = user_id);

-- Add trigger for automatic timestamp updates
CREATE TRIGGER update_favorite_portions_updated_at
BEFORE UPDATE ON public.favorite_portions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();