-- Add measurement unit to products table
ALTER TABLE public.products 
ADD COLUMN package_unit_type text DEFAULT 'пакет';

-- Update existing products to use appropriate units based on category
UPDATE public.products 
SET package_unit_type = CASE 
  WHEN category IN ('fruits', 'vegetables') THEN 'брой'
  WHEN category = 'dairy' THEN 'литър'
  WHEN category IN ('protein', 'grains', 'legumes', 'nuts') THEN 'пакет'
  WHEN category = 'other' THEN 'брой'
  ELSE 'пакет'
END;

-- Make the column not null after setting defaults
ALTER TABLE public.products 
ALTER COLUMN package_unit_type SET NOT NULL;