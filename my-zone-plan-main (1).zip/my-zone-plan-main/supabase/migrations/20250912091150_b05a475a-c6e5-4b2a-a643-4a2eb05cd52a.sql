-- Create theme settings table for dynamic color management
CREATE TABLE public.theme_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  colors JSONB NOT NULL DEFAULT '{}',
  is_active BOOLEAN NOT NULL DEFAULT false,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.theme_settings ENABLE ROW LEVEL SECURITY;

-- Only admins can manage themes
CREATE POLICY "Admins can manage themes" 
ON public.theme_settings 
FOR ALL 
USING (public.is_admin(auth.uid()));

-- Everyone can view active theme
CREATE POLICY "Everyone can view active theme" 
ON public.theme_settings 
FOR SELECT 
USING (is_active = true);

-- Create trigger for updated_at
CREATE TRIGGER update_theme_settings_updated_at
BEFORE UPDATE ON public.theme_settings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default theme
INSERT INTO public.theme_settings (name, is_active, colors) VALUES (
  'Зона диета - по подразбиране',
  true,
  '{
    "primary": "142 69% 58%",
    "primary_foreground": "0 0% 100%",
    "accent": "33 100% 65%",
    "accent_foreground": "0 0% 100%",
    "secondary": "45 25% 92%",
    "secondary_foreground": "210 15% 20%",
    "zone_protein": "160 60% 45%",
    "zone_carbs": "33 100% 65%",
    "zone_fat": "280 60% 65%",
    "zone_balanced": "142 69% 58%",
    "zone_warning": "45 93% 58%",
    "success": "142 69% 58%",
    "warning": "45 93% 58%",
    "destructive": "0 84.2% 60.2%"
  }'
);