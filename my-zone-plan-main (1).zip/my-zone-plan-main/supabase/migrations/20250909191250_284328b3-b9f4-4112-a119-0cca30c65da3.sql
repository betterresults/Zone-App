-- Create trigger to sync dish when it's created with a source_recipe_id
CREATE OR REPLACE FUNCTION public.sync_new_dish_from_recipe()
RETURNS TRIGGER AS $$
BEGIN
  -- If the dish is being created with a source_recipe_id, sync it immediately
  IF NEW.source_recipe_id IS NOT NULL THEN
    PERFORM public.sync_dish_from_recipe(NEW.id, NEW.source_recipe_id);
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Trigger to sync dish when created with source_recipe_id
CREATE TRIGGER trigger_sync_new_dish_from_recipe
  AFTER INSERT ON public.dishes
  FOR EACH ROW
  WHEN (NEW.source_recipe_id IS NOT NULL)
  EXECUTE FUNCTION public.sync_new_dish_from_recipe();

-- Also trigger sync when source_recipe_id is added/changed on existing dishes
CREATE TRIGGER trigger_sync_dish_on_recipe_link_change
  AFTER UPDATE OF source_recipe_id ON public.dishes
  FOR EACH ROW
  WHEN (NEW.source_recipe_id IS DISTINCT FROM OLD.source_recipe_id AND NEW.source_recipe_id IS NOT NULL)
  EXECUTE FUNCTION public.sync_new_dish_from_recipe();