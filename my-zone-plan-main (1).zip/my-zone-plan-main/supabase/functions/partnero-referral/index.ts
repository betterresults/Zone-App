import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const partneroApiKey = Deno.env.get('PARTNERO_API_KEY');
    if (!partneroApiKey) {
      console.error('PARTNERO_API_KEY not configured');
      return new Response(
        JSON.stringify({ error: 'API key not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const url = new URL(req.url);
    const action = url.pathname.split('/').pop();

    switch (action) {
      case 'create-partner':
        return await createPartner(req, supabaseClient, partneroApiKey);
      case 'get-referral-link':
        return await getReferralLink(req, supabaseClient, partneroApiKey);
      case 'get-stats':
        return await getReferralStats(req, partneroApiKey);
      case 'get-milestone-progress':
        return await getMilestoneProgress(req, partneroApiKey);
      case 'track-click':
        return await trackReferralClick(req, partneroApiKey);
      case 'track-signup':
        return await trackReferralSignup(req, supabaseClient, partneroApiKey);
      default:
        return new Response(
          JSON.stringify({ error: 'Invalid action' }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
    }
  } catch (error) {
    console.error('Error in partnero-referral function:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

async function trackReferralClick(req: Request, partneroApiKey: string) {
  const { referralCode } = await req.json();
  
  if (!referralCode) {
    return new Response(
      JSON.stringify({ error: 'Missing referral code' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
  
  try {
    console.log('Tracking referral click for code:', referralCode);
    
    // Extract customer ID from referral code (format: user_XXXXXXXX or ref_XXXXXXXX)
    let customerId = referralCode;
    if (referralCode.startsWith('user_') || referralCode.startsWith('ref_')) {
      customerId = referralCode.substring(5); // Remove prefix
    }
    
    // Track click in Partnero
    const clickResponse = await fetch(`https://api.partnero.com/v1/customers/${customerId}/clicks`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${partneroApiKey}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        source: 'web',
        user_agent: 'MyZone App',
        timestamp: new Date().toISOString()
      })
    });
    
    if (!clickResponse.ok) {
      const errorText = await clickResponse.text();
      console.error('Partnero click tracking error:', errorText);
      
      // Don't fail the request if click tracking fails
      return new Response(
        JSON.stringify({ success: true, warning: 'Click tracking failed but request processed' }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    
    const clickData = await clickResponse.json();
    console.log('Click tracked successfully:', clickData);
    
    return new Response(
      JSON.stringify({ success: true, data: clickData }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error tracking referral click:', error);
    return new Response(
      JSON.stringify({ success: true, warning: 'Click tracking failed but request processed' }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

async function trackReferralSignup(req: Request, supabaseClient: any, partneroApiKey: string) {
  const { referralCode, userId, email } = await req.json();
  
  if (!referralCode || !userId || !email) {
    return new Response(
      JSON.stringify({ error: 'Missing required parameters' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
  
  try {
    console.log('Tracking referral signup for:', { referralCode, userId, email });
    
    // Extract customer ID from referral code
    let referrerCustomerId = referralCode;
    if (referralCode.startsWith('user_') || referralCode.startsWith('ref_')) {
      referrerCustomerId = referralCode.substring(5);
    }
    
    // First create the new customer in Partnero
    const createCustomerResponse = await fetch('https://api.partnero.com/v1/customers', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${partneroApiKey}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        email: email,
        name: email.split('@')[0],
        status: 'active',
        referring_customer: referrerCustomerId
      })
    });
    
    if (createCustomerResponse.ok) {
      const customerData = await createCustomerResponse.json();
      const newCustomerId = customerData?.data?.id || customerData?.id;
      
      // Store the Partnero customer ID in our profiles table
      if (newCustomerId) {
        await supabaseClient
          .from('profiles')
          .update({ partnero_customer_id: newCustomerId })
          .eq('user_id', userId);
      }
      
      console.log('Referral signup tracked successfully:', customerData);
      
      return new Response(
        JSON.stringify({ success: true, data: customerData }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    } else {
      const errorText = await createCustomerResponse.text();
      console.error('Error creating referred customer:', errorText);
      
      return new Response(
        JSON.stringify({ success: true, warning: 'Signup tracking failed but user created' }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
  } catch (error) {
    console.error('Error tracking referral signup:', error);
    return new Response(
      JSON.stringify({ success: true, warning: 'Signup tracking failed but user created' }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

async function createPartner(req: Request, supabaseClient: any, partneroApiKey: string) {
  const { userId, email } = await req.json();

  if (!userId || !email) {
    return new Response(
      JSON.stringify({ error: 'Missing userId or email' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  // Create customer in Partnero
  const partneroResponse = await fetch('https://api.partnero.com/v1/customers', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${partneroApiKey}`,
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
    body: JSON.stringify({
      id: userId,
      key: `user_${userId.substring(0, 8)}`,
      email: email,
      name: email.split('@')[0],
      status: 'active'
    })
  });

  if (!partneroResponse.ok) {
    const errorText = await partneroResponse.text();
    console.error('Partnero API error:', errorText);
    return new Response(
      JSON.stringify({ error: 'Failed to create partner in Partnero', details: errorText }),
      { status: partneroResponse.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  const partneroData = await partneroResponse.json();
  console.log('Partner created in Partnero:', partneroData);

  return new Response(
    JSON.stringify({ success: true, partner: partneroData }),
    { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  );
}

async function getReferralLink(req: Request, supabaseClient: any, partneroApiKey: string) {
  const { userId, email } = await req.json();

  if (!userId) {
    return new Response(
      JSON.stringify({ error: 'Missing userId' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  console.log('Getting referral link for user:', userId, 'email:', email);

  try {
    // 1) Check if we have a stored Partnero customer ID
    const { data: profile } = await supabaseClient
      .from('profiles')
      .select('partnero_customer_id')
      .eq('user_id', userId)
      .single();

    let partneroCustomerId = profile?.partnero_customer_id;
    console.log('Stored Partnero customer ID:', partneroCustomerId);

    // 2) If no stored ID, search for customer by email
    if (!partneroCustomerId && email) {
      console.log('Searching for customer by email:', email);
      const searchResponse = await fetch(`https://api.partnero.com/v1/customers:search?email=${encodeURIComponent(email)}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${partneroApiKey}`,
          'Accept': 'application/json'
        }
      });

      if (searchResponse.ok) {
        const searchData = await searchResponse.json();
        const customers = searchData?.data || [];
        if (customers.length > 0) {
          partneroCustomerId = customers[0].id;
          console.log('Found existing customer ID:', partneroCustomerId);
          
          // Store the ID for future use
          await supabaseClient
            .from('profiles')
            .update({ partnero_customer_id: partneroCustomerId })
            .eq('user_id', userId);
        }
      }
    }

    // 3) If still no customer ID, create a new customer
    if (!partneroCustomerId) {
      console.log('Creating new Partnero customer');
      const createCustomerResponse = await fetch('https://api.partnero.com/v1/customers', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${partneroApiKey}`,
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          email: email,
          name: email?.split('@')[0] || 'User',
          status: 'active'
        })
      });

      if (!createCustomerResponse.ok) {
        const errorText = await createCustomerResponse.text();
        console.error('Failed to create Partnero customer:', errorText);
        return new Response(
          JSON.stringify({ error: 'Failed to create customer', details: errorText }),
          { status: createCustomerResponse.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const customerData = await createCustomerResponse.json();
      partneroCustomerId = customerData?.data?.id || customerData?.id;
      console.log('Created new customer with ID:', partneroCustomerId);

      // Store the new ID
      await supabaseClient
        .from('profiles')
        .update({ partnero_customer_id: partneroCustomerId })
        .eq('user_id', userId);
    }

    // 4) Fetch customer to get referral link
    console.log('Fetching customer to get referral link:', partneroCustomerId);
    const customerResp = await fetch(`https://api.partnero.com/v1/customers/${partneroCustomerId}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${partneroApiKey}`,
        'Accept': 'application/json'
      }
    });

    let referralLinkUrl: string | null = null;
    if (customerResp.ok) {
      const customerJson = await customerResp.json();
      referralLinkUrl = customerJson?.data?.referral_link || customerJson?.referral_link || null;
      console.log('Referral link from customer:', referralLinkUrl);
    } else {
      console.log('Failed to fetch customer:', await customerResp.text());
    }

    // 5) If still no link and we have email, try search by email
    if (!referralLinkUrl && email) {
      console.log('Searching customer by email for referral link');
      const searchResp = await fetch(`https://api.partnero.com/v1/customers:search?email=${encodeURIComponent(email)}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${partneroApiKey}`,
          'Accept': 'application/json'
        }
      });
      if (searchResp.ok) {
        const sData = await searchResp.json();
        const first = sData?.data?.[0];
        referralLinkUrl = first?.referral_link || null;
        if (first?.id && first.id !== partneroCustomerId) {
          partneroCustomerId = first.id;
          await supabaseClient
            .from('profiles')
            .update({ partnero_customer_id: partneroCustomerId })
            .eq('user_id', userId);
        }
      } else {
        console.log('Email search failed:', await searchResp.text());
      }
    }

    // 6) Prepare final URL
    const finalUrl = referralLinkUrl || '';
    console.log('Returning final URL:', finalUrl);

    return new Response(
      JSON.stringify({ success: true, referralLink: finalUrl, referralKey: partneroCustomerId }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in getReferralLink:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

async function getReferralStats(req: Request, partneroApiKey: string) {
  const { userId, partneroCustomerId: providedCustomerId, email } = await req.json();

  if (!userId && !providedCustomerId && !email) {
    return new Response(
      JSON.stringify({ error: 'Missing userId or partneroCustomerId or email' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  try {
    // Try to resolve Partnero customer ID
    let partneroCustomerId = providedCustomerId as string | undefined;

    if (!partneroCustomerId && userId) {
      const supabaseClient = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
      );
      const { data: profile } = await supabaseClient
        .from('profiles')
        .select('partnero_customer_id, email')
        .eq('user_id', userId)
        .maybeSingle();
      partneroCustomerId = profile?.partnero_customer_id || partneroCustomerId;
    }

    if (!partneroCustomerId && email) {
      const searchResponse = await fetch(`https://api.partnero.com/v1/customers:search?email=${encodeURIComponent(email)}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${partneroApiKey}`,
          'Accept': 'application/json'
        }
      });
      if (searchResponse.ok) {
        const searchData = await searchResponse.json();
        partneroCustomerId = searchData?.data?.[0]?.id;
      }
    }

    if (!partneroCustomerId) {
      return new Response(
        JSON.stringify({ error: 'Customer not found in Partnero' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch stats
    const statsResponse = await fetch(`https://api.partnero.com/v1/customers/${partneroCustomerId}/stats`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${partneroApiKey}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });

    if (!statsResponse.ok) {
      const errorText = await statsResponse.text();
      console.error('Partnero API error (stats):', errorText);
      return new Response(
        JSON.stringify({ error: 'Failed to get statistics', details: errorText }),
        { status: statsResponse.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const partneroData = await statsResponse.json();
    console.log('Customer stats:', partneroData);

    return new Response(
      JSON.stringify({ success: true, stats: partneroData }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (e) {
    console.error('Error in getReferralStats:', e);
    return new Response(
      JSON.stringify({ error: (e as Error).message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// Get milestone progress for refer-a-friend rewards
async function getMilestoneProgress(req: Request, partneroApiKey: string) {
  const { userId } = await req.json();

  if (!userId) {
    return new Response(
      JSON.stringify({ error: 'Missing userId' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Get stored Partnero customer ID
    const { data: profile } = await supabaseClient
      .from('profiles')
      .select('partnero_customer_id')
      .eq('user_id', userId)
      .single();

    const partneroCustomerId = profile?.partnero_customer_id;
    console.log('Getting milestone progress for Partnero customer:', partneroCustomerId);

    if (!partneroCustomerId) {
      // No Partnero customer ID found, return zero stats
      return new Response(JSON.stringify({
        totalReferrals: 0,
        clicks: 0,
        milestoneProgress: {
          current: 0,
          target: 3,
          nextReward: "1 безплатен месец",
          completed: 0
        },
        earnedRewards: [],
        referralLink: ''
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Get customer stats using Partnero customer ID
    const statsResponse = await fetch(`https://api.partnero.com/v1/customers/${partneroCustomerId}/stats`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${partneroApiKey}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });

    if (!statsResponse.ok) {
      if (statsResponse.status === 404) {
        // Customer not found in Partnero, return zero stats
        return new Response(JSON.stringify({
          totalReferrals: 0,
          clicks: 0,
          milestoneProgress: {
            current: 0,
            target: 3,
            nextReward: "1 безплатен месец",
            completed: 0
          },
          earnedRewards: [],
          referralLink: ''
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      const errorText = await statsResponse.text();
      console.error('Partnero stats API error:', errorText);
      throw new Error(`Partnero API error: ${statsResponse.status} ${statsResponse.statusText}`);
    }

    const statsData = await statsResponse.json();
    console.log('Partnero stats data:', statsData);
    
    // Get referrals for this customer
    const referralsResponse = await fetch(`https://api.partnero.com/v1/customers/${partneroCustomerId}/referrals`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${partneroApiKey}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });

    let referralsData = { data: [] };
    if (referralsResponse.ok) {
      referralsData = await referralsResponse.json();
      console.log('Partnero referrals data:', referralsData);
    } else {
      console.log('Failed to fetch referrals:', await referralsResponse.text());
    }

    // Get rewards for this customer
    const rewardsResponse = await fetch(`https://api.partnero.com/v1/customers/${partneroCustomerId}/rewards`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${partneroApiKey}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });

    let rewardsData = { data: [] };
    if (rewardsResponse.ok) {
      rewardsData = await rewardsResponse.json();
      console.log('Partnero rewards data:', rewardsData);
    } else {
      console.log('Failed to fetch rewards:', await rewardsResponse.text());
    }

    const statsRaw = statsData.data || statsData;
    const customer = statsRaw.customer || {};
    const referralsAgg = statsRaw.referrals || {};
    const refLinks = statsRaw.ref_links || [];

    // Derive clicks and signups
    let clicks = Number(referralsAgg.clicks ?? 0);
    if ((!clicks || Number.isNaN(clicks)) && Array.isArray(refLinks)) {
      clicks = refLinks.reduce((sum: number, l: any) => sum + Number(l?.clicks ?? 0), 0);
    }
    const signups = Number(referralsAgg.signups ?? 0);

    // Use signups as totalReferrals for milestone logic
    const totalReferrals = Number.isNaN(signups) ? 0 : signups;

    // Prefer direct customer ref link, then arrays from customer/ref_links
    const referralLink = (
      customer?.referral_link ||
      (Array.isArray(customer?.referral_links) && customer.referral_links[0]) ||
      (Array.isArray(refLinks) && (refLinks.find((l: any) => l?.default)?.url || refLinks[0]?.url)) ||
      ''
    );

    // Calculate milestone progress (every 3 referrals = 1 free month)
    const milestonesCompleted = Math.floor(totalReferrals / 3);
    const currentProgress = totalReferrals % 3;
    const nextTarget = 3;

    // Filter rewards related to referral milestones
    const earnedRewards = rewardsData.data?.filter((reward: any) => 
      reward.type === 'milestone' || reward.description?.toLowerCase()?.includes('referral')
    ).map((reward: any) => ({
      id: reward.id,
      description: reward.description || 'Безплатен месец',
      earnedAt: reward.created_at,
      value: reward.value || '1 месец'
    })) || [];

    console.log('Milestone progress calculated:', {
      totalReferrals,
      clicks,
      milestonesCompleted,
      currentProgress,
      earnedRewards: earnedRewards.length
    });

    return new Response(JSON.stringify({
      totalReferrals,
      clicks,
      milestoneProgress: {
        current: currentProgress,
        target: nextTarget,
        nextReward: "1 безплатен месец",
        completed: milestonesCompleted
      },
      earnedRewards,
      referralLink
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in getMilestoneProgress:', error);
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
}