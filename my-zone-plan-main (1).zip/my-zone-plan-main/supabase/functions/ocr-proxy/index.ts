import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Verify user authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Create Supabase client to verify user
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: authHeader },
        },
      }
    );

    // Verify user authentication
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      console.error('Authentication error:', userError);
      return new Response(
        JSON.stringify({ error: 'Invalid authentication' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const ocrApiKey = Deno.env.get('OCR_SPACE_API_KEY');
    
    if (!ocrApiKey) {
      console.error('OCR_SPACE_API_KEY not found');
      return new Response(JSON.stringify({ error: 'OCR API key not configured' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { imageDataUrl } = await req.json();
    
    if (!imageDataUrl) {
      return new Response(JSON.stringify({ error: 'No image data provided' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Validate image data URL format
    if (!imageDataUrl.startsWith('data:image/')) {
      return new Response(JSON.stringify({ error: 'Invalid image format' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Basic size check (limit to ~5MB base64)
    if (imageDataUrl.length > 7000000) {
      return new Response(JSON.stringify({ error: 'Image too large' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('Processing OCR request with OCR.space API');

    // Convert data URL to base64 string without the data URL prefix
    const base64Data = imageDataUrl.split(',')[1];
    
    const formData = new FormData();
    formData.append('apikey', ocrApiKey);
    formData.append('language', 'eng');
    formData.append('base64Image', `data:image/jpeg;base64,${base64Data}`);
    formData.append('detectOrientation', 'true');
    formData.append('scale', 'true');
    formData.append('OCREngine', '2');
    formData.append('isTable', 'true');

    const response = await fetch('https://api.ocr.space/parse/image', {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      console.error('OCR.space API error:', response.status, response.statusText);
      throw new Error(`OCR API error: ${response.status}`);
    }

    const result = await response.json();
    console.log('OCR.space API response:', JSON.stringify(result, null, 2));

    if (result.OCRExitCode !== 1 || !result.ParsedResults?.[0]?.ParsedText) {
      console.error('OCR failed:', result.ErrorMessage || 'No text found');
      return new Response(JSON.stringify({ 
        success: false, 
        error: result.ErrorMessage || 'No text could be extracted from the image'
      }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const extractedText = result.ParsedResults[0].ParsedText;
    console.log('Extracted text:', extractedText);

    return new Response(JSON.stringify({ 
      success: true, 
      text: extractedText 
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in ocr-proxy function:', error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: (error instanceof Error ? error.message : 'Unknown error') || 'OCR processing failed' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});