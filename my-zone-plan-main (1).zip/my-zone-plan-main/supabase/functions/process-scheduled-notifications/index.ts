import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface ScheduledNotification {
  id: string;
  user_id: string;
  notification_type: 'event' | 'habit';
  reference_id: string;
  scheduled_for: string;
  title: string;
  message: string;
  is_sent: boolean;
}

interface OneSignalNotification {
  headings: { [key: string]: string };
  contents: { [key: string]: string };
  target_channel: string;
  include_external_user_ids: string[];
  data?: { [key: string]: any };
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const oneSignalAppId = Deno.env.get('ONESIGNAL_APP_ID');
    const oneSignalApiKey = Deno.env.get('ONESIGNAL_REST_API_KEY');
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseServiceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!oneSignalAppId || !oneSignalApiKey) {
      console.error('Missing OneSignal configuration');
      return new Response(
        JSON.stringify({ error: 'OneSignal configuration missing' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!supabaseUrl || !supabaseServiceRoleKey) {
      console.error('Missing Supabase configuration');
      return new Response(
        JSON.stringify({ error: 'Supabase configuration missing' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Initialize Supabase client with service role key
    const supabase = createClient(supabaseUrl, supabaseServiceRoleKey);

    // Get current time with a small buffer (process notifications due in the next minute)
    const now = new Date();
    const bufferTime = new Date(now.getTime() + 60 * 1000); // 1 minute buffer

    console.log(`🔍 Checking for notifications due before: ${bufferTime.toISOString()}`);

    // Fetch pending notifications that are due
    const { data: notifications, error: fetchError } = await supabase
      .from('scheduled_notifications')
      .select('*')
      .eq('is_sent', false)
      .lte('scheduled_for', bufferTime.toISOString())
      .order('scheduled_for', { ascending: true })
      .limit(50); // Process max 50 notifications per run

    if (fetchError) {
      console.error('Error fetching notifications:', fetchError);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch notifications' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!notifications || notifications.length === 0) {
      console.log('📭 No pending notifications found');
      return new Response(
        JSON.stringify({ message: 'No pending notifications', count: 0 }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`📬 Found ${notifications.length} notifications to process`);

    let successCount = 0;
    let errorCount = 0;

    // Process each notification
    for (const notification of notifications as ScheduledNotification[]) {
      try {
        console.log(`📤 Processing notification ${notification.id} for user ${notification.user_id}`);
        
        if (notification.notification_type === 'habit') {
          // For habit notifications, use the send-habit-notification function
          const { error: habitError } = await supabase.functions.invoke('send-habit-notification', {
            body: {
              userId: notification.user_id,
              habitId: notification.reference_id,
              habitName: notification.title.replace('Напомняне за ', ''),
              habitColor: '#22C55E',
              durationMinutes: 45, // Default duration
              title: notification.title,
              message: notification.message
            }
          });
          
          if (habitError) {
            console.error(`❌ Failed to send habit notification ${notification.id}:`, habitError);
            errorCount++;
            continue;
          }
          
          console.log(`✅ Habit notification sent via send-habit-notification function`);
          
          // Mark notification as sent
          const { error: updateError } = await supabase
            .from('scheduled_notifications')
            .update({
              is_sent: true,
              sent_at: new Date().toISOString()
            })
            .eq('id', notification.id);

          if (updateError) {
            console.error(`❌ Failed to mark notification ${notification.id} as sent:`, updateError);
            errorCount++;
          } else {
            console.log(`✅ Notification ${notification.id} marked as sent`);
            successCount++;
          }
          
          continue;
        }

        // For non-habit notifications, use the original OneSignal flow
        const oneSignalPayload = {
          headings: { "en": notification.title },
          contents: { "en": notification.message },
          include_aliases: {
            "external_id": [notification.user_id]
          },
          target_channel: "push",
          data: {
            notification_type: notification.notification_type,
            reference_id: notification.reference_id,
            notification_id: notification.id
          }
        };

        // Send notification via OneSignal REST API v11+
        const oneSignalResponse = await fetch('https://api.onesignal.com/notifications', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Key ${oneSignalApiKey}`,
          },
          body: JSON.stringify({
            app_id: oneSignalAppId,
            ...oneSignalPayload
          }),
        });

        const oneSignalResult = await oneSignalResponse.json();

        if (oneSignalResponse.ok && oneSignalResult.id) {
          console.log(`✅ OneSignal notification sent successfully: ${oneSignalResult.id}`);
          
          // Mark notification as sent
          const { error: updateError } = await supabase
            .from('scheduled_notifications')
            .update({
              is_sent: true,
              sent_at: new Date().toISOString()
            })
            .eq('id', notification.id);

          if (updateError) {
            console.error(`❌ Failed to mark notification ${notification.id} as sent:`, updateError);
            errorCount++;
          } else {
            console.log(`✅ Notification ${notification.id} marked as sent`);
            successCount++;
          }
        } else {
          console.error(`❌ OneSignal API error for notification ${notification.id}:`, oneSignalResult);
          errorCount++;
        }
      } catch (error) {
        console.error(`❌ Error processing notification ${notification.id}:`, error);
        errorCount++;
      }
    }

    const result = {
      message: 'Notification processing completed',
      total: notifications.length,
      successful: successCount,
      errors: errorCount,
      timestamp: new Date().toISOString()
    };

    console.log(`📊 Processing summary:`, result);

    return new Response(
      JSON.stringify(result),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ Unexpected error in process-scheduled-notifications:', error);
    return new Response(
      JSON.stringify({ 
        error: 'Internal server error',
        details: error instanceof Error ? error.message : 'Unknown error' 
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});