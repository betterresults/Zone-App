import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log("🕒 Starting daily habits processing...");
    
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];
    
    console.log(`📅 Processing habits for date: ${yesterdayStr}`);
    
    // Get all active habits that should have been done yesterday
    const { data: habits, error: habitsError } = await supabase
      .from('habits')
      .select(`
        id,
        user_id,
        name,
        repeat_days,
        one_time_date,
        is_important,
        habit_type
      `)
      .eq('is_active', true);
    
    if (habitsError) {
      console.error("❌ Error fetching habits:", habitsError);
      throw habitsError;
    }
    
    console.log(`📋 Found ${habits?.length || 0} active habits`);
    
    const processedStats = [];
    
    for (const habit of habits || []) {
      // Check if habit should be active for yesterday
      const shouldBeActiveYesterday = isHabitActiveForDate(habit, yesterday);
      
      if (!shouldBeActiveYesterday) {
        continue;
      }
      
      // Check if already has a completion or stat record for yesterday
      const { data: existingCompletion } = await supabase
        .from('habit_completions')
        .select('id, completed_at')
        .eq('habit_id', habit.id)
        .eq('completion_date', yesterdayStr)
        .single();
      
      const { data: existingStat } = await supabase
        .from('habit_daily_stats')
        .select('id')
        .eq('habit_id', habit.id)
        .eq('date', yesterdayStr)
        .single();
      
      let status = 'missed';
      let completedAt = null;
      
      if (existingCompletion) {
        status = 'completed';
        completedAt = existingCompletion.completed_at || new Date().toISOString();
      }
      
      if (!existingStat) {
        // Create daily stat record
        const { data: newStat, error: statError } = await supabase
          .from('habit_daily_stats')
          .insert({
            user_id: habit.user_id,
            habit_id: habit.id,
            date: yesterdayStr,
            status,
            completed_at: completedAt
          })
          .select()
          .single();
        
        if (statError) {
          console.error(`❌ Error creating stat for habit ${habit.name}:`, statError);
          continue;
        }
        
        processedStats.push(newStat);
        console.log(`✅ Created ${status} stat for habit: ${habit.name}`);
        
        // If important task was missed, create it for today (max 3 per day)
        if (status === 'missed' && habit.is_important && habit.habit_type === 'task') {
          await handleImportantTaskRollover(supabase, habit, today);
        }
      }
    }
    
    console.log(`🎉 Processed ${processedStats.length} habit stats for ${yesterdayStr}`);
    
    return new Response(
      JSON.stringify({
        success: true,
        processed_date: yesterdayStr,
        processed_count: processedStats.length,
        message: `Successfully processed ${processedStats.length} habit stats`
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
    
  } catch (error) {
    console.error("❌ Error in process-daily-habits:", error);
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : 'Unknown error',
        success: false
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});

function isHabitActiveForDate(habit: any, date: Date): boolean {
  // For one-time habits, check if the date matches
  if (habit.one_time_date) {
    const oneTimeDate = new Date(habit.one_time_date);
    return oneTimeDate.toDateString() === date.toDateString();
  }
  
  // For recurring habits, check if the day is in repeat_days
  const dayOfWeek = date.getDay(); // 0 = Sunday, 1 = Monday, etc.
  const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const dayName = dayNames[dayOfWeek];
  
  return habit.repeat_days && habit.repeat_days.includes(dayName);
}

async function handleImportantTaskRollover(supabase: any, missedHabit: any, today: Date) {
  const todayStr = today.toISOString().split('T')[0];
  
  // Check how many important tasks user already has for today
  const { data: todayImportantTasks, error: countError } = await supabase
    .from('habits')
    .select('id')
    .eq('user_id', missedHabit.user_id)
    .eq('habit_type', 'task')
    .eq('is_important', true)
    .eq('is_active', true)
    .eq('one_time_date', todayStr);
  
  if (countError) {
    console.error("❌ Error counting today's important tasks:", countError);
    return;
  }
  
  if (todayImportantTasks && todayImportantTasks.length >= 3) {
    console.log(`⚠️ User already has 3 important tasks for today, skipping rollover for: ${missedHabit.name}`);
    return;
  }
  
  // Create new important task for today
  const { data: newTask, error: createError } = await supabase
    .from('habits')
    .insert({
      user_id: missedHabit.user_id,
      name: `📋 ${missedHabit.name}`,
      description: `Автоматично преместено от ${new Date(Date.now() - 24*60*60*1000).toLocaleDateString('bg-BG')}`,
      habit_type: 'task',
      is_important: true,
      one_time_date: todayStr,
      color: '#ef4444', // Red color for rolled over tasks
      category: 'important',
      repeat_days: [],
      is_active: true
    })
    .select()
    .single();
  
  if (createError) {
    console.error(`❌ Error creating rollover task for ${missedHabit.name}:`, createError);
  } else {
    console.log(`🔄 Created rollover important task: ${newTask.name}`);
  }
}