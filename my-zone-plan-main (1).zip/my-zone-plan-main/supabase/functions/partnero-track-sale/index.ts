import { serve } from "https://deno.land/std@0.190.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { customer_email, amount, currency, transaction_id } = await req.json();
    
    if (!customer_email || !amount || !transaction_id) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields' }), 
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    const partneroApiKey = Deno.env.get('PARTNERO_API_KEY');
    if (!partneroApiKey) {
      console.error('PARTNERO_API_KEY not configured');
      return new Response(
        JSON.stringify({ error: 'API key not configured' }), 
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Send sale data to Partnero API
    const partneroResponse = await fetch('https://api.partnero.com/v1/sales', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${partneroApiKey}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        customer_email: customer_email,
        transaction_id: transaction_id,
        amount: amount,
        currency: currency || 'BGN',
        product_name: 'Myzone Premium Subscription',
        commission_type: 'percentage', // or 'flat'
        commission_value: 30, // 30% commission
        status: 'confirmed'
      })
    });

    if (!partneroResponse.ok) {
      const errorText = await partneroResponse.text();
      console.error('Partnero API error:', errorText);
      return new Response(
        JSON.stringify({ 
          error: 'Failed to track sale with Partnero', 
          details: errorText 
        }), 
        { 
          status: partneroResponse.status, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    const partneroData = await partneroResponse.json();
    console.log('Sale tracked with Partnero:', partneroData);

    return new Response(
      JSON.stringify({ 
        success: true, 
        partnero_sale_id: partneroData.id,
        message: 'Sale tracked successfully' 
      }), 
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Error tracking sale:', error);
    return new Response(
      JSON.stringify({ 
        error: 'Internal server error', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }), 
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});