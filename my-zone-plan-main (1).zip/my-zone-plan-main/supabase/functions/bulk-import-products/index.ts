import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface Product {
  name: string;
  brand?: string;
  category: string;
  calories_per_100g: number;
  protein_per_100g: number;
  carbs_per_100g: number;
  fat_per_100g: number;
  fiber_per_100g: number;
  is_public?: boolean;
  image_url?: string;
}

// Function to download image and upload to Supabase storage
async function downloadAndUploadImage(imageUrl: string, fileName: string, supabaseClient: any): Promise<string | null> {
  try {
    console.log(`Downloading image from: ${imageUrl}`);
    
    const response = await fetch(imageUrl);
    if (!response.ok) {
      console.error(`Failed to download image: ${response.statusText}`);
      return null;
    }
    
    const contentType = response.headers.get('content-type') || 'image/jpeg';
    const arrayBuffer = await response.arrayBuffer();
    const fileExtension = contentType.includes('png') ? 'png' : 'jpg';
    const storageFileName = `${fileName}.${fileExtension}`;
    
    console.log(`Uploading image to storage: ${storageFileName}`);
    
    const { data, error } = await supabaseClient.storage
      .from('product-images')
      .upload(storageFileName, arrayBuffer, {
        contentType: contentType,
        upsert: true
      });
    
    if (error) {
      console.error('Storage upload error:', error);
      return null;
    }
    
    // Get public URL
    const { data: urlData } = supabaseClient.storage
      .from('product-images')
      .getPublicUrl(storageFileName);
    
    console.log(`Image uploaded successfully: ${urlData.publicUrl}`);
    return urlData.publicUrl;
    
  } catch (error) {
    console.error('Error downloading/uploading image:', error);
    return null;
  }
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const authHeader = req.headers.get('Authorization')!;
    const token = authHeader.replace('Bearer ', '');
    const { data: { user } } = await supabaseClient.auth.getUser(token);

    if (!user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check if user is admin
    const { data: userRoles } = await supabaseClient
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .single();

    if (!userRoles || userRoles.role !== 'admin') {
      return new Response(
        JSON.stringify({ error: 'Admin access required' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { csvData } = await req.json();
    console.log('Processing CSV data for bulk import');

    // Parse CSV data
    const lines = csvData.trim().split('\n');
    const headers = lines[0].split(',').map((h: string) => h.trim());
    
    const expectedHeaders = [
      'name', 'brand', 'category', 'calories_per_100g', 
      'protein_per_100g', 'carbs_per_100g', 'fat_per_100g', 
      'fiber_per_100g', 'is_public', 'image_url'
    ];

    // Validate headers
    const missingHeaders = expectedHeaders.filter(h => !headers.includes(h));
    if (missingHeaders.length > 0) {
      return new Response(
        JSON.stringify({ 
          error: 'Missing required headers',
          missing: missingHeaders,
          expected: expectedHeaders
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const products: Product[] = [];
    const errors: string[] = [];

    // Process each row
    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',').map((v: string) => v.trim());
      
      if (values.length < expectedHeaders.length) {
        errors.push(`Row ${i + 1}: Insufficient columns`);
        continue;
      }

      try {
        const imageUrl = values[headers.indexOf('image_url')] || '';
        
        const product: Product = {
          name: values[headers.indexOf('name')] || '',
          brand: values[headers.indexOf('brand')] || null,
          category: values[headers.indexOf('category')] || 'other',
          calories_per_100g: parseFloat(values[headers.indexOf('calories_per_100g')]) || 0,
          protein_per_100g: parseFloat(values[headers.indexOf('protein_per_100g')]) || 0,
          carbs_per_100g: parseFloat(values[headers.indexOf('carbs_per_100g')]) || 0,
          fat_per_100g: parseFloat(values[headers.indexOf('fat_per_100g')]) || 0,
          fiber_per_100g: parseFloat(values[headers.indexOf('fiber_per_100g')]) || 0,
          is_public: values[headers.indexOf('is_public')]?.toLowerCase() === 'true',
          image_url: imageUrl
        };

        // Validate required fields
        if (!product.name) {
          errors.push(`Row ${i + 1}: Name is required`);
          continue;
        }

        products.push(product);
      } catch (error) {
        errors.push(`Row ${i + 1}: ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
    }

    if (products.length === 0) {
      return new Response(
        JSON.stringify({ 
          error: 'No valid products to import',
          errors: errors
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Process image downloads for products with image URLs
    console.log('Processing image downloads...');
    const productsWithImages = [];
    
    for (const product of products) {
      let finalImageUrl = product.image_url;
      
      // If there's an image URL, download and upload it to our storage
      if (product.image_url && product.image_url.trim() !== '') {
        const fileName = `product_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
        const uploadedUrl = await downloadAndUploadImage(product.image_url, fileName, supabaseClient);
        if (uploadedUrl) {
          finalImageUrl = uploadedUrl;
        }
      }
      
      productsWithImages.push({
        ...product,
        image_url: finalImageUrl || null,
        user_id: user.id
      });
    }

    // Insert products into database
    const productsWithUserId = productsWithImages;

    const { data, error } = await supabaseClient
      .from('products')
      .insert(productsWithUserId)
      .select();

    if (error) {
      console.error('Database error:', error);
      return new Response(
        JSON.stringify({ error: 'Failed to import products', details: error.message }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Successfully imported ${data.length} products`);

    return new Response(
      JSON.stringify({ 
        success: true,
        imported: data.length,
        errors: errors.length > 0 ? errors : undefined,
        message: `Successfully imported ${data.length} products${errors.length > 0 ? ` with ${errors.length} errors` : ''}`
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in bulk import:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error', details: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});