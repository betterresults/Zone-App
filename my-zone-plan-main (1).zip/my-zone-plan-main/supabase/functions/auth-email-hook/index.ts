import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface AuthHookRequest {
  type: "signup" | "recovery" | "email_change" | "invite";
  email: string;
  token_hash?: string;
  confirmation_url?: string;
  recovery_url?: string;
  email_change_url?: string;
  invite_url?: string;
  user_id?: string;
  user_metadata?: {
    display_name?: string;
  };
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHookData: AuthHookRequest = await req.json();
    console.log("Auth hook received:", authHookData.type, "for", authHookData.email);

    // Create Supabase client for function invocation
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    let emailData;

    // Prepare email data based on the auth event type
    switch (authHookData.type) {
      case "signup":
        emailData = {
          email: authHookData.email,
          subject: "Добре дошли в MyZone.life - Потвърдете имейла си",
          template: "confirmation",
          confirmationLink: authHookData.confirmation_url || `https://app.myzone.life/auth`,
          displayName: authHookData.user_metadata?.display_name,
        };
        break;

      case "recovery":
        emailData = {
          email: authHookData.email,
          subject: "Възстановяване на парола - MyZone.life",
          template: "password-reset",
          resetLink: authHookData.recovery_url || `https://app.myzone.life/auth`,
        };
        break;

      case "email_change":
        emailData = {
          email: authHookData.email,
          subject: "Потвърдете новия си имейл - MyZone.life",
          template: "confirmation",
          confirmationLink: authHookData.email_change_url || `https://app.myzone.life/auth`,
        };
        break;

      case "invite":
        emailData = {
          email: authHookData.email,
          subject: "Поканени сте в MyZone.life",
          template: "welcome",
          displayName: authHookData.user_metadata?.display_name,
        };
        break;

      default:
        console.log("Unknown auth hook type:", authHookData.type);
        return new Response(JSON.stringify({ success: false, error: "Unknown hook type" }), {
          status: 400,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        });
    }

    // Call the send-admin-email function
    const { data, error } = await supabase.functions.invoke("send-admin-email", {
      body: emailData,
    });

    if (error) {
      console.error("Error calling send-admin-email:", error);
      return new Response(
        JSON.stringify({ success: false, error: error.message }),
        {
          status: 500,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    console.log("Email sent successfully via auth hook for:", authHookData.email);

    return new Response(JSON.stringify({ success: true, data }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });
  } catch (error: any) {
    console.error("Error in auth-email-hook function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);