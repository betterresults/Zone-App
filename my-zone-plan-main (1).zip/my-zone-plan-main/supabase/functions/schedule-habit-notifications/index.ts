// Edge Function: schedule-habit-notifications
// Schedules (or re-schedules) the next push notification for a habit by id.
// - Deletes existing unsent notifications for this habit
// - Creates a single upcoming scheduled_notifications record for the next occurrence

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface HabitRow {
  id: string;
  user_id: string;
  name: string;
  time_of_day: string | null;
  repeat_days: string[] | null;
  one_time_date: string | null; // date string
  reminder_enabled: boolean | null;
  reminder_minutes_before: number | null;
}

function toDateWithTime(base: Date, timeStr?: string | null): Date {
  const d = new Date(base);
  if (timeStr) {
    const [h, m] = timeStr.split(':').map((n) => Number(n));
    d.setHours(Number.isFinite(h) ? h : 9, Number.isFinite(m) ? m : 0, 0, 0);
  } else {
    d.setHours(9, 0, 0, 0);
  }
  return d;
}

Deno.serve(async (req) => {
  console.log('📥 schedule-habit-notifications invoked');
  
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const anonKey = Deno.env.get('SUPABASE_ANON_KEY');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!supabaseUrl || !anonKey || !serviceRoleKey) {
      return new Response(JSON.stringify({ error: 'Missing Supabase configuration' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey);
    const supabaseAuth = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: req.headers.get('Authorization') || '' } },
    });

    const { data: authData } = await supabaseAuth.auth.getUser();
    const authUser = authData?.user;
    if (!authUser) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { habitId } = (await req.json()) as { habitId?: string };
    console.log('📝 Received habitId:', habitId);
    if (!habitId) {
      return new Response(JSON.stringify({ error: 'habitId is required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Fetch habit
    const { data: habit, error: habitErr } = await supabaseAdmin
      .from('habits')
      .select('*')
      .eq('id', habitId)
      .single<HabitRow>();

    if (habitErr || !habit) {
      console.error('❌ Habit fetch error:', habitErr, 'habit:', habit);
      return new Response(JSON.stringify({ error: 'Habit not found' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Allow owner or admin
    let isAdmin = false;
    if (authUser.id !== habit.user_id) {
      const { data: roles, error: rolesErr } = await supabaseAdmin
        .from('user_roles')
        .select('role')
        .eq('user_id', authUser.id)
        .eq('role', 'admin');
      isAdmin = !rolesErr && Array.isArray(roles) && roles.length > 0;
      if (!isAdmin) {
        return new Response(JSON.stringify({ error: 'Forbidden' }), {
          status: 403,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
    }

    // Clear existing unsent notifications for this habit
    const { error: delErr } = await supabaseAdmin
      .from('scheduled_notifications')
      .delete()
      .eq('reference_id', habit.id)
      .eq('notification_type', 'habit')
      .eq('is_sent', false);
    if (delErr) console.warn('Delete existing notifications error:', delErr);

    // If reminders are disabled, nothing else to do
    if (!habit.reminder_enabled) {
      console.log('🔕 Reminders disabled for habit:', habit.id);
      return new Response(JSON.stringify({ message: 'Reminders disabled, cleared existing' }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Ensure user has push enabled
    const { data: profile, error: profErr } = await supabaseAdmin
      .from('profiles')
      .select('push_notifications_enabled')
      .eq('user_id', habit.user_id)
      .single<{ push_notifications_enabled: boolean }>();
    if (profErr || !profile?.push_notifications_enabled) {
      console.log('🔕 Push disabled for user or profile error:', profErr, profile);
      return new Response(JSON.stringify({ message: 'Push disabled for user, skipping scheduling' }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const now = new Date();
    const minutesBefore = habit.reminder_minutes_before ?? 15;

    let eventDateTime: Date | null = null;

    if (habit.one_time_date) {
      // One-time habit
      const date = new Date(habit.one_time_date);
      eventDateTime = toDateWithTime(date, habit.time_of_day);
      if (eventDateTime <= now) {
        eventDateTime = null; // already in the past
      }
    } else {
      // Recurring habit
      const repeatDays = Array.isArray(habit.repeat_days) ? habit.repeat_days : [];
      const dayMap: Record<string, number> = {
        sunday: 0, monday: 1, tuesday: 2, wednesday: 3, thursday: 4, friday: 5, saturday: 6,
      };

      // Find the next occurrence within the next 7 days
      for (let i = 0; i < 7; i++) {
        const d = new Date(now);
        d.setDate(d.getDate() + i);
        const dow = d.getDay();
        const dayName = Object.keys(dayMap).find((k) => dayMap[k] === dow);
        if (dayName && repeatDays.includes(dayName)) {
          const candidate = toDateWithTime(d, habit.time_of_day);
          const notifyAt = new Date(candidate);
          notifyAt.setMinutes(notifyAt.getMinutes() - minutesBefore);
          if (notifyAt > now) {
            eventDateTime = candidate;
            break;
          }
        }
      }

      // Fallback: daily next occurrence if repeat_days missing
      if (!eventDateTime) {
        const d = toDateWithTime(new Date(now), habit.time_of_day);
        if (d <= now) d.setDate(d.getDate() + 1);
        eventDateTime = d;
      }
    }

    if (!eventDateTime) {
      console.log('⏰ No upcoming occurrence to schedule for habit:', habit.id);
      return new Response(JSON.stringify({ message: 'No upcoming occurrence to schedule' }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const scheduledFor = new Date(eventDateTime);
    scheduledFor.setMinutes(scheduledFor.getMinutes() - minutesBefore);

    console.log('📅 Scheduling notification for:', scheduledFor.toISOString(), 'habit:', habit.name);

    const title = `Напомняне за ${habit.name}`;
    const message = `Време е за ${habit.name}!`;

    const { error: insErr } = await supabaseAdmin.from('scheduled_notifications').insert({
      user_id: habit.user_id,
      notification_type: 'habit',
      reference_id: habit.id,
      scheduled_for: scheduledFor.toISOString(),
      title,
      message,
    });

    if (insErr) {
      console.error('❌ Insert error:', insErr);
      return new Response(JSON.stringify({ error: 'Failed to insert notification' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('✅ Successfully scheduled notification for:', scheduledFor.toISOString());
    return new Response(JSON.stringify({ scheduled_for: scheduledFor.toISOString() }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (e) {
    console.error('Unhandled error:', e);
    return new Response(JSON.stringify({ error: 'Internal error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
