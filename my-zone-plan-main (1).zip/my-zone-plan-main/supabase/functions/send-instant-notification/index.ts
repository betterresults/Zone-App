import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface OneSignalNotification {
  app_id: string;
  include_aliases?: {
    external_id: string[];
  };
  include_subscription_ids?: string[];
  headings: Record<string, string>;
  contents: Record<string, string>;
  data?: any;
}

serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Get environment variables
    const oneSignalAppId = Deno.env.get('ONESIGNAL_APP_ID');
    const oneSignalApiKey = Deno.env.get('ONESIGNAL_REST_API_KEY');
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!oneSignalAppId || !oneSignalApiKey || !supabaseUrl || !supabaseServiceKey) {
      throw new Error('Missing required environment variables');
    }

    // Initialize Supabase client
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { title = 'Тест нотификация', message = 'Това е тест нотификация от Lovable!', userId } = await req.json();

    let oneSignalPayload: OneSignalNotification;

    if (userId) {
      // Send to specific user
      oneSignalPayload = {
        app_id: oneSignalAppId,
        include_aliases: {
          external_id: [userId]
        },
        headings: { en: title },
        contents: { en: message },
        data: { 
          type: 'test',
          timestamp: new Date().toISOString()
        }
      };
    } else {
      // Send to all subscribers
      const { data: profiles, error } = await supabase
        .from('profiles')
        .select('user_id')
        .limit(100);

      if (error) {
        throw error;
      }

      if (!profiles || profiles.length === 0) {
        return new Response(
          JSON.stringify({ 
            success: false, 
            message: 'No users found' 
          }),
          { 
            status: 404, 
            headers: { 'Content-Type': 'application/json', ...corsHeaders } 
          }
        );
      }

      oneSignalPayload = {
        app_id: oneSignalAppId,
        include_aliases: {
          external_id: profiles.map(p => p.user_id)
        },
        headings: { en: title },
        contents: { en: message },
        data: { 
          type: 'test',
          timestamp: new Date().toISOString()
        }
      };
    }

    console.log('📤 Sending instant notification:', {
      title,
      message,
      targets: userId ? `user ${userId}` : `${oneSignalPayload.include_aliases?.external_id.length} users`
    });

    // Send notification via OneSignal API
    const oneSignalResponse = await fetch('https://onesignal.com/api/v1/notifications', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Basic ${oneSignalApiKey}`,
      },
      body: JSON.stringify(oneSignalPayload),
    });

    const oneSignalResult = await oneSignalResponse.json();

    if (!oneSignalResponse.ok) {
      console.error('❌ OneSignal API error:', oneSignalResult);
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: oneSignalResult,
          message: 'Failed to send notification'
        }),
        { 
          status: 400, 
          headers: { 'Content-Type': 'application/json', ...corsHeaders } 
        }
      );
    }

    // Treat 200 with zero recipients or errors as a partial/failed send
    const recipients = Number(oneSignalResult?.recipients ?? oneSignalResult?.successful ?? 0);
    const hasErrors = !!oneSignalResult?.errors && (Array.isArray(oneSignalResult.errors)
      ? oneSignalResult.errors.length > 0
      : Object.keys(oneSignalResult.errors || {}).length > 0);

    if (recipients === 0 || hasErrors) {
      console.warn('⚠️ Notification sent with issues:', { recipients, errors: oneSignalResult?.errors });
      return new Response(
        JSON.stringify({ 
          success: false,
          partial: true,
          oneSignalResponse: oneSignalResult,
          message: 'Notification sent with issues',
        }),
        { 
          status: 207, 
          headers: { 'Content-Type': 'application/json', ...corsHeaders } 
        }
      );
    }

    console.log('✅ Notification sent successfully:', oneSignalResult);

    return new Response(
      JSON.stringify({ 
        success: true, 
        oneSignalResponse: oneSignalResult,
        message: 'Notification sent successfully'
      }),
      { 
        headers: { 'Content-Type': 'application/json', ...corsHeaders } 
      }
    );

  } catch (error: any) {
    console.error('❌ Error sending instant notification:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      { 
        status: 500, 
        headers: { 'Content-Type': 'application/json', ...corsHeaders } 
      }
    );
  }
});