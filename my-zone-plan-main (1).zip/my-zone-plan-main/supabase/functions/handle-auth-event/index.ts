import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.2';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    const authEvent = await req.json();
    console.log('Auth event received:', authEvent);

    // Handle user signup event
    if (authEvent.type === 'user.created') {
      const user = authEvent.user;
      
      // Check if this is a beta signup based on metadata
      const isBetaUser = user.user_metadata?.beta_signup === true;
      
      if (isBetaUser) {
        console.log('Creating beta subscriber for user:', user.id);
        
        // Create subscriber record for beta user
        const { error: subscriberError } = await supabaseAdmin
          .from('subscribers')
          .insert({
            user_id: user.id,
            email: user.email,
            subscribed: true,
            subscription_tier: 'pro',
            subscription_end: new Date(Date.now() + 6 * 30 * 24 * 60 * 60 * 1000).toISOString(), // 6 months
            subscription_source: 'beta'
          });

        if (subscriberError) {
          console.error('Error creating subscriber:', subscriberError);
        } else {
          console.log('Beta subscriber created successfully');
        }
      }
    }

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });
  } catch (error: any) {
    console.error("Error in handle-auth-event function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);