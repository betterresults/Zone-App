import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!supabaseUrl || !supabaseServiceKey) {
      throw new Error('Missing Supabase environment variables');
    }

    // Initialize Supabase client
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Parse URL parameters for GET requests (when OneSignal button is clicked)
    const url = new URL(req.url);
    const action = url.searchParams.get('action');
    const ml = url.searchParams.get('ml');
    const userId = url.searchParams.get('userId');

    if (!action || !ml || !userId) {
      throw new Error('Missing required parameters');
    }

    const volumeMl = parseInt(ml);
    if (isNaN(volumeMl) || volumeMl <= 0) {
      throw new Error('Invalid volume amount');
    }

    console.log('💧 Processing hydration action:', {
      action,
      volumeMl,
      userId
    });

    if (action === 'add') {
      // Add hydration intake to database
      const { data, error } = await supabase
        .from('hydration_intakes')
        .insert({
          user_id: userId,
          volume_ml: volumeMl,
          beverage_type: 'water',
          intake_at: new Date().toISOString(),
          note: `Добавено чрез нотификация (+${volumeMl}мл)`
        })
        .select()
        .single();

      if (error) {
        console.error('❌ Database error:', error);
        throw error;
      }

      console.log('✅ Hydration intake recorded:', data);

      // Return a simple success page that can be displayed in browser
      const successPage = `
        <!DOCTYPE html>
        <html>
        <head>
          <title>Записано!</title>
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <style>
            body {
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
              text-align: center;
              padding: 2rem;
              background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
              color: white;
              margin: 0;
              min-height: 100vh;
              display: flex;
              align-items: center;
              justify-content: center;
            }
            .container {
              background: rgba(255, 255, 255, 0.1);
              padding: 2rem;
              border-radius: 16px;
              backdrop-filter: blur(10px);
            }
            .icon { font-size: 4rem; margin-bottom: 1rem; }
            h1 { margin: 0.5rem 0; }
            p { opacity: 0.9; margin-bottom: 1.5rem; }
            .amount { 
              font-size: 1.5rem; 
              font-weight: bold; 
              color: #4ade80;
              margin: 1rem 0;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="icon">💧</div>
            <h1>Записано успешно!</h1>
            <div class="amount">+${volumeMl}мл вода</div>
            <p>Приемът на течности е добавен в дневника ви.</p>
            <small>Можете да затворите този прозорец.</small>
          </div>
        </body>
        </html>
      `;

      return new Response(successPage, {
        headers: { 
          'Content-Type': 'text/html; charset=utf-8',
          ...corsHeaders 
        }
      });
    }

    throw new Error('Unknown action');

  } catch (error: any) {
    console.error('❌ Error handling hydration action:', error);
    
    const errorPage = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Грешка</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
          body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            text-align: center;
            padding: 2rem;
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            color: white;
            margin: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
          }
          .container {
            background: rgba(255, 255, 255, 0.1);
            padding: 2rem;
            border-radius: 16px;
            backdrop-filter: blur(10px);
          }
          .icon { font-size: 4rem; margin-bottom: 1rem; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="icon">❌</div>
          <h1>Възникна грешка</h1>
          <p>Не успяхме да запишем приема на течности.</p>
          <small>Моля, опитайте отново или използвайте приложението.</small>
        </div>
      </body>
      </html>
    `;

    return new Response(errorPage, {
      status: 500,
      headers: { 
        'Content-Type': 'text/html; charset=utf-8',
        ...corsHeaders 
      }
    });
  }
});