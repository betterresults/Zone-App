import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface HydrationNotificationPayload {
  userId: string;
  title: string;
  message: string;
  currentMl?: number;
  goalMl?: number;
}

serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Get environment variables
    const oneSignalAppId = Deno.env.get('ONESIGNAL_APP_ID');
    const oneSignalApiKey = Deno.env.get('ONESIGNAL_REST_API_KEY');
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!oneSignalAppId || !oneSignalApiKey || !supabaseUrl || !supabaseServiceKey) {
      throw new Error('Missing required environment variables');
    }

    // Initialize Supabase client
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { userId, title, message, currentMl = 0, goalMl = 2000 }: HydrationNotificationPayload = await req.json();

    if (!userId) {
      throw new Error('userId is required');
    }

    // Calculate progress percentage
    const progressPercent = Math.round((currentMl / goalMl) * 100);

    console.log('💧 Sending hydration notification:', {
      userId,
      title,
      message,
      currentMl,
      goalMl,
      progressPercent
    });

     // OneSignal notification with action buttons
    const oneSignalPayload = {
      app_id: oneSignalAppId,
      target_channel: 'push',
      include_aliases: {
        external_id: [userId]
      },
      headings: { en: title },
      contents: { en: message },
      data: { 
        type: 'hydration',
        currentMl,
        goalMl,
        progressPercent,
        timestamp: new Date().toISOString()
      },
      // Web-specific configuration
      web_url: `https://cmznrqtrtwohclokilkv.supabase.co/?action=open_hydration`,
      // Action buttons for web push (different from mobile)
      web_buttons: [
        {
          id: 'add_200ml',
          text: '🥤 +200мл',
          url: `https://cmznrqtrtwohclokilkv.supabase.co/?action=add_water&ml=200`
        },
        {
          id: 'add_500ml',
          text: '🍶 +500мл', 
          url: `https://cmznrqtrtwohclokilkv.supabase.co/?action=add_water&ml=500`
        }
      ]
    };

    // Send notification via OneSignal API
    const oneSignalResponse = await fetch('https://onesignal.com/api/v1/notifications', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Basic ${oneSignalApiKey}`,
      },
      body: JSON.stringify(oneSignalPayload),
    });

    const oneSignalResult = await oneSignalResponse.json();

    if (!oneSignalResponse.ok) {
      console.error('❌ OneSignal API error:', oneSignalResult);
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: oneSignalResult,
          message: 'Failed to send hydration notification'
        }),
        { 
          status: 400, 
          headers: { 'Content-Type': 'application/json', ...corsHeaders } 
        }
      );
    }

    console.log('✅ Hydration notification sent successfully:', oneSignalResult);

    // Add more debug info about the actual delivery
    console.log('📊 OneSignal response details:', {
      id: oneSignalResult.id,
      recipients: oneSignalResult.recipients || 0,
      external_id_count: oneSignalResult.external_id_count || 0,
      errors: oneSignalResult.errors || 'none'
    });

    return new Response(
      JSON.stringify({ 
        success: true, 
        oneSignalResponse: oneSignalResult,
        message: 'Hydration notification sent successfully'
      }),
      { 
        headers: { 'Content-Type': 'application/json', ...corsHeaders } 
      }
    );

  } catch (error: any) {
    console.error('❌ Error sending hydration notification:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      { 
        status: 500, 
        headers: { 'Content-Type': 'application/json', ...corsHeaders } 
      }
    );
  }
});