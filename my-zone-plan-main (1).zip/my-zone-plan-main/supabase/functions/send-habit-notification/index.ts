import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface HabitNotificationPayload {
  userId: string;
  habitId: string;
  habitName: string;
  habitColor: string;
  durationMinutes?: number;
  title: string;
  message: string;
}

serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Get environment variables
    const oneSignalAppId = Deno.env.get('ONESIGNAL_APP_ID');
    const oneSignalApiKey = Deno.env.get('ONESIGNAL_REST_API_KEY');

    if (!oneSignalAppId || !oneSignalApiKey) {
      throw new Error('Missing required environment variables');
    }

    const { 
      userId, 
      habitId, 
      habitName, 
      habitColor, 
      durationMinutes, 
      title, 
      message 
    }: HabitNotificationPayload = await req.json();

    if (!userId || !habitId || !habitName) {
      throw new Error('userId, habitId and habitName are required');
    }

    console.log('🎯 Sending habit notification:', {
      userId,
      habitId,
      habitName,
      durationMinutes,
      title,
      message
    });

    // OneSignal notification with action buttons
    const oneSignalPayload = {
      app_id: oneSignalAppId,
      target_channel: 'push',
      include_aliases: {
        external_id: [userId]
      },
      headings: { en: title },
      contents: { en: message },
      data: { 
        type: 'habit',
        habitId,
        habitName,
        habitColor,
        durationMinutes,
        timestamp: new Date().toISOString()
      },
      // Web-specific configuration
      web_url: `https://cmznrqtrtwohclokilkv.supabase.co/habits`,
      // Action buttons for web push
      web_buttons: durationMinutes ? [
        {
          id: 'start_habit',
          text: `▶️ Започни ${habitName}`,
          url: `https://cmznrqtrtwohclokilkv.supabase.co/?action=start_habit&habit_id=${habitId}&duration=${durationMinutes}`
        }
      ] : [
        {
          id: 'open_habits',
          text: '📋 Отвори навици',
          url: `https://cmznrqtrtwohclokilkv.supabase.co/habits`
        }
      ]
    };

    // Send notification via OneSignal API
    const oneSignalResponse = await fetch('https://onesignal.com/api/v1/notifications', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Basic ${oneSignalApiKey}`,
      },
      body: JSON.stringify(oneSignalPayload),
    });

    const oneSignalResult = await oneSignalResponse.json();

    if (!oneSignalResponse.ok) {
      console.error('❌ OneSignal API error:', oneSignalResult);
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: oneSignalResult,
          message: 'Failed to send habit notification'
        }),
        { 
          status: 400, 
          headers: { 'Content-Type': 'application/json', ...corsHeaders } 
        }
      );
    }

    console.log('✅ Habit notification sent successfully:', oneSignalResult);

    return new Response(
      JSON.stringify({ 
        success: true, 
        oneSignalResponse: oneSignalResult,
        message: 'Habit notification sent successfully'
      }),
      { 
        headers: { 'Content-Type': 'application/json', ...corsHeaders } 
      }
    );

  } catch (error: any) {
    console.error('❌ Error sending habit notification:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      { 
        status: 500, 
        headers: { 'Content-Type': 'application/json', ...corsHeaders } 
      }
    );
  }
});