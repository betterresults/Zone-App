import { serve } from "https://deno.land/std@0.190.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { email, first_name, last_name } = await req.json();
    
    if (!email) {
      return new Response(
        JSON.stringify({ error: 'Email is required' }), 
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    const partneroApiKey = Deno.env.get('PARTNERO_API_KEY');
    if (!partneroApiKey) {
      console.error('PARTNERO_API_KEY not configured');
      return new Response(
        JSON.stringify({ error: 'API key not configured' }), 
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Send customer data to Partnero API
    const partneroResponse = await fetch('https://api.partnero.com/v1/customers', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${partneroApiKey}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        email: email,
        first_name: first_name || '',
        last_name: last_name || '',
        status: 'active'
      })
    });

    if (!partneroResponse.ok) {
      const errorText = await partneroResponse.text();
      console.error('Partnero API error:', errorText);
      return new Response(
        JSON.stringify({ 
          error: 'Failed to track signup with Partnero', 
          details: errorText 
        }), 
        { 
          status: partneroResponse.status, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    const partneroData = await partneroResponse.json();
    console.log('Signup tracked with Partnero:', partneroData);

    return new Response(
      JSON.stringify({ 
        success: true, 
        partnero_customer_id: partneroData.id,
        message: 'Signup tracked successfully' 
      }), 
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Error tracking signup:', error);
    return new Response(
      JSON.stringify({ 
        error: 'Internal server error', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }), 
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});