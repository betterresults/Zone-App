import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Link,
  Preview,
  Text,
  Section,
} from 'npm:@react-email/components@0.0.22'
import * as React from 'npm:react@18.3.1'

interface EmailConfirmationProps {
  confirmationLink: string
  email: string
}

export const EmailConfirmation = ({
  confirmationLink,
  email,
}: EmailConfirmationProps) => (
  <Html>
    <Head />
    <Preview>Потвърдете вашия имейл за MyZone.life ✅</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <Heading style={h1}>✅ Потвърдете имейла си</Heading>
        </Section>
        
        <Section style={content}>
          <Text style={greeting}>
            Здравейте! 👋
          </Text>
          
          <Text style={text}>
            Благодарим ви, che се регистрирахте в MyZone.life! За да завършите регистрацията си, моля потвърдете вашия имейл адрес.
          </Text>

          <Section style={infoSection}>
            <Text style={infoText}>
              📧 Имейл адрес: <strong>{email}</strong>
            </Text>
          </Section>

          <Section style={ctaSection}>
            <Link
              href={confirmationLink}
              style={button}
            >
              Потвърдете имейла 🚀
            </Link>
          </Section>

          <Text style={linkText}>
            Или копирайте и поставете този линк в браузъра си:
          </Text>
          <Text style={linkUrl}>
            {confirmationLink}
          </Text>

          <Section style={benefitsSection}>
            <Heading style={h2}>🎯 След потвърждението ще можете да:</Heading>
            <Text style={bulletPoint}>🔐 Влизате в акаунта си</Text>
            <Text style={bulletPoint}>🥗 Планирате вашето зоново хранене</Text>
            <Text style={bulletPoint}>📊 Проследявате напредъка си</Text>
            <Text style={bulletPoint}>💧 Следите хидратацията си</Text>
            <Text style={bulletPoint}>🏃‍♀️ Записвате тренировки</Text>
          </Section>

          <Text style={expiryText}>
            ⏰ Този линк е валиден за 24 часа.
          </Text>
        </Section>

        <Section style={footer}>
          <Text style={footerText}>
            С уважение,<br />
            Екипът на MyZone.life
          </Text>
          <Text style={footerLink}>
            <Link href="https://app.myzone.life" style={link}>
              app.myzone.life
            </Link>
          </Text>
        </Section>
      </Container>
    </Body>
  </Html>
)

export default EmailConfirmation

const main = {
  background: 'linear-gradient(135deg, hsl(142, 69%, 98%) 0%, hsl(200, 30%, 98%) 100%)',
  fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
  minHeight: '100vh',
  padding: '20px 0',
}

const container = {
  margin: '0 auto',
  padding: '0',
  maxWidth: '600px',
  backgroundColor: '#ffffff',
  borderRadius: '20px',
  boxShadow: '0 20px 60px rgba(0, 0, 0, 0.08), 0 8px 25px rgba(0, 0, 0, 0.06)',
  overflow: 'hidden',
}

const header = {
  background: 'linear-gradient(135deg, hsl(142, 69%, 58%) 0%, hsl(142, 69%, 40%) 100%)',
  textAlign: 'center' as const,
  padding: '40px 24px',
  position: 'relative' as const,
}

const h1 = {
  color: '#ffffff',
  fontSize: '36px',
  fontWeight: '800',
  lineHeight: '1.2',
  margin: '0',
  textAlign: 'center' as const,
  textShadow: '0 2px 8px rgba(0, 0, 0, 0.15)',
}

const h2 = {
  background: 'linear-gradient(135deg, hsl(142, 69%, 58%), hsl(142, 69%, 75%))',
  WebkitBackgroundClip: 'text',
  WebkitTextFillColor: 'transparent',
  backgroundClip: 'text',
  fontSize: '24px',
  fontWeight: '700',
  lineHeight: '1.3',
  margin: '20px 0 16px 0',
  textAlign: 'center' as const,
}

const content = {
  padding: '40px 32px',
}

const greeting = {
  color: 'hsl(210, 20%, 15%)',
  fontSize: '20px',
  lineHeight: '1.5',
  margin: '0 0 20px 0',
  fontWeight: '600',
  textAlign: 'center' as const,
}

const text = {
  color: 'hsl(210, 15%, 25%)',
  fontSize: '17px',
  lineHeight: '1.7',
  margin: '20px 0',
  textAlign: 'center' as const,
}

const infoSection = {
  background: 'linear-gradient(135deg, hsl(142, 69%, 96%) 0%, hsl(142, 69%, 92%) 100%)',
  borderRadius: '16px',
  padding: '24px',
  margin: '32px 0',
  border: '2px solid hsl(142, 69%, 85%)',
  boxShadow: '0 8px 25px rgba(76, 175, 80, 0.12)',
}

const infoText = {
  color: 'hsl(142, 69%, 20%)',
  fontSize: '18px',
  lineHeight: '1.6',
  margin: '0',
  textAlign: 'center' as const,
  fontWeight: '600',
}

const benefitsSection = {
  background: 'linear-gradient(135deg, hsl(45, 85%, 97%) 0%, hsl(45, 85%, 94%) 100%)',
  borderRadius: '16px',
  padding: '32px',
  margin: '32px 0',
  border: '2px solid hsl(45, 85%, 80%)',
  boxShadow: '0 8px 25px rgba(255, 193, 7, 0.15)',
}

const bulletPoint = {
  color: 'hsl(210, 20%, 15%)',
  fontSize: '17px',
  lineHeight: '1.7',
  margin: '12px 0',
  padding: '8px 0',
  fontWeight: '500',
}

const ctaSection = {
  textAlign: 'center' as const,
  margin: '40px 0',
  padding: '20px 0',
}

const button = {
  background: 'linear-gradient(135deg, hsl(142, 69%, 58%) 0%, hsl(142, 69%, 48%) 100%)',
  borderRadius: '12px',
  color: '#ffffff',
  fontSize: '18px',
  fontWeight: '700',
  textDecoration: 'none',
  textAlign: 'center' as const,
  display: 'inline-block',
  padding: '18px 36px',
  boxShadow: '0 12px 35px rgba(76, 175, 80, 0.35), 0 4px 15px rgba(76, 175, 80, 0.25)',
  textShadow: '0 1px 3px rgba(0, 0, 0, 0.2)',
  transition: 'all 0.3s ease',
  border: 'none',
}

const linkText = {
  color: 'hsl(210, 15%, 50%)',
  fontSize: '15px',
  lineHeight: '1.6',
  margin: '30px 0 12px 0',
  textAlign: 'center' as const,
  fontWeight: '500',
}

const linkUrl = {
  color: 'hsl(142, 69%, 45%)',
  fontSize: '14px',
  lineHeight: '1.6',
  margin: '0 0 30px 0',
  textAlign: 'center' as const,
  wordBreak: 'break-all' as const,
  padding: '16px 20px',
  background: 'linear-gradient(135deg, hsl(45, 85%, 97%) 0%, hsl(45, 85%, 94%) 100%)',
  borderRadius: '10px',
  border: '2px solid hsl(45, 85%, 85%)',
  fontFamily: 'Monaco, Consolas, "Courier New", monospace',
  fontWeight: '500',
}

const expiryText = {
  color: 'hsl(210, 15%, 45%)',
  fontSize: '15px',
  lineHeight: '1.6',
  margin: '30px 0 0 0',
  textAlign: 'center' as const,
  fontStyle: 'italic',
  fontWeight: '500',
  padding: '12px 20px',
  backgroundColor: 'hsl(45, 85%, 96%)',
  borderRadius: '8px',
  border: '1px solid hsl(45, 85%, 88%)',
}

const footer = {
  background: 'linear-gradient(135deg, hsl(210, 15%, 98%) 0%, hsl(210, 15%, 96%) 100%)',
  textAlign: 'center' as const,
  margin: '0',
  padding: '32px 24px',
  borderTop: '2px solid hsl(210, 15%, 92%)',
}

const footerText = {
  color: 'hsl(210, 15%, 40%)',
  fontSize: '15px',
  lineHeight: '1.6',
  margin: '0 0 12px 0',
  fontWeight: '500',
}

const footerLink = {
  margin: '12px 0 0 0',
}

const link = {
  background: 'linear-gradient(135deg, hsl(142, 69%, 58%), hsl(142, 69%, 75%))',
  WebkitBackgroundClip: 'text',
  WebkitTextFillColor: 'transparent',
  backgroundClip: 'text',
  textDecoration: 'none',
  fontSize: '15px',
  fontWeight: '600',
}