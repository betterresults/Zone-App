import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Link,
  Preview,
  Text,
  Section,
} from 'npm:@react-email/components@0.0.22'
import * as React from 'npm:react@18.3.1'

interface PasswordResetEmailProps {
  resetLink: string
  email: string
}

export const PasswordResetEmail = ({
  resetLink,
  email,
}: PasswordResetEmailProps) => (
  <Html>
    <Head />
    <Preview>Възстановяване на паролата за MyZone.life 🔑</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <Heading style={h1}>🔑 Възстановяване на парола</Heading>
        </Section>
        
        <Section style={content}>
          <Text style={greeting}>
            Здравейте! 👋
          </Text>
          
          <Text style={text}>
            Получихме заявка за възстановяване на паролата за вашия акаунт в MyZone.life. Ако не сте направили тази заявка, можете да игнорирате този имейл.
          </Text>

          <Section style={infoSection}>
            <Text style={infoText}>
              📧 Имейл адрес: <strong>{email}</strong>
            </Text>
          </Section>

          <Section style={ctaSection}>
            <Link
              href={resetLink}
              style={button}
            >
              Възстановете паролата 🚀
            </Link>
          </Section>

          <Text style={linkText}>
            Или копирайте и поставете този линк в браузъра си:
          </Text>
          <Text style={linkUrl}>
            {resetLink}
          </Text>

          <Section style={securitySection}>
            <Heading style={h2}>🔒 За вашата сигурност:</Heading>
            <Text style={bulletPoint}>🕐 Този линк е валиден за 1 час</Text>
            <Text style={bulletPoint}>🔗 Използвайте го само веднъж</Text>
            <Text style={bulletPoint}>🚫 Ако не сте поискали тази промяна, игнорирайте имейла</Text>
            <Text style={bulletPoint}>📧 При проблеми се свържете с нас</Text>
          </Section>

          <Text style={expiryText}>
            ⏰ Този линк ще изтече след 1 час от изпращането му.
          </Text>
        </Section>

        <Section style={footer}>
          <Text style={footerText}>
            С уважение,<br />
            Екипът на MyZone.life
          </Text>
          <Text style={footerLink}>
            <Link href="https://app.myzone.life" style={link}>
              app.myzone.life
            </Link>
          </Text>
        </Section>
      </Container>
    </Body>
  </Html>
)

export default PasswordResetEmail

const main = {
  background: 'linear-gradient(135deg, hsl(0, 65%, 98%) 0%, hsl(220, 30%, 98%) 100%)',
  fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
  minHeight: '100vh',
  padding: '20px 0',
}

const container = {
  margin: '0 auto',
  padding: '0',
  maxWidth: '600px',
  backgroundColor: '#ffffff',
  borderRadius: '20px',
  boxShadow: '0 25px 70px rgba(0, 0, 0, 0.08), 0 10px 30px rgba(0, 0, 0, 0.06)',
  overflow: 'hidden',
}

const header = {
  background: 'linear-gradient(135deg, hsl(0, 75%, 58%) 0%, hsl(220, 75%, 58%) 100%)',
  textAlign: 'center' as const,
  padding: '45px 24px',
  position: 'relative' as const,
}

const h1 = {
  color: '#ffffff',
  fontSize: '38px',
  fontWeight: '900',
  lineHeight: '1.2',
  margin: '0',
  textAlign: 'center' as const,
  textShadow: '0 3px 10px rgba(0, 0, 0, 0.2)',
  letterSpacing: '-0.5px',
}

const h2 = {
  background: 'linear-gradient(135deg, hsl(0, 75%, 55%), hsl(220, 75%, 55%))',
  WebkitBackgroundClip: 'text',
  WebkitTextFillColor: 'transparent',
  backgroundClip: 'text',
  fontSize: '26px',
  fontWeight: '800',
  lineHeight: '1.3',
  margin: '20px 0 16px 0',
  textAlign: 'center' as const,
}

const content = {
  padding: '45px 36px',
}

const greeting = {
  color: 'hsl(210, 25%, 10%)',
  fontSize: '21px',
  lineHeight: '1.5',
  margin: '0 0 22px 0',
  fontWeight: '700',
  textAlign: 'center' as const,
}

const text = {
  color: 'hsl(210, 20%, 20%)',
  fontSize: '18px',
  lineHeight: '1.8',
  margin: '22px 0',
  textAlign: 'center' as const,
  fontWeight: '400',
}

const infoSection = {
  background: 'linear-gradient(135deg, hsl(142, 80%, 96%) 0%, hsl(142, 80%, 92%) 100%)',
  borderRadius: '18px',
  padding: '28px',
  margin: '32px 0',
  border: '3px solid hsl(142, 80%, 80%)',
  boxShadow: '0 12px 35px rgba(76, 175, 80, 0.15)',
}

const infoText = {
  color: 'hsl(142, 80%, 20%)',
  fontSize: '18px',
  lineHeight: '1.7',
  margin: '0',
  textAlign: 'center' as const,
  fontWeight: '600',
}

const securitySection = {
  background: 'linear-gradient(135deg, hsl(0, 75%, 96%) 0%, hsl(0, 75%, 92%) 100%)',
  borderRadius: '18px',
  padding: '32px',
  margin: '32px 0',
  border: '3px solid hsl(0, 75%, 80%)',
  boxShadow: '0 12px 35px rgba(220, 53, 69, 0.15)',
}

const bulletPoint = {
  color: 'hsl(210, 25%, 10%)',
  fontSize: '17px',
  lineHeight: '1.8',
  margin: '14px 0',
  padding: '10px 0',
  fontWeight: '600',
  borderBottom: '1px solid hsl(0, 75%, 85%)',
}

const ctaSection = {
  textAlign: 'center' as const,
  margin: '45px 0',
  padding: '25px 0',
}

const button = {
  background: 'linear-gradient(135deg, hsl(0, 75%, 58%) 0%, hsl(220, 75%, 58%) 100%)',
  borderRadius: '15px',
  color: '#ffffff',
  fontSize: '19px',
  fontWeight: '800',
  textDecoration: 'none',
  textAlign: 'center' as const,
  display: 'inline-block',
  padding: '20px 40px',
  boxShadow: '0 15px 45px rgba(220, 53, 69, 0.4), 0 6px 20px rgba(13, 110, 253, 0.3)',
  textShadow: '0 2px 4px rgba(0, 0, 0, 0.3)',
  transition: 'all 0.3s ease',
  border: 'none',
  letterSpacing: '0.3px',
}

const linkText = {
  color: 'hsl(210, 20%, 45%)',
  fontSize: '16px',
  lineHeight: '1.7',
  margin: '28px 0 14px 0',
  textAlign: 'center' as const,
  fontWeight: '500',
}

const linkUrl = {
  color: 'hsl(0, 75%, 45%)',
  fontSize: '15px',
  lineHeight: '1.7',
  margin: '0 0 28px 0',
  textAlign: 'center' as const,
  wordBreak: 'break-all' as const,
  padding: '18px 22px',
  background: 'linear-gradient(135deg, hsl(0, 75%, 97%) 0%, hsl(0, 75%, 94%) 100%)',
  borderRadius: '12px',
  border: '2px solid hsl(0, 75%, 85%)',
  fontFamily: 'Monaco, Consolas, "Courier New", monospace',
  fontWeight: '500',
}

const expiryText = {
  color: 'hsl(210, 20%, 40%)',
  fontSize: '16px',
  lineHeight: '1.7',
  margin: '28px 0 0 0',
  textAlign: 'center' as const,
  fontStyle: 'italic',
  fontWeight: '500',
  padding: '16px 22px',
  backgroundColor: 'hsl(45, 90%, 96%)',
  borderRadius: '10px',
  border: '2px solid hsl(45, 90%, 85%)',
}

const footer = {
  background: 'linear-gradient(135deg, hsl(210, 20%, 98%) 0%, hsl(210, 20%, 95%) 100%)',
  textAlign: 'center' as const,
  margin: '0',
  padding: '36px 24px',
  borderTop: '3px solid hsl(210, 20%, 88%)',
}

const footerText = {
  color: 'hsl(210, 20%, 35%)',
  fontSize: '16px',
  lineHeight: '1.7',
  margin: '0 0 14px 0',
  fontWeight: '600',
}

const footerLink = {
  margin: '14px 0 0 0',
}

const link = {
  background: 'linear-gradient(135deg, hsl(0, 75%, 55%), hsl(220, 75%, 55%))',
  WebkitBackgroundClip: 'text',
  WebkitTextFillColor: 'transparent',
  backgroundClip: 'text',
  textDecoration: 'none',
  fontSize: '16px',
  fontWeight: '700',
}