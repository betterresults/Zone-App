import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Link,
  Preview,
  Text,
  Section,
  Img,
} from 'npm:@react-email/components@0.0.22'
import * as React from 'npm:react@18.3.1'

interface WelcomeEmailProps {
  displayName?: string
  email: string
}

export const WelcomeEmail = ({
  displayName,
  email,
}: WelcomeEmailProps) => (
  <Html>
    <Head />
    <Preview>Добре дошли в MyZone.life! 🌱</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <Heading style={h1}>🌱 Добре дошли в MyZone.life!</Heading>
        </Section>
        
        <Section style={content}>
          <Text style={greeting}>
            Здравейте{displayName ? ` ${displayName}` : ''}! 👋
          </Text>
          
          <Text style={text}>
            Добре дошли в MyZone.life! Започнете да проследявате здравето си с нашите удобни инструменти.
          </Text>

          <Section style={benefitsSection}>
            <Heading style={h2}>🎯 Какво ви очаква:</Heading>
            <Text style={bulletPoint}>🥗 <strong>Зоново хранене</strong> - балансирайте макронутриентите</Text>
            <Text style={bulletPoint}>💧 <strong>Проследяване на хидратация</strong></Text>
            <Text style={bulletPoint}>🏃‍♀️ <strong>Фитнес тракинг</strong></Text>
            <Text style={bulletPoint}>⏰ <strong>Интермитентно гладуване</strong></Text>
            <Text style={bulletPoint}>📱 <strong>Поддръжка</strong></Text>
          </Section>

          <Section style={ctaSection}>
            <Link
              href="https://app.myzone.life/auth"
              style={button}
            >
              Започнете сега 🚀
            </Link>
          </Section>

          <Text style={text}>
            Вашето мнение е важно за нас. Не се колебайте да споделяте обратна връзка и предложения.
          </Text>

          <Text style={text}>
            Приятно използване! 🌟
          </Text>
        </Section>

        <Section style={footer}>
          <Text style={footerText}>
            С уважение,<br />
            Екипът на MyZone.life
          </Text>
          <Text style={footerLink}>
            <Link href="https://app.myzone.life" style={link}>
              app.myzone.life
            </Link>
          </Text>
        </Section>
      </Container>
    </Body>
  </Html>
)

export default WelcomeEmail

const main = {
  background: 'linear-gradient(135deg, hsl(142, 85%, 98%) 0%, hsl(280, 30%, 98%) 100%)',
  fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
  minHeight: '100vh',
  padding: '20px 0',
}

const container = {
  margin: '0 auto',
  padding: '0',
  maxWidth: '600px',
  backgroundColor: '#ffffff',
  borderRadius: '20px',
  boxShadow: '0 25px 70px rgba(0, 0, 0, 0.08), 0 10px 30px rgba(0, 0, 0, 0.06)',
  overflow: 'hidden',
}

const header = {
  background: 'linear-gradient(135deg, hsl(142, 69%, 58%) 0%, hsl(142, 69%, 40%) 100%)',
  textAlign: 'center' as const,
  padding: '50px 24px',
  position: 'relative' as const,
}

const h1 = {
  color: '#ffffff',
  fontSize: '40px',
  fontWeight: '900',
  lineHeight: '1.2',
  margin: '0',
  textAlign: 'center' as const,
  textShadow: '0 3px 10px rgba(0, 0, 0, 0.2)',
  letterSpacing: '-0.5px',
}

const h2 = {
  background: 'linear-gradient(135deg, hsl(142, 69%, 58%), hsl(142, 69%, 75%))',
  WebkitBackgroundClip: 'text',
  WebkitTextFillColor: 'transparent',
  backgroundClip: 'text',
  fontSize: '28px',
  fontWeight: '800',
  lineHeight: '1.3',
  margin: '24px 0 20px 0',
  textAlign: 'center' as const,
}

const content = {
  padding: '50px 36px',
}

const greeting = {
  color: 'hsl(210, 25%, 10%)',
  fontSize: '22px',
  lineHeight: '1.5',
  margin: '0 0 24px 0',
  fontWeight: '700',
  textAlign: 'center' as const,
}

const text = {
  color: 'hsl(210, 20%, 20%)',
  fontSize: '18px',
  lineHeight: '1.8',
  margin: '24px 0',
  textAlign: 'center' as const,
  fontWeight: '400',
}

const benefitsSection = {
  background: 'linear-gradient(135deg, hsl(45, 95%, 96%) 0%, hsl(45, 95%, 92%) 100%)',
  borderRadius: '20px',
  padding: '36px',
  margin: '36px 0',
  border: '3px solid hsl(45, 95%, 75%)',
  boxShadow: '0 15px 40px rgba(255, 193, 7, 0.2), 0 5px 15px rgba(255, 193, 7, 0.1)',
  position: 'relative' as const,
}

const bulletPoint = {
  color: 'hsl(210, 25%, 10%)',
  fontSize: '18px',
  lineHeight: '1.8',
  margin: '16px 0',
  padding: '12px 0',
  fontWeight: '600',
  borderBottom: '1px solid hsl(45, 95%, 85%)',
}

const ctaSection = {
  textAlign: 'center' as const,
  margin: '50px 0',
  padding: '30px 0',
}

const button = {
  background: 'linear-gradient(135deg, hsl(142, 69%, 58%) 0%, hsl(142, 69%, 48%) 100%)',
  borderRadius: '15px',
  color: '#ffffff',
  fontSize: '20px',
  fontWeight: '800',
  textDecoration: 'none',
  textAlign: 'center' as const,
  display: 'inline-block',
  padding: '22px 44px',
  boxShadow: '0 15px 45px rgba(76, 175, 80, 0.4), 0 6px 20px rgba(76, 175, 80, 0.3)',
  textShadow: '0 2px 4px rgba(0, 0, 0, 0.3)',
  transition: 'all 0.3s ease',
  border: 'none',
  letterSpacing: '0.5px',
}

const footer = {
  background: 'linear-gradient(135deg, hsl(210, 20%, 98%) 0%, hsl(210, 20%, 95%) 100%)',
  textAlign: 'center' as const,
  margin: '0',
  padding: '40px 24px',
  borderTop: '3px solid hsl(210, 20%, 90%)',
}

const footerText = {
  color: 'hsl(210, 20%, 35%)',
  fontSize: '16px',
  lineHeight: '1.7',
  margin: '0 0 16px 0',
  fontWeight: '600',
}

const footerLink = {
  margin: '16px 0 0 0',
}

const link = {
  background: 'linear-gradient(135deg, hsl(142, 69%, 58%), hsl(142, 69%, 75%))',
  WebkitBackgroundClip: 'text',
  WebkitTextFillColor: 'transparent',
  backgroundClip: 'text',
  textDecoration: 'none',
  fontSize: '16px',
  fontWeight: '700',
}