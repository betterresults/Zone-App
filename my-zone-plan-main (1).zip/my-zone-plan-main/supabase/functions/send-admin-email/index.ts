import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { SMTPClient } from "https://deno.land/x/denomailer@1.6.0/mod.ts";

const client = new SMTPClient({
  connection: {
    hostname: "smtp.myzone.life",
    port: 465,
    tls: true,
    auth: {
      username: "contact@myzone.life",
      password: Deno.env.get("SMTP_PASSWORD") || "",
    },
  },
});

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface AdminEmailRequest {
  email: string;
  subject: string;
  template?: 'welcome' | 'confirmation' | 'password-reset';
  customContent?: string;
  displayName?: string;
  confirmationLink?: string;
  resetLink?: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { 
      email, 
      subject, 
      template, 
      customContent, 
      displayName,
      confirmationLink,
      resetLink 
    }: AdminEmailRequest = await req.json();

    let htmlContent: string;

    if (template) {
      // Use template
      switch (template) {
        case 'welcome':
          htmlContent = `
            <!DOCTYPE html>
            <html>
            <head>
              <meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <title>Добре дошли в MyZone.life</title>
              <style>
                body {
                  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                  line-height: 1.6;
                  color: #333;
                  max-width: 600px;
                  margin: 0 auto;
                  padding: 20px;
                }
                .header {
                  background: linear-gradient(135deg, hsl(142, 69%, 58%) 0%, hsl(142, 69%, 45%) 100%);
                  padding: 30px;
                  text-align: center;
                  border-radius: 10px 10px 0 0;
                }
                .header h1 {
                  color: white;
                  margin: 0;
                  font-size: 28px;
                }
                .content {
                  background: #f8f9fa;
                  padding: 30px;
                  border-radius: 0 0 10px 10px;
                  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                }
                .footer {
                  text-align: center;
                  margin-top: 20px;
                  padding: 20px;
                  border-top: 1px solid #e0e0e0;
                  font-size: 12px;
                  color: #666;
                }
              </style>
            </head>
            <body>
              <div class="header">
                <h1>🌱 MyZone.life</h1>
              </div>
              <div class="content">
                <h2>Добре дошли, ${displayName || 'потребител'}!</h2>
                <p>Радваме се, че се присъединихте към MyZone.life!</p>
                <p>Започнете своето пътешествие към по-здравословен начин на живот още днес.</p>
              </div>
              <div class="footer">
                <p>MyZone Team<br>
                <a href="https://myzone.life" style="color: hsl(142, 69%, 58%); text-decoration: none;">myzone.life</a></p>
              </div>
            </body>
            </html>
          `;
          break;
        case 'confirmation':
          htmlContent = `
            <!DOCTYPE html>
            <html>
            <head>
              <meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <title>Потвърдете имейла си</title>
              <style>
                body {
                  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                  line-height: 1.6;
                  color: #333;
                  max-width: 600px;
                  margin: 0 auto;
                  padding: 20px;
                }
                .header {
                  background: linear-gradient(135deg, hsl(142, 69%, 58%) 0%, hsl(142, 69%, 45%) 100%);
                  padding: 30px;
                  text-align: center;
                  border-radius: 10px 10px 0 0;
                }
                .header h1 {
                  color: white;
                  margin: 0;
                  font-size: 28px;
                }
                .content {
                  background: #f8f9fa;
                  padding: 30px;
                  border-radius: 0 0 10px 10px;
                  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                }
                .button {
                  display: inline-block;
                  background: hsl(142, 69%, 58%);
                  color: white;
                  padding: 15px 30px;
                  text-decoration: none;
                  border-radius: 5px;
                  margin: 20px 0;
                }
                .footer {
                  text-align: center;
                  margin-top: 20px;
                  padding: 20px;
                  border-top: 1px solid #e0e0e0;
                  font-size: 12px;
                  color: #666;
                }
              </style>
            </head>
            <body>
              <div class="header">
                <h1>🌱 MyZone.life</h1>
              </div>
              <div class="content">
                <h2>Потвърдете имейла си</h2>
                <p>Моля, кликнете на бутона по-долу, за да потвърдите имейл адреса си:</p>
                <a href="${confirmationLink || '#'}" class="button">Потвърди имейл</a>
                <p>Ако не можете да кликнете на бутона, копирайте и поставете следния линк в браузъра си:</p>
                <p style="word-break: break-all;">${confirmationLink || '#'}</p>
              </div>
              <div class="footer">
                <p>MyZone Team<br>
                <a href="https://myzone.life" style="color: hsl(142, 69%, 58%); text-decoration: none;">myzone.life</a></p>
              </div>
            </body>
            </html>
          `;
          break;
        case 'password-reset':
          htmlContent = `
            <!DOCTYPE html>
            <html>
            <head>
              <meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <title>Нулиране на парола</title>
              <style>
                body {
                  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                  line-height: 1.6;
                  color: #333;
                  max-width: 600px;
                  margin: 0 auto;
                  padding: 20px;
                }
                .header {
                  background: linear-gradient(135deg, hsl(142, 69%, 58%) 0%, hsl(142, 69%, 45%) 100%);
                  padding: 30px;
                  text-align: center;
                  border-radius: 10px 10px 0 0;
                }
                .header h1 {
                  color: white;
                  margin: 0;
                  font-size: 28px;
                }
                .content {
                  background: #f8f9fa;
                  padding: 30px;
                  border-radius: 0 0 10px 10px;
                  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                }
                .button {
                  display: inline-block;
                  background: hsl(142, 69%, 58%);
                  color: white;
                  padding: 15px 30px;
                  text-decoration: none;
                  border-radius: 5px;
                  margin: 20px 0;
                }
                .footer {
                  text-align: center;
                  margin-top: 20px;
                  padding: 20px;
                  border-top: 1px solid #e0e0e0;
                  font-size: 12px;
                  color: #666;
                }
              </style>
            </head>
            <body>
              <div class="header">
                <h1>🌱 MyZone.life</h1>
              </div>
              <div class="content">
                <h2>Нулиране на парола</h2>
                <p>Получихме заявка за нулиране на паролата за вашия акаунт.</p>
                <p>Кликнете на бутона по-долу, за да зададете нова парола:</p>
                <a href="${resetLink || '#'}" class="button">Нулирай парола</a>
                <p>Ако не можете да кликнете на бутона, копирайте и поставете следния линк в браузъра си:</p>
                <p style="word-break: break-all;">${resetLink || '#'}</p>
                <p>Ако не сте заявили нулиране на парола, моля игнорирайте този имейл.</p>
              </div>
              <div class="footer">
                <p>MyZone Team<br>
                <a href="https://myzone.life" style="color: hsl(142, 69%, 58%); text-decoration: none;">myzone.life</a></p>
              </div>
            </body>
            </html>
          `;
          break;
        default:
          throw new Error('Invalid template');
      }
    } else if (customContent) {
      // Use custom content
      htmlContent = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>${subject}</title>
          <style>
            body {
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
              line-height: 1.6;
              color: #333;
              max-width: 600px;
              margin: 0 auto;
              padding: 20px;
            }
            .header {
              background: linear-gradient(135deg, hsl(142, 69%, 58%) 0%, hsl(142, 69%, 45%) 100%);
              padding: 30px;
              text-align: center;
              border-radius: 10px 10px 0 0;
            }
            .header h1 {
              color: white;
              margin: 0;
              font-size: 28px;
            }
            .content {
              background: #f8f9fa;
              padding: 30px;
              border-radius: 0 0 10px 10px;
              box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            }
            .footer {
              text-align: center;
              margin-top: 20px;
              padding: 20px;
              border-top: 1px solid #e0e0e0;
              font-size: 12px;
              color: #666;
            }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>🌱 MyZone.life</h1>
          </div>
          <div class="content">
            ${customContent.replace(/\n/g, '<br>')}
          </div>
          <div class="footer">
            <p>MyZone Team<br>
            <a href="https://myzone.life" style="color: hsl(142, 69%, 58%); text-decoration: none;">myzone.life</a></p>
          </div>
        </body>
        </html>
      `;
    } else {
      throw new Error('Either template or customContent must be provided');
    }

    await client.send({
      from: "MyZone <contact@myzone.life>",
      to: email,
      subject: subject,
      html: htmlContent,
    });

    console.log("Admin email sent successfully to:", email);

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });
  } catch (error: any) {
    console.error("Error in send-admin-email function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);