import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.2';
import { corsHeaders } from '../_shared/cors.ts';

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    
    // Get authenticated user
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'No authorization header' }),
        { status: 401, headers: corsHeaders }
      );
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(
      authHeader.replace('Bearer ', '')
    );

    if (authError || !user) {
      console.error('Auth error:', authError);
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: corsHeaders }
      );
    }

    const { userId, trainingDays, trainingTimes, notificationMinutes } = await req.json();

    if (userId !== user.id) {
      return new Response(
        JSON.stringify({ error: 'User ID mismatch' }),
        { status: 403, headers: corsHeaders }
      );
    }

    console.log('🏋️ Scheduling fitness notifications for user:', userId);
    console.log('Training days:', trainingDays);
    console.log('Training times:', trainingTimes);

    // Delete existing fitness notifications
    const { error: deleteError } = await supabase
      .from('scheduled_notifications')
      .delete()
      .eq('user_id', userId)
      .eq('notification_type', 'fitness');

    if (deleteError) {
      console.error('Error deleting existing notifications:', deleteError);
    }

    // Check if user has push notifications enabled
    const { data: profile } = await supabase
      .from('profiles')
      .select('push_notifications_enabled')
      .eq('user_id', userId)
      .single();

    if (!profile?.push_notifications_enabled) {
      console.log('Push notifications disabled for user');
      return new Response(
        JSON.stringify({ message: 'Push notifications disabled' }),
        { status: 200, headers: corsHeaders }
      );
    }

    // Schedule notifications for each training day
    const notifications = [];
    
    for (const dayIndex of trainingDays) {
      if (typeof dayIndex !== 'number' || dayIndex < 0 || dayIndex > 6) continue;
      
      const timeForDay = trainingTimes[dayIndex.toString()];
      if (!timeForDay) continue;

      // Calculate next occurrence of this training day
      const now = new Date();
      const nextDate = new Date();
      
      // Set to the target day of week (0 = Sunday, 1 = Monday, etc.)
      const currentDay = nextDate.getDay();
      const targetDay = dayIndex === 6 ? 0 : dayIndex + 1; // Convert our format to JS format
      let daysUntilTarget = (targetDay - currentDay + 7) % 7;
      
      // If it's today but past the time, schedule for next week
      if (daysUntilTarget === 0) {
        const [hours, minutes] = timeForDay.split(':').map(Number);
        const targetTime = new Date();
        targetTime.setHours(hours, minutes, 0, 0);
        
        if (now >= targetTime) {
          daysUntilTarget = 7;
        }
      }
      
      nextDate.setDate(nextDate.getDate() + daysUntilTarget);
      
      // Set the notification time (training time minus notification minutes)
      const [hours, minutes] = timeForDay.split(':').map(Number);
      nextDate.setHours(hours, minutes, 0, 0);
      nextDate.setMinutes(nextDate.getMinutes() - (notificationMinutes || 30));

      // Only schedule if in the future
      if (nextDate > now) {
        notifications.push({
          user_id: userId,
          notification_type: 'fitness',
          reference_id: (globalThis.crypto as any).randomUUID(),
          title: 'Време за тренировка! 🏋️',
          message: `Вашата тренировка започва след ${notificationMinutes || 30} минути`,
          scheduled_for: nextDate.toISOString(),
        });
      }
    }

    if (notifications.length > 0) {
      const { error: insertError } = await supabase
        .from('scheduled_notifications')
        .insert(notifications);

      if (insertError) {
        console.error('Error inserting notifications:', insertError);
        throw insertError;
      }

      console.log(`✅ Scheduled ${notifications.length} fitness notifications`);
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        scheduled: notifications.length,
        message: `Scheduled ${notifications.length} fitness notifications`
      }),
      { status: 200, headers: corsHeaders }
    );

  } catch (err) {
    console.error('Error in schedule-fitness-notifications:', err);
    const message = err instanceof Error ? err.message : String(err);
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: corsHeaders }
    );
  }
});