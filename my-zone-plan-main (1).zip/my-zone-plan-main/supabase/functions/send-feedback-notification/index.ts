import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface NotificationRequest {
  feedback_id: string;
  status_change?: boolean;
  admin_response?: boolean;
  new_status?: string;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const oneSignalAppId = Deno.env.get('ONESIGNAL_APP_ID')!;
    const oneSignalApiKey = Deno.env.get('ONESIGNAL_REST_API_KEY')!;

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { feedback_id, status_change, admin_response, new_status }: NotificationRequest = await req.json();

    console.log('Processing feedback notification:', { feedback_id, status_change, admin_response, new_status });

    // Get feedback details and user info
    const { data: feedback, error: feedbackError } = await supabase
      .from('beta_feedback')
      .select(`
        id,
        title,
        status,
        user_id,
        admin_notes
      `)
      .eq('id', feedback_id)
      .single();

    if (feedbackError) {
      console.error('Error fetching feedback:', feedbackError);
      throw new Error('Failed to fetch feedback');
    }

    // Get user profile for notification
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('user_id, display_name, email')
      .eq('user_id', feedback.user_id)
      .single();

    if (profileError) {
      console.error('Error fetching user profile:', profileError);
      throw new Error('Failed to fetch user profile');
    }

    // Prepare notification message
    let notificationTitle = '';
    let notificationMessage = '';

    if (admin_response) {
      notificationTitle = 'Нов отговор от екипа';
      notificationMessage = `Получихте отговор по вашето съобщение "${feedback.title}"`;
    } else if (status_change && new_status) {
      const statusLabels: Record<string, string> = {
        'new': 'Ново',
        'in_progress': 'В процес', 
        'resolved': 'Решено',
        'closed': 'Затворено'
      };
      
      notificationTitle = 'Промяна в статуса на съобщение';
      notificationMessage = `Статусът на вашето съобщение "${feedback.title}" е променен на "${statusLabels[new_status] || new_status}"`;
    } else {
      notificationTitle = 'Актуализация на съобщение';
      notificationMessage = `Има актуализация по вашето съобщение "${feedback.title}"`;
    }

    console.log('Sending notification:', { notificationTitle, notificationMessage });

    // Send OneSignal notification
    const notificationPayload = {
      app_id: oneSignalAppId,
      filters: [
        { field: 'tag', key: 'user_id', relation: '=', value: feedback.user_id }
      ],
      headings: { 'en': notificationTitle },
      contents: { 'en': notificationMessage },
      data: {
        type: 'feedback_update',
        feedback_id: feedback.id,
        status_change: status_change || false,
        admin_response: admin_response || false
      },
      web_url: `${Deno.env.get('SUPABASE_URL')?.replace('https://', 'https://').replace('.supabase.co', '.lovableproject.com')}/feedback`,
      chrome_web_icon: '/icon-192.png'
    };

    const oneSignalResponse = await fetch('https://onesignal.com/api/v1/notifications', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Basic ${oneSignalApiKey}`
      },
      body: JSON.stringify(notificationPayload)
    });

    const oneSignalResult = await oneSignalResponse.json();
    console.log('OneSignal response:', oneSignalResult);

    if (!oneSignalResponse.ok) {
      console.error('OneSignal error:', oneSignalResult);
      throw new Error(`OneSignal API error: ${oneSignalResult.errors || 'Unknown error'}`);
    }

    // Log notification activity
    await supabase
      .from('user_activities')
      .insert({
        user_id: feedback.user_id,
        activity_category: 'notifications',
        activity_type: 'feedback_notification_sent',
        activity_description: `Изпратена нотификация за обратна връзка: ${notificationTitle}`,
        activity_data: {
          feedback_id: feedback.id,
          notification_type: admin_response ? 'admin_response' : 'status_change',
          oneSignal_id: oneSignalResult.id
        }
      });

    return new Response(
      JSON.stringify({ 
        success: true, 
        notification_id: oneSignalResult.id,
        recipients: oneSignalResult.recipients 
      }),
      { 
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
        status: 200 
      }
    );

  } catch (error: any) {
    console.error('Error in send-feedback-notification:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
        status: 500 
      }
    );
  }
});