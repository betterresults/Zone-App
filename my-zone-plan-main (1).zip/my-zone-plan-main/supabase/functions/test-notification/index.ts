import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const oneSignalAppId = Deno.env.get('ONESIGNAL_APP_ID');
    const oneSignalApiKey = Deno.env.get('ONESIGNAL_REST_API_KEY');
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseServiceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!oneSignalAppId || !oneSignalApiKey) {
      console.error('Missing OneSignal configuration');
      return new Response(
        JSON.stringify({ error: 'OneSignal configuration missing' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!supabaseUrl || !supabaseServiceRoleKey) {
      console.error('Missing Supabase configuration');
      return new Response(
        JSON.stringify({ error: 'Supabase configuration missing' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Initialize Supabase client with service role key
    const supabase = createClient(supabaseUrl, supabaseServiceRoleKey);

    // Get the specific notification
    const notificationId = '4f3a4d2f-37e9-491a-b539-0b3c5d2c023e';
    
    const { data: notification, error: fetchError } = await supabase
      .from('scheduled_notifications')
      .select('*')
      .eq('id', notificationId)
      .eq('is_sent', false)
      .single();

    if (fetchError || !notification) {
      console.error('Error fetching notification:', fetchError);
      return new Response(
        JSON.stringify({ error: 'Notification not found or already sent' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`📤 Testing notification ${notification.id} for user ${notification.user_id}`);

    // Prepare OneSignal notification payload
    const oneSignalPayload = {
      headings: { "en": notification.title },
      contents: { "en": notification.message },
      target_channel: "push",
      include_external_user_ids: [notification.user_id],
      data: {
        notification_type: notification.notification_type,
        reference_id: notification.reference_id,
        notification_id: notification.id
      }
    };

    console.log('Sending to OneSignal with payload:', JSON.stringify(oneSignalPayload, null, 2));

    console.log('OneSignal config check:');
    console.log('App ID:', oneSignalAppId);
    console.log('API Key exists:', !!oneSignalApiKey);
    console.log('API Key length:', oneSignalApiKey?.length);

    // Send notification via OneSignal
    const oneSignalResponse = await fetch('https://api.onesignal.com/notifications?c=push', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Key ${oneSignalApiKey}`,
      },
      body: JSON.stringify({
        app_id: oneSignalAppId,
        ...oneSignalPayload
      }),
    });

    const oneSignalResult = await oneSignalResponse.json();

    console.log('OneSignal response status:', oneSignalResponse.status);
    console.log('OneSignal response:', JSON.stringify(oneSignalResult, null, 2));

    if (oneSignalResponse.ok && oneSignalResult.id) {
      console.log(`✅ OneSignal notification sent successfully: ${oneSignalResult.id}`);
      
      // Mark notification as sent
      const { error: updateError } = await supabase
        .from('scheduled_notifications')
        .update({
          is_sent: true,
          sent_at: new Date().toISOString()
        })
        .eq('id', notification.id);

      if (updateError) {
        console.error(`❌ Failed to mark notification as sent:`, updateError);
        return new Response(
          JSON.stringify({ 
            success: true, 
            oneSignalId: oneSignalResult.id,
            warning: 'Notification sent but failed to mark as sent in database'
          }),
          { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      } else {
        console.log(`✅ Notification marked as sent`);
        return new Response(
          JSON.stringify({ 
            success: true, 
            oneSignalId: oneSignalResult.id,
            message: 'Notification sent successfully'
          }),
          { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    } else {
      console.error(`❌ OneSignal API error:`, oneSignalResult);
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'OneSignal API error',
          details: oneSignalResult 
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

  } catch (error) {
    console.error('❌ Unexpected error:', error);
    return new Response(
      JSON.stringify({ 
        success: false,
        error: 'Internal server error',
        details: error instanceof Error ? error.message : 'Unknown error' 
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});