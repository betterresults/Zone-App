importScripts('https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.sw.js');

// Service worker for PWA with OneSignal integration
const CACHE_NAME = 'zone-plan-v' + Date.now();
const STATIC_CACHE = 'zone-plan-static-v' + Date.now();

// Install event - cache essential resources
self.addEventListener('install', event => {
  console.log('Service Worker: Installing...');
  event.waitUntil(
    caches.open(STATIC_CACHE)
      .then(cache => {
        console.log('Service Worker: Caching essential files');
        return cache.addAll([
          '/',
          '/manifest.json',
          '/icon-192.png',
          '/icon-512.png'
        ]);
      })
  );
});

// Activate event - clean old caches
self.addEventListener('activate', event => {
  console.log('Service Worker: Activating...');
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== STATIC_CACHE && cacheName !== CACHE_NAME) {
            console.log('Service Worker: Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => {
      console.log('Service Worker: Claiming clients');
      return self.clients.claim();
    })
  );
});

// Fetch event - network first strategy for better updates
self.addEventListener('fetch', event => {
  // Skip non-GET requests
  if (event.request.method !== 'GET') {
    return;
  }

  // Skip external requests
  if (!event.request.url.startsWith(self.location.origin)) {
    return;
  }

  event.respondWith(
    // Network first, then cache
    fetch(event.request)
      .then(response => {
        // If network request is successful, update cache and return response
        if (response && response.status === 200 && response.type === 'basic') {
          const responseClone = response.clone();
          caches.open(CACHE_NAME)
            .then(cache => {
              cache.put(event.request, responseClone);
            });
        }
        return response;
      })
      .catch(() => {
        // If network fails, try to get from cache
        return caches.match(event.request)
          .then(response => {
            if (response) {
              return response;
            }
            // If not in cache either, return a basic offline page
            if (event.request.destination === 'document') {
              return new Response(
                '<html><body><h1>Офлайн</h1><p>Моля, проверете интернет връзката си.</p></body></html>',
                { 
                  headers: { 'Content-Type': 'text/html' }
                }
              );
            }
          });
      })
  );
});

// ВАЖНО: Премахваме собствените push/notification handlers
// OneSignal ще ги обработва чрез importScripts

// Listen for message from client to skip waiting
self.addEventListener('message', event => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});