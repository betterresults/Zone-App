import { useEffect, useState } from 'react';
import { useAdmin, type UserProfile } from '@/hooks/useAdmin';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { 
  Shield, 
  Users, 
  BarChart, 
  Ban, 
  CheckCircle, 
  UserPlus, 
  UserMinus, 
  Trash2, 
  Edit,
  Crown,
  Activity,
  Apple,
  ChefHat,
  Calendar as CalendarIcon,
  TrendingUp,
  Bell
} from 'lucide-react';
import { Navigate } from 'react-router-dom';
import { ActivityFeed } from '@/components/admin/ActivityFeed';
import { SendNotificationDialog } from '@/components/admin/SendNotificationDialog';
import { InstantNotificationDialog } from '@/components/admin/InstantNotificationDialog';
import { WaterNotificationTest } from '@/components/admin/WaterNotificationTest';

const Admin = () => {
  const {
    isAdmin,
    loading,
    stats,
    users,
    loadStats,
    loadUsers,
    blockUser,
    unblockUser,
    makeAdmin,
    removeAdmin,
    deleteUser,
    updateUserProfile
  } = useAdmin();

  const [blockReason, setBlockReason] = useState('');
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [editingUser, setEditingUser] = useState<UserProfile | null>(null);
  const [editForm, setEditForm] = useState({
    display_name: '',
    email: ''
  });

  useEffect(() => {
    if (isAdmin) {
      loadStats();
      loadUsers();
    }
  }, [isAdmin]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Достъп отказан</h2>
          <p className="text-muted-foreground">Нямате права за достъп до тази страница.</p>
        </div>
      </div>
    );
  }

  const handleBlockUser = () => {
    if (selectedUser && blockReason.trim()) {
      blockUser(selectedUser.user_id, blockReason);
      setBlockReason('');
      setSelectedUser(null);
    }
  };

  const handleEditUser = (user: UserProfile) => {
    setEditingUser(user);
    setEditForm({
      display_name: user.display_name || '',
      email: user.email
    });
  };

  const handleUpdateUser = () => {
    if (editingUser) {
      updateUserProfile(editingUser.user_id, editForm);
      setEditingUser(null);
    }
  };

  const isUserAdmin = (user: UserProfile) => {
    return user.user_roles?.some(role => role.role === 'admin') || false;
  };

  const statsCards = [
    {
      title: 'Общо потребители',
      value: stats?.total_users || 0,
      icon: Users,
      color: 'text-blue-600'
    },
    {
      title: 'Нови (30 дни)',
      value: stats?.users_last_30_days || 0,
      icon: TrendingUp,
      color: 'text-green-600'
    },
    {
      title: 'Блокирани',
      value: stats?.blocked_users || 0,
      icon: Ban,
      color: 'text-red-600'
    },
    {
      title: 'Продукти',
      value: stats?.total_products || 0,
      icon: Apple,
      color: 'text-zone-protein'
    },
    {
      title: 'Рецепти',
      value: stats?.total_recipes || 0,
      icon: ChefHat,
      color: 'text-zone-carbs'
    },
    {
      title: 'Хранения (30 дни)',
      value: stats?.meals_last_30_days || 0,
      icon: CalendarIcon,
      color: 'text-zone-fat'
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <Shield className="h-8 w-8 text-primary" />
        <div>
          <h1 className="text-3xl font-bold text-foreground">Админ панел</h1>
          <p className="text-muted-foreground">Управление на системата MyZone</p>
        </div>
      </div>

      <Tabs defaultValue="stats" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="stats" className="flex items-center gap-2">
            <BarChart className="w-4 h-4" />
            Статистики
          </TabsTrigger>
          <TabsTrigger value="users" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            Потребители
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="w-4 h-4" />
            Нотификации
          </TabsTrigger>
          <TabsTrigger value="activity" className="flex items-center gap-2">
            <Activity className="w-4 h-4" />
            Активност
          </TabsTrigger>
        </TabsList>

        {/* Stats Tab */}
        <TabsContent value="stats" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {statsCards.map((stat) => {
              const Icon = stat.icon;
              return (
                <Card key={stat.title}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">
                          {stat.title}
                        </p>
                        <p className="text-3xl font-bold">{stat.value}</p>
                      </div>
                      <Icon className={`h-8 w-8 ${stat.color}`} />
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <Button onClick={loadStats} variant="outline">
            Обнови статистиките
          </Button>
        </TabsContent>

        {/* Users Tab */}
        <TabsContent value="users" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-semibold">Управление на потребители</h2>
            <Button onClick={loadUsers} variant="outline">
              Обнови списъка
            </Button>
          </div>

          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Потребител</TableHead>
                    <TableHead>Роля</TableHead>
                    <TableHead>Статус</TableHead>
                    <TableHead>Дата на регистрация</TableHead>
                    <TableHead className="text-right">Действия</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{user.display_name || 'Няма име'}</p>
                          <p className="text-sm text-muted-foreground">{user.email}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        {isUserAdmin(user) ? (
                          <Badge variant="default" className="bg-yellow-500">
                            <Crown className="w-3 h-3 mr-1" />
                            Админ
                          </Badge>
                        ) : (
                          <Badge variant="secondary">Потребител</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {user.blocked ? (
                          <Badge variant="destructive">
                            <Ban className="w-3 h-3 mr-1" />
                            Блокиран
                          </Badge>
                        ) : (
                          <Badge variant="default" className="bg-green-500">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Активен
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {new Date(user.created_at).toLocaleDateString('bg-BG')}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end space-x-2">
                          {/* Edit User */}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEditUser(user)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>

                          {/* Block/Unblock */}
                          {user.blocked ? (
                            <Button
                              size="sm"
                              variant="default"
                              onClick={() => unblockUser(user.user_id)}
                            >
                              <CheckCircle className="w-4 h-4" />
                            </Button>
                          ) : (
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => setSelectedUser(user)}
                                >
                                  <Ban className="w-4 h-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Блокиране на потребител</DialogTitle>
                                  <DialogDescription>
                                    Въведете причина за блокирането на {user.email}
                                  </DialogDescription>
                                </DialogHeader>
                                <div className="space-y-2">
                                  <Label htmlFor="reason">Причина</Label>
                                  <Textarea
                                    id="reason"
                                    value={blockReason}
                                    onChange={(e) => setBlockReason(e.target.value)}
                                    placeholder="Опишете причината за блокирането..."
                                  />
                                </div>
                                <DialogFooter>
                                  <Button
                                    onClick={handleBlockUser}
                                    variant="destructive"
                                    disabled={!blockReason.trim()}
                                  >
                                    Блокирай
                                  </Button>
                                </DialogFooter>
                              </DialogContent>
                            </Dialog>
                          )}

                          {/* Admin Actions */}
                          {isUserAdmin(user) ? (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => removeAdmin(user.user_id)}
                            >
                              <UserMinus className="w-4 h-4" />
                            </Button>
                          ) : (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => makeAdmin(user.user_id)}
                            >
                              <UserPlus className="w-4 h-4" />
                            </Button>
                          )}

                          {/* Delete User */}
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button size="sm" variant="destructive">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Изтриване на потребител</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Сигурни ли сте, че искате да изтриете потребителя {user.email}? 
                                  Това действие е необратимо и ще изтрие всичките му данни.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Отказ</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => deleteUser(user.user_id)}
                                  className="bg-destructive text-destructive-foreground"
                                >
                                  Изтрий
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notifications Tab */}
        <TabsContent value="notifications" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-semibold">Управление на нотификации</h2>
            <SendNotificationDialog users={users.map(u => ({ user_id: u.user_id, email: u.email, display_name: u.display_name }))} />
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Push нотификации</CardTitle>
              <CardDescription>
                Изпращайте push нотификации до всички потребители или до конкретни потребители
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <Bell className="h-8 w-8 text-primary" />
                      <div>
                        <h3 className="font-semibold">Персонални нотификации</h3>
                        <p className="text-sm text-muted-foreground">
                          Изпращане до конкретен потребител
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <Users className="h-8 w-8 text-primary" />
                      <div>
                        <h3 className="font-semibold">Масови нотификации</h3>
                        <p className="text-sm text-muted-foreground">
                          Изпращане до всички потребители
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Test Water Notification with Action Buttons */}
              <Card>
                <CardHeader>
                  <CardTitle>Тест известие за вода с бутони</CardTitle>
                  <CardDescription>
                    Изпрати тестово известие с бутони за бързо добавяне на вода
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <WaterNotificationTest />
                </CardContent>
              </Card>

              <div className="p-4 bg-muted rounded-lg">
                <h4 className="font-medium mb-2">Планирани типове известия:</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• <strong>Хидратация:</strong> 3 пъти дневно - 12:00, 16:00, 20:00 ч. с бутони за вода</li>
                  <li>• <strong>Фастинг:</strong> 10 мин. преди започване с бутон "Започни"</li>
                  <li>• <strong>Храна:</strong> 15 мин. след часовете за хранене с бутон "Изядено"</li>
                  <li>• <strong>Навици:</strong> В зададените часове с бутон за завършване</li>
                </ul>
              </div>

              {/* Instant Notification Controls */}
              <div className="flex gap-4">
                <InstantNotificationDialog users={users.map(u => ({ user_id: u.user_id, email: u.email, display_name: u.display_name }))} />
              </div>

            </CardContent>
          </Card>
        </TabsContent>

        {/* Activity Tab */}
        <TabsContent value="activity" className="space-y-6">
          <ActivityFeed />
        </TabsContent>
      </Tabs>

      {/* Edit User Dialog */}
      {editingUser && (
        <Dialog open={!!editingUser} onOpenChange={() => setEditingUser(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Редактиране на потребител</DialogTitle>
              <DialogDescription>
                Променете данните на потребителя {editingUser.email}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="display_name">Име</Label>
                <Input
                  id="display_name"
                  value={editForm.display_name}
                  onChange={(e) => setEditForm(prev => ({ ...prev, display_name: e.target.value }))}
                  placeholder="Име на потребителя"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Имейл</Label>
                <Input
                  id="email"
                  value={editForm.email}
                  onChange={(e) => setEditForm(prev => ({ ...prev, email: e.target.value }))}
                  placeholder="Имейл адрес"
                />
              </div>
            </div>
            <DialogFooter>
              <Button onClick={() => setEditingUser(null)} variant="outline">
                Отказ
              </Button>
              <Button onClick={handleUpdateUser}>
                Запази промените
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default Admin;