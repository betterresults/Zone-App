import React, { useEffect, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useReferral } from '@/hooks/useReferral';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { MousePointerClick, UserPlus, Share, Info, Trophy, Gift, Beaker } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { supabase } from '@/integrations/supabase/client';
import RewardTimeline from '@/components/referral/RewardTimeline';


// Declare Partnero global
declare global {
  interface Window {
    po: any;
  }
}

const Referral = () => {
  const { user, loading: authLoading } = useAuth();
  const { referralData, loading, error, refetch, generateReferralLink, copyReferralLink, generating } = useReferral();
  const [isOpen, setIsOpen] = React.useState(false);


  useEffect(() => {
    // Embeddable Partnero widget temporarily disabled (403 without Program ID).
    // We rely on our API-based stats and manual link generation below.
  }, []);

  if (authLoading || loading) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-1/3"></div>
          <div className="h-64 bg-muted rounded"></div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="container mx-auto p-6">
        <Card className="border-warning">
          <CardContent className="pt-6">
            <p className="text-warning">Моля, влезте в акаунта си за да видите "Покани приятел".</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="space-y-2">
        <div className="flex items-center gap-3">
          <h1 className="text-3xl font-bold tracking-tight">Покани приятел</h1>
          <Button
            variant="ghost"
            size="sm"
            className="p-1"
            onClick={() => setIsOpen((v) => !v)}
            aria-expanded={isOpen}
            aria-controls="how-it-works"
            title="Как работи?"
          >
            <Info className="h-4 w-4" />
          </Button>
        </div>
        <p className="text-muted-foreground">
          Ако MyZone ви е полезен и искате да помогнете на приятели да открият платформата, споделете я с тях! Получавате награди според типа на канените приятели.
        </p>
      </div>

      {isOpen && (
        <div id="how-it-works" className="space-y-6 mt-6">
          {/* How it Works Section */}
          <Card className="bg-gradient-to-r from-primary/5 to-accent/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Info className="h-5 w-5" />
                Как работи "Покани приятел"?
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center space-y-2">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                    <Share className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-semibold">1. Споделете</h3>
                  <p className="text-sm text-muted-foreground">
                    Споделете вашия уникален линк с приятели и семейство
                  </p>
                </div>
                
                <div className="text-center space-y-2">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                    <UserPlus className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-semibold">2. Регистрират се</h3>
                  <p className="text-sm text-muted-foreground">
                    Приятелите ви се регистрират чрез вашия линк
                  </p>
                </div>
                
                <div className="text-center space-y-2">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                    <Gift className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-semibold">3. Получавате награда</h3>
                  <p className="text-sm text-muted-foreground">
                    За всеки активен приятел получавате безплатен месец
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Кликвания по линка
            </CardTitle>
            <MousePointerClick className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {referralData?.clicks || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              Общо кликвания
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Канени приятели
            </CardTitle>
            <UserPlus className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {referralData?.totalReferrals || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              Успешни регистрации
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Прогрес
            </CardTitle>
            <Gift className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {referralData?.milestoneProgress?.current || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              Активни приятели
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Interactive Reward Timeline */}
      {referralData && (
        <RewardTimeline 
          freeReferrals={referralData.milestoneProgress?.current || 0}
          premiumReferrals={Math.floor((referralData.totalReferrals || 0) * 0.3)}
        />
      )}

      {/* Earned Rewards */}
      {referralData?.earnedRewards && referralData.earnedRewards.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Gift className="h-5 w-5 text-primary" />
              Спечелени награди
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {referralData.earnedRewards.map((reward) => (
                <div key={reward.id} className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg">
                  <div>
                    <div className="font-medium">{reward.description}</div>
                    <div className="text-sm text-muted-foreground">
                      Спечелено на {new Date(reward.earnedAt).toLocaleDateString('bg-BG')}
                    </div>
                  </div>
                  <div className="text-sm font-medium text-primary">
                    {reward.value}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Referral Link Generation */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Gift className="h-5 w-5" />
            Вашият референтен линк
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Error Display */}
          {error && (
            <div className="mb-2 p-3 bg-destructive/10 border border-destructive/20 rounded-lg">
              <p className="text-destructive text-sm">Грешка: {error}</p>
            </div>
          )}

          <div className="flex flex-col sm:flex-row gap-3">
            <Input
              readOnly
              value={referralData?.referralLink || ''}
              placeholder="Все още нямате генериран линк"
            />
            <div className="flex gap-2">
              {!referralData?.referralLink && (
                <Button
                  type="button"
                  onClick={async (e) => {
                    e.preventDefault();
                    await generateReferralLink();
                  }}
                  disabled={generating}
                  aria-busy={generating}
                >
                  {generating ? 'Генериране...' : 'Генерирай линк'}
                </Button>
              )}
              <Button type="button" variant="secondary" onClick={copyReferralLink} disabled={!referralData?.referralLink}>
                Копирай линка
              </Button>
            </div>
          </div>
          <p className="text-sm text-muted-foreground">Споделете този линк с приятели, за да натрупвате награди.</p>
        </CardContent>
      </Card>


      {/* Important Information */}
      <Card>
        <CardHeader>
          <CardTitle>Важни условия</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 border rounded-lg bg-gradient-to-r from-primary/5 to-primary/10">
                <div>
                  <p className="font-medium">Система награди</p>
                  <p className="text-sm text-muted-foreground">Различни награди за безплатни и премиум приятели</p>
                </div>
              </div>
              
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <p className="font-medium">Условие за приятели</p>
                  <p className="text-sm text-muted-foreground">Трябва да са нови потребители</p>
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <p className="font-medium">Добавяне на награда</p>
                  <p className="text-sm text-muted-foreground">Автоматично към вашия акаунт</p>
                </div>
              </div>
              
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <p className="font-medium">Валидност на кукитата</p>
                  <p className="text-sm text-muted-foreground">90 дни</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

    </div>
  );
};

export default Referral;