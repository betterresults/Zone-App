import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp, 
  Target, 
  ChefHat, 
  Calendar, 
  Clock, 
  Droplets,
  Dumbbell,
  CheckCircle2,
  Users,
  Heart,
  Zap,
  Shield,
  Star,
  ArrowRight,
  Play,
  User,
  LogIn
} from "lucide-react";
import { Link } from "react-router-dom";
import { useReferralTracking } from "@/hooks/useReferralTracking";

const Landing = () => {
  // Track referral parameters from URL
  useReferralTracking();
  const features = [
    {
      icon: Target,
      title: "Zone диет система",
      description: "Прецизно балансиране на протеини, въглехидрати и мазнини в съотношение 4:3:3 за оптимален метаболизъм. Автоматично изчисление на Zone блоковете за всяко ястие и порция, което прави здравословното хранене лесно и точно."
    },
    {
      icon: ChefHat,
      title: "Интелигентно готвене и рецепти",
      description: "Създавайте, запазвайте и търсете рецепти с автоматично изчисление на калориите, макронутриентите и Zone блоковете. Калкулиране на точните стойности за всяка порция, адаптиране на рецептите според броя порции, организиране на любимите ви рецепти в лесно достъпна библиотека."
    },
    {
      icon: Calendar,
      title: "Седмично планиране на менюто",
      description: "Планирайте менюто си напред за цялата седмица и никога не се чудете какво да ядете. Автоматично генериране на списъци за пазаруване, балансиране на хранителните стойности за всеки ден, лесно копиране на успешни менюта от предишни седмици."
    },
    {
      icon: TrendingUp,
      title: "Проследяване на прогреса и аналитика",
      description: "Детайлно следене на теглото, измерванията на тялото, приема на храна и хранителни стойности. Визуални графики и отчети, които показват напредъка ви във времето, анализ на тенденциите и постигнатите цели."
    },
    {
      icon: Droplets,
      title: "Проследяване на хидратацията",
      description: "Следете дневното си водно количество с лесни за използване инструменти. Персонализирани цели за хидратация според теглото и активността ви, напомняния за пиене на вода, статистики за хидратацията във времето."
    },
    {
      icon: Clock,
      title: "Интервално гладуване",
      description: "Интегриран таймер за интервално гладуване с различни персонализирани режими (16:8, 18:6, 24 часа и др.). Проследяване на успешно завършените постове, статистики и мотивационни инструменти за по-лесно спазване на режима."
    },
    {
      icon: Dumbbell,
      title: "Фитнес и тренировки",
      description: "Проследяване на физическата активност, изгорени калории от тренировки, интеграция с фитнес целите. Възможност за добавяне на различни видове тренировки и тяхното влияние върху дневния калориен баланс."
    },
  ];

  const benefits = [
    "Устойчиво отслабване и поддържане на здравословно тегло",
    "По-добра енергия и издръжливост през целия ден", 
    "Подобрена концентрация и ментална яснота",
    "Намален риск от хронични заболявания",
    "Контролирани нива на кръвната захар и инсулин",
    "Оптимизиран метаболизъм и по-ефективно изгаряне на мазнини",
    "По-добро качество на съня и възстановяване",
    "Увеличена мускулна маса и намалена мастна тъкан"
  ];

  const testimonials = [
    {
      name: "Мария П.",
      text: "С MyZone успях да свали 15 кг за 6 месеца и да поддържам енергията си високо през целия ден. Комбинацията от Zone диета, фитнес проследяване и интервално гладуване наистина работи!",
      rating: 5
    },
    {
      name: "Димитър К.",
      text: "Като спортист, MyZone ми помогна да оптимизирам хранителния си режим и тренировките. Проследяването на всички аспекти - от храна до хидратация, прави голяма разлика в представянето ми.",
      rating: 5
    },
    {
      name: "Елена С.",
      text: "Планирането на менюто и автоматичното изчисление на калориите направи здравословното ми хранене толкова лесно! Най-накрая имам контрол над теглото си без стрес.",
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between max-w-full overflow-hidden">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
              <span className="text-white font-bold">Z</span>
            </div>
            <span className="text-xl font-bold text-primary">MyZone</span>
          </div>
          <div className="flex items-center gap-4">
            <Link to="/auth">
              <Button variant="ghost" className="hidden sm:inline-flex">Вход</Button>
              <Button variant="ghost" size="icon" className="sm:hidden hover:bg-muted hover:text-foreground">
                <User className="w-4 h-4" />
                <span className="sr-only">Вход</span>
              </Button>
            </Link>
            <Link to="/auth">
              <Button className="hidden sm:inline-flex">Започни безплатно</Button>
              <Button size="icon" className="sm:hidden">
                <LogIn className="w-4 h-4" />
                <span className="sr-only">Започни безплатно</span>
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-6 md:py-12 lg:py-20 bg-gradient-to-br from-primary/5 via-background to-accent/5">
        <div className="container mx-auto px-4 text-center space-y-4 md:space-y-6 max-w-full overflow-hidden">
          <Badge variant="secondary" className="mb-4">
            <Star className="w-4 h-4 mr-2" />
            Научно базирано приложение за здравословен живот
          </Badge>
          
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-7xl font-bold text-foreground max-w-4xl mx-auto leading-tight px-2 text-center">
            Постигни оптималното си здраве и форма с
            <span className="text-primary bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent"> MyZone</span>
          </h1>
          
          <p className="text-base sm:text-lg lg:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed px-4">
            Цялостно приложение за здравословен живот - проследяване на храната, Zone диета, фитнес, хидратация и интервално гладуване. 
            Всичко необходимо за постигане и поддържане на идеалното ти тегло и здраве.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mt-4 md:mt-8 px-4">
            <Link to="/auth" className="w-full sm:w-auto">
              <Button size="lg" className="text-base sm:text-lg px-6 sm:px-8 py-4 sm:py-6 w-full sm:w-auto">
                <Play className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                Започни безплатно днес
              </Button>
            </Link>
            <Link to="/information" className="w-full sm:w-auto">
              <Button variant="outline" size="lg" className="text-base sm:text-lg px-4 sm:px-6 py-4 sm:py-6 w-full sm:w-auto whitespace-normal text-center min-h-[3rem]">
                Научи повече
              </Button>
            </Link>
          </div>
          
          <div className="flex flex-wrap items-center justify-center gap-4 md:gap-8 mt-6 md:mt-12 text-sm text-muted-foreground px-4">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-green-500" />
              Безплатно
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-green-500" />
              Научно базирано
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-green-500" />
              Лесно за използване
            </div>
          </div>
        </div>
      </section>

      {/* What is Zone Diet */}
      <section className="py-8 md:py-12 lg:py-16 bg-background">
        <div className="container mx-auto px-4 max-w-full overflow-hidden">
          <div className="text-center space-y-4 mb-8 md:mb-16">
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground text-center">
              Как MyZone помага за здравословен живот?
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-center">
              MyZone предлага цялостен подход към здравословното хранене, включвайки Zone диетата като основа за балансирано хранене, 
              съчетано с проследяване на фитнес, хидратация и интервално гладуване за оптимални резултати.
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
            <div className="space-y-6">
              <h3 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground text-center">
                Как работи Zone системата?
              </h3>
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 bg-zone-protein/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <div className="w-4 h-4 bg-zone-protein rounded-full"></div>
                  </div>
                  <div>
                    <h4 className="font-semibold text-zone-protein">Протеини (7г на блок)</h4>
                    <p className="text-muted-foreground">Изграждат и поддържат мускулната маса, стимулират метаболизма</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 bg-zone-carbs/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <div className="w-4 h-4 bg-zone-carbs rounded-full"></div>
                  </div>
                  <div>
                    <h4 className="font-semibold text-zone-carbs">Въглехидрати (9г на блок)</h4>
                    <p className="text-muted-foreground">Предпочитайте нискогликемични за стабилна енергия</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 bg-zone-fat/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <div className="w-4 h-4 bg-zone-fat rounded-full"></div>
                  </div>
                  <div>
                    <h4 className="font-semibold text-zone-fat">Мазнини (1.5г на блок)</h4>
                    <p className="text-muted-foreground">Полезни мазнини за хормонален баланс и наситеност</p>
                  </div>
                </div>
              </div>
              
              <div className="p-6 bg-gradient-to-r from-primary/5 to-accent/5 rounded-xl">
                <p className="text-sm text-muted-foreground mb-2">Ключовата информация:</p>
                <p className="font-medium">
                  Всеки Zone блок съдържа точно балансирано съотношение 4:3:3 
                  (40% въглехидрати, 30% протеини, 30% мазнини) за оптимален хормонален отговор.
                </p>
              </div>
            </div>
            
            <div className="bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border">
              <h4 className="text-xl font-bold text-foreground mb-6 text-center">
                Пример: 1 Zone блок
              </h4>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-zone-protein/10 rounded-lg border border-zone-protein/20">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-zone-protein rounded-full"></div>
                    <span className="font-medium text-zone-protein">Протеини</span>
                  </div>
                  <span className="text-xl font-bold text-zone-protein">7г</span>
                </div>
                
                <div className="flex items-center justify-between p-4 bg-zone-carbs/10 rounded-lg border border-zone-carbs/20">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-zone-carbs rounded-full"></div>
                    <span className="font-medium text-zone-carbs">Въглехидрати</span>
                  </div>
                  <span className="text-xl font-bold text-zone-carbs">9г</span>
                </div>
                
                <div className="flex items-center justify-between p-4 bg-zone-fat/10 rounded-lg border border-zone-fat/20">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-zone-fat rounded-full"></div>
                    <span className="font-medium text-zone-fat">Мазнини</span>
                  </div>
                  <span className="text-xl font-bold text-zone-fat">1.5г</span>
                </div>
                
                <div className="text-center pt-4 border-t">
                  <p className="text-2xl font-bold text-primary">~95 калории</p>
                  <p className="text-sm text-muted-foreground">на блок</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-8 md:py-16 lg:py-20 bg-gradient-to-br from-accent/5 to-primary/5">
        <div className="container mx-auto px-4">
          <div className="text-center space-y-4 mb-8 md:mb-16">
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground text-center">
              Всичко необходимо в едно приложение
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-center">
              MyZone ти предоставя всички инструменти за постигане на оптимално здраве, устойчиво отслабване и поддържане на идеална форма
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {features.map((feature, index) => (
              <Card key={index} className="group hover:shadow-lg transition-all duration-300">
                <CardContent className="p-8">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold text-foreground mb-3">
                    {feature.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-8 md:py-16 lg:py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
            <div className="space-y-6">
              <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground text-center">
                Защо хората избират MyZone?
              </h2>
              <p className="text-xl text-muted-foreground text-center">
                Научно доказаните подходи и цялостното проследяване правят MyZone предпочитаният избор 
                за хората, които искат реални и устойчиви резултати за здравето си.
              </p>
              
              <div className="space-y-3">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
                    <span className="text-foreground">{benefit}</span>
                  </div>
                ))}
              </div>
              
              <Link to="/auth">
                <Button size="lg" className="mt-6">
                  Започни своята трансформация
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>
            
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-6">
                <Card className="text-center p-6 bg-gradient-to-br from-green-50 to-green-100 border-green-200">
                  <Heart className="w-8 h-8 text-green-600 mx-auto mb-3" />
                  <h4 className="font-bold text-2xl text-green-700">85%</h4>
                  <p className="text-sm text-green-600">подобрена енергия</p>
                </Card>
                
                <Card className="text-center p-6 bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
                  <Shield className="w-8 h-8 text-blue-600 mx-auto mb-3" />
                  <h4 className="font-bold text-2xl text-blue-700">90%</h4>
                  <p className="text-sm text-blue-600">по-добро здраве</p>
                </Card>
              </div>
              
              <div className="space-y-6 mt-8">
                <Card className="text-center p-6 bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
                  <Zap className="w-8 h-8 text-purple-600 mx-auto mb-3" />
                  <h4 className="font-bold text-2xl text-purple-700">78%</h4>
                  <p className="text-sm text-purple-600">по-добър фокус</p>
                </Card>
                
                <Card className="text-center p-6 bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
                  <Users className="w-8 h-8 text-orange-600 mx-auto mb-3" />
                  <h4 className="font-bold text-2xl text-orange-700">10К+</h4>
                  <p className="text-sm text-orange-600">доволни потребители</p>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-8 md:py-16 lg:py-20 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="container mx-auto px-4">
          <div className="text-center space-y-4 mb-8 md:mb-16">
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground text-center">
              Какво казват нашите потребители
            </h2>
            <p className="text-xl text-muted-foreground text-center">
              Истински истории за трансформация от хора като теб
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-background">
                <CardContent className="p-8">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-6 leading-relaxed">
                    "{testimonial.text}"
                  </p>
                  <p className="font-semibold text-foreground">
                    {testimonial.name}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-8 md:py-16 lg:py-20 bg-gradient-to-r from-primary to-accent text-white">
        <div className="container mx-auto px-4 text-center space-y-4 md:space-y-8">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-center">
            Готов да започнеш своята трансформация?
          </h2>
          <p className="text-xl opacity-90 max-w-2xl mx-auto text-center">
            Присъедини се към хиляди хора, които вече постигат резултатите си с MyZone. 
            Започни безплатно днес - не са необходими кредитни карти.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link to="/auth">
              <Button size="lg" variant="secondary" className="text-lg px-8 py-6">
                <Play className="w-5 h-5 mr-2" />
                Създай безплатен акаунт
              </Button>
            </Link>
            <Link to="/information">
              <Button size="lg" variant="outline" className="text-lg px-8 py-6 text-white border-white hover:bg-white hover:text-primary bg-transparent">
                Научи повече
              </Button>
            </Link>
          </div>
          
          <div className="flex items-center justify-center gap-4 md:gap-8 mt-6 md:mt-12 text-sm opacity-80">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              Безплатна регистрация
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              Без месечни такси
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              Пълен достъп
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-6 md:py-12 bg-muted/30 border-t">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-primary rounded-md flex items-center justify-center">
                <span className="text-white font-bold text-sm">Z</span>
              </div>
              <span className="text-lg font-bold text-primary">MyZone</span>
            </div>
            
            <div className="flex items-center gap-6 text-sm text-muted-foreground">
              <Link to="/information" className="hover:text-foreground transition-colors">
                За здравословното хранене
              </Link>
              <Link to="/auth" className="hover:text-foreground transition-colors">
                Вход
              </Link>
              <Link to="/auth" className="hover:text-foreground transition-colors">
                Регистрация
              </Link>
            </div>
            
            <p className="text-sm text-muted-foreground">
              © 2024 MyZone. Всички права запазени.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Landing;