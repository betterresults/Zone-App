import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle, Users, Star, MessageSquare } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useBetaTesters } from '@/hooks/useBetaTesters';
import authBackground from '@/assets/auth-background-green.jpg';

const BetaSignup = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    displayName: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { signUp } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { data: betaTestersCount = 0 } = useBetaTesters();
  
  const BETA_LIMIT = 50;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (betaTestersCount >= BETA_LIMIT) {
      toast({
        title: "Beta програмата е пълна",
        description: "Моля опитайте отново по-късно.",
        variant: "destructive"
      });
      return;
    }
    
    setLoading(true);
    setError('');

    try {
      const { error: signUpError, user } = await signUp(
        formData.email, 
        formData.password, 
        formData.displayName,
        { beta_signup: true }
      );

      if (signUpError) {
        setError(signUpError.message);
        return;
      }

      // Immediately create PRO subscription for beta user
      if (user) {
        try {
          const sixMonthsFromNow = new Date(Date.now() + 6 * 30 * 24 * 60 * 60 * 1000).toISOString();
          
          await supabase
            .from('subscribers')
            .upsert({
              user_id: user.id,
              email: formData.email,
              subscribed: true,
              subscription_tier: 'pro',
              subscription_end: sixMonthsFromNow,
              subscription_source: 'beta'
            }, {
              onConflict: 'email'
            });

          // Refresh the beta testers count immediately
          queryClient.invalidateQueries({ queryKey: ['betaTestersCount'] });
        } catch (err) {
          console.error('Failed to create beta subscription:', err);
        }
      }

      navigate('/beta-welcome');
    } catch (error) {
      console.error('Beta signup error:', error);
      setError('Възникна грешка при регистрацията');
    } finally {
      setLoading(false);
    }
  };

  const benefits = [
    { icon: Star, text: "6 месеца безплатен премиум достъп" },
    { icon: Users, text: "Ранен достъп до нови функции" },
    { icon: MessageSquare, text: "Директен канал за обратна връзка" }
  ];

  return (
    <div 
      className="min-h-screen flex items-center justify-center p-4 overflow-x-hidden"
      style={{
        backgroundImage: `url(${authBackground})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }}
    >
      {/* Background overlay - same as auth page */}
      <div className="absolute inset-0 bg-black/30" />
      
      <div className="w-full max-w-6xl relative z-10">
        {/* Header Section */}
        <div className="text-center mb-8 md:mb-12">
          <h1 className="text-4xl md:text-7xl font-bold mb-4 md:mb-6 text-white drop-shadow-lg">
            My Zone
          </h1>
          <h2 className="text-2xl md:text-4xl font-bold text-white mb-3 md:mb-4 drop-shadow-sm">
            Присъединете се към нашата бета програма
          </h2>
          <p className="text-base md:text-xl text-white/90 drop-shadow-sm max-w-2xl mx-auto px-4">
            Получете 6 месеца безплатен премиум достъп и помогнете ни да направим приложението по-добро с вашата обратна връзка
          </p>
        </div>

        {/* Main Content - Responsive Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8 items-stretch">
          {/* Left Column - Benefits and Limited Spots */}
          <div className="space-y-4 md:space-y-6 h-full flex flex-col order-2 lg:order-1">
            {/* Benefits */}
            <div className="space-y-3 md:space-y-4 flex-1">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-center gap-3 p-3 md:p-4 bg-white/90 backdrop-blur-md rounded-lg border shadow-lg">
                  <div className="flex-shrink-0 w-8 h-8 md:w-10 md:h-10 bg-primary/10 rounded-full flex items-center justify-center">
                    <benefit.icon className="w-4 h-4 md:w-5 md:h-5 text-primary" />
                  </div>
                  <span className="text-foreground font-medium text-sm md:text-base">{benefit.text}</span>
                </div>
              ))}
            </div>

            {/* Limited Spots Section */}
            <Card className="bg-white/90 backdrop-blur-md border-primary/20 shadow-2xl">
              <CardContent className="p-4 md:p-6">
                <div className="text-center space-y-3 md:space-y-4">
                  <div className="flex items-center justify-center gap-2 mb-3 md:mb-4">
                    <CheckCircle className="h-5 w-5 md:h-6 md:w-6 text-primary" />
                    <h3 className="text-xl md:text-2xl font-bold text-foreground">Ограничено място</h3>
                  </div>
                  
                  <div className="space-y-3 md:space-y-4">
                    <div className="text-base md:text-lg text-muted-foreground">
                      Само <span className="font-bold text-primary">{BETA_LIMIT}</span> избрани бета тестери
                    </div>
                    
                    <div className="space-y-2 md:space-y-3">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Регистрирани:</span>
                        <span className="font-bold text-xl md:text-2xl text-primary">
                          {betaTestersCount}/{BETA_LIMIT}
                        </span>
                      </div>
                      
                      <div className="w-full bg-muted rounded-full h-3 md:h-4 overflow-hidden shadow-inner">
                        <div 
                          className="bg-gradient-to-r from-primary to-primary/80 h-3 md:h-4 rounded-full transition-all duration-500 ease-out relative overflow-hidden" 
                          style={{ width: `${Math.min((betaTestersCount / BETA_LIMIT) * 100, 100)}%` }}
                        >
                          <div className="absolute inset-0 bg-white/20 animate-pulse" />
                        </div>
                      </div>
                      
                      <div className="text-sm">
                        <span className="text-muted-foreground">Остават:</span>
                        <span className="font-semibold text-foreground ml-1">
                          {Math.max(BETA_LIMIT - betaTestersCount, 0)} места
                        </span>
                      </div>
                    </div>
                  </div>

                  {betaTestersCount >= BETA_LIMIT && (
                    <div className="text-center p-3 md:p-4 bg-destructive/10 rounded-lg border border-destructive/20">
                      <p className="text-destructive font-semibold text-sm md:text-base">⚠️ Beta програмата е пълна</p>
                      <p className="text-xs md:text-sm text-muted-foreground mt-1">Моля опитайте отново по-късно</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Registration Form */}
          <Card className="bg-white/90 backdrop-blur-md shadow-2xl h-full order-1 lg:order-2">
            <CardHeader className="pb-4 md:pb-6">
              <CardTitle className="text-xl md:text-2xl">Регистрация</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <form onSubmit={handleSubmit} className="space-y-3 md:space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="displayName" className="text-sm md:text-base">Име</Label>
                  <Input
                    id="displayName"
                    type="text"
                    placeholder="Вашето име"
                    value={formData.displayName}
                    onChange={(e) => setFormData(prev => ({ ...prev, displayName: e.target.value }))}
                    required
                    className="h-10 md:h-12"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm md:text-base">Имейл</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your@email.com"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                    required
                    className="h-10 md:h-12"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-sm md:text-base">Парола</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Изберете сигурна парола"
                    value={formData.password}
                    onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                    required
                    className="h-10 md:h-12"
                  />
                </div>

                {error && (
                  <Alert variant="destructive" className="py-2 md:py-3">
                    <AlertDescription className="text-sm">{error}</AlertDescription>
                  </Alert>
                )}

                <Button 
                  type="submit" 
                  className="w-full h-10 md:h-12 text-sm md:text-base" 
                  disabled={loading || betaTestersCount >= BETA_LIMIT}
                >
                  {loading 
                    ? 'Регистриране...' 
                    : betaTestersCount >= BETA_LIMIT 
                      ? 'Beta програмата е пълна' 
                      : 'Присъединяване към бета програмата'
                  }
                </Button>

                <p className="text-xs md:text-sm text-muted-foreground text-center">
                  Вече имате профил?{' '}
                  <button
                    type="button"
                    onClick={() => navigate('/auth')}
                    className="text-primary hover:underline"
                  >
                    Влезте тук
                  </button>
                </p>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default BetaSignup;