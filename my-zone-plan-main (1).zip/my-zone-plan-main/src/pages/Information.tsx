import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useFeatureFlags } from '@/hooks/useFeatureFlags';
import { useProfile } from '@/hooks/useProfile';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { Target, Heart, Droplets, Clock, Dumbbell, Brain, Shield, Zap, Flame, Leaf, Activity, AlertCircle, Gauge, Coffee, Moon, Sun, Settings, Smile, Lightbulb, Timer, Trophy, Star } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Information = () => {
  const { isZoneEnabled, isFitnessEnabled, isHydrationEnabled, isFastingEnabled } = useFeatureFlags();
  const { profile, refetch, calculateZoneBlocks } = useProfile();
  const navigate = useNavigate();

  const toggleFeature = async (feature: string, enabled: boolean) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ [`${feature}_enabled`]: enabled })
        .eq('id', profile?.id);

      if (error) throw error;

      await refetch();
      toast({
        title: "Настройката е запазена",
        description: `${feature === 'zone' ? 'Зоната' : feature === 'fitness' ? 'Фитнесът' : feature === 'hydration' ? 'Хидратацията' : 'Фастингът'} е ${enabled ? 'включен' : 'изключен'}`,
      });
    } catch (error) {
      toast({
        title: "Грешка",
        description: "Неуспешно запазване на настройката",
        variant: "destructive",
      });
    }
  };

  const getRecommendedBlocks = () => {
    if (profile?.daily_blocks) {
      return profile.daily_blocks;
    }
    
    if (profile?.height_cm && profile?.weight_kg && profile?.age && profile?.gender && profile?.activity_level && profile?.weight_goal) {
      return calculateZoneBlocks({
        height_cm: profile.height_cm,
        weight_kg: profile.weight_kg,
        age: profile.age,
        gender: profile.gender,
        activity_level: profile.activity_level,
        weight_goal: profile.weight_goal
      });
    }
    
    return null;
  };

  return (
    <div className="container mx-auto px-6 py-8 space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-foreground">Здравна информация</h1>
        <p className="text-xl text-muted-foreground max-w-4xl mx-auto">
          Открийте как правилното хранене, хидратация, фитнес и фастинг могат да подобрят здравето ви и да регулират телесните функции.
        </p>
      </div>

      <Tabs defaultValue="zone" className="w-full">
        <TabsList className="grid w-full grid-cols-2 grid-rows-2 h-20 md:grid-cols-4 md:grid-rows-1 md:h-10 mb-6">
          <TabsTrigger value="zone">Зона диета</TabsTrigger>
          <TabsTrigger value="fasting">Фастинг</TabsTrigger>
          <TabsTrigger value="hydration">Хидратация</TabsTrigger>
          <TabsTrigger value="fitness">Фитнес</TabsTrigger>
        </TabsList>

        {/* Zone Diet Tab */}
        <TabsContent value="zone" className="space-y-6">
          <div className="text-center mt-6 space-y-4">
            <h2 className="text-3xl font-bold text-foreground flex items-center justify-center gap-2">
              <Target className="w-8 h-8 text-primary" />
              Зона диета — Балансът на хормоните
            </h2>
            {!isZoneEnabled && (
              <div className="flex items-center justify-center gap-2 p-4 bg-muted/50 rounded-lg border">
                <span className="text-sm font-medium">Включи Зоната</span>
                <Switch
                  checked={isZoneEnabled}
                  onCheckedChange={(checked) => toggleFeature('zone', checked)}
                />
              </div>
            )}
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="w-5 h-5 text-blue-500" />
                Какво е Зона диетата?
              </CardTitle>
              <CardDescription>
                Зона диетата е научно обоснован хранителен подход, създаден от д-р Бари Сиърс
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                Зона диетата не е просто диета за отслабване - това е начин на живот, базиран на контрола на хормоналния отговор на тялото чрез храната. 
                Основната цел е да се поддържа тялото в специална метаболитна зона, където възпалението е минимално, а енергийните нива са оптимални.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-primary/10 rounded-lg">
                  <h4 className="font-semibold mb-2">40% Въглехидрати</h4>
                  <p className="text-sm text-muted-foreground">Предимно от зеленчуци и плодове с нисък гликемичен индекс</p>
                </div>
                <div className="p-4 bg-primary/10 rounded-lg">
                  <h4 className="font-semibold mb-2">30% Протеини</h4>
                  <p className="text-sm text-muted-foreground">Постно месо, риба, яйца или растителни източници</p>
                </div>
                <div className="p-4 bg-primary/10 rounded-lg">
                  <h4 className="font-semibold mb-2">30% Мазнини</h4>
                  <p className="text-sm text-muted-foreground">Здравословни мазнини като омега-3, зехтин, авокадо</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-green-500" />
                  Какво се случва в тялото?
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Flame className="w-4 h-4 text-red-500" />
                      Контрол на възпалението
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      Правилното съотношение регулира производството на айкозаноиди - сигнални молекули, които контролират възпалителните процеси в тялото. 
                      Намалява се производството на провъзпалителни вещества и се увеличава на противовъзпалителните.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Gauge className="w-4 h-4 text-blue-500" />
                      Стабилизиране на кръвната захар
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      Контролираното количество въглехидрати предотвратява рязкото покачване на глюкозата в кръвта. Това води до по-стабилно ниво на инсулин, 
                      което е ключово за предотвратяване на диабет тип 2 и метаболитен синдром.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Heart className="w-4 h-4 text-red-500" />
                      Кардиоваскуларна защита
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      Намаляването на хроничното възпаление и подобряването на липидния профил защитават сърцето и кръвоносните съдове. 
                      Намалява се рискът от инфаркт, инсулт и атеросклероза.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-primary" />
                  Zone блокове обяснени
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="p-4 bg-zone-protein/10 rounded-lg border-l-4 border-zone-protein">
                    <h4 className="font-semibold mb-2 flex items-center gap-2 text-zone-protein">
                      <span className="w-6 h-6 rounded-full bg-zone-protein flex items-center justify-center text-white text-sm font-bold">P</span>
                      Протеини - 7g на блок
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      Протеините са строителният материал на тялото. Един блок съдържа 7g протеин, което е приблизително 30g постно месо, 
                      40g риба или 1 яйце. Протеините стабилизират кръвната захар и стимулират глюкагона.
                    </p>
                  </div>
                  
                  <div className="p-4 bg-zone-carbs/10 rounded-lg border-l-4 border-zone-carbs">
                    <h4 className="font-semibold mb-2 flex items-center gap-2 text-zone-carbs">
                      <span className="w-6 h-6 rounded-full bg-zone-carbs flex items-center justify-center text-white text-sm font-bold">В</span>
                      Въглехидрати - 9g нетни въглехидрати на блок
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      Въглехидратите са основният източник на енергия. Използваме нетни въглехидрати (общи въглехидрати минус фибри), 
                      защото фибрите не повишават кръвната захар. Предпочитаме зеленчуци и плодове с нисък гликемичен индекс.
                    </p>
                  </div>
                  
                  <div className="p-4 bg-zone-fat/10 rounded-lg border-l-4 border-zone-fat">
                    <h4 className="font-semibold mb-2 flex items-center gap-2 text-zone-fat">
                      <span className="w-6 h-6 rounded-full bg-zone-fat flex items-center justify-center text-white text-sm font-bold">М</span>
                      Мазнини - 3g на блок
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      Мазнините осигуряват устойчива енергия и помагат за усвояването на мастноразтворимите витамини. 
                      Един блок съдържа 3g мазнини общо, но тъй като много храни вече съдържат "скрити мазнини", 
                      при готвенето добавяме само 1.5g мазнини (зехтин, орехи, авокадо).
                    </p>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center gap-4 p-3 rounded-lg bg-zone-protein/10 border">
                    <div className="w-10 h-10 rounded-full bg-zone-protein flex items-center justify-center flex-shrink-0">
                      <span className="text-white font-bold text-sm">P</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm">7g протеин = 1 блок</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4 p-3 rounded-lg bg-zone-carbs/10 border">
                    <div className="w-10 h-10 rounded-full bg-zone-carbs flex items-center justify-center flex-shrink-0">
                      <span className="text-white font-bold text-sm">В</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm">9g нетни въглехидрати = 1 блок</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4 p-3 rounded-lg bg-zone-fat/10 border">
                    <div className="w-10 h-10 rounded-full bg-zone-fat flex items-center justify-center flex-shrink-0">
                      <span className="text-white font-bold text-sm">М</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm">1.5g добавени мазнини = 1 блок</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Heart className="w-5 h-5 text-red-500" />
                Здравни ползи от Зона диетата
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2 text-green-600">🩺 Подобрено управление на диабета</h4>
                    <p className="text-sm text-muted-foreground">Стабилни нива на кръвната захар намаляват нуждата от инсулин и подобряват контрола при диабет тип 2</p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-blue-600">🧠 Повишена умствена яснота</h4>
                    <p className="text-sm text-muted-foreground">Стабилните нива на глюкоза осигуряват постоянно гориво за мозъка, подобрявайки концентрацията и паметта</p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-purple-600">⚡ Повече енергия през деня</h4>
                    <p className="text-sm text-muted-foreground">Избягване на енергийни пикове и спадове води до устойчива енергия без умора</p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-orange-600">🏃 Подобрена спортна производителност</h4>
                    <p className="text-sm text-muted-foreground">Оптималното съотношение на макронутриенти подобрява издръжливостта и възстановяването</p>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2 text-red-600">❤️ Сърдечно-съдово здраве</h4>
                    <p className="text-sm text-muted-foreground">Намаляване на възпалението и подобряване на липидния профил защитава сърцето</p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-green-600">⚖️ Устойчива загуба на тегло</h4>
                    <p className="text-sm text-muted-foreground">Контролът на инсулина насърчава горенето на мазнини без загуба на мускулна маса</p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-blue-600">🛡️ Противовъзпалително действие</h4>
                    <p className="text-sm text-muted-foreground">Намаляване на хроничното възпаление, което е в основата на много болести</p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-indigo-600">😴 По-качествен сън</h4>
                    <p className="text-sm text-muted-foreground">Стабилните хормонални нива подобряват циклите на съня и възстановяването</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Fasting Tab */}
        <TabsContent value="fasting" className="space-y-6">
          <div className="text-center mt-6 space-y-4">
            <h2 className="text-3xl font-bold text-foreground flex items-center justify-center gap-2">
              <Clock className="w-8 h-8 text-orange-500" />
              Интермитентен фастинг — Регенерация чрез почивка
            </h2>
            {!isFastingEnabled && (
              <div className="flex items-center justify-center gap-2 p-4 bg-muted/50 rounded-lg border">
                <span className="text-sm font-medium">Включи фастинга</span>
                <Switch
                  checked={isFastingEnabled}
                  onCheckedChange={(checked) => toggleFeature('fasting', checked)}
                />
              </div>
            )}
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-orange-500" />
                Какво е интермитентният фастинг?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Интермитентният фастинг (IF) е модел на хранене, който включва периоди на хранене и периоди на въздържание от храна. 
                Това не е диета в традиционния смисъл, а график на хранене, който оптимизира метаболитните процеси в тялото.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border">
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Sun className="w-4 h-4 text-green-500" />
                    12:12 метод
                  </h4>
                  <p className="text-sm text-muted-foreground">12 часа фастинг, 12 часа за хранене</p>
                  <Badge variant="secondary" className="mt-2">За начинаещи</Badge>
                </div>
                <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border">
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Sun className="w-4 h-4 text-blue-500" />
                    14:10 метод
                  </h4>
                  <p className="text-sm text-muted-foreground">14 часа фастинг, 10 часа за хранене</p>
                  <Badge variant="secondary" className="mt-2">За начинаещи</Badge>
                </div>
                <div className="p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg border">
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Sun className="w-4 h-4 text-orange-500" />
                    16:8 метод
                  </h4>
                  <p className="text-sm text-muted-foreground">16 часа фастинг, 8 часа за хранене</p>
                  <Badge variant="secondary" className="mt-2">Популярен</Badge>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg border">
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Moon className="w-4 h-4 text-purple-500" />
                    18:6 метод
                  </h4>
                  <p className="text-sm text-muted-foreground">18 часа фастинг, 6 часа за хранене</p>
                  <Badge variant="destructive" className="mt-2">За напреднали</Badge>
                </div>
                <div className="p-4 bg-red-50 dark:bg-red-900/20 rounded-lg border">
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Star className="w-4 h-4 text-red-500" />
                    OMAD (23:1)
                  </h4>
                  <p className="text-sm text-muted-foreground">Едно хранене на ден - най-екстремната форма</p>
                  <Badge variant="destructive" className="mt-2">За напреднали</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-yellow-500" />
                  Какво се случва в тялото при фастинг?
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Flame className="w-4 h-4 text-red-500" />
                      Кетоза и липолиза (~4-12 часа)
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      Когато запасите от гликоген се изчерпват, тялото започва да разгражда мазнините за енергия. 
                      Времето варира според индивида и активността.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Brain className="w-4 h-4 text-blue-500" />
                      Автофагия (~12-18 часа)
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      Активира се процесът на автофагия - клетъчно "почистване", при което се рециклират повредени протеини и органели. 
                      Постепенно засилваща се с времето.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Shield className="w-4 h-4 text-green-500" />
                      Хормонална оптимизация (~16+ часа)
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      Увеличава се производството на хормон на растежа, подобрява се инсулиновата чувствителност 
                      и се оптимизира производството на норадреналин.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-green-500" />
                  Механизми на действие
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Gauge className="w-4 h-4 text-blue-500" />
                    AMPK/mTOR баланс
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    Активира се AMPK (енергиен сензор), който инхибира mTOR пътя и стимулира катаболни процеси за енергия
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Clock className="w-4 h-4 text-purple-500" />
                    Циркаден ритъм
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    Подобрява синхронизацията на биологичните часовници, което оптимизира съня и метаболизма
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Shield className="w-4 h-4 text-green-500" />
                    Противовъзпалително действие
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    Намалява производството на провъзпалителни цитокини и активира противовъзпалителни пътища
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Brain className="w-4 h-4 text-indigo-500" />
                    Когнитивни ползи
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    Увеличава BDNF, подобрява неврогенезата и защитава мозъка от неврозапаление
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Heart className="w-5 h-5 text-red-500" />
                Научно доказани ползи от фастинга
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2 text-blue-600">🧬 Клетъчна регенерация и дълголетие</h4>
                    <p className="text-sm text-muted-foreground">
                      Автофагията премахва повредени клетъчни компоненти и стимулира производството на нови, здрави клетки. 
                      Това забавя процеса на стареене и увеличава продължителността на живота.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-green-600">⚖️ Ефективна загуба на тегло</h4>
                    <p className="text-sm text-muted-foreground">
                      Фастингът принуждава тялото да използва мазнините като основен източник на енергия, 
                      което води до значителна редукция на телесните мазнини при запазване на мускулната маса.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-purple-600">🧠 Подобрена когнитивна функция</h4>
                    <p className="text-sm text-muted-foreground">
                      Кетонните тела осигуряват по-ефективно гориво за мозъка от глюкозата, 
                      подобрявайки концентрацията, паметта и общата умствена яснота.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-red-600">❤️ Кардиоваскуларно здраве</h4>
                    <p className="text-sm text-muted-foreground">
                      Намаляване на кръвното налягане, подобряване на липидния профил и намаляване на риска от сърдечно-съдови заболявания
                    </p>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2 text-orange-600">🩺 Контрол на диабета</h4>
                    <p className="text-sm text-muted-foreground">
                      Значително подобряване на инсулиновата чувствителност и гликемичния контрол, 
                      което може да доведе до намаляване или премахване на медикамента при диабет тип 2.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-indigo-600">🛡️ Противовъзпалително действие</h4>
                    <p className="text-sm text-muted-foreground">
                      Драстично намаляване на маркерите за хронично възпаление в тялото, 
                      което е в основата на повечето възрастови заболявания.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-cyan-600">🧬 Защита от рак</h4>
                    <p className="text-sm text-muted-foreground">
                      Автофагията помага за премахването на потенциално канцерогенни клетки, 
                      а ниските нива на инсулин и IGF-1 намаляват риска от определени видове рак.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-teal-600">🧠 Неврозащита</h4>
                    <p className="text-sm text-muted-foreground">
                      Защита от неврологични заболявания като Алцхаймер, Паркинсон и деменция 
                      чрез подобряване на мозъчната пластичност и намаляване на неврозапалението.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Hydration Tab */}
        <TabsContent value="hydration" className="space-y-6">
          <div className="text-center mt-6 space-y-4">
            <h2 className="text-3xl font-bold text-foreground flex items-center justify-center gap-2">
              <Droplets className="w-8 h-8 text-blue-500" />
              Хидратация — Основата на живота
            </h2>
            {!isHydrationEnabled && (
              <div className="flex items-center justify-center gap-2 p-4 bg-muted/50 rounded-lg border">
                <span className="text-sm font-medium">Включи хидратацията</span>
                <Switch
                  checked={isHydrationEnabled}
                  onCheckedChange={(checked) => toggleFeature('hydration', checked)}
                />
              </div>
            )}
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Droplets className="w-5 h-5 text-blue-500" />
                Защо водата е толкова важна?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Водата е най-важният нутриент за тялото - съставлява около 60% от телесното тегло при възрастните и участва във всички биологични процеси. 
                Без вода човек може да оцелее само 3-5 дни, докато без храна - седмици.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border">
                  <h4 className="font-semibold mb-2">Транспорт на вещества</h4>
                  <p className="text-sm text-muted-foreground">Носи хранителни вещества към клетките и премахва токсини</p>
                </div>
                <div className="p-4 bg-cyan-50 dark:bg-cyan-900/20 rounded-lg border">
                  <h4 className="font-semibold mb-2">Регулиране на температурата</h4>
                  <p className="text-sm text-muted-foreground">Поддържа нормална телесна температура чрез потене</p>
                </div>
                <div className="p-4 bg-teal-50 dark:bg-teal-900/20 rounded-lg border">
                  <h4 className="font-semibold mb-2">Лубрикация на ставите</h4>
                  <p className="text-sm text-muted-foreground">Осигурява плавно движение и предпазва от износване</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="w-5 h-5 text-blue-500" />
                  Какво се случва при дехидратация?
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-yellow-500" />
                      Леко дехидратация (2% загуба на течности)
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      Намалява се концентрацията, появява се умора, главоболие и раздразителност. 
                      Физическата производителност може да спадне с до 10%.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-orange-500" />
                      Умерена дехидратация (5% загуба)
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      Значително намаляване на физическата и умствената производителност, 
                      сухота в устата, намалено уриниране, мускулни крампи.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-red-500" />
                      Тежка дехидратация (10%+ загуба)
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      Опасно за живота състояние - бъбречна недостатъчност, шок, 
                      повишена телесна температура, конвулсии.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-green-500" />
                  Как тялото регулира водния баланс?
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Brain className="w-4 h-4 text-purple-500" />
                    Хипоталамус и ADH
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    Хипоталамусът следи концентрацията на солите в кръвта и освобождава антидиуретичен хормон (ADH), 
                    който контролира задържането на вода в бъбреците.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Droplets className="w-4 h-4 text-blue-500" />
                    Жаждата като сигнал
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    Чувството за жажда се активира когато нивото на хидратация спадне с 1-2%. 
                    Това е късен сигнал - оптималното е да се пие вода преди да се почувства жажда.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Heart className="w-4 h-4 text-red-500" />
                    Кардиоваскуларна адаптация
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    При дехидратация сърцето работи по-интензивно за да поддържа кръвообращението, 
                    тъй като обемът на кръвта намалява.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Heart className="w-5 h-5 text-red-500" />
                Ползи от правилната хидратация
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2 text-blue-600">🧠 Оптимална мозъчна функция</h4>
                    <p className="text-sm text-muted-foreground">
                      Мозъкът е 75% вода. Правилната хидратация подобрява концентрацията, паметта, настроението 
                      и когнитивните способности. Дори 2% дехидратация може да намали умствената производителност с 20%.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-green-600">💪 Подобрена физическа производителност</h4>
                    <p className="text-sm text-muted-foreground">
                      Поддържа оптималния обем на кръвта за доставка на кислород към мускулите, 
                      регулира телесната температура и предотвратява мускулните крампи по време на тренировка.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-purple-600">✨ Здрава и сияеща кожа</h4>
                    <p className="text-sm text-muted-foreground">
                      Водата поддържа еластичността и хидратацията на кожата отвътре навън, 
                      намалява бръчките и подобрява цялостния й вид и текстура.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-teal-600">🥗 Подобрено храносмилане</h4>
                    <p className="text-sm text-muted-foreground">
                      Помага за разграждането и усвояването на хранителните вещества, 
                      предотвратява запек и поддържа здравата чревна микрофлора.
                    </p>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2 text-red-600">❤️ Здраво сърце и кръвообращение</h4>
                    <p className="text-sm text-muted-foreground">
                      Поддържа нормален обем и вискозитет на кръвта, което намалява натоварването върху сърцето 
                      и помага за контрола на кръвното налягане.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-yellow-600">🫁 Ефективна детоксикация</h4>
                    <p className="text-sm text-muted-foreground">
                      Бъбреците използват водата за филтриране и извеждане на токсини и метаболитни отпадъци, 
                      предотвратявайки образуването на бъбречни камъни.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-indigo-600">🦴 Здрави стави и хрущяли</h4>
                    <p className="text-sm text-muted-foreground">
                      Синовиалната течност в ставите е предимно вода. Правилната хидратация осигурява 
                      плавно движение и предпазва от износване на хрущялите.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-cyan-600">⚖️ Подпомага отслабването</h4>
                    <p className="text-sm text-muted-foreground">
                      Водата увеличава чувството за ситост, ускорява метаболизма с до 30% за 30-40 минути 
                      и помага за разграждането на мазнините (липолиза).
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Fitness Tab */}
        <TabsContent value="fitness" className="space-y-6">
          <div className="text-center mt-6 space-y-4">
            <h2 className="text-3xl font-bold text-foreground flex items-center justify-center gap-2">
              <Dumbbell className="w-8 h-8 text-purple-500" />
              Фитнес — Инвестиция в здравето
            </h2>
            {!isFitnessEnabled && (
              <div className="flex items-center justify-center gap-2 p-4 bg-muted/50 rounded-lg border">
                <span className="text-sm font-medium">Включи фитнеса</span>
                <Switch
                  checked={isFitnessEnabled}
                  onCheckedChange={(checked) => toggleFeature('fitness', checked)}
                />
              </div>
            )}
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Dumbbell className="w-5 h-5 text-purple-500" />
                Защо физическата активност е незаменима?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Редовната физическа активност е един от най-мощните инструменти за подобряване на здравето. 
                Тялото е създадено за движение, а съвременният седящ начин на живот противоречи на нашата биологична природа.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg border">
                  <h4 className="font-semibold mb-2">Сърдечно-съдова система</h4>
                  <p className="text-sm text-muted-foreground">Укрепва сърцето, подобрява кръвообращението и намалява кръвното налягане</p>
                </div>
                <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border">
                  <h4 className="font-semibold mb-2">Мускулно-скелетна система</h4>
                  <p className="text-sm text-muted-foreground">Изгражда мускулна маса, укрепва костите и подобрява гъвкавостта</p>
                </div>
                <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border">
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Smile className="w-4 h-4 text-green-500" />
                    Ментално здраве
                  </h4>
                  <p className="text-sm text-muted-foreground">Намалява депресия и тревожност, подобрява настроението и самочувствието</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-yellow-500" />
                  Какво се случва в тялото при тренировка?
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Heart className="w-4 h-4 text-red-500" />
                      Митохондриална биогенеза
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      Увеличава се броят на митохондриите - "електростанциите" на клетките, 
                      което подобрява VO2max и енергийната ефективност.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Gauge className="w-4 h-4 text-blue-500" />
                      Инсулинова чувствителност
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      Мускулите използват глюкозата по-ефективно, намалявайки риска от диабет тип 2
                      и подобрявайки метаболитното здраве.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Shield className="w-4 h-4 text-green-500" />
                      Костна плътност и хормонален баланс
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      Силовите тренировки стимулират костообразуването и оптимизират производството 
                      на хормони като тестостерон и хормон на растежа.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-green-500" />
                  Видове тренировки и колко често?
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Flame className="w-4 h-4 text-red-500" />
                    Кардио и HIIT
                  </h4>
                  <p className="text-sm text-muted-foreground mb-1">
                    Подобряват кислородния капацитет и горят калории ефективно.
                  </p>
                  <p className="text-xs text-muted-foreground">📅 3-5 пъти седмично, 20-45 минути</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Dumbbell className="w-4 h-4 text-purple-500" />
                    Силови тренировки
                  </h4>
                  <p className="text-sm text-muted-foreground mb-1">
                    Изграждат мускулна маса и увеличават метаболизма в покой.
                  </p>
                  <p className="text-xs text-muted-foreground">📅 2-4 пъти седмично, 45-75 минути</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Lightbulb className="w-4 h-4 text-yellow-500" />
                    Мобилност и стабилност
                  </h4>
                  <p className="text-sm text-muted-foreground mb-1">
                    Йога, пилатес - подобряват гъвкавостта и координацията.
                  </p>
                  <p className="text-xs text-muted-foreground">📅 2-3 пъти седмично, 30-60 минути</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Timer className="w-4 h-4 text-cyan-500" />
                    Възстановяване
                  </h4>
                  <p className="text-sm text-muted-foreground mb-1">
                    Активна почивка, разходки, лек стречинг.
                  </p>
                  <p className="text-xs text-muted-foreground">📅 Ежедневно, 15-30 минути</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-green-500" />
                Научно доказани ползи от редовната физическа активност
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2 text-red-600">❤️ Сърдечно-съдово здраве</h4>
                    <p className="text-sm text-muted-foreground">
                      Намаляване на риска от сърдечни заболявания с до 35%, подобряване на липидния профил, 
                      контрол на кръвното налягане и укрепване на сърдечната мускулатура.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-blue-600">🧠 Когнитивно здраве</h4>
                    <p className="text-sm text-muted-foreground">
                      Подобрява паметта, концентрацията и изпълнителните функции. Намалява риска от деменция и Алцхаймер с до 40%. 
                      Стимулира неврогенезата - образуването на нови мозъчни клетки.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-green-600">💪 Мускулно-скелетно здраве</h4>
                    <p className="text-sm text-muted-foreground">
                      Предотвратява загубата на мускулна маса с възрастта (саркопения), укрепва костите, 
                      подобрява гъвкавостта и намалява риска от падания и фрактури.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-purple-600">😊 Психично здраве</h4>
                    <p className="text-sm text-muted-foreground">
                      Ефективен антидепресант - намалява симптомите на депресия и тревожност. 
                      Подобрява самочувствието, самооценката и качеството на съня.
                    </p>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2 text-orange-600">🩺 Профилактика на заболявания</h4>
                    <p className="text-sm text-muted-foreground">
                      Намалява риска от диабет тип 2 с до 50%, предотвратява много видове рак (дебело черво, гърда, простата), 
                      контролира кръвната захар и подобрява инсулиновата чувствителност.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-cyan-600">⚖️ Контрол на теглото</h4>
                    <p className="text-sm text-muted-foreground">
                      Увеличава енергийните разходи, подобрява телесната композиция (повече мускули, по-малко мазнини), 
                      ускорява метаболизма и помага за дългосрочното поддържане на здравословно тегло.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-indigo-600">🔬 Дълголетие и възстановяване</h4>
                    <p className="text-sm text-muted-foreground">
                      Увеличава продължителността на живота с 3-7 години, подобрява качеството на живот в напреднала възраст, 
                      ускорява възстановяването от заболявания и операции.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-teal-600">🌙 По-качествен сън</h4>
                    <p className="text-sm text-muted-foreground">
                      Подобрява качеството на съня, съкращава времето за заспиване, увеличава дълбокия сън 
                      и намалява нощните събуждания. По-добрият сън подобрява възстановяването и хормоналния баланс.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Information;