import { useState } from 'react';
import { useShoppingLists } from '@/hooks/useShoppingLists';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  ShoppingCart, 
  Calendar, 
  Plus, 
  Archive, 
  Bookmark, 
  Clock,
  CheckCircle,
  Trash2,
  MoreVertical,
  ChevronDown
} from 'lucide-react';
import { format, startOfWeek, endOfWeek } from 'date-fns';
import { bg } from 'date-fns/locale';
import { useSubscription } from '@/hooks/useSubscription';
import { ProFeatureGuard } from '@/components/subscription/ProFeatureGuard';
import { ModernShoppingList } from '@/components/shopping/ModernShoppingList';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

export default function ShoppingLists() {
  const { isPro } = useSubscription();
  const { 
    shoppingLists, 
    isLoading, 
    updateShoppingListItemMutation, 
    deleteShoppingListMutation,
    deleteShoppingListItemMutation,
    saveAsTemplateMutation,
    archiveShoppingListMutation,
    createFromTemplateMutation,
    createShoppingListMutation
  } = useShoppingLists();
  const [selectedList, setSelectedList] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('active');
  const [showCreateFromTemplate, setShowCreateFromTemplate] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [newListName, setNewListName] = useState('');
  const [listToDelete, setListToDelete] = useState<string | null>(null);
  const [showDeleteFromMenu, setShowDeleteFromMenu] = useState(false);
  const [showCreatePersonal, setShowCreatePersonal] = useState(false);
  const [personalListName, setPersonalListName] = useState('');

  const selectedListData = selectedList ? shoppingLists.find(list => list.id === selectedList) : null;

  const handleToggleItem = async (itemId: string, field: 'is_purchased' | 'is_available') => {
    const item = selectedListData?.items?.find(i => i.id === itemId);
    if (!item) return;

    await updateShoppingListItemMutation.mutateAsync({
      itemId,
      updates: { [field]: !item[field] }
    });
  };

  const handleArchive = async (listId: string) => {
    await archiveShoppingListMutation.mutateAsync(listId);
    setSelectedList(null);
  };

  const handleSaveAsTemplate = async (listId: string, templateName: string) => {
    await saveAsTemplateMutation.mutateAsync({ listId, templateName });
  };

  const handleCreateFromTemplate = async () => {
    if (!selectedTemplate || !newListName.trim()) return;

    const now = new Date();
    const weekStart = startOfWeek(now, { weekStartsOn: 1 });
    const weekEnd = endOfWeek(now, { weekStartsOn: 1 });

    await createFromTemplateMutation.mutateAsync({
      templateId: selectedTemplate,
      name: newListName.trim(),
      week_start_date: format(weekStart, 'yyyy-MM-dd'),
      week_end_date: format(weekEnd, 'yyyy-MM-dd'),
    });

    setShowCreateFromTemplate(false);
    setSelectedTemplate('');
    setNewListName('');
  };

  const handleCreatePersonal = async () => {
    if (!personalListName.trim()) return;

    const now = new Date();
    const weekStart = startOfWeek(now, { weekStartsOn: 1 });
    const weekEnd = endOfWeek(now, { weekStartsOn: 1 });

    await createShoppingListMutation.mutateAsync({
      name: personalListName.trim(),
      week_start_date: format(weekStart, 'yyyy-MM-dd'),
      week_end_date: format(weekEnd, 'yyyy-MM-dd'),
      items: []
    });

    setShowCreatePersonal(false);
    setPersonalListName('');
  };

  const handleDeleteList = async (listId: string) => {
    await deleteShoppingListMutation.mutateAsync(listId);
    setListToDelete(null);
  };

  const handleDeleteListsFromMenu = async () => {
    const listsToDelete = activeLists.filter(list => 
      list.name.includes('от менюто') || 
      list.name.includes('от шаблон') ||
      list.name.includes('меню')
    );

    for (const list of listsToDelete) {
      try {
        await deleteShoppingListMutation.mutateAsync(list.id);
      } catch (error) {
        console.error(`Грешка при изтриване на списък ${list.name}:`, error);
      }
    }

    setShowDeleteFromMenu(false);
  };

  // Filter lists based on active tab - use name prefixes as indicators
  const activeLists = shoppingLists.filter(list => !list.name.startsWith('[АРХИВ]') && !list.name.startsWith('[ШАБЛОН]'));
  const archivedLists = shoppingLists.filter(list => list.name.startsWith('[АРХИВ]'));
  const templateLists = shoppingLists.filter(list => list.name.startsWith('[ШАБЛОН]'));

  if (selectedListData) {
    return (
      <ProFeatureGuard feature="Пазаруване">
        <div className="container mx-auto px-3 md:px-4 lg:px-6">
          <ModernShoppingList
            list={selectedListData}
            onBack={() => setSelectedList(null)}
            onToggleItem={handleToggleItem}
            onArchive={handleArchive}
            onSaveAsTemplate={handleSaveAsTemplate}
            onDeleteItem={async (itemId: string) => {
              await deleteShoppingListItemMutation.mutateAsync(itemId);
            }}
          />
        </div>
      </ProFeatureGuard>
    );
  }

  return (
    <ProFeatureGuard feature="Пазаруване">
      <div className="container mx-auto px-3 md:px-4 lg:px-6 space-y-6">
        <div className="pt-2 flex items-center justify-between">
          <h1 className="text-3xl font-bold">Пазаруване</h1>
          <div className="flex items-center gap-2">
            {activeLists.filter(list => 
              list.name.includes('от менюто') || 
              list.name.includes('от шаблон') ||
              list.name.includes('меню')
            ).length > 0 && (
              <Button 
                variant="destructive" 
                size="sm"
                onClick={() => setShowDeleteFromMenu(true)}
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Изчисти списъци от менюто
              </Button>
            )}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Създай
                  <ChevronDown className="w-4 h-4 ml-2" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setShowCreatePersonal(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Нов личен списък
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Нов списък от менюто
                </DropdownMenuItem>
                {templateLists.length > 0 && (
                  <DropdownMenuItem onClick={() => setShowCreateFromTemplate(true)}>
                    <Bookmark className="w-4 h-4 mr-2" />
                    От шаблон
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className={`grid w-full ${archivedLists.length > 0 ? 'grid-cols-3' : 'grid-cols-2'}`}>
            <TabsTrigger value="active" className="flex items-center gap-1">
              <ShoppingCart className="w-4 h-4" />
              Активни
            </TabsTrigger>
            <TabsTrigger value="templates" className="flex items-center gap-1">
              <Bookmark className="w-4 h-4" />
              Шаблони
            </TabsTrigger>
            {archivedLists.length > 0 && (
              <TabsTrigger value="archived" className="flex items-center gap-1">
                <Archive className="w-4 h-4" />
                Архив
              </TabsTrigger>
            )}
          </TabsList>

          <TabsContent value="active" className="space-y-4">
            {isLoading ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">Зареждане...</p>
              </div>
            ) : activeLists.length === 0 ? (
              <Card>
                <CardContent className="text-center py-12">
                  <ShoppingCart className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-xl font-semibold mb-2">Няма активни списъци</h3>
                  <p className="text-muted-foreground mb-6">
                    Създайте личен списък, използвайте менюто или шаблон
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {activeLists.map((list) => (
                  <Card key={list.id} className="cursor-pointer hover:shadow-md transition-all duration-200">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex-1" onClick={() => setSelectedList(list.id)}>
                          <div className="flex items-center justify-between mb-2">
                            <h3 className="text-lg font-medium">{list.name}</h3>
                            <div className="flex items-center gap-2">
                              <div className="text-sm font-bold text-primary bg-primary/10 px-2 py-1 rounded">
                                {list.completed_items_count}/{list.total_items_count}
                              </div>
                              {list.is_completed && (
                                <Badge variant="default" className="text-xs">
                                  <CheckCircle className="w-3 h-3 mr-1" />
                                  Завършен
                                </Badge>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
                            <Calendar className="w-4 h-4" />
                            <span>
                              {format(new Date(list.week_start_date), 'dd.MM', { locale: bg })} - {format(new Date(list.week_end_date), 'dd.MM', { locale: bg })}
                            </span>
                          </div>
                          
                          <div className="w-full bg-secondary rounded-full h-2">
                            <div 
                              className="bg-primary h-2 rounded-full transition-all duration-300" 
                              style={{ width: `${list.total_items_count > 0 ? (list.completed_items_count / list.total_items_count) * 100 : 0}%` }}
                            />
                          </div>
                        </div>
                        
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm" className="p-2 ml-2">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem 
                              onClick={() => setListToDelete(list.id)}
                              className="text-destructive"
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Изтрий списък
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="templates" className="space-y-4">
            {templateLists.length === 0 ? (
              <Card>
                <CardContent className="text-center py-12">
                  <Bookmark className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-xl font-semibold mb-2">Няма шаблони</h3>
                  <p className="text-muted-foreground">
                    Запазете списък като шаблон, за да го използвате отново
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {templateLists.map((template) => (
                  <Card key={template.id} className="hover:shadow-md transition-all duration-200">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Bookmark className="w-5 h-5 text-primary" />
                            <h3 className="text-lg font-medium">{template.name.replace('[ШАБЛОН] ', '')}</h3>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">
                            {template.total_items_count} продукта
                          </p>
                          <p className="text-xs text-muted-foreground">
                            Създаден на {format(new Date(template.created_at), 'dd.MM.yyyy', { locale: bg })}
                          </p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => {
                            setSelectedTemplate(template.id);
                            setShowCreateFromTemplate(true);
                          }}
                        >
                          <Plus className="w-4 h-4 mr-1" />
                          Използвай
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="archived" className="space-y-4">
            {archivedLists.length === 0 ? (
              <Card>
                <CardContent className="text-center py-12">
                  <Archive className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-xl font-semibold mb-2">Няма архивирани списъци</h3>
                  <p className="text-muted-foreground">
                    Завършените списъци ще се появят тук
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {archivedLists.map((list) => (
                  <Card key={list.id} className="opacity-60 cursor-pointer hover:opacity-80 transition-opacity">
                    <CardContent className="p-4" onClick={() => setSelectedList(list.id)}>
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Archive className="w-5 h-5 text-muted-foreground" />
                            <h3 className="text-lg font-medium">{list.name.replace('[АРХИВ] ', '')}</h3>
                          </div>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                            <Clock className="w-4 h-4" />
                            <span>
                              Архивиран на {format(new Date(list.updated_at), 'dd.MM.yyyy', { locale: bg })}
                            </span>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {list.total_items_count} продукта ({list.completed_items_count} завършени)
                          </p>
                        </div>
                        <Badge variant="secondary">Архивиран</Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Create Personal List Dialog */}
        <Dialog open={showCreatePersonal} onOpenChange={setShowCreatePersonal}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Създай личен списък</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Име на списъка</label>
                <Input
                  placeholder="Моят списък за пазаруване..."
                  value={personalListName}
                  onChange={(e) => setPersonalListName(e.target.value)}
                />
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setShowCreatePersonal(false)} className="flex-1">
                  Отказ
                </Button>
                <Button 
                  onClick={handleCreatePersonal} 
                  className="flex-1"
                  disabled={!personalListName.trim() || createShoppingListMutation.isPending}
                >
                  {createShoppingListMutation.isPending ? 'Създаване...' : 'Създай'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Create From Template Dialog */}
        <Dialog open={showCreateFromTemplate} onOpenChange={setShowCreateFromTemplate}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Създай от шаблон</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Шаблон</label>
                <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                  <SelectTrigger>
                    <SelectValue placeholder="Избери шаблон..." />
                  </SelectTrigger>
                  <SelectContent>
                    {templateLists.map((template) => (
                      <SelectItem key={template.id} value={template.id}>
                        {template.name.replace('[ШАБЛОН] ', '')}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium">Име на новия списък</label>
                <Input
                  placeholder="Пазаруване за тази седмица..."
                  value={newListName}
                  onChange={(e) => setNewListName(e.target.value)}
                />
              </div>
              <Button onClick={handleCreateFromTemplate} className="w-full">
                Създай списък
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <AlertDialog open={!!listToDelete} onOpenChange={() => setListToDelete(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Изтриване на списък</AlertDialogTitle>
              <AlertDialogDescription>
                Сигурни ли сте, че искате да изтриете този списък? Това действие не може да бъде отменено.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Отказ</AlertDialogCancel>
              <AlertDialogAction 
                onClick={() => listToDelete && handleDeleteList(listToDelete)}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Изтрий
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Delete Lists From Menu Confirmation Dialog */}
        <AlertDialog open={showDeleteFromMenu} onOpenChange={setShowDeleteFromMenu}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Изтриване на списъци от менюто</AlertDialogTitle>
              <AlertDialogDescription>
                Сигурни ли сте, че искате да изтриете всички списъци създадени от менюто или шаблони? 
                Това действие ще изтрие {activeLists.filter(list => 
                  list.name.includes('от менюто') || 
                  list.name.includes('от шаблон') ||
                  list.name.includes('меню')
                ).length} списъка и не може да бъде отменено.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Отказ</AlertDialogCancel>
              <AlertDialogAction 
                onClick={handleDeleteListsFromMenu}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Изтрий всички
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </ProFeatureGuard>
  );
}