import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useProfile } from '@/hooks/useProfile';
import { useSubscription } from '@/hooks/useSubscription';
import { ProFeatureGuard } from '@/components/subscription/ProFeatureGuard';
import { EnableNotificationsDialog } from '@/components/fitness/EnableNotificationsDialog';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { toast } from 'sonner';
import { Dumbbell, Calendar, Activity, Bell, BellOff, Trash2, Info, ChevronUp, ChevronDown, Pencil } from 'lucide-react';
import { format, startOfWeek, addDays } from 'date-fns';
import { WorkoutLog } from '@/components/fitness/WorkoutLog';
import { CompactWeekSettings } from '@/components/fitness/CompactWeekSettings';
import { RestBetweenExercisesSettings } from '@/components/fitness/RestBetweenExercisesSettings';

interface FitnessSettings {
  id?: string;
  training_days_per_week: number;
  training_days: number[];
  training_times: { [day: number]: string }; // час за всеки ден
  notifications_enabled?: boolean;
  notification_minutes?: number;
  rest_between_exercises_seconds?: number; // почивка между упражнения
}

interface FitnessSession {
  id?: string;
  session_date: string;
  completed: boolean;
  calories_burned: number | null;
  notes: string | null;
}

const WEEKDAYS = [
  { id: 0, name: 'П', fullName: 'Понеделник' },
  { id: 1, name: 'В', fullName: 'Вторник' },
  { id: 2, name: 'С', fullName: 'Сряда' },
  { id: 3, name: 'Ч', fullName: 'Четвъртък' },
  { id: 4, name: 'П', fullName: 'Петък' },
  { id: 5, name: 'С', fullName: 'Събота' },
  { id: 6, name: 'Н', fullName: 'Неделя' }
];

export default function Fitness() {
  const { user } = useAuth();
  const { profile, updateProfile } = useProfile();
  const { isPro } = useSubscription();
  
  const fitnessEnabled = profile?.fitness_enabled ?? false;

  const [settings, setSettings] = useState<FitnessSettings>({
    training_days_per_week: 3,
    training_days: [],
    training_times: {},
    notifications_enabled: false,
    notification_minutes: 30,
    rest_between_exercises_seconds: 120 // 2 минути по подразбиране
  });
  const [sessions, setSessions] = useState<FitnessSession[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showWorkoutDialog, setShowWorkoutDialog] = useState(false);
  const [selectedDay, setSelectedDay] = useState<{ date: string; name: string; dayOfWeek: number } | null>(null);
  const [showClearDialog, setShowClearDialog] = useState(false);
  const [syncingHabits, setSyncingHabits] = useState(false);
  const [showNotificationDialog, setShowNotificationDialog] = useState(false);
  const [pendingMinutes, setPendingMinutes] = useState<number>(30);

  const currentWeek = startOfWeek(new Date(), { weekStartsOn: 1 });
  
  const handleUpdateSettings = (newSettings: Partial<FitnessSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const handleToggleFitness = async (enabled: boolean) => {
    try {
      await updateProfile({ fitness_enabled: enabled });
      toast.success(enabled ? 'Фитнес проследяването е активирано' : 'Фитнес проследяването е деактивирано');
    } catch (error) {
      toast.error('Грешка при запазване на настройките');
    }
  };

  useEffect(() => {
    if (user) {
      fetchFitnessSettings();
      fetchWeekSessions();
    }
  }, [user]);

  const fetchFitnessSettings = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from('fitness_settings')
      .select('*')
      .eq('user_id', user.id)
      .maybeSingle();

    if (error) {
      console.error('Error fetching fitness settings:', error);
      return;
    }

    if (data) {
      setSettings({
        id: data.id,
        training_days_per_week: data.training_days_per_week,
        training_days: Array.isArray(data.training_days) ? data.training_days.filter((day): day is number => typeof day === 'number') : [],
        training_times: (data as any).training_times || {},
        notifications_enabled: (data as any).notifications_enabled || false,
        notification_minutes: (data as any).notification_minutes || 30
      });
    }
    setLoading(false);
  };

  const fetchWeekSessions = async () => {
    if (!user) return;

    const weekStart = format(currentWeek, 'yyyy-MM-dd');
    const weekEnd = format(addDays(currentWeek, 6), 'yyyy-MM-dd');

    const { data, error } = await supabase
      .from('fitness_sessions')
      .select('*')
      .eq('user_id', user.id)
      .gte('session_date', weekStart)
      .lte('session_date', weekEnd);

    if (error) {
      console.error('Error fetching fitness sessions:', error);
      return;
    }

    setSessions(data || []);
  };

  const saveSettings = async () => {
    if (!user || !settings) return;

    // Check if notifications are disabled and show dialog
    if (!settings.notifications_enabled) {
      setPendingMinutes(settings.notification_minutes || 30);
      setShowNotificationDialog(true);
      return;
    }

    await performSave();
  };

  const performSave = async (override?: Partial<FitnessSettings>) => {
    if (!user || !settings) return;

    const toSave = { ...settings, ...(override || {}) };

    setSaving(true);
    try {
      const { data, error } = await supabase
        .from('fitness_settings')
        .upsert({
          user_id: user.id,
          training_days_per_week: toSave.training_days_per_week,
          training_days: toSave.training_days,
          training_times: toSave.training_times,
          notifications_enabled: toSave.notifications_enabled,
          notification_minutes: toSave.notification_minutes,
          rest_between_exercises_seconds: toSave.rest_between_exercises_seconds
        }, {
          onConflict: 'user_id'
        })
        .select()
        .single();

      if (error) throw error;

      // Update local settings with the returned data (including id)
      setSettings(prev => ({ 
        ...prev, 
        id: data.id,
        training_days: Array.isArray(data.training_days) ? data.training_days.filter((day): day is number => typeof day === 'number') : prev?.training_days || [],
        training_times: (data as any).training_times ?? prev?.training_times ?? {},
        notifications_enabled: (data as any).notifications_enabled ?? prev?.notifications_enabled ?? toSave.notifications_enabled ?? false,
        notification_minutes: (data as any).notification_minutes ?? prev?.notification_minutes ?? toSave.notification_minutes ?? 30
      }));

      // Auto-sync habits after saving settings (silent)
      await syncHabitsFromTemplate(true);

      // Auto-update fitness notifications after saving settings using the same payload
      if (toSave.notifications_enabled && (toSave.training_days?.length || 0) > 0) {
        try {
          console.log('📅 Scheduling fitness notifications...', {
            userId: user.id,
            trainingDays: toSave.training_days,
            trainingTimes: toSave.training_times,
            notificationMinutes: toSave.notification_minutes
          });

          const { error: scheduleError } = await supabase.functions.invoke('schedule-fitness-notifications', {
            body: { 
              userId: user.id,
              trainingDays: toSave.training_days,
              trainingTimes: toSave.training_times,
              notificationMinutes: toSave.notification_minutes || 30
            }
          });
          
          if (scheduleError) {
            console.error('Error scheduling fitness notifications:', scheduleError);
            toast.warning('Настройките са запазени, но има проблем с планирането на известията');
          } else {
            console.log('✅ Fitness notifications scheduled successfully');
            toast.success('Настройките, навиците и известията са обновени успешно');
          }
        } catch (error) {
          console.error('Error calling schedule-fitness-notifications:', error);
          toast.warning('Настройките са запазени, но има проблем с известията');
        }
      } else {
        // If notifications are disabled, delete existing ones
        try {
          const { error: deleteError } = await supabase
            .from('scheduled_notifications')
            .delete()
            .eq('user_id', user.id)
            .eq('notification_type', 'fitness');

          if (deleteError) {
            console.error('Error deleting fitness notifications:', deleteError);
          }
          
          toast.success('Настройките и навиците са обновени (известия изключени)');
        } catch (error) {
          console.error('Error deleting fitness notifications:', error);
          toast.success('Настройките и навиците са обновени');
        }
      }
    } catch (error) {
      console.error('Error saving fitness settings:', error);
      toast.error('Грешка при запазване на настройките');
    } finally {
      setSaving(false);
    }
  };

  const handleConfirmEnable = (minutes: number) => {
    setSettings(prev => prev ? { ...prev, notifications_enabled: true, notification_minutes: minutes } : prev);
    setShowNotificationDialog(false);
    // Save with notifications enabled and selected minutes using override to avoid stale state
    setTimeout(() => performSave({ notifications_enabled: true, notification_minutes: minutes }), 0);
  };

  const handleToggleNotificationsClick = () => {
    if (!settings) return;
    if (!settings.notifications_enabled) {
      setPendingMinutes(settings.notification_minutes || 30);
      setShowNotificationDialog(true);
    } else {
      // Turn off and save immediately
      setSettings(prev => prev ? { ...prev, notifications_enabled: false } : prev);
      setTimeout(() => performSave({ notifications_enabled: false }), 0);
    }
  };

  const handleSkipNotifications = () => {
    setShowNotificationDialog(false);
    // Save without notifications
    setTimeout(performSave, 100);
  };

  const clearTemplate = async () => {
    if (!user) return;

    setSaving(true);
    try {
      // 1. Изтриваме всички фитнес навици
      await supabase
        .from('habits')
        .delete()
        .eq('user_id', user.id)
        .or("category.eq.fitness,name.ilike.%трен%,name.ilike.%тич%,name.ilike.%кардио%" );

      // 2. Изтриваме всички workout упражнения
      await supabase
        .from('workout_exercises')
        .delete()
        .eq('user_id', user.id);

      // 3. Изтриваме всички fitness сесии
      await supabase
        .from('fitness_sessions')
        .delete()
        .eq('user_id', user.id);

      // 4. Изтриваме fitness настройките
      await supabase
        .from('fitness_settings')
        .delete()
        .eq('user_id', user.id);

      // 5. Нулираме локалните настройки
      setSettings({
        training_days_per_week: 3,
        training_days: [],
        training_times: {},
        notifications_enabled: false,
        notification_minutes: 30,
        rest_between_exercises_seconds: 120
      });

      setShowClearDialog(false);
      toast.success('Фитнес шаблонът е изтрит успешно! Можете да започнете наново.');
    } catch (error) {
      console.error('Error clearing fitness template:', error);
      toast.error('Грешка при изтриване на шаблона');
    } finally {
      setSaving(false);
    }
  };
  
  const syncHabitsFromTemplate = async (silent: boolean = false) => {
    if (!user || !settings?.id) return;
    setSyncingHabits(true);
    try {
      // Deduplicate day ids just in case
      const uniqueDays = Array.from(new Set(settings.training_days || []));

      // Fetch all user's fitness habits (we'll reconcile & link them to the template)
      const { data: allFitnessHabits, error: habitsError } = await supabase
        .from('habits')
        .select('*')
        .eq('user_id', user.id)
        .eq('category', 'fitness');
      if (habitsError) throw habitsError;

      const dayNamesEn = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday'];
      const dayNamesBg = ['Понеделник','Вторник','Сряда','Четвъртък','Петък','Събота','Неделя'];
      const activeDays = new Set(uniqueDays);

      const computeReminder = (time: string | undefined) => {
        const t = time || '09:00';
        const [h, m] = t.split(':').map(Number);
        const offset = settings.notification_minutes || 30;
        let total = h * 60 + m - offset;
        if (total < 0) total = 0;
        const rh = Math.floor(total / 60);
        const rm = total % 60;
        return `${rh.toString().padStart(2,'0')}:${rm.toString().padStart(2,'0')}`;
      };

      let created = 0;
      let updated = 0;

      // For each active day, make sure we have exactly one linked habit
      for (const dayId of uniqueDays) {
        const en = dayNamesEn[dayId];
        const bg = dayNamesBg[dayId];
        const time = settings.training_times[dayId] || '09:00';
        const reminder_time = settings.notifications_enabled ? computeReminder(time) : null;

        const matches = (allFitnessHabits || []).filter((h: any) => Array.isArray(h.repeat_days) && h.repeat_days.includes(en));
        const linked = matches.find((h: any) => h.fitness_template_id === settings.id);
        const templateLike = matches.find((h: any) => !h.fitness_template_id && (h.description?.toLowerCase().includes('шаблон') || h.name?.toLowerCase().startsWith('тренировка -')));

        if (linked) {
          // Update the linked one
          const { error } = await supabase
            .from('habits')
            .update({
              name: `Тренировка - ${bg}`,
              time_of_day: time,
              reminder_enabled: !!settings.notifications_enabled,
              reminder_time: settings.notifications_enabled ? reminder_time : null,
              is_active: true,
              repeat_days: [en]
            })
            .eq('id', linked.id);
          if (error) throw error;
          updated++;

          // Deactivate other duplicates for this day that look like template clones
          const duplicates = matches.filter((h: any) => h.id !== linked.id && (h.fitness_template_id || h.description?.toLowerCase().includes('шаблон')));
          if (duplicates.length) {
            await Promise.all(duplicates.map((dup: any) =>
              supabase.from('habits').update({ is_active: false }).eq('id', dup.id)
            ));
          }
        } else if (templateLike) {
          // Link and update the best candidate
          const { error } = await supabase
            .from('habits')
            .update({
              name: `Тренировка - ${bg}`,
              time_of_day: time,
              reminder_enabled: !!settings.notifications_enabled,
              reminder_time: settings.notifications_enabled ? reminder_time : null,
              is_active: true,
              repeat_days: [en],
              fitness_template_id: settings.id
            })
            .eq('id', templateLike.id);
          if (error) throw error;
          updated++;

          // Deactivate other duplicates
          const duplicates = matches.filter((h: any) => h.id !== templateLike.id && (h.fitness_template_id || h.description?.toLowerCase().includes('шаблон')));
          if (duplicates.length) {
            await Promise.all(duplicates.map((dup: any) =>
              supabase.from('habits').update({ is_active: false }).eq('id', dup.id)
            ));
          }
        } else {
          // Create a new linked habit
          const { error } = await supabase
            .from('habits')
            .insert({
              user_id: user.id,
              name: `Тренировка - ${bg}`,
              description: null, // Remove the template description
              category: 'fitness',
              color: '#8B5CF6',
              repeat_days: [en],
              time_of_day: time,
              reminder_enabled: !!settings.notifications_enabled,
              reminder_time: settings.notifications_enabled ? reminder_time : null,
              is_active: true,
              fitness_template_id: settings.id
            });
          if (error) throw error;
          created++;
        }
      }

      // Deactivate linked habits for days that are no longer active in the template
      const linkedHabits = (allFitnessHabits || []).filter((h: any) => h.fitness_template_id === settings.id);
      const deactivateOps = linkedHabits.map(async (habit: any) => {
        const habitDay = habit.repeat_days?.[0];
        const habitDayIndex = dayNamesEn.indexOf(habitDay);
        if (habitDayIndex !== -1 && !activeDays.has(habitDayIndex)) {
          const { error } = await supabase
            .from('habits')
            .update({ is_active: false })
            .eq('id', habit.id);
          if (error) throw error;
        }
      });
      await Promise.all(deactivateOps);

      // Auto-update fitness notifications after syncing habits
      if (!silent) {
        if (settings.notifications_enabled && settings.training_days.length > 0) {
          try {
            console.log('📅 Updating fitness notifications after habit sync...', {
              userId: user.id,
              trainingDays: settings.training_days,
              trainingTimes: settings.training_times,
              notificationMinutes: settings.notification_minutes
            });

            const { error: scheduleError } = await supabase.functions.invoke('schedule-fitness-notifications', {
              body: { 
                userId: user.id,
                trainingDays: settings.training_days,
                trainingTimes: settings.training_times,
                notificationMinutes: settings.notification_minutes || 30
              }
            });
            
            if (scheduleError) {
              console.error('Error scheduling fitness notifications:', scheduleError);
              toast.success(`Навиците са синхронизирани: създадени ${created}, обновени ${updated}. ⚠️ Проблем с известията.`);
            } else {
              console.log('✅ Fitness notifications updated successfully');
              toast.success(`Навиците и известията са синхронизирани: създадени ${created}, обновени ${updated}.`);
            }
          } catch (error) {
            console.error('Error calling schedule-fitness-notifications:', error);
            toast.success(`Навиците са синхронизирани: създадени ${created}, обновени ${updated}. ⚠️ Проблем с известията.`);
          }
        } else {
          toast.success(`Навиците са синхронизирани: създадени ${created}, обновени ${updated}.`);
        }
      }
    } catch (error) {
      console.error('Error syncing habits from template:', error);
      toast.error('Грешка при синхронизиране на навиците');
    } finally {
      setSyncingHabits(false);
    }
  };
  
  const toggleTrainingDay = (dayId: number) => {
    const newTrainingDays = settings.training_days.includes(dayId)
      ? settings.training_days.filter(d => d !== dayId)
      : [...settings.training_days, dayId];

    // Ако добавяме нов ден, задай час по подразбиране
    const newTrainingTimes = { ...settings.training_times };
    if (!settings.training_days.includes(dayId) && newTrainingDays.includes(dayId)) {
      newTrainingTimes[dayId] = '09:00';
    } else if (settings.training_days.includes(dayId) && !newTrainingDays.includes(dayId)) {
      delete newTrainingTimes[dayId];
    }

    setSettings({
      ...settings,
      training_days: newTrainingDays,
      training_days_per_week: newTrainingDays.length,
      training_times: newTrainingTimes
    });
  };

  const updateTrainingTime = (dayId: number, time: string) => {
    setSettings({
      ...settings,
      training_times: {
        ...settings.training_times,
        [dayId]: time
      }
    });
  };

  const getSessionForDate = (date: string): FitnessSession | undefined => {
    return sessions.find(s => s.session_date === date);
  };

  const isTrainingDay = (dayId: number): boolean => {
    return settings.training_days.includes(dayId);
  };

  const handleDaySelect = (day: { date: string; name: string; dayOfWeek: number }) => {
    setSelectedDay(day);
    setShowWorkoutDialog(true);
  };

  if (loading) {
    return <div className="p-6">Зареждане...</div>;
  }

  const content = (
    <div className="container mx-auto p-4 md:p-6 space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <Dumbbell className="w-8 h-8 text-primary" />
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Фитнес</h1>
          <p className="text-muted-foreground">
            Проследявайте вашите тренировки и прогрес
          </p>
        </div>
      </div>

      <div className="space-y-6">
        {/* Настройки */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-lg">
              <Calendar className="w-5 h-5" />
              Настройки за тренировки
              <div className="flex items-center gap-2 ml-auto">
                <Button
                  size="sm"
                  variant={settings.notifications_enabled ? "default" : "destructive"}
                  onClick={handleToggleNotificationsClick}
                  className="gap-2 h-8"
                >
                  {settings.notifications_enabled ? (
                    <>
                      <Bell className="w-4 h-4" />
                      <span className="font-medium">Включени</span>
                    </>
                  ) : (
                    <>
                      <BellOff className="w-4 h-4" />
                      <span className="font-medium">ИЗКЛЮЧЕНИ</span>
                    </>
                  )}
                </Button>
              </div>
            </CardTitle>
            <CardDescription>Изберете дните и часовете за тренировка</CardDescription>
            {settings.notifications_enabled && (
              <div className="mt-3 flex items-center gap-3">
                <Label className="text-sm font-medium">Известие:</Label>
                <span className="text-sm">{settings.notification_minutes || 30} мин преди</span>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => {
                    setPendingMinutes(settings.notification_minutes || 30);
                    setShowNotificationDialog(true);
                  }}
                  aria-label="Промени минутите"
                >
                  <Pencil className="w-4 h-4" />
                </Button>
              </div>
            )}

          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label className="text-base font-medium mb-4 block">
                Дни за тренировка
              </Label>
              <CompactWeekSettings
                settings={settings}
                onUpdateSettings={handleUpdateSettings}
                sessions={sessions}
              />
            </div>

            <RestBetweenExercisesSettings
              value={settings.rest_between_exercises_seconds || 120}
              onChange={(seconds) => handleUpdateSettings({ rest_between_exercises_seconds: seconds })}
              className="mt-4"
            />

            <Button 
              onClick={saveSettings} 
              disabled={saving}
              className="w-full mt-6"
            >
              {saving ? 'Запазване...' : 'Запази настройките'}
            </Button>
          </CardContent>
        </Card>

        {/* Шаблон за тренировки */}
        <Card>
          <CardHeader className="flex items-center justify-between gap-2">
            <div>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Activity className="w-5 h-5" />
                Шаблон за тренировки
              </CardTitle>
              <CardDescription>
                Настройте упражненията за всеки тренировъчен ден
              </CardDescription>
            </div>
            {settings.training_days.length > 0 && (
              <Button size="sm" onClick={() => syncHabitsFromTemplate()} disabled={syncingHabits} className="whitespace-nowrap">
                {syncingHabits ? 'Синхронизиране...' : 'Създай/обнови навици'}
              </Button>
            )}
          </CardHeader>
          <CardContent>
            {settings.training_days.length === 0 ? (
              <div className="text-center text-muted-foreground py-8">
                <p>Първо изберете дни за тренировка от настройките вляво</p>
                <p className="text-sm">След това ще можете да настроите упражненията за всеки ден</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="grid gap-3 grid-cols-1 sm:grid-cols-2">
                  {WEEKDAYS.map((day) => {
                    const shouldTrain = isTrainingDay(day.id);
                    
                    if (!shouldTrain) {
                      return null;
                    }

                    return (
                      <button
                        key={day.id}
                        onClick={() => handleDaySelect({ 
                          date: format(addDays(currentWeek, day.id), 'yyyy-MM-dd'), 
                          name: day.fullName,
                          dayOfWeek: day.id
                        })}
                        className="p-4 rounded-xl border-2 transition-all bg-card hover:bg-accent border-border hover:border-primary/50 text-left w-full"
                      >
                        <div className="space-y-1">
                          <div className="font-semibold text-sm">{day.fullName}</div>
                          <div className="text-xs text-muted-foreground">Настрой упражнения</div>
                          <div className="text-xs text-primary">
                            {settings.training_times[day.id] || '09:00'}ч
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Clear Template Button */}
                {(settings.training_days.length > 0 || settings.id) && (
                  <div className="pt-4 border-t">
                    <AlertDialog open={showClearDialog} onOpenChange={setShowClearDialog}>
                      <AlertDialogTrigger asChild>
                        <Button 
                          variant="destructive"
                          size="sm"
                          className="w-full text-xs"
                          disabled={saving}
                        >
                          <Trash2 className="w-3 h-3 mr-1" />
                          Изтрий шаблона и започни наново
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Изтриване на фитнес шаблон</AlertDialogTitle>
                          <AlertDialogDescription className="space-y-2">
                            <p>Сигурни ли сте, че искате да изтриете целия фитнес шаблон?</p>
                            <div className="bg-muted p-3 rounded-lg">
                              <p className="font-medium text-sm mb-2">Това ще изтрие:</p>
                              <ul className="text-sm space-y-1">
                                <li>• Всички настройки за тренировки</li>
                                <li>• Всички фитнес навици</li>
                                <li>• Всички записани упражнения и тренировки</li>
                              </ul>
                            </div>
                            <p className="text-destructive font-medium">Това действие НЕ МОЖЕ да бъде отменено!</p>
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Отказ</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={clearTemplate}
                            disabled={saving}
                            className="bg-destructive hover:bg-destructive/90"
                          >
                            {saving ? 'Изтриване...' : 'Да, изтрий шаблона'}
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Workout Details Dialog */}
      <Dialog open={showWorkoutDialog} onOpenChange={setShowWorkoutDialog}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden rounded-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Dumbbell className="w-5 h-5" />
              Упражнения за {selectedDay?.name}
            </DialogTitle>
            <DialogDescription>
              Този шаблон ще се прилага всяка седмица за {selectedDay?.name}
            </DialogDescription>
          </DialogHeader>
          
          {selectedDay && (
            <WorkoutLog 
              sessionDate={selectedDay.date}
              dayName={selectedDay.name}
              dayOfWeek={selectedDay.dayOfWeek}
              trainingTime={settings.training_times[selectedDay.dayOfWeek] || '09:00'}
              allTrainingDays={settings.training_days}
              restBetweenExercises={settings.rest_between_exercises_seconds || 120}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );

  return (
    <ProFeatureGuard 
      feature="Фитнес интеграция"
      description="Проследявайте тренировките си, записвайте упражнения с детайли и интегрирайте данните с хранителния си план"
    >
      {isPro && fitnessEnabled ? content : (
        <div className="container mx-auto p-4 md:p-6 space-y-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Dumbbell className="w-8 h-8 text-primary" />
              <h1 className="text-2xl md:text-3xl font-bold">Фитнес</h1>
            </div>
            <div className="flex items-center gap-3">
              <Label htmlFor="fitness-toggle" className="text-sm font-medium">
                Активирай фитнес
              </Label>
              <Switch
                id="fitness-toggle"
                checked={fitnessEnabled}
                onCheckedChange={handleToggleFitness}
              />
            </div>
          </div>
          
          <Card className="border-muted">
            <CardContent className="pt-6">
              <div className="text-center space-y-4">
                <div className="w-16 h-16 mx-auto bg-muted rounded-full flex items-center justify-center">
                  <Dumbbell className="w-8 h-8 text-muted-foreground" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-2">Фитнес проследяването не е активирано</h3>
                  <p className="text-muted-foreground">
                    Активирайте фитнес проследяването за да започнете да записвате тренировките си.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <EnableNotificationsDialog
        open={showNotificationDialog}
        onOpenChange={setShowNotificationDialog}
        defaultMinutes={pendingMinutes}
        onConfirm={handleConfirmEnable}
        onSkip={handleSkipNotifications}
      />
    </ProFeatureGuard>
  );
}