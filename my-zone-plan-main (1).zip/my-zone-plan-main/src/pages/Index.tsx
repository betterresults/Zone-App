import { useState } from 'react';
import { useMemo } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useSubscription } from '@/hooks/useSubscription';
import { useProfile } from '@/hooks/useProfile';
import { useFeatureFlags } from '@/hooks/useFeatureFlags';
import { useKetoCalculation } from '@/hooks/useKetoCalculation';
import { useCalorieTarget } from '@/hooks/useCalorieTarget';
import { HydrationCard } from '@/components/hydration/HydrationCard';
import { useFasting } from '@/hooks/useFasting';
import { useHabits } from '@/hooks/useHabits';
import { useHabitSessions } from '@/hooks/useHabitSessions';
import { usePlannedMeals } from '@/hooks/usePlannedMeals';
import { useCalendarEvents } from '@/hooks/useCalendarEvents';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ChefHat, Calendar, TrendingUp, Clock, Droplets, CheckCircle2, Plus, Target, ShoppingCart, RotateCcw, Coffee, Wine, Milk, Trash2, X, Play, ChevronDown, ChevronUp, Square, Zap, AlertTriangle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { format, startOfDay, startOfWeek, getDay } from 'date-fns';
import { supabase } from '@/integrations/supabase/client';
import { AddMealToTodayDialog } from '@/components/index/AddMealToTodayDialog';
import { HabitTimerCard } from '@/components/habits/HabitTimerCard';
import { FullscreenHabitTimer } from '@/components/habits/FullscreenHabitTimer';
import { FastingStartDialog } from '@/components/fasting/FastingStartDialog';
import { useTodayMealsWithDishes } from '@/hooks/useTodayMealsWithDishes';
import { useIsMobile } from '@/hooks/use-mobile';
import { useToast } from '@/hooks/use-toast';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

const Index = () => {
  const { user } = useAuth();
  const { profile } = useProfile();
  const { isPro } = useSubscription();
  const { isZoneEnabled, isKetoEnabled, dailyCarbsLimit } = useFeatureFlags();
  const { calculateKetoCompliance } = useKetoCalculation();
  const { dailyCalorieTarget } = useCalorieTarget();
  const { activeFast, startFast, endFast, isStarting, isEnding, getCurrentFastingTime, formatFastingTime } = useFasting();
  const { habits, isHabitCompleted, isHabitActiveOnDay, completeHabitMutation, uncompleteHabitMutation, useHabitCompletions } = useHabits();
  const { todaySessions, parseDurationFromDescription, getActiveSession, startSessionMutation, endSessionMutation } = useHabitSessions();
  const { plannedMeals: allPlannedMeals, togglePlannedMeal: globalTogglePlannedMeal, refetch: refetchGlobalPlannedMeals } = usePlannedMeals();
  const { events, getEventsForDate } = useCalendarEvents();
  const [showAddMealDialog, setShowAddMealDialog] = useState(false);
  const [portionOpenId, setPortionOpenId] = useState<string | null>(null);
  const [fullscreenTimerHabit, setFullscreenTimerHabit] = useState<any>(null);
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);
  const [expandedHabits, setExpandedHabits] = useState<Set<string>>(new Set());
  const [showFastingDialog, setShowFastingDialog] = useState(false);
  const { toast } = useToast();
  const isMobile = useIsMobile();

  const today = new Date();
  const { data: todayMealsWithDishes, refetch: refetchTodayMeals } = useTodayMealsWithDishes(user);
  const { plannedMeals, togglePlannedMeal, calculateMealNutrition, getMealName, refetch: refetchPlannedMeals } = usePlannedMeals(today);
  
  // Combine consumed meals and planned meals for today's nutrition
  const todayMeals = useMemo(() => {
    const getKey = (m: any) => `${m.meal_type}|${m.product_id || ''}|${m.recipe_id || ''}|${m.dish_id || ''}`;

    // Consumed from meals table
    const consumedMeals = (todayMealsWithDishes || []).filter((m: any) => !!m.is_consumed).map((meal: any) => ({
      ...meal,
      name: getMealName(meal as any),
      nutrition: calculateMealNutrition(meal as any),
      isPlanned: false,
      isConsumed: true,
    }));
    const consumedKeys = new Set(consumedMeals.map(getKey));

    // Planned from weekly plans (not completed)
    const weeklyPlanned = (plannedMeals || [])
      .filter((meal) => !meal.is_completed)
      .map((meal) => ({
        ...meal,
        name: getMealName(meal as any),
        nutrition: calculateMealNutrition(meal as any),
        isPlanned: true,
        isConsumed: false,
      }));
    const weeklyPlannedKeys = new Set(weeklyPlanned.map(getKey));

    // Planned from meals table (is_consumed = false), but only if not already consumed and not also in weekly planned
    const plannedFromMeals = (todayMealsWithDishes || [])
      .filter((m: any) => !m.is_consumed)
      .filter((m: any) => !consumedKeys.has(getKey(m)) && !weeklyPlannedKeys.has(getKey(m)))
      .map((meal: any) => ({
        ...meal,
        name: getMealName(meal as any),
        nutrition: calculateMealNutrition(meal as any),
        isPlanned: true,
        isConsumed: false,
      }));

    return [...consumedMeals, ...weeklyPlanned, ...plannedFromMeals];
  }, [todayMealsWithDishes, plannedMeals, getMealName, calculateMealNutrition]);

  const { data: todayCompletions = [] } = useHabitCompletions(startOfDay(today), today);
  
  const todayHabits = useMemo(() => {
    if (!habits) return [];
    return habits.filter(habit =>
      habit.habit_type === 'habit' &&
      isHabitActiveOnDay(habit, today) &&
      habit.is_active
    );
  }, [habits, today, isHabitActiveOnDay]);

  const allTasks = useMemo(() => {
    if (!habits) return [];
    return habits.filter(habit =>
      habit.habit_type === 'task' &&
      isHabitActiveOnDay(habit, today) &&
      habit.is_active
    );
  }, [habits, today, isHabitActiveOnDay]);

  // Separate important incomplete tasks, regular tasks, and completed tasks
  const importantIncompleteTasks = useMemo(() => {
    return allTasks.filter(task => 
      task.is_important && !isHabitCompleted(task.id, today, todayCompletions)
    );
  }, [allTasks, today, todayCompletions, isHabitCompleted]);

  const regularTasks = useMemo(() => {
    // Only non-important and incomplete tasks
    return allTasks.filter(task => 
      !task.is_important && !isHabitCompleted(task.id, today, todayCompletions)
    );
  }, [allTasks, today, todayCompletions, isHabitCompleted]);

  const completedTasks = useMemo(() => {
    // All completed tasks (important or not)
    return allTasks.filter(task => 
      isHabitCompleted(task.id, today, todayCompletions)
    );
  }, [allTasks, today, todayCompletions, isHabitCompleted]);

  // For compatibility with existing code
  const sortedTasks = useMemo(() => {
    return [...regularTasks, ...completedTasks];
  }, [regularTasks, completedTasks]);

  const todayEvents = useMemo(() => {
    return getEventsForDate(today) || [];
  }, [getEventsForDate, today]);

  const totalActivities = todayHabits.length + allTasks.length + todayEvents.length;
  const completedHabits = todayHabits.filter(habit => isHabitCompleted(habit.id, today, todayCompletions)).length;
  const completedTasksCount = allTasks.filter(task => isHabitCompleted(task.id, today, todayCompletions)).length;
  const completedActivities = completedHabits + completedTasksCount;
  const habitProgress = totalActivities > 0 ? Math.round((completedActivities / totalActivities) * 100) : 0;

  const totalNutrition = useMemo(() => {
    // Only include consumed meals (not planned ones) in nutrition calculation
    const consumedMealsOnly = todayMeals.filter(meal => (meal as any).isConsumed && !(meal as any).isPlanned);
    return consumedMealsOnly.reduce((acc, meal) => {
      const nutrition = meal.nutrition;
      return {
        calories: acc.calories + nutrition.calories,
        protein: acc.protein + nutrition.protein,
        carbs: acc.carbs + nutrition.carbs,
        fat: acc.fat + nutrition.fat,
        fiber: acc.fiber + 0 // Since nutrition doesn't have fiber, use 0
      };
    }, { calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 });
  }, [todayMeals]);

  const ketoCompliance = isKetoEnabled ? calculateKetoCompliance(totalNutrition) : null;

  const handleToggleHabit = async (habitId: string) => {
    const isCompleted = todayCompletions.some(completion => completion.habit_id === habitId);
    try {
      if (isCompleted) {
        await uncompleteHabitMutation.mutateAsync({ habitId, date: today });
      } else {
        await completeHabitMutation.mutateAsync({ habitId, date: today });
      }
    } catch (error) {
      toast({
        title: "Грешка",
        description: "Неуспешно актуализиране на навика",
        variant: "destructive",
      });
    }
  };

  const toggleHabitExpansion = (habitId: string) => {
    const newExpanded = new Set(expandedHabits);
    if (newExpanded.has(habitId)) {
      newExpanded.delete(habitId);
    } else {
      newExpanded.add(habitId);
    }
    setExpandedHabits(newExpanded);
  };

  const handleServingsChange = async (mealId: string, newServings: number) => {
    try {
      const { error } = await supabase
        .from('meals')
        .update({ servings: newServings })
        .eq('id', mealId);

      if (error) throw error;
      
      refetchTodayMeals();
      refetchPlannedMeals();
    } catch (error) {
      console.error('Error updating servings:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно актуализиране на порциите",
        variant: "destructive",
      });
    }
  };

  const portionOptions = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.5, 3];

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Добре дошли!</h1>
          <p className="text-muted-foreground mb-6">Моля, влезте в системата, за да видите вашия дневник.</p>
          <Link to="/auth">
            <Button>Вход</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted/20">
      <div className="container mx-auto px-4 py-6 space-y-6">
        {/* 2x2 Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Today's Food Card */}
            <Card className="bg-gradient-to-r from-green-50/50 to-blue-50/50">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-lg text-foreground">
                  <TrendingUp className="w-5 h-5 text-green-600" />
                  Днешен прогрес
                </CardTitle>
                <CardDescription className="text-sm">
                  {Math.round(Math.max(0, totalNutrition.carbs - (totalNutrition.fiber || 0)))} от {dailyCarbsLimit || 25}г нето въглехидрати
                </CardDescription>
              </CardHeader>
              
              <CardContent className="space-y-6">
                {/* Net Carbs Progress */}
                <div className="text-center">
                  <div className={`text-3xl font-bold mb-1 ${
                    Math.max(0, totalNutrition.carbs) > 26.25 ? 'text-red-600' : 'text-green-600'
                  }`}>
                    {Math.round(Math.max(0, totalNutrition.carbs - (totalNutrition.fiber || 0)))} / {dailyCarbsLimit || 25}г
                  </div>
                  <Progress 
                    value={Math.min(100, (Math.max(0, totalNutrition.carbs - (totalNutrition.fiber || 0)) / (dailyCarbsLimit || 25)) * 100)} 
                    className="w-full h-3 mb-4" 
                  />
                </div>

                {/* Meals and Calories Grid */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 rounded-lg bg-white/50 border">
                    <Clock className="w-6 h-6 mx-auto mb-2 text-orange-500" />
                    <div className="text-2xl font-bold text-foreground">{todayMeals.filter(meal => (meal as any).isConsumed && !(meal as any).isPlanned).length}</div>
                    <div className="text-sm text-muted-foreground">Хранения</div>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-white/50 border">
                    <TrendingUp className="w-6 h-6 mx-auto mb-2 text-green-500" />
                    <div className="text-2xl font-bold text-foreground">{Math.round(totalNutrition.calories)}</div>
                    <div className="text-sm text-muted-foreground">Калории</div>
                  </div>
                </div>

                {/* Macros Grid */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="text-center p-4 rounded-lg bg-green-100 border border-green-200">
                    <div className="text-lg font-bold text-green-700 mb-1">
                      {totalNutrition.calories > 0 ? Math.round((totalNutrition.protein * 4 / Math.max(totalNutrition.calories, 1)) * 100) : 0}%
                    </div>
                    <div className="text-sm text-green-600 font-medium mb-1">
                      {Math.round(totalNutrition.protein)}г
                    </div>
                    <div className="text-xs text-green-600/70">Протеини</div>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-orange-100 border border-orange-200">
                    <div className="text-lg font-bold text-orange-700 mb-1">
                      {totalNutrition.calories > 0 ? Math.round((totalNutrition.carbs * 4 / Math.max(totalNutrition.calories, 1)) * 100) : 0}%
                    </div>
                    <div className="text-sm text-orange-600 font-medium mb-1">
                      {Math.round(totalNutrition.carbs)}г
                    </div>
                    <div className="text-xs text-orange-600/70">Въглехидр</div>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-purple-100 border border-purple-200">
                    <div className="text-lg font-bold text-purple-700 mb-1">
                      {totalNutrition.calories > 0 ? Math.round((totalNutrition.fat * 9 / Math.max(totalNutrition.calories, 1)) * 100) : 0}%
                    </div>
                    <div className="text-sm text-purple-600 font-medium mb-1">
                      {Math.round(totalNutrition.fat)}г
                    </div>
                    <div className="text-xs text-purple-600/70">Мазнини</div>
                  </div>
                </div>

                {/* Add Food Button */}
                <Button 
                  onClick={() => setShowAddMealDialog(true)}
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-3 text-base font-medium"
                  size="default"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Добави хранене
                </Button>

                {/* Today's Meals List */}
                {todayMeals.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="font-medium text-sm text-muted-foreground mb-2">Планирани хранения:</h4>
                    
                    {/* Active Meals (planned and consumed, not completed) */}
                    {todayMeals.filter(meal => !(meal as any).isConsumed || (meal as any).isPlanned).map((meal: any) => {
                      const nutrition = meal.nutrition;
                      const mealName = meal.name;  
                      const currentServings = Number(meal.servings) || 1;
                      
                      // Get meal type label
                      const mealTypeLabels = {
                        'breakfast': 'Закуска',
                        'lunch': 'Обяд', 
                        'dinner': 'Вечеря',
                        'snack': 'Междинно'
                      };
                      const mealTypeLabel = mealTypeLabels[meal.meal_type as keyof typeof mealTypeLabels] || meal.meal_type;

                      return (
                        <Card key={meal.id} className={`bg-white/60 hover:bg-white/80 transition-colors ${
                          (meal as any).isPlanned ? 'border-l-4 border-l-blue-400' : ''
                        }`}>
                          <CardContent className="p-2">
                            <div className="flex items-center justify-between gap-2">
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-1">
                                   <span className="px-1.5 py-0.5 bg-muted rounded-full text-muted-foreground text-[10px] font-medium">
                                     {mealTypeLabel}
                                   </span>
                                   {(meal as any).isPlanned && (
                                     <span className="px-1.5 py-0.5 bg-blue-100 text-blue-700 rounded-full text-[9px] font-medium">
                                       Планирано
                                     </span>
                                   )}
                                 </div>
                                 <h3 className={`font-medium text-xs mb-1 truncate ${
                                   (meal as any).isPlanned ? 'text-blue-800' : ''
                                 }`}>
                                   {mealName}
                                 </h3>
                                 <div className="text-xs text-muted-foreground">
                                   {Math.round(nutrition.calories * currentServings)} ккал • 
                                   {Math.round(nutrition.protein * currentServings)}г протеин • 
                                   {Math.round(nutrition.carbs * currentServings)}г въглехидрати • 
                                   {Math.round(nutrition.fat * currentServings)}г мазнини
                                 </div>
                               </div>
                               
                               <div className="flex items-center gap-1">
                                 {/* Servings control - only for consumed meals */}
                                 {!(meal as any).isPlanned && (
                                   <Popover open={portionOpenId === meal.id} onOpenChange={(open) => setPortionOpenId(open ? meal.id : null)}>
                                     <PopoverTrigger asChild>
                                       <Button variant="ghost" size="sm" className="px-1.5 h-6 flex items-center gap-1 hover:bg-muted text-xs">
                                        <span className="text-lg font-bold leading-none text-foreground">{currentServings}</span>
                                        <span className="text-[11px] text-muted-foreground">порц.</span>
                                      </Button>
                                    </PopoverTrigger>
                                    <PopoverContent align="end" className="w-44 p-2">
                                      <div className="grid grid-cols-3 gap-2">
                                        {portionOptions.map((opt) => (
                                          <Button
                                            key={opt}
                                            variant={opt === currentServings ? 'default' : 'outline'}
                                            size="sm"
                                            className="h-8 text-xs"
                                            onClick={() => { handleServingsChange(meal.id, opt); setPortionOpenId(null); }}
                                          >
                                            {opt}
                                          </Button>
                                        ))}
                                      </div>
                                    </PopoverContent>
                                  </Popover>
                                 )}
                                 
                                  {/* Different buttons for planned vs consumed meals */}
                                  {(meal as any).isPlanned ? (
                                    <div className="flex items-center gap-1">
                                      <Button
                                        size="sm"
                                        variant="outline"
                                        className="h-6 px-2 text-xs bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200"
                                        onClick={async () => {
                                          try {
                                            await togglePlannedMeal(meal as any);
                                            refetchTodayMeals();
                                            refetchPlannedMeals();
                                            toast({
                                              title: "Успех",
                                              description: "Ястието е консумирано успешно",
                                            });
                                          } catch (error) {
                                            console.error('Error consuming meal:', error);
                                            toast({
                                              title: "Грешка",
                                              description: "Неуспешно консумиране на ястието",
                                              variant: "destructive",
                                            });
                                          }
                                        }}
                                      >
                                        Консумирай
                                      </Button>
                                      <Button
                                        size="icon"
                                        variant="ghost"  
                                        className="h-5 w-5 rounded-full text-muted-foreground hover:bg-destructive hover:text-destructive-foreground"
                                        aria-label="Изтрий планираното ястие"
                                        title="Изтрий планираното ястие"
                                        onClick={async () => {
                                          try {
                                            // Delete from weekly plan
                                            const { error: weeklyErr } = await supabase
                                              .from('weekly_meal_plans')
                                              .delete()
                                              .eq('id', meal.id);
                                            if (weeklyErr) throw weeklyErr;

                                            // Also delete any matching entry from today's meals
                                            const deleteConditions: any = {
                                              user_id: user!.id,
                                              date: format(today, 'yyyy-MM-dd'),
                                              meal_type: meal.meal_type,
                                            };
                                            if (meal.product_id) deleteConditions.product_id = meal.product_id;
                                            if (meal.recipe_id) deleteConditions.recipe_id = meal.recipe_id;
                                            if (meal.dish_id) deleteConditions.dish_id = meal.dish_id;

                                            await supabase
                                              .from('meals')
                                              .delete()
                                              .match(deleteConditions);
                                            
                                            refetchTodayMeals();
                                            refetchPlannedMeals();
                                            toast({
                                              title: "Успех",
                                              description: "Планираното ястие е изтрито успешно",
                                            });
                                          } catch (error) {
                                            console.error('Error deleting planned meal:', error);
                                            toast({
                                              title: "Грешка",
                                              description: "Неуспешно изтриване на планираното ястие",
                                              variant: "destructive",
                                            });
                                          }
                                        }}
                                      >
                                        <X className="h-3 w-3" />
                                      </Button>
                                    </div>
                                  ) : (
                                    <div className="flex items-center gap-1">
                                      <Button
                                        size="sm"
                                        variant="outline"
                                        className="h-6 px-2 text-xs"
                                        onClick={async () => {
                                          try {
                                            const { error } = await supabase
                                              .from('meals')
                                              .update({ is_consumed: false })
                                              .eq('id', meal.id);
                                            
                                            if (error) throw error;
                                            
                                            refetchTodayMeals();
                                            refetchPlannedMeals();
                                            toast({
                                              title: "Успех",
                                              description: "Ястието е върнато като неконсумирано",
                                            });
                                          } catch (error) {
                                            console.error('Error returning meal:', error);
                                            toast({
                                              title: "Грешка",
                                              description: "Неуспешно връщане на ястието",
                                              variant: "destructive",
                                            });
                                          }
                                        }}
                                      >
                                        Върни
                                      </Button>
                                      <Button
                                        size="icon"
                                        variant="ghost"  
                                        className="h-5 w-5 rounded-full text-muted-foreground hover:bg-destructive hover:text-destructive-foreground"
                                        aria-label="Изтрий ястието"
                                        title="Изтрий ястието"
                                        onClick={async () => {
                                          try {
                                            const { error } = await supabase
                                              .from('meals')
                                              .delete()
                                              .eq('id', meal.id);
                                            
                                            if (error) throw error;
                                            
                                            refetchTodayMeals();
                                            refetchPlannedMeals();
                                            toast({
                                              title: "Успех",
                                              description: "Ястието е изтрито успешно",
                                            });
                                          } catch (error) {
                                            console.error('Error deleting meal:', error);
                                            toast({
                                              title: "Грешка",
                                              description: "Неуспешно изтриване на ястието",
                                              variant: "destructive",
                                            });
                                          }
                                        }}
                                      >
                                        <X className="h-3 w-3" />
                                      </Button>
                                    </div>
                                  )}
                               </div>
                             </div>
                           </CardContent>
                         </Card>
                       );
                     })}
                     
                     {/* Consumed/Completed Meals - Small grey boxes at bottom */}
                     {todayMeals.filter(meal => (meal as any).isConsumed && !(meal as any).isPlanned).length > 0 && (
                       <div className="pt-2 border-t border-muted">
                         <div className="text-xs text-muted-foreground mb-2 font-medium">Консумирани</div>
                         <div className="grid grid-cols-1 gap-2">
                            {todayMeals.filter(meal => (meal as any).isConsumed && !(meal as any).isPlanned).map((meal: any, index: number) => (
                              <Card key={meal.id || `consumed-${index}`} 
                                   className="bg-muted/50 hover:bg-muted/70 transition-colors border border-muted">
                                <CardContent className="p-2">
                                  <div className="flex items-center justify-between gap-2">
                                    <div className="flex-1 min-w-0">
                                      <div className="text-xs text-muted-foreground truncate font-medium">
                                        {meal.name}
                                      </div>
                                      <div className="text-xs text-muted-foreground">
                                        {Math.round(meal.nutrition.calories)} ккал
                                      </div>
                                    </div>
                                    <Button
                                      size="icon"
                                      variant="ghost"
                                      className="h-6 w-6 rounded-full text-muted-foreground hover:bg-muted hover:text-foreground"
                                      title="Върни като неконсумирано"
                                      onClick={async () => {
                                        const { error } = await supabase
                                          .from('meals')
                                          .update({ is_consumed: false })
                                          .eq('id', meal.id);
                                        
                                        if (!error) {
                                          refetchTodayMeals();
                                          refetchPlannedMeals();
                                          toast({
                                            title: "Успех",
                                            description: "Ястието е върнато като неконсумирано",
                                          });
                                        }
                                      }}
                                    >
                                      <RotateCcw className="h-3 w-3" />
                                    </Button>
                                  </div>
                                </CardContent>
                              </Card>
                           ))}
                         </div>
                       </div>
                     )}
                   </div>
                 )}
              </CardContent>
            </Card>

            {/* Events, Habits and Tasks Progress Card */}
            <Card className="bg-gradient-to-r from-zone-carbs/5 to-zone-fat/5">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Target className="w-5 h-5 text-zone-carbs" />
                  Събития, навици и задачи днес
                </CardTitle>
                <CardDescription className="text-sm">
                  {completedActivities} от {totalActivities} завършени
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Progress value={totalActivities > 0 ? habitProgress : 0} className="w-full h-2" />
                <div className="text-center">
                  <div className="text-xl lg:text-2xl font-bold text-zone-carbs">
                    {habitProgress}%
                  </div>
                  <div className="text-xs lg:text-sm text-muted-foreground">днешен прогрес</div>
                </div>
                
                {/* Compact Category Cards */}
                <div className="grid grid-cols-1 gap-3">
                  
                  {/* Important Tasks - Always shown at top */}
                  {importantIncompleteTasks.length > 0 && (
                    <div className="space-y-2">
                      <h4 className="text-sm font-medium text-red-700 dark:text-red-400 flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4" />
                        Важни задачи
                      </h4>
                      {importantIncompleteTasks.map((task) => {
                        const isCompleted = isHabitCompleted(task.id, today, todayCompletions);
                        
                        return (
                          <Card key={task.id} className="border-2 border-red-200 shadow-sm hover:shadow-md transition-all duration-200 bg-red-50/30 dark:bg-red-900/10" style={{ background: `linear-gradient(0deg, ${(task.color || '#DC2626')}15, ${(task.color || '#DC2626')}15)` }}>
                            <CardContent className="p-3 cursor-pointer" onClick={(e) => { e.stopPropagation(); handleToggleHabit(task.id); }}>
                              <div className="flex items-center justify-between">
                                <div className="flex-1 min-w-0 pr-12">
                                  <h3 className="font-semibold text-base mb-1 text-red-800 dark:text-red-200">
                                    {task.name}
                                  </h3>
                                  {task.time_of_day && (
                                    <span className="text-base text-red-700 dark:text-red-300 font-bold">
                                      {task.time_of_day.slice(0, 5)}
                                    </span>
                                  )}
                                </div>
                                <div className="flex items-center gap-2">
                                  <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-red-100 dark:bg-red-900/50">
                                    <AlertTriangle className="w-3 h-3 text-red-600 dark:text-red-400" />
                                    <span className="text-xs font-medium text-red-700 dark:text-red-300">Важна</span>
                                  </div>
                                  
                                  <div 
                                    className={`${isMobile ? 'w-4 h-4' : 'w-5 h-5'} rounded-full border-2 flex items-center justify-center transition-colors flex-shrink-0 ${
                                      isCompleted 
                                        ? 'bg-zone-carbs border-zone-carbs' 
                                        : 'border-red-500 hover:border-red-600 hover:bg-red-50'
                                    }`}
                                  >
                                    {isCompleted && <div className={`${isMobile ? 'w-1.5 h-1.5' : 'w-2 h-2'} bg-white rounded-full`} />}
                                  </div>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        );
                      })}
                    </div>
                  )}

                  {/* Events Category Card */}
                  {todayEvents.length > 0 && (
                    <Card className="cursor-pointer border shadow-sm bg-blue-50/30 dark:bg-blue-900/10 hover:shadow-md transition-all"
                          onClick={() => setExpandedCategory(expandedCategory === 'events' ? null : 'events')}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center">
                              <Calendar className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                            </div>
                            <div>
                              <h3 className="font-semibold text-base">Събития</h3>
                              <p className="text-sm text-muted-foreground">
                                {todayEvents.length} планирани
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="secondary" className="bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300">
                              {todayEvents.length}
                            </Badge>
                            {expandedCategory === 'events' ? (
                              <ChevronUp className="w-4 h-4 text-muted-foreground" />
                            ) : (
                              <ChevronDown className="w-4 h-4 text-muted-foreground" />
                            )}
                          </div>
                        </div>
                        
                        {/* Expanded Events */}
                        {expandedCategory === 'events' && (
                          <div className="mt-4 space-y-2">
                            {todayEvents.map((event) => (
                              <Card key={event.id} className="border shadow-sm" style={{ background: `linear-gradient(0deg, ${event.color || '#3B82F6'}22, ${event.color || '#3B82F6'}22)` }}>
                                <CardContent className="p-3">
                                  <div className="flex items-center justify-between">
                                    <div className="flex-1 min-w-0">
                                      <h3 className="font-medium text-base mb-1">
                                        {event.title}
                                      </h3>
                                      {event.start_time && (
                                        <span className="text-base text-foreground font-bold">
                                          {event.start_time.slice(0, 5)}
                                        </span>
                                      )}
                                    </div>
                                    <div className="flex items-center gap-1 bg-blue-100 dark:bg-blue-900/50 px-2 py-1 rounded-full">
                                      <Calendar className="w-3 h-3 text-blue-600 dark:text-blue-400" />
                                      <span className="text-xs font-medium text-blue-700 dark:text-blue-300">Събитие</span>
                                    </div>
                                  </div>
                                </CardContent>
                              </Card>
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  )}
                  
                  {/* Tasks Category Card */}
                  {sortedTasks.length > 0 && (
                    <Card className="cursor-pointer border shadow-sm bg-purple-50/30 dark:bg-purple-900/10 hover:shadow-md transition-all"
                          onClick={() => setExpandedCategory(expandedCategory === 'tasks' ? null : 'tasks')}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-purple-100 dark:bg-purple-900/50 flex items-center justify-center">
                              <Zap className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                            </div>
                            <div>
                              <h3 className="font-semibold text-base">Задачи</h3>
                              <p className="text-sm text-muted-foreground">
                                {sortedTasks.filter(task => isHabitCompleted(task.id, today, todayCompletions)).length} от {sortedTasks.length} завършени
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="secondary" className="bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300">
                              {sortedTasks.length}
                            </Badge>
                            {expandedCategory === 'tasks' ? (
                              <ChevronUp className="w-4 h-4 text-muted-foreground" />
                            ) : (
                              <ChevronDown className="w-4 h-4 text-muted-foreground" />
                            )}
                          </div>
                        </div>
                        
                         {/* Expanded Tasks */}
                         {expandedCategory === 'tasks' && (
                           <div className="mt-4 space-y-2">
                             {/* Regular incomplete tasks */}
                             {regularTasks.map((task) => {
                               const isCompleted = isHabitCompleted(task.id, today, todayCompletions);
                               
                               return (
                                 <Card key={task.id} className={`border shadow-sm hover:shadow-md transition-all duration-200 ${isCompleted ? 'opacity-60' : ''} relative`} style={{ background: `linear-gradient(0deg, ${(task.color || '#8B5CF6')}22, ${(task.color || '#8B5CF6')}22)` }}>
                                   <CardContent className="p-3 cursor-pointer" onClick={(e) => { e.stopPropagation(); handleToggleHabit(task.id); }}>
                                     {isCompleted && (
                                       <div className="absolute top-2 right-2 flex items-center gap-1 bg-green-100 dark:bg-green-900/50 px-1.5 py-0.5 rounded-full">
                                         <CheckCircle2 className="w-3 h-3 text-green-600 dark:text-green-400" />
                                         <span className="text-xs font-medium text-green-700 dark:text-green-300">✓</span>
                                       </div>
                                     )}
                                     
                                     <div className="flex items-center justify-between">
                                       <div className="flex-1 min-w-0 pr-12">
                                         <h3 className={`font-medium text-base mb-1 ${isCompleted ? 'text-muted-foreground' : ''}`}>
                                           {task.name}
                                         </h3>
                                         {task.time_of_day && (
                                           <span className="text-base text-foreground font-bold">
                                             {task.time_of_day.slice(0, 5)}
                                           </span>
                                         )}
                                       </div>
                                       <div className="flex items-center gap-2">
                                         <div className={`flex items-center gap-1 px-2 py-1 rounded-full ${
                                           task.is_important 
                                             ? 'bg-red-100 dark:bg-red-900/50' 
                                             : 'bg-purple-100 dark:bg-purple-900/50'
                                         }`}>
                                           <Zap className={`w-3 h-3 ${
                                             task.is_important 
                                               ? 'text-red-600 dark:text-red-400' 
                                               : 'text-purple-600 dark:text-purple-400'
                                           }`} />
                                           <span className={`text-xs font-medium ${
                                             task.is_important 
                                               ? 'text-red-700 dark:text-red-300' 
                                               : 'text-purple-700 dark:text-purple-300'
                                           }`}>
                                             {task.is_important ? 'Важна' : 'Задача'}
                                           </span>
                                         </div>
                                         
                                         <div 
                                           className={`${isMobile ? 'w-4 h-4' : 'w-5 h-5'} rounded-full border-2 flex items-center justify-center transition-colors flex-shrink-0 ${
                                             isCompleted 
                                               ? 'bg-zone-carbs border-zone-carbs' 
                                               : 'border-muted-foreground hover:border-zone-carbs'
                                           }`}
                                         >
                                           {isCompleted && <div className={`${isMobile ? 'w-1.5 h-1.5' : 'w-2 h-2'} bg-white rounded-full`} />}
                                         </div>
                                       </div>
                                     </div>
                                   </CardContent>
                                 </Card>
                               );
                             })}
                             
                             {/* Completed tasks - smaller and grey at bottom */}
                             {completedTasks.length > 0 && (
                               <div className="mt-4 pt-4 border-t border-muted-foreground/20">
                                 <h5 className="text-xs font-medium text-muted-foreground mb-2">Завършени задачи</h5>
                                 <div className="space-y-1">
                                   {completedTasks.map((task) => {
                                     const isCompleted = isHabitCompleted(task.id, today, todayCompletions);
                                     
                                     return (
                                       <Card key={task.id} className="border shadow-sm bg-muted/30 opacity-50 scale-95" style={{ background: `linear-gradient(0deg, ${(task.color || '#8B5CF6')}10, ${(task.color || '#8B5CF6')}10)` }}>
                                         <CardContent className="p-2 cursor-pointer" onClick={(e) => { e.stopPropagation(); handleToggleHabit(task.id); }}>
                                           <div className="flex items-center justify-between">
                                             <div className="flex-1 min-w-0 pr-8">
                                               <h3 className="font-medium text-sm text-muted-foreground line-through">
                                                 {task.name}
                                               </h3>
                                               {task.time_of_day && (
                                                 <span className="text-sm text-muted-foreground">
                                                   {task.time_of_day.slice(0, 5)}
                                                 </span>
                                               )}
                                             </div>
                                             <div className="flex items-center gap-2">
                                               <div className="flex items-center gap-1 bg-green-100 dark:bg-green-900/50 px-1.5 py-0.5 rounded-full">
                                                 <CheckCircle2 className="w-2 h-2 text-green-600 dark:text-green-400" />
                                                 <span className="text-xs font-medium text-green-700 dark:text-green-300">✓</span>
                                               </div>
                                               
                                               <div 
                                                 className={`${isMobile ? 'w-3 h-3' : 'w-4 h-4'} rounded-full border-2 flex items-center justify-center transition-colors flex-shrink-0 bg-zone-carbs border-zone-carbs`}
                                               >
                                                 <div className={`${isMobile ? 'w-1 h-1' : 'w-1.5 h-1.5'} bg-white rounded-full`} />
                                               </div>
                                             </div>
                                           </div>
                                         </CardContent>
                                       </Card>
                                     );
                                   })}
                                 </div>
                               </div>
                             )}
                           </div>
                         )}
                      </CardContent>
                    </Card>
                  )}
                  
                  {/* Habits Category Card */}
                  {todayHabits.length > 0 && (
                    <Card className="cursor-pointer border shadow-sm bg-green-50/30 dark:bg-green-900/10 hover:shadow-md transition-all"
                          onClick={() => setExpandedCategory(expandedCategory === 'habits' ? null : 'habits')}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900/50 flex items-center justify-center">
                              <Target className="w-5 h-5 text-green-600 dark:text-green-400" />
                            </div>
                            <div>
                              <h3 className="font-semibold text-base">Навици</h3>
                              <p className="text-sm text-muted-foreground">
                                {todayHabits.filter(habit => isHabitCompleted(habit.id, today, todayCompletions)).length} от {todayHabits.length} завършени
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="secondary" className="bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300">
                              {todayHabits.length}
                            </Badge>
                            {expandedCategory === 'habits' ? (
                              <ChevronUp className="w-4 h-4 text-muted-foreground" />
                            ) : (
                              <ChevronDown className="w-4 h-4 text-muted-foreground" />
                            )}
                          </div>
                        </div>
                        
                        {/* Expanded Habits */}
                        {expandedCategory === 'habits' && (
                          <div className="mt-4 space-y-2">
                            {/* Active/Incomplete Habits */}
                            {todayHabits.filter(habit => !isHabitCompleted(habit.id, today, todayCompletions)).map((habit) => {
                              const isCompleted = isHabitCompleted(habit.id, today, todayCompletions);
                              const targetDurationMinutes = parseDurationFromDescription(habit.description);
                              const hasTimer = !!targetDurationMinutes;
                              const habitSessions = todaySessions.filter(s => s.habit_id === habit.id && s.ended_at);
                              const activeSession = getActiveSession(habit.id);
                              
                              const totalCompletedMinutes = habitSessions.reduce((sum, session) => sum + (session.actual_duration_minutes || 0), 0);
                              const currentElapsed = (() => {
                                if (!activeSession) return 0;
                                const startTime = new Date(activeSession.started_at);
                                const now = new Date();
                                return Math.floor((now.getTime() - startTime.getTime()) / 1000);
                              })();
                              const currentElapsedMinutes = Math.floor(currentElapsed / 60);
                              const totalMinutes = totalCompletedMinutes + currentElapsedMinutes;
                              const isHabitFullyCompleted = targetDurationMinutes && totalMinutes >= targetDurationMinutes;
                              
                              return (
                                <Card key={habit.id} className={`border shadow-sm hover:shadow-md transition-all duration-200 ${isHabitFullyCompleted ? 'opacity-60' : ''} relative`} style={{ background: `linear-gradient(0deg, ${(habit.color || '#8B5CF6')}22, ${(habit.color || '#8B5CF6')}22)` }}>
                                  <CardContent className="p-3 cursor-pointer" onClick={(e) => { e.stopPropagation(); handleToggleHabit(habit.id); }}>
                                    {isHabitFullyCompleted && (
                                      <div className="absolute top-2 right-2 flex items-center gap-1 bg-green-100 dark:bg-green-900/50 px-1.5 py-0.5 rounded-full">
                                        <CheckCircle2 className="w-3 h-3 text-green-600 dark:text-green-400" />
                                        <span className="text-xs font-medium text-green-700 dark:text-green-300">✓</span>
                                      </div>
                                    )}
                                    
                                    <div className="flex items-center justify-between">
                                      <div className="flex-1 min-w-0 pr-12">
                                        <h3 className={`font-medium text-base mb-1 ${isHabitFullyCompleted ? 'text-muted-foreground' : ''}`}>
                                          {habit.name}
                                        </h3>
                                        {hasTimer && (
                                          <div className={`text-sm ${isHabitFullyCompleted ? 'text-muted-foreground/70' : 'text-muted-foreground'}`}>
                                            {totalMinutes >= targetDurationMinutes ? (
                                              <span className="font-medium">{totalMinutes} / {targetDurationMinutes} минути</span>
                                            ) : (
                                              <>
                                                {totalMinutes} / {targetDurationMinutes >= 60 && targetDurationMinutes % 60 === 0 
                                                  ? `${targetDurationMinutes / 60} ${targetDurationMinutes / 60 === 1 ? 'час' : 'часа'}`
                                                  : `${targetDurationMinutes} минути`
                                                }
                                              </>
                                            )}
                                          </div>
                                        )}
                                        {habit.time_of_day && (
                                          <span className="text-base sm:text-lg md:text-xl text-foreground font-bold mt-1 block">
                                            {habit.time_of_day.slice(0, 5)}
                                          </span>
                                        )}
                                      </div>
                                      
                                      <div className="flex items-center gap-2">
                                        <div className="flex items-center gap-1 bg-green-100 dark:bg-green-900/50 px-2 py-1 rounded-full">
                                          <Target className="w-3 h-3 text-green-600 dark:text-green-400" />
                                          <span className="text-xs font-medium text-green-700 dark:text-green-300">Навик</span>
                                        </div>
                                        
                                        {hasTimer && activeSession && (
                                          <div className="flex flex-col items-end">
                                            <div className={`text-2xl font-mono font-bold leading-none ${isHabitFullyCompleted ? 'text-muted-foreground' : ''}`}>
                                              {Math.floor(currentElapsed / 3600) > 0 
                                                ? `${Math.floor(currentElapsed / 3600)}:${Math.floor((currentElapsed % 3600) / 60).toString().padStart(2, '0')}`
                                                : Math.floor(currentElapsed / 60).toString()
                                              }
                                            </div>
                                            <div className="text-xs text-muted-foreground mt-0.5">
                                              {Math.floor(currentElapsed / 3600) > 0 ? 'часа' : 'минути'}
                                            </div>
                                          </div>
                                        )}
                                       
                                        {hasTimer ? (
                                          <Button
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              setFullscreenTimerHabit(habit);
                                            }}
                                            disabled={startSessionMutation.isPending || endSessionMutation.isPending}
                                            size="sm"
                                            className="w-9 h-9 rounded-full p-0"
                                            variant={activeSession ? "outline" : "default"}
                                          >
                                            {!activeSession ? (
                                              <Play className="w-4 h-4" />
                                            ) : (
                                              <Square className="w-4 h-4" />
                                            )}
                                          </Button>
                                        ) : (
                                          <div 
                                            className={`${isMobile ? 'w-4 h-4' : 'w-5 h-5'} rounded-full border-2 flex items-center justify-center transition-colors flex-shrink-0 ${
                                              isCompleted 
                                                ? 'bg-zone-carbs border-zone-carbs' 
                                                : 'border-muted-foreground hover:border-zone-carbs'
                                            }`}
                                          >
                                            {isCompleted && <div className={`${isMobile ? 'w-1.5 h-1.5' : 'w-2 h-2'} bg-white rounded-full`} />}
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  </CardContent>
                                </Card>
                              );
                            })}
                            
                            {/* Completed Habits - smaller and grey at bottom */}
                            {todayHabits.filter(habit => isHabitCompleted(habit.id, today, todayCompletions)).length > 0 && (
                              <div className="mt-4 pt-4 border-t border-muted-foreground/20">
                                <h5 className="text-xs font-medium text-muted-foreground mb-2">Завършени навици</h5>
                                <div className="space-y-1">
                                  {todayHabits.filter(habit => isHabitCompleted(habit.id, today, todayCompletions)).map((habit) => {
                                    const isCompleted = isHabitCompleted(habit.id, today, todayCompletions);
                                    
                                    return (
                                      <Card key={habit.id} className="border shadow-sm bg-muted/30 opacity-50 scale-95" style={{ background: `linear-gradient(0deg, ${(habit.color || '#8B5CF6')}10, ${(habit.color || '#8B5CF6')}10)` }}>
                                        <CardContent className="p-2 cursor-pointer" onClick={(e) => { e.stopPropagation(); handleToggleHabit(habit.id); }}>
                                          <div className="flex items-center justify-between">
                                            <div className="flex-1 min-w-0 pr-8">
                                              <h3 className="font-medium text-sm text-muted-foreground line-through">
                                                {habit.name}
                                              </h3>
                                               {habit.time_of_day && (
                                                 <span className="text-sm text-muted-foreground line-through">
                                                   {habit.time_of_day.slice(0, 5)}
                                                 </span>
                                               )}
                                            </div>
                                            <div className="flex items-center gap-2">
                                              <div className="flex items-center gap-1 bg-green-100 dark:bg-green-900/50 px-1.5 py-0.5 rounded-full">
                                                <CheckCircle2 className="w-2 h-2 text-green-600 dark:text-green-400" />
                                                <span className="text-xs font-medium text-green-700 dark:text-green-300">✓</span>
                                              </div>
                                              
                                              <div 
                                                className={`${isMobile ? 'w-3 h-3' : 'w-4 h-4'} rounded-full border-2 flex items-center justify-center transition-colors flex-shrink-0 bg-zone-carbs border-zone-carbs`}
                                              >
                                                <div className={`${isMobile ? 'w-1 h-1' : 'w-1.5 h-1.5'} bg-white rounded-full`} />
                                              </div>
                                            </div>
                                          </div>
                                        </CardContent>
                                      </Card>
                                    );
                                  })}
                                </div>
                              </div>
                            )}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  )}
                </div>
                
                {/* Show message if no activities */}
                {todayHabits.length === 0 && allTasks.length === 0 && todayEvents.length === 0 && (
                  <div className="text-center space-y-3">
                    <p className="text-muted-foreground text-sm">
                      Няма планирани дейности за днес
                    </p>
                    <div className="flex gap-2 justify-center flex-wrap">
                      <Link to="/calendar">
                        <Button size="sm" className="text-xs">
                          <Calendar className="w-3 h-3 mr-1" />
                          Добави събитие
                        </Button>
                      </Link>
                      <Link to="/habits">
                        <Button variant="outline" size="sm" className="text-xs">
                          <Plus className="w-3 h-3 mr-1" />
                          Добави навик
                        </Button>
                      </Link>
                      <Link to="/habits">
                        <Button variant="outline" size="sm" className="text-xs">
                          <Zap className="w-3 h-3 mr-1" />
                          Добави задача
                        </Button>
                      </Link>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          
          {/* Hydration Card */}
          <HydrationCard profile={profile} />

          {/* Fasting Card */}  
          {profile?.fasting_enabled !== false && (
            <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Clock className="w-5 h-5 text-zone-fat" />
                    Фастинг  
                  </CardTitle>
                   {activeFast && (
                     <CardDescription className="text-sm">
                       Активна фастинг сесия
                     </CardDescription>
                   )}
                </CardHeader>
                <CardContent className="space-y-4">
                  {activeFast ? (
                    <>
                      <div className="text-center">
                        <div className="text-xl lg:text-2xl font-bold text-zone-fat font-mono">
                          {formatFastingTime(getCurrentFastingTime())}
                        </div>
                        <div className="text-xs lg:text-sm text-muted-foreground">изминало време</div>
                        {activeFast.target_hours && (
                          <div className="mt-2">
                            <Progress 
                              value={Math.min((getCurrentFastingTime() / (1000 * 60 * 60 * activeFast.target_hours)) * 100, 100)} 
                              className="w-full h-2" 
                            />
                            <div className="text-xs text-muted-foreground mt-1">
                              Цел: {activeFast.target_hours} часа
                            </div>
                          </div>
                        )}
                      </div>
                      <Button 
                        onClick={() => endFast(activeFast.id)}
                        disabled={isEnding}
                        className="w-full"
                        variant="destructive"
                      >
                        {isEnding ? 'Завършване...' : 'Завърши фастинг'}
                      </Button>
                    </>
                  ) : (
                     <div className="space-y-4">
                       {/* Recommended fasting durations */}
                      <div className="space-y-2">
                        <h4 className="text-sm font-medium text-muted-foreground mb-2">Препоръчителни:</h4>
                        <div className="grid grid-cols-2 gap-2">
                          <Button 
                            onClick={() => startFast({ target_hours: 12 })}
                            disabled={isStarting}
                            variant="outline"
                            className="flex flex-col h-auto py-3"
                          >
                            <span className="font-semibold text-lg">12h</span>
                            <span className="text-xs text-muted-foreground">Лесен</span>
                          </Button>
                          <Button 
                            onClick={() => startFast({ target_hours: 14 })}
                            disabled={isStarting}
                            variant="outline"
                            className="flex flex-col h-auto py-3"
                          >
                            <span className="font-semibold text-lg">14h</span>
                            <span className="text-xs text-muted-foreground">Умерен</span>
                          </Button>
                          <Button 
                            onClick={() => startFast({ target_hours: 16 })}
                            disabled={isStarting}
                            variant="outline"
                            className="flex flex-col h-auto py-3 ring-2 ring-primary/30"
                          >
                            <span className="font-semibold text-lg">16h</span>
                            <span className="text-xs text-muted-foreground">Популярен</span>
                          </Button>
                          <Button 
                            onClick={() => startFast({ target_hours: 18 })}
                            disabled={isStarting}
                            variant="outline"
                            className="flex flex-col h-auto py-3"
                          >
                            <span className="font-semibold text-lg">18h</span>
                            <span className="text-xs text-muted-foreground">Напреднал</span>
                          </Button>
                        </div>
                      </div>

                      <div className="border-t pt-3">
                        <Button variant="ghost" size="sm" className="w-full text-xs" onClick={() => setShowFastingDialog(true)}>
                          <Plus className="w-3 h-3 mr-1" />
                          Персонализиран фастинг
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
        </div>

      <AddMealToTodayDialog
        open={showAddMealDialog}
        onOpenChange={setShowAddMealDialog}
      />

      <FastingStartDialog
        open={showFastingDialog}
        onOpenChange={setShowFastingDialog}
        onStart={startFast}
        isStarting={isStarting}
      />

      <FullscreenHabitTimer
        habit={fullscreenTimerHabit}
        isOpen={!!fullscreenTimerHabit}
        onClose={() => setFullscreenTimerHabit(null)}
      />
      </div>
    </div>
  );
};

export default Index;
