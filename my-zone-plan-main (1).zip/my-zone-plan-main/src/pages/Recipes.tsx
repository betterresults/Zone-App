import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Switch } from '@/components/ui/switch';
import { Plus, ChefHat, Search, Edit, Trash2, Users, Clock, Eye, Star, Package, Utensils, Filter, Settings, Heart } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { AddRecipeDialog } from '@/components/recipes/AddRecipeDialog';
import { EditRecipeDialog } from '@/components/recipes/EditRecipeDialog';
import { useFeatureFlags } from '@/hooks/useFeatureFlags';
import { ZoneIndicator } from '@/components/ui/zone-indicator';
import { KetoIndicator } from '@/components/ui/keto-indicator';
import { useZoneCalculation } from '@/hooks/useZoneCalculation';
import { useKetoCalculation } from '@/hooks/useKetoCalculation';
import { cn } from '@/lib/utils';
import { ProFeatureGuard } from '@/components/subscription/ProFeatureGuard';

const Recipes = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddRecipe, setShowAddRecipe] = useState(false);
  const [activeTab, setActiveTab] = useState('my-recipes');
  const [editingRecipe, setEditingRecipe] = useState<any>(null);
  
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { isZoneEnabled, isKetoEnabled, dailyCarbsLimit } = useFeatureFlags();
  const { calculateZoneBlocks } = useZoneCalculation();
  const { calculateKetoCompliance } = useKetoCalculation();

  // Fetch recipes
  const { data: recipes = [], isLoading } = useQuery({
    queryKey: ['recipes', searchTerm, activeTab],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      let query = supabase
        .from('recipes')
        .select(`
          *,
          recipe_ingredients (
            grams,
            products (
              id,
              name,
              protein_per_100g,
              carbs_per_100g,
              fat_per_100g,
              fiber_per_100g,
              calories_per_100g
            )
          )
        `);

      if (activeTab === 'public-recipes') {
        query = query.eq('is_public', true);
      } else {
        query = query.eq('user_id', user.id);
      }
      
      query = query.order('created_at', { ascending: false });

      if (searchTerm) {
        query = query.ilike('name', `%${searchTerm}%`);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data || [];
    }
  });

  // Fetch user's copied recipes (to check which public recipes are already copied)
  const { data: userRecipeNames = [] } = useQuery({
    queryKey: ['user-recipe-names'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data, error } = await supabase
        .from('recipes')
        .select('name')
        .eq('user_id', user.id);
      
      if (error) throw error;
      return data?.map(r => r.name) || [];
    },
    enabled: activeTab === 'public-recipes'
  });

  const deleteRecipeMutation = useMutation({
    mutationFn: async (recipeId: string) => {
      const { error } = await supabase
        .from('recipes')
        .delete()
        .eq('id', recipeId);

      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Рецептата е изтрита!", {
        description: "Успешно изтрихте рецептата."
      });
      queryClient.invalidateQueries({ queryKey: ['recipes'] });
    },
    onError: (error) => {
      toast.error("Грешка", {
        description: "Неуспешно изтриване на рецептата."
      });
    }
  });

  const togglePublicMutation = useMutation({
    mutationFn: async ({ recipeId, isPublic }: { recipeId: string; isPublic: boolean }) => {
      const { error } = await supabase
        .from('recipes')
        .update({ is_public: isPublic })
        .eq('id', recipeId);

      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Рецептата е обновена!", {
        description: "Успешно променихте статуса на рецептата."
      });
      queryClient.invalidateQueries({ queryKey: ['recipes'] });
    },
    onError: (error) => {
      toast.error("Грешка", {
        description: "Неуспешно обновяване на рецептата."
      });
    }
  });

  const createDishMutation = useMutation({
    mutationFn: async (recipe: any) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Check if dish with this name already exists
      const { data: existingDish } = await supabase
        .from('dishes')
        .select('id')
        .eq('user_id', user.id)
        .eq('name', recipe.name)
        .single();

      if (existingDish) {
        throw new Error('Ястие с това име вече съществува');
      }

      // Create the dish
      const { data: dish, error: dishError } = await supabase
        .from('dishes')
        .insert({
          name: recipe.name,
          description: recipe.description,
          meal_type: recipe.meal_type || 'lunch',
          is_public: false,
          user_id: user.id
        })
        .select()
        .single();

      if (dishError) throw dishError;

      // Get recipe ingredients and create dish ingredients (adjusted for 1 serving)
      const { data: recipeIngredients, error: ingredientsError } = await supabase
        .from('recipe_ingredients')
        .select('product_id, grams')
        .eq('recipe_id', recipe.id);

      if (ingredientsError) throw ingredientsError;

      if (recipeIngredients?.length) {
        const dishIngredients = recipeIngredients.map(ingredient => ({
          dish_id: dish.id,
          product_id: ingredient.product_id,
          grams: ingredient.grams / recipe.servings // Adjust for 1 serving
        }));

        const { error: insertError } = await supabase
          .from('dish_ingredients')
          .insert(dishIngredients);

        if (insertError) throw insertError;
      }
    },
    onSuccess: () => {
      toast.success("Ястието е създадено!", {
        description: "Рецептата беше успешно конвертирана в ястие за 1 порция."
      });
      queryClient.invalidateQueries({ queryKey: ['user-dishes'] });
    },
    onError: (error) => {
      toast.error("Грешка", {
        description: error.message || "Неуспешно създаване на ястие."
      });
    }
  });

  // Cook recipe function
  const cookRecipe = (recipe: any) => {
    // Convert recipe ingredients to cooking items format
    const cookingItems = recipe.recipe_ingredients
      ?.filter((ingredient: any) => ingredient.products) // Skip null products
      ?.map((ingredient: any) => ({
        id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
        product: ingredient.products,
        grams: ingredient.grams,
        portionName: undefined
      })) || [];
    
    // Save to localStorage for Cook page to pick up
    localStorage.setItem('cookingItems', JSON.stringify(cookingItems));
    // Save source recipe meta so Cook page can offer update option
    const sourceMeta = {
      id: recipe.id,
      name: recipe.name,
      description: recipe.description,
      instructions: recipe.instructions,
      servings: recipe.servings,
      meal_type: recipe.meal_type,
      is_public: recipe.is_public,
    };
    localStorage.setItem('sourceRecipe', JSON.stringify(sourceMeta));
    
    // Navigate to Cook page
    navigate('/cook');
    
    toast.success("Рецептата е заредена за готвене!", {
      description: "Всички съставки са добавени в страницата за готвене."
    });
  };

  const copyRecipeMutation = useMutation({
    mutationFn: async (recipe: any) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Check if recipe with this name already exists in user's recipes
      const { data: existingRecipe } = await supabase
        .from('recipes')
        .select('id')
        .eq('user_id', user.id)
        .eq('name', recipe.name)
        .single();

      if (existingRecipe) {
        throw new Error('Рецепта с това име вече съществува в Вашите рецепти');
      }

      // Copy the recipe
      const { data: newRecipe, error: recipeError } = await supabase
        .from('recipes')
        .insert({
          name: recipe.name,
          description: recipe.description,
          instructions: recipe.instructions,
          servings: recipe.servings,
          meal_type: recipe.meal_type,
          user_id: user.id,
          is_public: false,
          image_urls: recipe.image_urls
        })
        .select()
        .single();

      if (recipeError) throw recipeError;

      // Handle product cloning and ingredients copying
      if (recipe.recipe_ingredients?.length) {
        const productIdMapping: Record<string, string> = {};
        const clonedProducts: string[] = [];

        // Extract all product IDs from ingredients
        const originalProductIds = recipe.recipe_ingredients.map((ingredient: any) => ingredient.products.id);

        // Check which products exist in user's account (owned by user or public)
        const { data: existingProducts } = await supabase
          .from('products')
          .select('id')
          .in('id', originalProductIds)
          .or(`user_id.eq.${user.id},is_public.eq.true`);

        const existingProductIds = existingProducts?.map(p => p.id) || [];

        // Find products that need to be cloned
        const missingProductIds = originalProductIds.filter(id => !existingProductIds.includes(id));

        // Clone missing products
        if (missingProductIds.length > 0) {
          // Get full product data for missing products
          const { data: productsToClone } = await supabase
            .from('products')
            .select('*')
            .in('id', missingProductIds);

          if (productsToClone?.length) {
            // Clone products with new user_id
            const clonedProductsData = productsToClone.map(product => ({
              name: product.name,
              brand: product.brand,
              calories_per_100g: product.calories_per_100g,
              protein_per_100g: product.protein_per_100g,
              carbs_per_100g: product.carbs_per_100g,
              fat_per_100g: product.fat_per_100g,
              fiber_per_100g: product.fiber_per_100g,
              category: product.category,
              custom_category: product.custom_category,
              custom_icon: product.custom_icon,
              default_serving_grams: product.default_serving_grams,
              package_size_grams: product.package_size_grams,
              package_unit_type: product.package_unit_type,
              package_size_unit: product.package_size_unit,
              image_url: product.image_url,
              barcode: product.barcode,
              user_id: user.id,
              is_public: false
            }));

            const { data: newProducts, error: cloneError } = await supabase
              .from('products')
              .insert(clonedProductsData)
              .select('id');

            if (cloneError) throw cloneError;

            // Create mapping from old to new product IDs
            missingProductIds.forEach((oldId, index) => {
              const newId = newProducts?.[index]?.id;
              if (newId) {
                productIdMapping[oldId] = newId;
                const productName = productsToClone.find(p => p.id === oldId)?.name;
                if (productName) clonedProducts.push(productName);
              }
            });
          }
        }

        // Create ingredients with correct product IDs
        const ingredients = recipe.recipe_ingredients.map((ingredient: any) => {
          const originalProductId = ingredient.products.id;
          const finalProductId = productIdMapping[originalProductId] || originalProductId;
          
          return {
            recipe_id: newRecipe.id,
            product_id: finalProductId,
            grams: ingredient.grams
          };
        });

        const { error: ingredientsError } = await supabase
          .from('recipe_ingredients')
          .insert(ingredients);

        if (ingredientsError) throw ingredientsError;

        return { clonedProducts };
      }

      return { clonedProducts: [] };
    },
    onSuccess: (result) => {
      const { clonedProducts } = result || { clonedProducts: [] };
      
      if (clonedProducts.length > 0) {
        toast.success("Рецептата е копирана!", {
          description: `Публичната рецепта е успешно добавена към Вашите рецепти. Автоматично са добавени ${clonedProducts.length} продукт${clonedProducts.length === 1 ? '' : 'а'}: ${clonedProducts.join(', ')}.`
        });
      } else {
        toast.success("Рецептата е копирана!", {
          description: "Публичната рецепта е успешно добавена към Вашите рецепти."
        });
      }
      
      queryClient.invalidateQueries({ queryKey: ['recipes'] });
      queryClient.invalidateQueries({ queryKey: ['user-recipe-names'] });
    },
    onError: (error) => {
      toast.error("Грешка", {
        description: error.message || "Неуспешно копиране на рецептата."
      });
    }
  });

  // Calculate nutrition for a recipe
  const calculateRecipeNutrition = (recipe: any) => {
    if (!recipe.recipe_ingredients) return { protein: 0, carbs: 0, fat: 0, fiber: 0, calories: 0 };

    return recipe.recipe_ingredients.reduce((total: any, ingredient: any) => {
      const product = ingredient.products;
      
      // Skip ingredients with null/deleted products
      if (!product) return total;
      
      const ratio = ingredient.grams / 100;
      
      return {
        protein: total.protein + (product.protein_per_100g * ratio),
        carbs: total.carbs + (product.carbs_per_100g * ratio),
        fiber: total.fiber + (product.fiber_per_100g * ratio),
        fat: total.fat + (product.fat_per_100g * ratio),
        calories: total.calories + (product.calories_per_100g * ratio)
      };
    }, { protein: 0, carbs: 0, fiber: 0, fat: 0, calories: 0 });
  };

  const mealTypeLabels = {
    breakfast: 'Закуска',
    lunch: 'Обяд', 
    dinner: 'Вечеря',
    snack: 'Междинно'
  };

  return (
    <div className="container mx-auto px-6 py-8 space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-foreground">Рецепти</h1>
        <Button 
          size="sm"
          className="flex items-center gap-2"
          onClick={() => setShowAddRecipe(true)}
        >
          <Plus className="w-4 h-4" />
          Нова рецепта
        </Button>
      </div>

      {/* Search */}
      <div className="relative w-full">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
        <Input
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Търси рецепти..."
          className="pl-10"
        />
      </div>

      {/* Recipe Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="my-recipes" className="gap-2">
            <ChefHat className="w-4 h-4" />
            Моите рецепти
          </TabsTrigger>
          <TabsTrigger value="public-recipes" className="gap-2">
            <Eye className="w-4 h-4" />
            Публични рецепти
          </TabsTrigger>
        </TabsList>

        <TabsContent value="my-recipes">
          {/* Recipes Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {isLoading ? (
              <div className="col-span-full text-center py-8">Зареждане...</div>
            ) : activeTab === 'my-recipes' && recipes.length === 0 ? (
              <Card className="col-span-full">
                <CardContent className="flex flex-col items-center justify-center py-16 text-center">
                  <ChefHat className="w-16 h-16 text-muted-foreground mb-4" />
                  <CardTitle className="text-xl mb-2">
                    {searchTerm ? 'Няма намерени рецепти' : 'Няма създадени рецепти'}
                  </CardTitle>
                  <CardDescription className="mb-6 max-w-sm">
                    {searchTerm 
                      ? 'Опитайте различни ключови думи за търсене.'
                      : 'Създавайте рецепти от вашите продукти и следете точното съотношение на макронутриенти според Зоната'
                    }
                  </CardDescription>
                  {!searchTerm && (
                    <Button 
                      variant="outline"
                      onClick={() => setShowAddRecipe(true)}
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Създай първата рецепта
                    </Button>
                  )}
                </CardContent>
              </Card>
            ) : (
              activeTab === 'my-recipes' && recipes.map((recipe) => {
                const nutrition = calculateRecipeNutrition(recipe);
                const zoneData = calculateZoneBlocks(nutrition);

                return (
                  <Card key={recipe.id} className="h-full hover:shadow-md transition-shadow overflow-hidden group cursor-pointer animate-fade-in relative flex flex-col">
                    {/* Action buttons in top right corner */}
                    <div className="absolute top-2 right-2 z-10 flex gap-1">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-8 w-8 p-0 bg-white/80 hover:bg-white hover:text-primary border border-white/20 backdrop-blur-sm"
                        onClick={() => setEditingRecipe(recipe)}
                      >
                        <Settings className="w-4 h-4" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0 bg-white/80 hover:bg-white hover:text-destructive border border-white/20 backdrop-blur-sm"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Потвърдете изтриването</AlertDialogTitle>
                            <AlertDialogDescription>
                              Наистина ли искате да изтриете рецептата "{recipe.name}"? Това действие не може да бъде отменено.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Отказ</AlertDialogCancel>
                            <AlertDialogAction 
                              onClick={() => deleteRecipeMutation.mutate(recipe.id)}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              Изтрий
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>

                    {/* Recipe image */}
                    <div className="w-full h-40 md:h-48 bg-gradient-to-br from-muted to-muted/50 flex items-center justify-center relative overflow-hidden">
                      {recipe.image_urls && recipe.image_urls.length > 0 ? (
                        <img 
                          src={recipe.image_urls[0]} 
                          alt={recipe.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <ChefHat className="w-16 h-16 text-muted-foreground/50" />
                      )}
                      <div className="absolute top-3 left-3 flex items-center gap-1 flex-wrap">
                        <Badge 
                          variant="outline" 
                          className="bg-white/90 backdrop-blur-sm border-white/20"
                        >
                          {mealTypeLabels[recipe.meal_type as keyof typeof mealTypeLabels]}
                        </Badge>
                        {recipe.is_zone_compliant && isZoneEnabled && (
                          <Badge 
                            variant="outline" 
                            className="bg-gradient-to-r from-zone-protein/20 to-zone-fat/20 text-zone-protein border-zone-protein/30 backdrop-blur-sm"
                          >
                            Zone
                          </Badge>
                        )}
                        {recipe.is_keto_friendly && isKetoEnabled && (
                          <Badge 
                            variant="outline" 
                            className="bg-gradient-to-r from-green-500/20 to-green-600/20 text-green-700 border-green-500/30 backdrop-blur-sm"
                          >
                            Keto
                          </Badge>
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 w-6 p-0 bg-white/90 hover:bg-white hover:text-green-600 border border-white/20 backdrop-blur-sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            cookRecipe(recipe);
                          }}
                          title="Готви рецептата"
                        >
                          <ChefHat className="w-3 h-3" />
                        </Button>
                      </div>
                      {recipe.is_public && (
                        <Badge 
                          variant="secondary" 
                          className="absolute bottom-3 left-3 bg-white/90 text-foreground border-0"
                        >
                          <Eye className="w-3 h-3 mr-1" />
                          Публична
                        </Badge>
                      )}
                    </div>
                    
                    <CardHeader className="pb-2 px-3 pt-3">
                      <div className="space-y-2">
                        <CardTitle className="text-base md:text-lg leading-tight font-semibold line-clamp-2">
                          {recipe.name}
                        </CardTitle>
                        {recipe.description && (
                          <CardDescription className="text-sm line-clamp-2">
                            {recipe.description}
                          </CardDescription>
                        )}
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                            <Users className="w-3 h-3" />
                            {recipe.servings} порции
                          </span>
                        </div>
                      </div>
                    </CardHeader>
                    
                     <CardContent className="pt-0 px-3 pb-3 space-y-3 flex-1 flex flex-col">
                      {/* Calories highlight */}
                      <div className="text-center py-2 bg-gradient-to-r from-primary/5 via-primary/10 to-primary/5 rounded-lg border border-primary/20">
                        <div className="text-xl md:text-2xl font-bold text-primary">{Math.round(nutrition.calories)}</div>
                        <div className="text-xs text-muted-foreground font-medium">калории общо</div>
                      </div>
                      
                      {/* Macros grid */}
                      <div className="grid grid-cols-3 gap-2 text-center">
                        <div className="space-y-1">
                          <div className="text-sm md:text-lg font-semibold text-green-600">{nutrition.protein.toFixed(1)}г</div>
                          <div className="text-xs text-muted-foreground">Протеин</div>
                        </div>
                        <div className="space-y-1">
                          <div className="text-sm md:text-lg font-semibold text-blue-600">{nutrition.carbs.toFixed(1)}г</div>
                          <div className="text-xs text-muted-foreground">Въглехидр.</div>
                        </div>
                        <div className="space-y-1">
                          <div className="text-sm md:text-lg font-semibold text-orange-600">{nutrition.fat.toFixed(1)}г</div>
                          <div className="text-xs text-muted-foreground">Мазнини</div>
                        </div>
                      </div>

                      {/* Zone/Keto indicators */}
                      {isZoneEnabled && (
                        <ZoneIndicator 
                          zoneData={zoneData}
                          compact={true}
                          className="justify-center"
                        />
                      )}
                      {isKetoEnabled && (
                        <KetoIndicator 
                          ketoData={calculateKetoCompliance(nutrition, dailyCarbsLimit)}
                          compact={true}
                          className="justify-center"
                        />
                      )}
                      
                      {/* Create dish button */}
                      <div className="mt-auto">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full border-primary/30 hover:bg-primary hover:text-primary-foreground transition-all duration-200"
                          onClick={() => createDishMutation.mutate(recipe)}
                          disabled={createDishMutation.isPending}
                        >
                          <Utensils className="w-4 h-4 mr-2" />
                          {createDishMutation.isPending ? 'Създава...' : 'Създай ястие'}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            )}
          </div>
        </TabsContent>

        <TabsContent value="public-recipes">
          <ProFeatureGuard 
            feature="публични рецепти"
            description="Достъпът до публичната библиотека с рецепти е достъпен само за Премиум потребители."
          >
          {/* Recipes Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {isLoading ? (
              <div className="col-span-full text-center py-8">Зареждане...</div>
            ) : activeTab === 'public-recipes' && recipes.length === 0 ? (
              <Card className="col-span-full">
                <CardContent className="flex flex-col items-center justify-center py-16 text-center">
                  <ChefHat className="w-16 h-16 text-muted-foreground mb-4" />
                  <CardTitle className="text-xl mb-2">
                    {searchTerm ? 'Няма намерени рецепти' : 'Няма публични рецепти'}
                  </CardTitle>
                  <CardDescription className="mb-6 max-w-sm">
                    {searchTerm 
                      ? 'Опитайте различни ключови думи за търсене.'
                      : 'Няма публични рецепти за показване'
                    }
                  </CardDescription>
                </CardContent>
              </Card>
            ) : (
              activeTab === 'public-recipes' && recipes.map((recipe) => {
                  const nutrition = calculateRecipeNutrition(recipe);
                  const zoneData = calculateZoneBlocks(nutrition);
                  const isAlreadyCopied = userRecipeNames.includes(recipe.name);

                return (
                  <Card 
                    key={recipe.id} 
                    className={cn(
                      "h-full hover:shadow-md transition-shadow overflow-hidden group cursor-pointer animate-fade-in relative min-h-[400px]",
                      isAlreadyCopied && "opacity-60"
                    )}
                  >
                    {/* Like button for public recipes */}
                    <div className="absolute top-2 right-2 z-10 flex gap-1">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className={cn(
                          "h-8 w-8 p-0 bg-white/80 hover:bg-white border border-white/20 backdrop-blur-sm",
                          isAlreadyCopied 
                            ? "text-green-600 hover:text-green-700" 
                            : "hover:text-red-500"
                        )}
                        onClick={(e) => {
                          e.stopPropagation();
                          if (!isAlreadyCopied) {
                            copyRecipeMutation.mutate(recipe);
                          }
                        }}
                        disabled={copyRecipeMutation.isPending || isAlreadyCopied}
                      >
                        <Heart className={cn("w-4 h-4", isAlreadyCopied && "fill-current")} />
                      </Button>
                    </div>

                    {/* Recipe image */}
                    <div className="w-full h-48 bg-gradient-to-br from-muted to-muted/50 flex items-center justify-center relative overflow-hidden">
                      {recipe.image_urls && recipe.image_urls.length > 0 ? (
                        <img 
                          src={recipe.image_urls[0]} 
                          alt={recipe.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <ChefHat className="w-16 h-16 text-muted-foreground/50" />
                      )}
                       <div className="absolute top-3 left-3 flex items-center gap-1 flex-wrap">
                         <Badge 
                           variant="outline" 
                           className="bg-white/90 backdrop-blur-sm border-white/20"
                         >
                           {mealTypeLabels[recipe.meal_type as keyof typeof mealTypeLabels]}
                         </Badge>
                          {recipe.is_zone_compliant && (
                            <Badge 
                              variant="outline" 
                              className="bg-gradient-to-r from-zone-protein/20 to-zone-fat/20 text-zone-protein border-zone-protein/30 backdrop-blur-sm"
                            >
                              Zone
                            </Badge>
                          )}
                          {recipe.is_keto_friendly && (
                            <Badge 
                              variant="outline" 
                              className="bg-gradient-to-r from-green-500/20 to-green-600/20 text-green-700 border-green-500/30 backdrop-blur-sm"
                            >
                              Keto
                            </Badge>
                          )}
                       </div>
                      <Badge 
                        variant="secondary" 
                        className="absolute bottom-3 left-3 bg-white/90 text-foreground border-0"
                      >
                        <Eye className="w-3 h-3 mr-1" />
                        Публична
                      </Badge>
                    </div>
                    
                     <CardHeader className="pb-2">
                       <div className="space-y-1">
                        <CardTitle className="text-lg leading-tight font-semibold line-clamp-2">
                          {recipe.name}
                        </CardTitle>
                        {recipe.description && (
                          <CardDescription className="text-sm line-clamp-2">
                            {recipe.description}
                          </CardDescription>
                        )}
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                            <Users className="w-3 h-3" />
                            {recipe.servings} порции
                          </span>
                        </div>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="pt-0 space-y-2">
                      {/* Calories highlight */}
                      <div className="text-center py-3 bg-gradient-to-r from-primary/5 via-primary/10 to-primary/5 rounded-lg border border-primary/20">
                        <div className="text-2xl font-bold text-primary">{Math.round(nutrition.calories)}</div>
                        <div className="text-xs text-muted-foreground font-medium">калории общо</div>
                      </div>
                      
                      {/* Macros grid */}
                      <div className="grid grid-cols-3 gap-3 text-center">
                        <div className="space-y-1">
                          <div className="text-lg font-semibold text-green-600">{nutrition.protein.toFixed(1)}г</div>
                          <div className="text-xs text-muted-foreground">Протеин</div>
                        </div>
                        <div className="space-y-1">
                          <div className="text-lg font-semibold text-blue-600">{nutrition.carbs.toFixed(1)}г</div>
                          <div className="text-xs text-muted-foreground">Въглехидр.</div>
                        </div>
                        <div className="space-y-1">
                          <div className="text-lg font-semibold text-orange-600">{nutrition.fat.toFixed(1)}г</div>
                          <div className="text-xs text-muted-foreground">Мазнини</div>
                        </div>
                      </div>

                      {/* Zone/Keto indicators */}
                      {isZoneEnabled && (
                        <ZoneIndicator 
                          zoneData={zoneData}
                          compact={true}
                          className="justify-center"
                        />
                      )}
                      {isKetoEnabled && (
                        <KetoIndicator 
                          ketoData={calculateKetoCompliance(nutrition, dailyCarbsLimit)}
                          compact={true}
                          className="justify-center"
                        />
                      )}
                    </CardContent>
                  </Card>
                );
              })
            )}
           </div>
          </ProFeatureGuard>
        </TabsContent>
      </Tabs>

      <AddRecipeDialog 
        open={showAddRecipe} 
        onOpenChange={setShowAddRecipe} 
      />
      
      <EditRecipeDialog
        recipe={editingRecipe}
        open={!!editingRecipe}
        onOpenChange={(open) => !open && setEditingRecipe(null)}
      />
    </div>
  );
};

export default Recipes;