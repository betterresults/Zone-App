import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Plus, Search, Apple, Copy, Package, X, Edit } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { AddProductDialog } from '@/components/products/AddProductDialog';
import { CategoryChangeDialog } from '@/components/products/CategoryChangeDialog';

const Products = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [showCategoryDialog, setShowCategoryDialog] = useState(false);
  const [categoryEditProduct, setCategoryEditProduct] = useState(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch user's personal products with optimized query
  const { data: myProducts = [], isLoading: loadingMyProducts } = useQuery({
    queryKey: ['my-products'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('is_public', false)
        .order('name');
      
      if (error) throw error;
      return data || [];
    },
    staleTime: 1000 * 60 * 5, // 5 minutes
    refetchOnWindowFocus: false
  });

  // Fetch public catalog products with optimized query
  const { data: catalogProducts = [], isLoading: loadingCatalog } = useQuery({
    queryKey: ['catalog-products'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('is_public', true)
        .order('name');
      
      if (error) throw error;
      return data || [];
    },
    staleTime: 1000 * 60 * 10, // 10 minutes for catalog
    refetchOnWindowFocus: false
  });

  // Fetch favorite portions
  const { data: favoritePortions = [] } = useQuery({
    queryKey: ['favorite-portions'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('favorite_portions')
        .select('*')
        .order('grams');
      
      if (error) throw error;
      return data || [];
    },
    staleTime: 1000 * 60 * 5,
    refetchOnWindowFocus: false
  });

  // Clone product mutation
  const cloneProductMutation = useMutation({
    mutationFn: async (product: any) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error } = await supabase
        .from('products')
        .insert({
          name: product.name,
          category: product.category,
          calories_per_100g: product.calories_per_100g,
          protein_per_100g: product.protein_per_100g,
          carbs_per_100g: product.carbs_per_100g,
          fiber_per_100g: product.fiber_per_100g,
          fat_per_100g: product.fat_per_100g,
          default_serving_grams: product.default_serving_grams,
          brand: product.brand,
          barcode: product.barcode,
          image_url: product.image_url, // Copy the image URL
          is_public: false,
          user_id: user.id
        });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my-products'] });
      toast({
        title: "Продуктът е добавен",
        description: "Продуктът е успешно копиран в вашата колекция",
        duration: 3000, // 3 секунди
      });
    },
    onError: (error) => {
      toast({
        title: "Грешка",
        description: "Възникна грешка при добавянето на продукта",
        variant: "destructive",
      });
    }
  });

  // Delete product mutation
  const deleteProductMutation = useMutation({
    mutationFn: async (productId: string) => {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', productId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my-products'] });
      queryClient.invalidateQueries({ queryKey: ['favorite-portions'] });
      toast({
        title: "Продуктът е изтрит",
        description: "Продуктът е успешно премахнат от вашата колекция",
        duration: 3000, // 3 секунди
      });
    },
    onError: (error) => {
      toast({
        title: "Грешка", 
        description: "Възникна грешка при изтриването на продукта",
        variant: "destructive",
      });
    }
  });

  const categories = [
    { value: 'all', label: 'Всички', isCustom: false },
    { value: 'fruits', label: 'Плодове', isCustom: false },
    { value: 'vegetables', label: 'Зеленчуци', isCustom: false },
    { value: 'protein', label: 'Протеини', isCustom: false },
    { value: 'dairy', label: 'Млечни', isCustom: false },
    { value: 'grains', label: 'Зърнени', isCustom: false },
    { value: 'legumes', label: 'Варива', isCustom: false },
    { value: 'nuts', label: 'Ядки', isCustom: false },
    { value: 'fats', label: 'Мазнини', isCustom: false },
    { value: 'other', label: 'Други', isCustom: false }
  ];

  const getCategoryLabel = (category: string) => {
    return categories.find(c => c.value === category)?.label || category;
  };

  // Get all unique custom categories from products
  const getCustomCategories = () => {
    const allProducts = [...myProducts, ...catalogProducts];
    const customCategories = new Set();
    
    allProducts.forEach(product => {
      if (product.custom_category?.trim()) {
        customCategories.add(product.custom_category.trim());
      }
    });
    
    return Array.from(customCategories).map(cat => ({
      value: cat as string,
      label: cat as string,
      isCustom: true
    }));
  };

  // Combined categories (predefined + custom)
  const allCategories = [...categories, ...getCustomCategories()];

  const filterProducts = (products: any[]) => {
    return products.filter(product => {
      const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          (product.brand && product.brand.toLowerCase().includes(searchTerm.toLowerCase()));
      
      if (selectedCategory === 'all') {
        return matchesSearch;
      }
      
      // Check both standard category and custom category
      const productCategory = product.custom_category?.trim() || product.category;
      const matchesCategory = productCategory === selectedCategory;
      
      return matchesSearch && matchesCategory;
    });
  };

  // Separate catalog products into added and not added
  const getFilteredCatalogProducts = () => {
    const filtered = filterProducts(catalogProducts);
    const myProductNames = new Set(myProducts.map(p => p.name.toLowerCase()));
    
    const notAdded = filtered.filter(product => !myProductNames.has(product.name.toLowerCase()));
    const alreadyAdded = filtered.filter(product => myProductNames.has(product.name.toLowerCase()));
    
    return { notAdded, alreadyAdded };
  };

  const ProductCard = ({ product, showCloneButton = false, showDeleteButton = false, showEditButton = false }: { 
    product: any, 
    showCloneButton?: boolean,
    showDeleteButton?: boolean,
    showEditButton?: boolean
  }) => {
    const handleDeleteClick = () => {
      deleteProductMutation.mutate(product.id);
    };

    const handleEditClick = () => {
      setEditingProduct(product);
      setShowAddDialog(true);
    };

    return (
    <Card className="overflow-hidden group relative min-h-[320px] flex flex-col" data-product-item>
      {/* Image Header with overlay text */}
      <div className="relative aspect-[4/3] bg-gradient-to-br from-muted to-muted/50 overflow-hidden flex-shrink-0">
        {product.image_url ? (
          <img 
            src={product.image_url} 
            alt={product.name}
            className="w-full h-full object-cover"
            loading="lazy"
            style={{ objectFit: 'cover' }}
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-muted to-muted/50 flex items-center justify-center">
            <Package className="w-12 h-12 text-muted-foreground/50" />
          </div>
        )}
        
        {/* Overlay with gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-black/20 to-transparent" />
        
        {/* Category badge - top left */}
        <div className="absolute top-2 left-2">
          <Badge 
            variant="secondary" 
            className="text-xs px-2 py-1 font-medium bg-black/30 text-white border border-white/30 cursor-pointer hover:bg-black/40 transition-colors focus:outline-none focus:ring-0"
            onClick={() => {
              if (showEditButton) {
                setCategoryEditProduct(product);
                setShowCategoryDialog(true);
              }
            }}
          >
            {product.custom_category?.trim() || getCategoryLabel(product.category)}
          </Badge>
        </div>

        {/* Action buttons - top right */}
        <div className="absolute top-2 right-2 flex gap-1">
          {showEditButton && (
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-6 w-6 p-0 bg-black/30 hover:bg-black/50 hover:text-white border border-white/30 text-white"
              onClick={handleEditClick}
            >
              <Edit className="w-3 h-3" />
            </Button>
          )}
          
          {showDeleteButton && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-6 w-6 p-0 bg-black/30 hover:bg-black/50 hover:text-red-400 border border-white/30 text-white"
                  disabled={deleteProductMutation.isPending}
                >
                  <X className="w-3 h-3" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Изтриване на продукт</AlertDialogTitle>
                  <AlertDialogDescription>
                    Сигурни ли сте, че искате да изтриете "{product.name}"? 
                    Това действие не може да бъде отменено.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Отказ</AlertDialogCancel>
                  <AlertDialogAction onClick={handleDeleteClick} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                    Изтрий
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>

        {/* Product name - centered at bottom */}
        <div className="absolute bottom-2 left-2 right-2 text-center">
          <h3 className="text-white font-bold text-lg leading-tight line-clamp-2 drop-shadow-lg">
            {product.name}
          </h3>
        </div>
      </div>

      {/* Content below image */}
      <div className="p-3 sm:p-4 flex-1 flex flex-col justify-between">
        
        {/* Nutrition Information */}
        <div className="space-y-3 flex-1">
          {/* Calories highlight */}
          <div className="text-center py-2 bg-gradient-to-r from-primary/5 via-primary/10 to-primary/5 rounded-lg border border-primary/20">
            <div className="text-xl font-bold text-primary mb-0.5">{product.calories_per_100g}</div>
            <div className="text-xs text-muted-foreground font-medium uppercase tracking-wide">калории</div>
          </div>
          
          {/* Macros grid */}
          <div className="grid grid-cols-3 gap-1 text-center">
            <div className="space-y-0.5">
              <div className="text-sm font-bold text-green-600">{product.protein_per_100g}г</div>
              <div className="text-xs text-muted-foreground leading-tight">П</div>
            </div>
            <div className="space-y-0.5">
              <div className="text-sm font-bold text-blue-600">{product.carbs_per_100g}г</div>
              <div className="text-xs text-muted-foreground leading-tight">В</div>
            </div>
            <div className="space-y-0.5">
              <div className="text-sm font-bold text-orange-600">{product.fat_per_100g}г</div>
              <div className="text-xs text-muted-foreground leading-tight">М</div>
            </div>
          </div>
          
          {/* Fiber and Brand row */}
          <div className="flex justify-between items-center">
            <span className="text-xs text-muted-foreground">
              <span className="font-medium">Фибри:</span> {product.fiber_per_100g || 0}г
            </span>
            {product.brand && (
              <Badge 
                variant="secondary" 
                className="text-xs px-2 py-0.5 font-medium"
              >
                {product.brand}
              </Badge>
            )}
          </div>
          
          {/* Clone button */}
          {showCloneButton && (
            <Button 
              variant="outline" 
              size="sm" 
              className="w-full mt-3 border-primary/30 hover:bg-primary hover:text-primary-foreground transition-all duration-200"
              onClick={() => cloneProductMutation.mutate(product)}
              disabled={cloneProductMutation.isPending}
            >
              <Copy className="w-4 h-4 mr-2" />
              {cloneProductMutation.isPending ? 'Добавя...' : 'Добави в моите'}
            </Button>
          )}
        </div>
      </div>
    </Card>
    );
  };

  const EmptyState = ({ title, description, buttonText, icon: Icon, onButtonClick }: {
    title: string;
    description: string;
    buttonText: string;
    icon: any;
    onButtonClick?: () => void;
  }) => (
    <Card className="col-span-full">
      <CardContent className="flex flex-col items-center justify-center py-16 text-center">
        <Icon className="w-16 h-16 text-muted-foreground mb-4" />
        <CardTitle className="text-xl mb-2">{title}</CardTitle>
        <CardDescription className="mb-6 max-w-sm">
          {description}
        </CardDescription>
        <Button variant="outline" onClick={onButtonClick}>
          <Plus className="w-4 h-4 mr-2" />
          {buttonText}
        </Button>
      </CardContent>
    </Card>
  );

  return (
    <div className="container mx-auto px-6 py-8 space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-foreground">Продукти</h1>
        <Button 
          onClick={() => setShowAddDialog(true)}
          size="icon"
          className="h-10 w-10"
        >
          <Plus className="h-5 w-5" />
        </Button>
      </div>

      <Tabs defaultValue="my-products" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="my-products">Моите продукти</TabsTrigger>
          <TabsTrigger value="catalog">Каталог</TabsTrigger>
        </TabsList>

        {/* Search and Filter Controls */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Търсене на продукти..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-full sm:w-48">
              <SelectValue placeholder="Категория" />
            </SelectTrigger>
            <SelectContent>
              {allCategories.map(category => (
                <SelectItem key={category.value} value={category.value}>
                  {category.label}
                  {category.isCustom && <span className="ml-1 text-xs opacity-60">★</span>}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <TabsContent value="my-products" className="space-y-6">
          <div className="grid gap-3 grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
            {loadingMyProducts ? (
              // Skeleton loading cards
              Array.from({ length: 8 }).map((_, index) => (
                <Card key={`skeleton-${index}`} className="overflow-hidden animate-pulse">
                  <div className="aspect-[4/3] bg-muted" />
                  <div className="p-3 space-y-3">
                    <div className="h-4 bg-muted rounded w-3/4 mx-auto" />
                    <div className="grid grid-cols-3 gap-1">
                      <div className="h-8 bg-muted rounded" />
                      <div className="h-8 bg-muted rounded" />
                      <div className="h-8 bg-muted rounded" />
                    </div>
                    <div className="h-3 bg-muted rounded w-1/2" />
                  </div>
                </Card>
              ))
            ) : filterProducts(myProducts).length > 0 ? (
              filterProducts(myProducts).map(product => (
                <ProductCard 
                  key={product.id} 
                  product={product} 
                  showDeleteButton={true}
                  showEditButton={true}
                />
              ))
            ) : myProducts.length === 0 ? (
              <EmptyState
                title="Няма добавени продукти"
                description="Започнете с добавяне на хранителни продукти от каталога или създайте свои собствени"
                buttonText="Добави първия продукт"
                icon={Apple}
                onButtonClick={() => setShowAddDialog(true)}
              />
            ) : (
              <EmptyState
                title="Няма резултати"
                description="Не са намерени продукти, които да отговарят на търсенето ви"
                buttonText="Изчисти филтрите"
                icon={Search}
              />
            )}
          </div>
        </TabsContent>

        <TabsContent value="catalog" className="space-y-6">
          {(() => {
            const { notAdded, alreadyAdded } = getFilteredCatalogProducts();
            
            return (
              <>
                {/* Available products */}
                {notAdded.length > 0 && (
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-foreground">Налични продукти</h3>
                    <div className="grid gap-3 grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
                      {notAdded.map(product => (
                        <ProductCard 
                          key={product.id} 
                          product={product} 
                          showCloneButton={true}
                        />
                      ))}
                    </div>
                  </div>
                )}
                
                {/* Already added products */}
                {alreadyAdded.length > 0 && (
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="flex-1 h-px bg-border" />
                      <span className="text-sm text-muted-foreground bg-background px-3">
                        Вече добавени към вашата колекция
                      </span>
                      <div className="flex-1 h-px bg-border" />
                    </div>
                    <div className="grid gap-3 grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
                      {alreadyAdded.map(product => (
                        <div key={product.id} className="relative">
                          <ProductCard 
                            product={product} 
                            showCloneButton={false}
                          />
                          <div className="absolute inset-0 bg-background/60 backdrop-blur-[1px] rounded-lg flex items-center justify-center">
                            <div className="text-sm font-medium text-muted-foreground bg-background/90 px-3 py-1 rounded-full border">
                              ✓ Добавен
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                {loadingCatalog && (
                  // Skeleton loading cards for catalog
                  <div className="grid gap-3 grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
                    {Array.from({ length: 8 }).map((_, index) => (
                      <Card key={`catalog-skeleton-${index}`} className="overflow-hidden animate-pulse">
                        <div className="aspect-[4/3] bg-muted" />
                        <div className="p-3 space-y-3">
                          <div className="h-4 bg-muted rounded w-3/4 mx-auto" />
                          <div className="grid grid-cols-3 gap-1">
                            <div className="h-8 bg-muted rounded" />
                            <div className="h-8 bg-muted rounded" />
                            <div className="h-8 bg-muted rounded" />
                          </div>
                          <div className="h-3 bg-muted rounded w-1/2" />
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
                
                {!loadingCatalog && notAdded.length === 0 && alreadyAdded.length === 0 && (
                  <EmptyState
                    title="Няма намерени продукти"
                    description="Не са намерени продукти в каталога, които да отговарят на търсенето ви"
                    buttonText="Изчисти филтрите"
                    icon={Package}
                  />
                )}
              </>
            );
          })()}
        </TabsContent>
      </Tabs>
      
      <AddProductDialog 
        open={showAddDialog} 
        onOpenChange={(open) => {
          setShowAddDialog(open);
          if (!open) setEditingProduct(null);
        }}
        editProduct={editingProduct}
      />

      <CategoryChangeDialog
        open={showCategoryDialog}
        onOpenChange={setShowCategoryDialog}
        product={categoryEditProduct}
      />
    </div>
  );
};

export default Products;