import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, Sparkles, Users, MessageSquare } from 'lucide-react';

const BetaWelcome = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/5 to-background flex items-center justify-center p-4">
      <div className="max-w-2xl w-full space-y-8">
        {/* Success Animation */}
        <div className="text-center">
          <div className="relative mx-auto w-24 h-24 mb-6">
            <CheckCircle className="w-24 h-24 text-green-500 animate-pulse" />
            <Sparkles className="w-8 h-8 text-yellow-500 absolute -top-2 -right-2 animate-bounce" />
          </div>
          <h1 className="text-4xl font-bold text-primary mb-4">
            Добре дошли в Beta програмата! 🎉
          </h1>
          <p className="text-xl text-muted-foreground">
            Благодарим ви, че се присъединихте към нашата Beta общност!
          </p>
        </div>

        {/* Welcome Card */}
        <Card className="p-8 bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
          <div className="text-center space-y-6">
            <h2 className="text-2xl font-semibold text-primary">
              Вашата регистрация е успешна!
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
              <div className="text-center">
                <Users className="w-12 h-12 text-primary mx-auto mb-3" />
                <h3 className="font-semibold mb-2">Ексклузивен достъп</h3>
                <p className="text-sm text-muted-foreground">
                  Получавате достъп до най-новите функции преди всички останали
                </p>
              </div>
              
              <div className="text-center">
                <MessageSquare className="w-12 h-12 text-primary mx-auto mb-3" />
                <h3 className="font-semibold mb-2">Вашето мнение е важно</h3>
                <p className="text-sm text-muted-foreground">
                  Помогнете ни да подобрим приложението с вашите отзиви
                </p>
              </div>
              
              <div className="text-center">
                <Sparkles className="w-12 h-12 text-primary mx-auto mb-3" />
                <h3 className="font-semibold mb-2">Специални предимства</h3>
                <p className="text-sm text-muted-foreground">
                  Ексклузивни функции и предимства само за Beta тестерите
                </p>
              </div>
            </div>

            <div className="bg-muted/50 rounded-lg p-6 mt-8">
              <h3 className="font-semibold text-lg mb-3">Какво следва?</h3>
              <ul className="text-left space-y-2 text-sm">
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                  Проверете имейла си за потвърждение на акаунта
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                  Започнете да изследвате новите функции
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                  Споделете вашите отзиви в секцията за обратна връзка
                </li>
              </ul>
            </div>

            <div className="flex gap-4 justify-center mt-8">
              <Button 
                onClick={() => navigate('/')}
                size="lg"
                className="bg-primary hover:bg-primary/90"
              >
                Започнете сега
              </Button>
              <Button 
                onClick={() => navigate('/auth')}
                variant="outline"
                size="lg"
              >
                Влизане в акаунта
              </Button>
            </div>
          </div>
        </Card>

        <div className="text-center text-sm text-muted-foreground">
          <p>Имате въпроси? Свържете се с нас на contact@myzone.life</p>
        </div>
      </div>
    </div>
  );
};

export default BetaWelcome;