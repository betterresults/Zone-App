import { useState } from 'react';
import { useFeedback } from '@/hooks/useFeedback';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { MessageSquare, ThumbsUp, ThumbsDown, Bug, Lightbulb, Plus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const Feedback = () => {
  const [formData, setFormData] = useState({
    feedback_type: '',
    category: '',
    title: '',
    description: ''
  });
  const [loading, setLoading] = useState(false);
  const { submitFeedback, userFeedback, loading: feedbackLoading } = useFeedback();
  const { toast } = useToast();

  const feedbackTypes = [
    { value: 'like', label: 'Харесва ми', icon: ThumbsUp, color: 'bg-green-500' },
    { value: 'dislike', label: 'Не ми харесва', icon: ThumbsDown, color: 'bg-red-500' },
    { value: 'bug', label: 'Бъг/Проблем', icon: Bug, color: 'bg-orange-500' },
    { value: 'improvement', label: 'Подобрение', icon: Lightbulb, color: 'bg-blue-500' },
    { value: 'other', label: 'Друго', icon: MessageSquare, color: 'bg-purple-500' }
  ];

  const categories = [
    'Навици',
    'Рецепти', 
    'Хранене',
    'Фитнес',
    'Хидратация',
    'Гладуване',
    'Потребителски интерфейс',
    'Производителност',
    'Друго'
  ];

  const statusLabels = {
    'new': { label: 'Ново', color: 'bg-blue-500' },
    'in_progress': { label: 'В процес', color: 'bg-yellow-500' },
    'resolved': { label: 'Решено', color: 'bg-green-500' },
    'closed': { label: 'Затворено', color: 'bg-gray-500' }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await submitFeedback(formData);
      setFormData({
        feedback_type: '',
        category: '',
        title: '',
        description: ''
      });
      toast({
        title: "Благодарим!",
        description: "Вашето съобщение беше изпратено успешно.",
      });
    } catch (error) {
      toast({
        title: "Грешка",
        description: "Възникна проблем при изпращането на съобщението.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getTypeInfo = (type: string) => {
    return feedbackTypes.find(t => t.value === type) || feedbackTypes[4];
  };

  return (
    <div className="container mx-auto py-8 px-4 max-w-6xl">
      <div className="mb-8 text-center">
        <h1 className="text-4xl font-bold text-foreground mb-4">Връзка с нас</h1>
      </div>

      <div className="grid gap-8 lg:grid-cols-2">
        {/* Feedback Form */}
        <Card className="shadow-lg border-0 bg-gradient-to-br from-card to-card/50">
          <CardHeader className="pb-6">
            <CardTitle className="flex items-center gap-3 text-xl">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Plus className="w-5 h-5 text-primary" />
              </div>
              Ново съобщение
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="feedback_type">Тип съобщение</Label>
                <Select 
                  value={formData.feedback_type} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, feedback_type: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Изберете тип" />
                  </SelectTrigger>
                  <SelectContent>
                    {feedbackTypes.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        <div className="flex items-center gap-2">
                          <type.icon className="w-4 h-4" />
                          {type.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Категория</Label>
                <Select 
                  value={formData.category} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Изберете категория" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="title">Заглавие</Label>
                <Input
                  id="title"
                  placeholder="Кратко описание на съобщението"
                  value={formData.title}
                  onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Описание</Label>
                <Textarea
                  id="description"
                  placeholder="Подробно описание на вашето съобщение..."
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  rows={4}
                  required
                />
              </div>

              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? 'Изпращане...' : 'Изпрати съобщение'}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* My Feedback */}
        <Card className="shadow-lg border-0 bg-gradient-to-br from-card to-card/50">
          <CardHeader className="pb-6">
            <CardTitle className="flex items-center gap-3 text-xl">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <MessageSquare className="w-5 h-5 text-primary" />
              </div>
              Моите съобщения
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {feedbackLoading ? (
                <div className="text-center py-4">Зареждане...</div>
              ) : userFeedback.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <MessageSquare className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p>Все още не сте изпратили съобщения</p>
                </div>
              ) : (
                  userFeedback.map((feedback) => {
                    const typeInfo = getTypeInfo(feedback.feedback_type);
                    const statusInfo = statusLabels[feedback.status as keyof typeof statusLabels];
                    
                    return (
                      <div key={feedback.id} className="border rounded-xl p-6 space-y-4 bg-gradient-to-br from-background to-muted/20 shadow-sm hover:shadow-md transition-shadow">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className={`w-8 h-8 rounded-full ${typeInfo.color} flex items-center justify-center`}>
                              <typeInfo.icon className="w-4 h-4 text-white" />
                            </div>
                            <span className="font-semibold text-lg">{feedback.title}</span>
                          </div>
                          <Badge variant="outline" className={`text-white ${statusInfo.color} px-3 py-1`}>
                            {statusInfo.label}
                          </Badge>
                        </div>
                        
                        <div className="flex gap-2">
                          <Badge variant="secondary" className="text-xs font-medium">
                            {typeInfo.label}
                          </Badge>
                          {feedback.category && (
                            <Badge variant="outline" className="text-xs">
                              {feedback.category}
                            </Badge>
                          )}
                        </div>
                        
                        <p className="text-sm leading-relaxed text-muted-foreground bg-muted/30 p-4 rounded-lg">
                          {feedback.description}
                        </p>
                        
                        {feedback.admin_notes && (
                          <div className="mt-4 p-4 bg-primary/5 border border-primary/20 rounded-lg">
                            <div className="flex items-center gap-2 mb-2">
                              <MessageSquare className="w-4 h-4 text-primary" />
                              <strong className="text-primary">Отговор от екипа:</strong>
                            </div>
                            <p className="text-sm leading-relaxed">{feedback.admin_notes}</p>
                          </div>
                        )}
                        
                        <div className="text-xs text-muted-foreground flex items-center gap-1 pt-2 border-t">
                          <span>Изпратено на</span>
                          <span className="font-medium">{new Date(feedback.created_at).toLocaleDateString('bg-BG')}</span>
                        </div>
                      </div>
                    );
                  })
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Feedback;