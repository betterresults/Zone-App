import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { Calendar as CalendarIcon, Plus, Droplets, Clock, Dumbbell, Utensils, Target, Timer, TrendingUp, CheckCircle2, Edit, Trash2, ChevronLeft, ChevronRight, Coffee, Wine, Milk, RotateCcw, CalendarDays, Lock, X, ChevronUp, ChevronDown, Play, Square } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { format, isToday, startOfDay, isSameDay, startOfWeek, getDay, startOfMonth, endOfMonth, eachDayOfInterval, addWeeks, addMonths, addYears, subWeeks, subMonths, subYears } from 'date-fns';
import { bg } from 'date-fns/locale';
import { useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useProfile } from '@/hooks/useProfile';
import { useFeatureFlags } from '@/hooks/useFeatureFlags';
import { useCalorieTarget } from '@/hooks/useCalorieTarget';
import { HydrationCard } from '@/components/hydration/HydrationCard';
import { useFasting } from '@/hooks/useFasting';
import { useFitnessToday } from '@/hooks/useFitnessToday';
import { useHabits } from '@/hooks/useHabits';
import { useHabitSessions } from '@/hooks/useHabitSessions';
import { AddMealToTodayDialog } from '@/components/index/AddMealToTodayDialog';
import { FastingStartDialog } from '@/components/fasting/FastingStartDialog';
import { useAuth } from '@/hooks/useAuth';
import { useTodayMealsWithDishes } from '@/hooks/useTodayMealsWithDishes';
import { usePlannedMeals } from '@/hooks/usePlannedMeals';
import { useCalendarEvents } from '@/hooks/useCalendarEvents';
import { useSubscription } from '@/hooks/useSubscription';
import { AddEventDialog } from '@/components/calendar/AddEventDialog';
import { ConflictResolutionDialog } from '@/components/calendar/ConflictResolutionDialog';
import { CalendarEventCard } from '@/components/calendar/CalendarEventCard';
import { HabitCard } from '@/components/calendar/HabitCard';
import { Link } from 'react-router-dom';
import { useIsMobile } from '@/hooks/use-mobile';
import { addDays, differenceInDays } from 'date-fns';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DayView } from '@/components/calendar/DayView';
import { WeekView } from '@/components/calendar/WeekView';
import { MobileWeekListView } from '@/components/calendar/MobileWeekListView';
import { MonthView } from '@/components/calendar/MonthView';
import { YearView } from '@/components/calendar/YearView';
import { AddItemDialog } from '@/components/calendar/AddItemDialog';

const Calendar = () => {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [viewType, setViewType] = useState<'week' | 'month' | 'year' | 'day'>('day');
  const [showAddMeal, setShowAddMeal] = useState(false);
  const [showFastingDialog, setShowFastingDialog] = useState(false);
  const [showAddEvent, setShowAddEvent] = useState(false);
  const [showAddItem, setShowAddItem] = useState(false);
  const [showConflictDialog, setShowConflictDialog] = useState(false);
  const [pendingEvent, setPendingEvent] = useState<any>(null);
  const [eventConflicts, setEventConflicts] = useState<any[]>([]);
  const [portionOpenId, setPortionOpenId] = useState<string | null>(null);
  const [expandedHabits, setExpandedHabits] = useState<Set<string>>(new Set());

  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { profile } = useProfile();
  const { user } = useAuth();
  const { isZoneEnabled, isFitnessEnabled, isHydrationEnabled, isFastingEnabled } = useFeatureFlags();
  const { dailyCalorieTarget } = useCalorieTarget();
  const { isPro } = useSubscription();
  const isMobile = useIsMobile();
  
  // Navigation functions
  const navigateView = (direction: 'prev' | 'next') => {
    let newDate = new Date(selectedDate);
    
    switch (viewType) {
      case 'week':
        newDate = direction === 'prev' ? subWeeks(selectedDate, 1) : addWeeks(selectedDate, 1);
        break;
      case 'month':
        newDate = direction === 'prev' ? subMonths(selectedDate, 1) : addMonths(selectedDate, 1);
        break;
      case 'year':
        newDate = direction === 'prev' ? subYears(selectedDate, 1) : addYears(selectedDate, 1);
        break;
      case 'day':
        newDate = direction === 'prev' ? addDays(selectedDate, -1) : addDays(selectedDate, 1);
        break;
    }
    
    // Don't allow going to past dates
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (newDate < today && direction === 'prev') {
      return;
    }
    
    setSelectedDate(newDate);
  };
  
  const goToToday = () => {
    setSelectedDate(new Date());
  };
  
  const getDateDisplayText = () => {
    const dayName = format(selectedDate, 'EEEE', { locale: bg });
    const dateText = format(selectedDate, 'dd.MM', { locale: bg });
    
    switch (viewType) {
      case 'week':
        const weekStart = startOfWeek(selectedDate, { weekStartsOn: 1 });
        const weekEnd = addDays(weekStart, 6);
        return {
          title: `${format(weekStart, 'd', { locale: bg })} - ${format(weekEnd, 'd', { locale: bg })} седмица`,
          subtitle: format(selectedDate, 'MMMM yyyy', { locale: bg })
        };
      case 'month':
        return {
          title: format(selectedDate, 'MMMM', { locale: bg }),
          subtitle: format(selectedDate, 'yyyy', { locale: bg })
        };
      case 'year':
        return {
          title: format(selectedDate, 'yyyy', { locale: bg }),
          subtitle: ''
        };
      case 'day':
        return {
          title: `${dayName}, ${dateText}`,
          subtitle: format(selectedDate, 'yyyy', { locale: bg })
        };
      default:
        return { title: dateText, subtitle: dayName };
    }
  };
  
  const displayInfo = getDateDisplayText();
  
  // Check if date selection is restricted by subscription
  const today = new Date();
  const daysDifference = differenceInDays(selectedDate, today);
  const isRestrictedDate = !isPro && daysDifference > 30;

  // Calendar events
  const { 
    events, 
    getEventsForDate, 
    createEvent, 
    deleteEvent, 
    isCreating 
  } = useCalendarEvents(selectedDate, addDays(selectedDate, 30));

  // Event handlers
  const handleEditEvent = (event: any) => {
    toast({
      title: "Редактиране на събитие",
      description: "Функцията за редактиране ще бъде добавена скоро",
    });
  };

  const handleDuplicateEvent = (event: any) => {
    const nextDay = addDays(new Date(event.event_date), 1);
    const duplicatedEvent = {
      ...event,
      event_date: nextDay,
      id: undefined
    };
    
    createEvent(duplicatedEvent);
    toast({
      title: "Събитието е дублирано",
      description: `Създадено за ${format(nextDay, 'dd.MM.yyyy', { locale: bg })}`,
    });
  };

  // Habit handlers
  const handleEditHabit = (habit: any) => {
    toast({
      title: "Редактиране на навик",
      description: "Функцията за редактиране ще бъде добавена скоро",
    });
  };

  const handleDuplicateHabit = (habit: any) => {
    toast({
      title: "Дублиране на навик",
      description: "Функцията за дублиране ще бъде добавена скоро",
    });
  };

  const deleteHabit = async (habitId: string) => {
    try {
      await deleteHabitMutation.mutateAsync(habitId);
      toast({
        title: "Успех",
        description: "Навикът беше изтрит успешно",
      });
    } catch (error) {
      console.error('Error deleting habit:', error);
      toast({
        title: "Грешка",
        description: "Възникна проблем при изтриване на навика",
        variant: "destructive"
      });
    }
  };

  // Check for conflicts before creating event
  const checkEventConflicts = (eventData: any) => {
    const dateEvents = getEventsForDate(selectedDate);
    const dateHabits = habits.filter(habit => 
      isHabitActiveOnDay(habit, selectedDate) && habit.time_of_day
    );
    
    const conflicts = [];
    for (const habit of dateHabits) {
      if (hasTimeConflict(habit.time_of_day!, eventData.start_time || '')) {
        conflicts.push({
          habit,
          event: eventData,
          time: habit.time_of_day
        });
      }
    }
    
    return conflicts;
  };

  const handleEventCreate = async (eventData: any) => {
    const conflicts = checkEventConflicts(eventData);
    
    if (conflicts.length > 0) {
      setPendingEvent(eventData);
      setEventConflicts(conflicts);
      setShowConflictDialog(true);
      setShowAddEvent(false);
      return;
    }
    
    await createEvent(eventData);
    setShowAddEvent(false);
  };

  const handleConflictResolution = async (resolution: any) => {
    try {
      switch (resolution.type) {
        case 'change_event_time':
          const updatedEvent = { ...pendingEvent, start_time: resolution.newEventTime };
          await createEvent(updatedEvent);
          break;
          
        case 'change_habit_time':
          await supabase.from('habit_day_overrides').insert({
            user_id: user?.id,
            habit_id: resolution.habitId,
            override_date: format(selectedDate, 'yyyy-MM-dd'),
            override_type: 'change_time',
            new_time: resolution.newHabitTime
          });
          await createEvent(pendingEvent);
          queryClient.invalidateQueries({ queryKey: ['habits'] });
          break;
          
        case 'skip_habit':
          await supabase.from('habit_day_overrides').insert({
            user_id: user?.id,
            habit_id: resolution.habitId,
            override_date: format(selectedDate, 'yyyy-MM-dd'),
            override_type: 'skip',
            new_time: null
          });
          await createEvent(pendingEvent);
          queryClient.invalidateQueries({ queryKey: ['habits'] });
          break;
          
        case 'ignore_conflict':
          await createEvent(pendingEvent);
          break;
      }
      
      setPendingEvent(null);
      setEventConflicts([]);
      
      toast({
        title: "Успех",
        description: "Събитието беше създадено успешно",
      });
      
    } catch (error) {
      console.error('Error resolving conflict:', error);
      toast({
        title: "Грешка",
        description: "Възникна проблем при създаване на събитието",
        variant: "destructive"
      });
    }
  };
  
  const hasTimeConflict = (habitTime: string, eventTime: string): boolean => {
    if (!habitTime || !eventTime) return false;
    const habitHour = habitTime.split(':')[0];
    const eventHour = eventTime.split(':')[0];
    return habitHour === eventHour;
  };

  const getConflictsForDate = (date: Date) => {
    const dateEvents = getEventsForDate(date);
    const dateHabits = habits.filter(habit => 
      isHabitActiveOnDay(habit, date) && habit.time_of_day
    );
    
    const conflicts = [];
    for (const habit of dateHabits) {
      for (const event of dateEvents) {
        if (hasTimeConflict(habit.time_of_day!, event.start_time || '')) {
          conflicts.push({
            habit,
            event,
            time: habit.time_of_day
          });
        }
      }
    }
    
    return conflicts;
  };

  // Hooks for different activities
  const { data: allMeals = [] } = useTodayMealsWithDishes(user);
  const meals = allMeals.filter((meal: any) => {
    const mealDate = new Date(meal.date);
    return mealDate.toDateString() === selectedDate.toDateString();
  });
  
  const { plannedMeals, togglePlannedMeal, calculateMealNutrition, getMealName, refetch: refetchPlannedMeals } = usePlannedMeals(selectedDate);
  const { activeFast, getCurrentFastingTime, formatFastingTime, startFast, endFast, isStarting } = useFasting();
  const { isTrainingDay, session: fitnessSession, updateSession: updateFitnessSession } = useFitnessToday(selectedDate);
  const { habits, isHabitCompleted, isHabitActiveOnDay, completeHabitMutation, uncompleteHabitMutation, updateHabitMutation, deleteHabitMutation, useHabitCompletions } = useHabits();

  const todayConflicts = getConflictsForDate(selectedDate);

  const { data: habitCompletions = [] } = useHabitCompletions(selectedDate, selectedDate);
  const { todaySessions, getActiveSession, parseDurationFromDescription, startSessionMutation, endSessionMutation } = useHabitSessions();
  
  const todayHabits = habits.filter(habit => isHabitActiveOnDay(habit, selectedDate));
  const completedHabits = todayHabits.filter(habit => isHabitCompleted(habit.id, selectedDate, habitCompletions));
  const habitProgress = todayHabits.length > 0 ? Math.round((completedHabits.length / todayHabits.length) * 100) : 0;

  // Calculate nutrition for the selected date
  const dayNutrition = meals.reduce((total, meal) => {
    let nutrition = { protein: 0, carbs: 0, fat: 0, fiber: 0, calories: 0 };

    if (meal.recipes) {
      meal.recipes.recipe_ingredients?.forEach((ingredient: any) => {
        const product = ingredient.products;
        const ratio = ingredient.grams / 100;
        nutrition.protein += product.protein_per_100g * ratio * (meal.servings || 1);
        nutrition.carbs += product.carbs_per_100g * ratio * (meal.servings || 1);
        nutrition.fat += product.fat_per_100g * ratio * (meal.servings || 1);
        nutrition.fiber += product.fiber_per_100g * ratio * (meal.servings || 1);
        nutrition.calories += product.calories_per_100g * ratio * (meal.servings || 1);
      });
    } else if ((meal as any).dishes) {
      (meal as any).dishes.dish_ingredients?.forEach((ingredient: any) => {
        const product = ingredient.products;
        const ratio = ingredient.grams / 100;
        nutrition.protein += product.protein_per_100g * ratio * (meal.servings || 1);
        nutrition.carbs += product.carbs_per_100g * ratio * (meal.servings || 1);
        nutrition.fat += product.fat_per_100g * ratio * (meal.servings || 1);
        nutrition.fiber += product.fiber_per_100g * ratio * (meal.servings || 1);
        nutrition.calories += product.calories_per_100g * ratio * (meal.servings || 1);
      });
    } else if (meal.products) {
      const product = meal.products;
      const ratio = (meal.grams || 100) / 100;
      nutrition.protein += product.protein_per_100g * ratio;
      nutrition.carbs += product.carbs_per_100g * ratio;
      nutrition.fat += product.fat_per_100g * ratio;
      nutrition.fiber += product.fiber_per_100g * ratio;
      nutrition.calories += product.calories_per_100g * ratio;
    }

    return {
      protein: total.protein + nutrition.protein,
      carbs: total.carbs + nutrition.carbs,
      fat: total.fat + nutrition.fat,
      fiber: total.fiber + nutrition.fiber,
      calories: total.calories + nutrition.calories
    };
  }, { protein: 0, carbs: 0, fat: 0, fiber: 0, calories: 0 });

  const calculateTodayBlocks = () => {
    return meals.reduce((total, meal) => {
      let nutrition = { protein: 0, carbs: 0, fat: 0 };

      if (meal.recipes) {
        meal.recipes.recipe_ingredients?.forEach((ingredient: any) => {
          const product = ingredient.products;
          const ratio = ingredient.grams / 100;
          nutrition.protein += product.protein_per_100g * ratio * (meal.servings || 1);
          nutrition.carbs += product.carbs_per_100g * ratio * (meal.servings || 1);
          nutrition.fat += product.fat_per_100g * ratio * (meal.servings || 1);
        });
      } else if ((meal as any).dishes) {
        (meal as any).dishes.dish_ingredients?.forEach((ingredient: any) => {
          const product = ingredient.products;
          const ratio = ingredient.grams / 100;
          nutrition.protein += product.protein_per_100g * ratio * (meal.servings || 1);
          nutrition.carbs += product.carbs_per_100g * ratio * (meal.servings || 1);
          nutrition.fat += product.fat_per_100g * ratio * (meal.servings || 1);
        });
      } else if (meal.products) {
        const product = meal.products;
        const ratio = (meal.grams || 100) / 100;
        nutrition.protein += product.protein_per_100g * ratio;
        nutrition.carbs += product.carbs_per_100g * ratio;
        nutrition.fat += product.fat_per_100g * ratio;
      }

      const proteinBlocks = nutrition.protein / 7;
      const carbBlocks = nutrition.carbs / 9; 
      const fatBlocks = nutrition.fat / 1.5;

      return {
        protein: total.protein + proteinBlocks,
        carbs: total.carbs + carbBlocks,
        fat: total.fat + fatBlocks
      };
    }, { protein: 0, carbs: 0, fat: 0 });
  };

  const todayBlocks = calculateTodayBlocks();
  const dailyBlocks = profile?.daily_blocks || 11;

  const dayEvents = getEventsForDate(selectedDate);
  const totalActivities = dayEvents.length + todayHabits.length;
  const completedActivities = dayEvents.length + completedHabits.length;
  const dayProgress = totalActivities > 0 ? Math.round((completedActivities / totalActivities) * 100) : 0;

  const handleHabitCreate = (habitData: any) => {
    setShowAddItem(false);
  };

  const handleToggleHabit = async (habitId: string) => {
    const isCompleted = isHabitCompleted(habitId, selectedDate, habitCompletions);
    
    if (isCompleted) {
      await uncompleteHabitMutation.mutateAsync({ 
        habitId, 
        date: selectedDate 
      });
    } else {
      await completeHabitMutation.mutateAsync({ 
        habitId, 
        date: selectedDate 
      });
    }
  };

  const [fullscreenTimerHabit, setFullscreenTimerHabit] = useState<any>(null);

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      {/* Calendar Tabs - най-отгоре */}
      <Tabs value={viewType} onValueChange={(value) => setViewType(value as any)} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="day" className="flex items-center gap-2">
            <CalendarIcon className="h-4 w-4" />
            Ден
          </TabsTrigger>
          <TabsTrigger value="week">
            Седмица
          </TabsTrigger>
          <TabsTrigger value="month">
            Месец
          </TabsTrigger>
          <TabsTrigger value="year">
            Година
          </TabsTrigger>
        </TabsList>

        {/* Header */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <Button variant="outline" size="sm" onClick={() => navigateView('prev')}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              
              <div className="text-center">
                <CardTitle className="text-xl lg:text-2xl">
                  {displayInfo.title}
                </CardTitle>
                {displayInfo.subtitle && (
                  <p className="text-sm text-muted-foreground">{displayInfo.subtitle}</p>
                )}
                {!isToday(selectedDate) && (
                  <Button variant="ghost" size="sm" onClick={goToToday} className="mt-2">
                    Днес
                  </Button>
                )}
              </div>
              
              <Button variant="outline" size="sm" onClick={() => navigateView('next')}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
        </Card>


        <TabsContent value="day" className="mt-6">
          <DayView
            selectedDate={selectedDate}
            onDateSelect={setSelectedDate}
            events={events}
            habits={habits}
            getEventsForDate={getEventsForDate}
            isHabitActiveOnDay={isHabitActiveOnDay}
            onAddEvent={() => setShowAddEvent(true)}
            onEditEvent={handleEditEvent}
            onDuplicateEvent={handleDuplicateEvent}
            deleteEvent={deleteEvent}
            onEditHabit={handleEditHabit}
            onDuplicateHabit={handleDuplicateHabit}
            deleteHabit={deleteHabit}
            todayCompletions={habitCompletions}
            todaySessions={todaySessions}
            isHabitCompleted={isHabitCompleted}
            handleToggleHabit={handleToggleHabit}
            parseDurationFromDescription={parseDurationFromDescription}
            getActiveSession={getActiveSession}
            setFullscreenTimerHabit={setFullscreenTimerHabit}
            startSessionMutation={startSessionMutation}
            endSessionMutation={endSessionMutation}
            expandedHabits={expandedHabits}
          />
        </TabsContent>

        <TabsContent value="week" className="mt-6">
          {isMobile ? (
            <MobileWeekListView
              selectedDate={selectedDate}
              onDateSelect={setSelectedDate}
              events={events}
              habits={habits}
              getEventsForDate={getEventsForDate}
              isHabitActiveOnDay={isHabitActiveOnDay}
              onAddEvent={() => setShowAddEvent(true)}
              deleteEvent={deleteEvent}
            />
          ) : (
            <WeekView
              selectedDate={selectedDate}
              onDateSelect={setSelectedDate}
              events={events}
              habits={habits}
              getEventsForDate={getEventsForDate}
              isHabitActiveOnDay={isHabitActiveOnDay}
              onAddEvent={() => setShowAddEvent(true)}
              onEditEvent={handleEditEvent}
              onDuplicateEvent={handleDuplicateEvent}
              deleteEvent={deleteEvent}
            />
          )}
        </TabsContent>

        <TabsContent value="month" className="mt-6">
          <MonthView
            selectedDate={selectedDate}
            onDateSelect={setSelectedDate}
            events={events}
            habits={habits}
            getEventsForDate={getEventsForDate}
            isHabitActiveOnDay={isHabitActiveOnDay}
            onAddEvent={() => setShowAddEvent(true)}
            onEditEvent={handleEditEvent}
            onDuplicateEvent={handleDuplicateEvent}
            deleteEvent={deleteEvent}
          />
        </TabsContent>

        <TabsContent value="year" className="mt-6">
          <YearView
            selectedDate={selectedDate}
            onDateSelect={setSelectedDate}
            events={events}
            habits={habits}
            getEventsForDate={getEventsForDate}
            isHabitActiveOnDay={isHabitActiveOnDay}
          />
        </TabsContent>
      </Tabs>

      {/* Hydration Card */}
      {isHydrationEnabled && (
        <HydrationCard selectedDate={selectedDate} />
      )}

      {/* Food/Nutrition Progress Card */}
      <Card className="bg-gradient-to-r from-primary/5 to-accent/5">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg">
            <TrendingUp className="w-5 h-5 text-primary" />
            Хранене за {format(selectedDate, 'dd.MM', { locale: bg })}
          </CardTitle>
          <CardDescription className="text-sm">
            {isZoneEnabled && profile?.daily_blocks
              ? `${Math.min(todayBlocks.protein, todayBlocks.carbs, todayBlocks.fat).toFixed(1)} от ${profile.daily_blocks} блока`
              : dailyCalorieTarget
              ? `${Math.round(dayNutrition.calories)} от ${dailyCalorieTarget} калории`
              : `${Math.round(dayNutrition.calories)} калории`
            }
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {isZoneEnabled && profile?.daily_blocks && (
            <div className="space-y-2">
              <Progress 
                value={Math.min((Math.min(todayBlocks.protein, todayBlocks.carbs, todayBlocks.fat) / profile.daily_blocks) * 100, 100)} 
                className="w-full h-2" 
              />
              <div className="text-center">
                <div className="text-xl lg:text-2xl font-bold text-primary">
                  {Math.min(todayBlocks.protein, todayBlocks.carbs, todayBlocks.fat).toFixed(1)} / {profile.daily_blocks}
                </div>
                <div className="text-xs lg:text-sm text-muted-foreground">Zone блока</div>
              </div>
            </div>
          )}
          
          {!isZoneEnabled && dailyCalorieTarget && (
            <div className="space-y-2">
              <Progress 
                value={Math.min((dayNutrition.calories / dailyCalorieTarget) * 100, 100)} 
                className="w-full h-2" 
              />
              <div className="text-center">
                <div className="text-xl lg:text-2xl font-bold text-primary">
                  {Math.round(dayNutrition.calories)} / {dailyCalorieTarget}
                </div>
                <div className="text-xs lg:text-sm text-muted-foreground">калории</div>
              </div>
            </div>
          )}
          
          <div className="grid grid-cols-2 gap-2 lg:gap-4">
            <div className="text-center p-2 lg:p-4 rounded-lg bg-card border">
              <Clock className="w-4 h-4 lg:w-6 lg:h-6 mx-auto mb-1 lg:mb-2 text-zone-carbs" />
              <p className="text-lg lg:text-2xl font-bold">{meals.length}</p>
              <p className="text-xs lg:text-sm text-muted-foreground">Хранения</p>
            </div>
            <div className="text-center p-2 lg:p-4 rounded-lg bg-card border">
              <TrendingUp className="w-4 h-4 lg:w-6 lg:h-6 mx-auto mb-1 lg:mb-2 text-success" />
              <p className="text-lg lg:text-2xl font-bold">{Math.round(dayNutrition.calories)}</p>
              <p className="text-xs lg:text-sm text-muted-foreground">Калории</p>
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-1 lg:gap-3">
            <div className="text-center p-2 rounded-lg bg-zone-protein/10 border border-zone-protein/20">
              <div className="w-3 h-3 rounded-full bg-zone-protein mx-auto mb-1"></div>
              <p className="font-medium text-zone-protein text-xs lg:text-sm">{dayNutrition.protein.toFixed(1)}г</p>
              <p className="text-zone-protein/80 text-[10px] lg:text-xs leading-tight">Протеини</p>
            </div>
            <div className="text-center p-2 rounded-lg bg-zone-carbs/10 border border-zone-carbs/20">
              <div className="w-3 h-3 rounded-full bg-zone-carbs mx-auto mb-1"></div>
              <p className="font-medium text-zone-carbs text-xs lg:text-sm">{dayNutrition.carbs.toFixed(1)}г</p>
              <p className="text-zone-carbs/80 text-[10px] lg:text-xs leading-tight">Въглехидрати</p>
            </div>
            <div className="text-center p-2 rounded-lg bg-zone-fat/10 border border-zone-fat/20">
              <div className="w-3 h-3 rounded-full bg-zone-fat mx-auto mb-1"></div>
              <p className="font-medium text-zone-fat text-xs lg:text-sm">{dayNutrition.fat.toFixed(1)}г</p>
              <p className="text-zone-fat/80 text-[10px] lg:text-xs leading-tight">Мазнини</p>
            </div>
          </div>

          <div className="text-center mt-3">
            <Button 
              onClick={() => setShowAddMeal(true)}
              variant="outline"
              size="sm"
            >
              <Plus className="h-4 w-4 mr-2" />
              Добави храна
            </Button>
          </div>

          {meals.length > 0 && (
            <div className="space-y-3">
              {meals.map((meal) => {
                let mealName = '';
                if (meal.products) {
                  mealName = meal.products.name;
                } else if (meal.recipes) {
                  mealName = meal.recipes.name;
                } else if ((meal as any).dishes) {
                  mealName = (meal as any).dishes.name;
                }
                
                const currentServings = meal.servings || 1;

                return (
                  <Card key={meal.id} className="border shadow-sm">
                    <CardContent className="p-3">
                      <div className="flex items-center justify-between mb-2">
                        {/* Left */}
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full" style={{
                            backgroundColor: meal.meal_type === 'breakfast' ? '#f59e0b' :
                                           meal.meal_type === 'snack' ? '#10b981' :
                                           meal.meal_type === 'lunch' ? '#3b82f6' : '#ef4444'
                          }}></div>
                          <span className="text-[11px] text-muted-foreground capitalize">
                            {meal.meal_type === 'breakfast' ? 'Закуска' :
                             meal.meal_type === 'snack' ? 'Снек' :
                             meal.meal_type === 'lunch' ? 'Обяд' : 'Вечеря'}
                          </span>
                        </div>
                        {/* Right */}
                        <div className="flex justify-end">
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-4 w-4 rounded-full hover:bg-destructive/10 hover:text-destructive opacity-30 hover:opacity-100 transition-opacity"
                            aria-label="Изтрий храненето"
                            title="Изтрий храненето"
                            onClick={async () => {
                              await supabase.from('meals').delete().eq('id', meal.id);
                              queryClient.invalidateQueries({ queryKey: ['meals'] });
                            }}
                          >
                            <Trash2 className="w-2 h-2" />
                          </Button>
                        </div>
                      </div>

                      <div className="mt-1 flex items-center justify-between">
                        <h4 className="font-medium text-sm truncate pr-2">{mealName}</h4>
                        <div className="flex items-center gap-1">
                          <span className="text-lg font-bold leading-none text-foreground">{currentServings}</span>
                          <span className="text-[11px] text-muted-foreground">порц.</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Dialogs */}
      <AddEventDialog
        open={showAddEvent}
        onOpenChange={setShowAddEvent}
        selectedDate={selectedDate}
        onSave={handleEventCreate}
        isLoading={isCreating}
      />

      <AddItemDialog
        open={showAddItem}
        onOpenChange={setShowAddItem}
        selectedDate={selectedDate}
        onEventCreate={handleEventCreate}
        onHabitCreate={handleHabitCreate}
        isCreating={isCreating}
      />

      <ConflictResolutionDialog
        open={showConflictDialog}
        onOpenChange={setShowConflictDialog}
        conflicts={eventConflicts}
        eventData={pendingEvent}
        selectedDate={selectedDate}
        onResolve={handleConflictResolution}
      />

      <AddMealToTodayDialog 
        open={showAddMeal}
        onOpenChange={setShowAddMeal}
        selectedDate={selectedDate}
      />

      <FastingStartDialog
        open={showFastingDialog}
        onOpenChange={setShowFastingDialog}
        onStart={startFast}
        isStarting={isStarting}
      />
    </div>
  );
};

export default Calendar;