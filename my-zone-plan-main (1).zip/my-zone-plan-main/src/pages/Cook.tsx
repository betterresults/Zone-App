import { useState, useCallback, useMemo, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Plus, Trash2, ChefHat, Save, Calculator, Search, ChevronDown, ChevronLeft, ChevronRight, Filter } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { AddProductDialog } from '@/components/products/AddProductDialog';
import { SaveMenu } from '@/components/cooking/SaveMenu';
import { useDebounce } from 'use-debounce';
import { useFeatureFlags } from '@/hooks/useFeatureFlags';
import { useKetoCalculation } from '@/hooks/useKetoCalculation';

interface CookingItem {
  id: string;
  product: any;
  grams: number;
  portionName?: string;
}

interface ZoneCalculation {
  blocks: number;
  protein: number;
  carbs: number;
  fat: number;
  calories: number;
}

const Cook = () => {
  const [cookingItems, setCookingItems] = useState<CookingItem[]>([]);
  const [customGrams, setCustomGrams] = useState<number>(100);
  const [searchQuery, setSearchQuery] = useState('');
  const [debouncedSearchQuery] = useDebounce(searchQuery, 300);
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [showProductSelection, setShowProductSelection] = useState(true);
  const [addedProductIds, setAddedProductIds] = useState<Set<string>>(new Set());
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [categoryDialogOpen, setCategoryDialogOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [sourceRecipe, setSourceRecipe] = useState<any>(null); // Track if cooking from existing recipe
  const { isZoneEnabled, isKetoEnabled, dailyCarbsLimit } = useFeatureFlags();
  const { calculateKetoCompliance } = useKetoCalculation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

// Product categories for filtering
const categories = [
  { value: 'all', label: 'Всички' },
  { value: 'vegetables', label: 'Зеленчуци' },
  { value: 'fruits', label: 'Плодове' },
  { value: 'protein', label: 'Протеини' },
  { value: 'dairy', label: 'Млечни' },
  { value: 'grains', label: 'Зърнени' },
  { value: 'legumes', label: 'Варива' },
  { value: 'nuts', label: 'Ядки' },
  { value: 'fats', label: 'Мазнини' },
  { value: 'other', label: 'Други' }
];

const PRODUCTS_PER_PAGE = 12;

  // Load cooking items from localStorage on mount
  useEffect(() => {
    const loadItemsAsync = async () => {
      const saved = localStorage.getItem('cookingItems');
      const savedSourceRecipe = localStorage.getItem('sourceRecipe');
      
      if (saved) {
        try {
          const parsedItems: CookingItem[] = JSON.parse(saved);
          
          // Refresh product data from database to ensure we have latest nutritional values
          const { data: { user } } = await supabase.auth.getUser();
          if (user) {
            const productIds = parsedItems.map(item => item.product.id);
            const { data: freshProducts } = await supabase
              .from('products')
              .select('*')
              .eq('user_id', user.id)
              .in('id', productIds);
            
            if (freshProducts) {
              // Update items with fresh product data
              const updatedItems = parsedItems.map(item => {
                const freshProduct = freshProducts.find(p => p.id === item.product.id);
                return freshProduct ? { ...item, product: freshProduct } : item;
              });
              setCookingItems(updatedItems);
              const productIdSet = new Set<string>(updatedItems.map((item: CookingItem) => item.product.id));
              setAddedProductIds(productIdSet);
            } else {
              setCookingItems(parsedItems);
              const productIdSet = new Set<string>(parsedItems.map((item: CookingItem) => item.product.id));
              setAddedProductIds(productIdSet);
            }
          }
        } catch (error) {
          console.error('Error loading cooking items:', error);
        }
      }
      
      if (savedSourceRecipe) {
        try {
          const parsedSourceRecipe = JSON.parse(savedSourceRecipe);
          setSourceRecipe(parsedSourceRecipe);
        } catch (error) {
          console.error('Error loading source recipe:', error);
          localStorage.removeItem('sourceRecipe');
        }
      }
    };
    
    loadItemsAsync();
  }, []);

  // Save cooking items to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('cookingItems', JSON.stringify(cookingItems));
  }, [cookingItems]);

  // Save source recipe to localStorage whenever it changes
  useEffect(() => {
    if (sourceRecipe) {
      localStorage.setItem('sourceRecipe', JSON.stringify(sourceRecipe));
    } else {
      localStorage.removeItem('sourceRecipe');
    }
  }, [sourceRecipe]);

  // Listen for product updates to refresh the list
  useEffect(() => {
    const channel = supabase
      .channel('product-updates')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'products'
        },
        () => {
          // Refresh products when new one is added
          queryClient.invalidateQueries({ queryKey: ['my-products-for-cooking'] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [queryClient]);

  // Fetch user products with filtering and pagination
  const { data: productsData = { products: [], total: 0 }, isLoading } = useQuery({
    queryKey: ['my-products-for-cooking', debouncedSearchQuery, selectedCategories, currentPage],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return { products: [], total: 0 };
      
      let query = supabase
        .from('products')
        .select('*', { count: 'exact' })
        .eq('user_id', user.id)
        .order('name');

      // Apply category filter - multiple categories
      if (selectedCategories.length > 0) {
        query = query.in('category', selectedCategories as any);
      }

      // Apply search filter
      if (debouncedSearchQuery.trim()) {
        query = query.ilike('name', `%${debouncedSearchQuery.trim()}%`);
      }

      // Apply pagination
      const from = (currentPage - 1) * PRODUCTS_PER_PAGE;
      const to = from + PRODUCTS_PER_PAGE - 1;
      query = query.range(from, to);

      const { data, error, count } = await query;
      
      if (error) throw error;
      return { 
        products: data || [], 
        total: count || 0 
      };
    },
    staleTime: 1000 * 60 * 5,
    refetchOnWindowFocus: false
  });

  const myProducts = productsData.products;
  const totalProducts = productsData.total;
  const totalPages = Math.ceil(totalProducts / PRODUCTS_PER_PAGE);

  // Reset pagination when filters change and close dropdown
  useEffect(() => {
    setCurrentPage(1);
  }, [selectedCategories, debouncedSearchQuery]);

  // Close category dropdown when clicking outside (removed since we use fixed overlay now)

  const calculateZoneBlocks = (protein: number, carbs: number, fat: number): ZoneCalculation => {
    const proteinBlocks = protein / 7; // 7г протеин = 1 блок
    const carbBlocks = carbs / 9;      // 9г въглехидрати = 1 блок  
    const fatBlocks = fat / 1.5;       // 1.5г добавени мазнини = 1 блок (заради скрити мазнини в храните)

    // Zone diet правилна логика: най-малкият брой блокове определя Zone статуса
    const blocks = Math.min(proteinBlocks, carbBlocks, fatBlocks);

    return {
      blocks,
      protein: proteinBlocks,
      carbs: carbBlocks,
      fat: fatBlocks,
      calories: (protein * 4) + (carbs * 4) + (fat * 9)
    };
  };

  const getTotalNutrition = () => {
    return cookingItems.reduce((total, item) => {
      const factor = item.grams / 100;
      const calories = (Number(item.product.calories_per_100g) || 0) * factor;
      const protein = (Number(item.product.protein_per_100g) || 0) * factor;
      const carbs = (Number(item.product.carbs_per_100g) || 0) * factor;
      const fat = (Number(item.product.fat_per_100g) || 0) * factor;
      const fiber = (Number(item.product.fiber_per_100g) || 0) * factor;
      
      // Calculate net carbs PER PRODUCT first, then sum
      const productNetCarbs = Math.max(0, (Number(item.product.carbs_per_100g) || 0) - (Number(item.product.fiber_per_100g) || 0)) * factor;
      
      return {
        calories: total.calories + calories,
        protein: total.protein + protein,
        carbs: total.carbs + carbs,
        fat: total.fat + fat,
        fiber: total.fiber + fiber,
        netCarbs: (total.netCarbs || 0) + productNetCarbs
      };
    }, { calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0, netCarbs: 0 });
  };

  const addProduct = useCallback((productId: string, grams: number = 100, portionName?: string) => {
    const product = myProducts.find(p => p.id === productId);
    if (!product) return;

    // Check if product is already added
    const existingItem = cookingItems.find(item => item.product.id === productId);
    if (existingItem) {
      // If already added, remove it (toggle behavior)
      removeItem(existingItem.id);
      return;
    }

    const newItem: CookingItem = {
      id: Date.now().toString(),
      product,
      grams,
      portionName
    };

    setCookingItems(prev => [...prev, newItem]);
    setAddedProductIds(prev => new Set([...prev, productId]));
    setCustomGrams(100);
  }, [myProducts, cookingItems]);

  const removeItem = useCallback((id: string) => {
    setCookingItems(prev => {
      const item = prev.find(item => item.id === id);
      if (item) {
        // Check if this was the last item of this product
        const remainingItems = prev.filter(i => i.id !== id && i.product.id === item.product.id);
        if (remainingItems.length === 0) {
          setAddedProductIds(prevIds => {
            const newSet = new Set(prevIds);
            newSet.delete(item.product.id);
            return newSet;
          });
        }
      }
      return prev.filter(item => item.id !== id);
    });
  }, []);

  const updateItemGrams = useCallback((id: string, newGrams: number) => {
    setCookingItems(items => 
      items.map(item => 
        item.id === id ? { ...item, grams: newGrams } : item
      )
    );
  }, []);

  const clearAll = useCallback(() => {
    setCookingItems([]);
    setAddedProductIds(new Set());
    setSourceRecipe(null);
    localStorage.removeItem('cookingItems');
    localStorage.removeItem('sourceRecipe');
  }, []);

  const nutrition = useMemo(() => getTotalNutrition(), [cookingItems]);
  const zoneCalc = useMemo(() => calculateZoneBlocks(nutrition.protein, nutrition.carbs, nutrition.fat), [nutrition]);
  const ketoCalc = useMemo(() => calculateKetoCompliance(nutrition, dailyCarbsLimit), [nutrition, dailyCarbsLimit]);

  return (
    <div className="container mx-auto px-2 sm:px-4 py-2 space-y-2 max-w-full overflow-x-hidden">
      {/* Header */}
      <div className="flex items-center justify-between gap-2">
        <div className="min-w-0 flex-1">
           {/* Removed title - keeping space for layout */}
        </div>
        {!showProductSelection && cookingItems.length > 0 && (
          <Button 
            variant="default" 
            size="sm"
            onClick={() => setShowProductSelection(true)}
            className="bg-gradient-to-r from-primary to-primary-light hover:from-primary-dark hover:to-primary shadow-lg hover:shadow-xl transition-all duration-300 text-xs sm:text-sm px-2 sm:px-3 py-2 flex-shrink-0"
          >
            <Plus className="w-3 h-3 mr-1" />
            <span className="hidden sm:inline">Добави продукти</span>
            <span className="sm:hidden">Добави</span>
          </Button>
        )}
      </div>

      {/* Product Selection - Collapsible */}
      {showProductSelection && (
        <div className="space-y-2 border border-border rounded-lg p-2 sm:p-3 bg-card">
          {/* Search and Add Row */}
          <div className="flex gap-2">
            <div className="relative flex-1">
              <ChefHat className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-primary" />
              <Search className="w-4 h-4 absolute left-8 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
               <Input
                placeholder="Търси продукт..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-14"
                key="search-input"
              />
            </div>
            <Button 
              variant="outline" 
              onClick={() => setShowAddProduct(true)}
              size="icon"
              className="flex-shrink-0"
            >
              <Plus className="w-4 h-4" />
            </Button>
          </div>

          {/* Category Filter */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="text-sm font-medium text-muted-foreground">Категории</div>
              <Button variant="outline" size="sm" onClick={() => setCategoryDialogOpen(true)} className="flex items-center gap-2">
                <Filter className="w-4 h-4" /> Филтрирай
              </Button>
            </div>
            {selectedCategories.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {selectedCategories.map((cat) => (
                  <Badge key={cat} variant="secondary" className="text-xs">
                    {categories.find(c => c.value === cat)?.label || cat}
                  </Badge>
                ))}
                <Button variant="ghost" size="sm" className="h-7" onClick={() => setSelectedCategories([])}>Изчисти</Button>
              </div>
            )}
          </div>

          {/* Categories Dialog */}
          <Dialog open={categoryDialogOpen} onOpenChange={setCategoryDialogOpen}>
            <DialogContent className="max-w-sm">
              <DialogHeader>
                <DialogTitle>Избери категории</DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-2 py-2">
                {categories.filter(c => c.value !== 'all').map((category) => {
                  const checked = selectedCategories.includes(category.value);
                  return (
                    <label key={category.value} className="flex items-center gap-2 rounded-lg border p-2 cursor-pointer">
                      <Checkbox
                        checked={checked}
                        onCheckedChange={(val) => {
                          const v = !!val;
                          setSelectedCategories((prev) =>
                            v ? [...prev, category.value] : prev.filter((x) => x !== category.value)
                          );
                        }}
                      />
                      <span className="text-sm">{category.label}</span>
                    </label>
                  );
                })}
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t">
                <Button variant="outline" onClick={() => setCategoryDialogOpen(false)}>Затвори</Button>
                <Button onClick={() => setCategoryDialogOpen(false)}>Приложи</Button>
              </div>
            </DialogContent>
          </Dialog>

          {/* Loading indicator */}
          {isLoading ? (
            <div className="text-center py-4 text-muted-foreground">
              Зареждане...
            </div>
          ) : (
            <>
              {/* Products Grid - Modern Cards */}
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7 gap-2">
                {myProducts.map(product => {
                  const isAdded = addedProductIds.has(product.id);
                  return (
                    <div 
                      key={`product-${product.id}`} 
                      data-product-item
                      className={`relative cursor-pointer aspect-square rounded-lg border-2 overflow-hidden transition-colors duration-200 ${
                        isAdded 
                          ? 'border-primary bg-primary/10' 
                          : 'border-border hover:border-primary/50'
                      }`}
                      onClick={() => addProduct(product.id, 0)}
                    >
                      {/* Background Image */}
                      {product.image_url ? (
                        <div 
                          className={`absolute inset-0 bg-cover bg-center transition-all duration-200 ${isAdded ? 'opacity-70' : ''}`}
                          style={{ backgroundImage: `url(${product.image_url})` }}
                        />
                      ) : (
                        <div className={`absolute inset-0 bg-gradient-to-br from-primary/20 to-primary/40 flex items-center justify-center transition-all duration-200 ${isAdded ? 'from-primary/40 to-primary/60' : ''}`}>
                          <ChefHat className="w-6 h-6 text-primary" />
                        </div>
                      )}
                      
                      {/* Text Overlay */}
                      <div className="absolute inset-0 flex items-end justify-center pb-4">
                        <div className="backdrop-blur-sm px-2 py-1.5 rounded-md border bg-background/90 border-border/50">
                          <h4 className="font-semibold text-xs leading-tight uppercase tracking-wide text-center line-clamp-2 text-foreground">
                            {product.name}
                          </h4>
                        </div>
                      </div>

                      {/* Selected indicator */}
                      {isAdded && (
                        <div className="absolute top-2 right-2 w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                          <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                        </div>
                      )}
                    </div>
                  );
                })}
                
                {myProducts.length === 0 && (
                  <div className="col-span-full text-center py-8 text-muted-foreground">
                    <ChefHat className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>{searchQuery || selectedCategories.length > 0 ? 'Няма намерени продукти' : 'Няма добавени продукти'}</p>
                  </div>
                )}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-center gap-2 pt-1">
                  <Button 
                    variant="outline" 
                    size="icon"
                    onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                    disabled={currentPage === 1}
                    className="w-8 h-8"
                    aria-label="Предишна страница"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  <span className="text-[11px] text-muted-foreground min-w-[36px] text-center">
                    {currentPage} / {totalPages}
                  </span>
                  <Button 
                    variant="outline" 
                    size="icon"
                    onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                    disabled={currentPage === totalPages}
                    className="w-8 h-8"
                    aria-label="Следваща страница"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              )}
            </>
          )}

          {/* Hide Button */}
          {cookingItems.length > 0 && (
            <div className="flex justify-center pt-2 border-t">
              <Button 
                variant="ghost" 
                onClick={() => setShowProductSelection(false)}
                size="sm"
              >
                Скрий продукти
              </Button>
            </div>
          )}
        </div>
      )}


      {/* Added Products List */}
      <Card className="border-border">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle>Добавени продукти ({cookingItems.length})</CardTitle>
            {cookingItems.length > 0 && (
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  onClick={clearAll}
                  size="sm"
                  className="hidden sm:flex"
                >
                  Изчисти всичко
                </Button>
                <Button 
                  variant="outline" 
                  onClick={clearAll}
                  size="sm"
                  className="sm:hidden"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent className="p-2 sm:p-3">
          {cookingItems.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <ChefHat className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p className="text-lg">Все още няма добавени продукти</p>
              <p className="text-sm">Започнете с избирането на продукт отгоре</p>
            </div>
          ) : (
            <>
              <div className="space-y-2 sm:space-y-3">
              {cookingItems.map(item => {
                // Universal gram options for any combination
                const gramOptions = [1, 2, 5, 10, 20, 25, 100, 200];

                return (
                <div key={item.id} className="bg-muted/30 rounded-lg p-2 sm:p-3 border border-border">
                  {/* First line: Image, Name, Editable grams, Delete */}
                  <div className="flex items-center gap-2 mb-2">
                      {/* Product image */}
                      <div className="w-10 h-8 sm:w-12 sm:h-10 bg-muted rounded-lg flex items-center justify-center overflow-hidden flex-shrink-0">
                        {item.product.image_url ? (
                          <img 
                            src={item.product.image_url} 
                            alt={item.product.name}
                            className="w-full h-full object-cover rounded-lg"
                          />
                        ) : (
                          <ChefHat className="w-3 h-3 sm:w-4 sm:h-4 text-muted-foreground" />
                        )}
                      </div>

                      {/* Product name and debug info */}
                      <div className="flex-1 min-w-0 pr-1">
                        <h4 className="font-medium text-xs sm:text-sm truncate">{item.product.name}</h4>
                        <div className="text-xs text-muted-foreground mt-0.5">
                          C:{(Number(item.product.carbs_per_100g) || 0).toFixed(1)} 
                          F:{(Number(item.product.fiber_per_100g) || 0).toFixed(1)}
                          {item.grams > 0 && (
                            <span className="ml-1 text-primary">
                              → {((Number(item.product.carbs_per_100g) || 0) * item.grams / 100).toFixed(1)}г
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Modern number control with arrows */}
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => updateItemGrams(item.id, Math.max(0, item.grams - 1))}
                          className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground"
                        >
                          <ChevronLeft className="w-3 h-3" />
                        </Button>
                        <div className="bg-muted/50 rounded-lg px-2 py-1 min-w-[45px] text-center">
                          <span className="font-bold text-sm">{item.grams}</span>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => updateItemGrams(item.id, item.grams + 1)}
                          className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground"
                        >
                          <ChevronRight className="w-3 h-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => updateItemGrams(item.id, 0)}
                          className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground hover:bg-muted/20"
                          title="Нулирай грамове"
                        >
                          <svg className="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/>
                            <path d="M21 3v5h-5"/>
                            <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/>
                            <path d="M3 21v-5h5"/>
                          </svg>
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeItem(item.id)}
                          className="h-6 w-6 p-0 text-muted-foreground hover:text-destructive"
                          title="Премахни"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>

                    </div>

                    {/* Second line: Quick gram selection with responsive layout */}
                    <div className="border-2 border-dashed border-primary/30 rounded-lg p-1.5 sm:p-2 bg-primary/5">
                      <div className="flex flex-col gap-1 sm:gap-2">
                        <div className="text-xs text-muted-foreground font-medium">
                          Добави грамове
                        </div>
                        <div className="flex gap-1 overflow-x-auto pb-1">
                          {gramOptions.map((grams) => (
                            <Button
                              key={grams}
                              variant="outline"
                              size="sm"
                              className="h-6 sm:h-8 text-xs px-1.5 sm:px-2 flex-shrink-0 min-w-[32px] sm:min-w-[40px]"
                              onClick={() => updateItemGrams(item.id, Math.max(0, item.grams + grams))}
                            >
                              +{grams}
                            </Button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                );
               })}
              </div>
              
             {/* Save Button */}
             <div className="mt-2 sm:mt-3 pt-2 border-t">
                <SaveMenu 
                  cookingItems={cookingItems} 
                  totalNutrition={nutrition}
                  buttonText="Запази рецептата"
                  sourceRecipe={sourceRecipe}
                />
             </div>
           </>
          )}
        </CardContent>
      </Card>

      {/* Zone Calculator - Bottom */}
      {cookingItems.length > 0 && (
        <Card className="border-2 border-primary/20">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-xl">
              <Calculator className="w-6 h-6" />
              {isZoneEnabled ? 'Zone Резултат' : isKetoEnabled ? 'Кето Резултат' : 'Хранителни стойности'}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-3">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Total macros - only show when no specific diet is selected */}
              {!isZoneEnabled && !isKetoEnabled && (
                <div className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900 p-4 rounded-lg">
                  <h3 className="font-bold text-sm text-blue-700 dark:text-blue-300 mb-3 text-center">ОБЩО МАКРОСИ</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center bg-white/50 dark:bg-black/20 p-2 rounded">
                      <span className="font-medium">Протеин</span>
                      <span className="font-bold text-blue-600">{nutrition.protein.toFixed(1)}г</span>
                    </div>
                    <div className="flex justify-between items-center bg-white/50 dark:bg-black/20 p-2 rounded">
                      <span className="font-medium">Въглехидрати</span>
                      <span className="font-bold text-green-600">{nutrition.carbs.toFixed(1)}г</span>
                    </div>
                    <div className="flex justify-between items-center bg-white/50 dark:bg-black/20 p-2 rounded">
                      <span className="font-medium">Мазнини</span>
                      <span className="font-bold text-orange-600">{nutrition.fat.toFixed(1)}г</span>
                    </div>
                    <div className="flex justify-between items-center bg-primary/10 p-2 rounded border-2 border-primary/20">
                      <span className="font-bold">Калории</span>
                      <span className="font-bold text-primary text-lg">{Math.round(nutrition.calories)}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Zone blocks */}
              {isZoneEnabled && (
                <div className="text-center space-y-4">
                  <h3 className="font-bold text-sm text-muted-foreground">ZONE БЛОКОВЕ</h3>
                  <div className="flex justify-center items-center gap-4">
                    {(() => {
                      const minBlocks = Math.min(zoneCalc.protein, zoneCalc.carbs, zoneCalc.fat); // Zone Diet правилна логика
                      const maxBlocks = Math.max(zoneCalc.protein, zoneCalc.carbs, zoneCalc.fat);
                      const ratio = minBlocks / maxBlocks;
                      
                      // Determine colors based on zone status
                      const getBlockColor = (blockValue: number) => {
                        if (ratio >= 0.9) {
                          // В ЗОНАТА - всички зелени
                          return 'bg-green-500';
                        } else if (ratio >= 0.7) {
                          // БЛИЗО ДО ЗОНАТА - само зелени и жълти, БЕЗ червени
                          const percentOfMax = blockValue / maxBlocks;
                          return percentOfMax >= 0.85 ? 'bg-green-500' : 'bg-yellow-500';
                        } else {
                          // ИЗВЪН ЗОНАТА - може да има червени
                          const percentOfMax = blockValue / maxBlocks;
                          if (percentOfMax >= 0.9) {
                            return 'bg-green-500';
                          } else if (percentOfMax >= 0.7) {
                            return 'bg-yellow-500';
                          } else {
                            return 'bg-red-500';
                          }
                        }
                      };
                      
                      return (
                        <>
                          <div className="text-center">
                            <div className={`w-16 h-16 rounded-full text-white flex items-center justify-center text-lg font-bold ${getBlockColor(zoneCalc.protein)}`}>
                              {zoneCalc.protein.toFixed(1)}
                            </div>
                            <div className="text-xs mt-1 font-medium">Протеин</div>
                          </div>
                          <div className="text-center">
                            <div className={`w-16 h-16 rounded-full text-white flex items-center justify-center text-lg font-bold ${getBlockColor(zoneCalc.carbs)}`}>
                              {zoneCalc.carbs.toFixed(1)}
                            </div>
                            <div className="text-xs mt-1 font-medium">Въглехидр.</div>
                          </div>
                          <div className="text-center">
                            <div className={`w-16 h-16 rounded-full text-white flex items-center justify-center text-lg font-bold ${getBlockColor(zoneCalc.fat)}`}>
                              {zoneCalc.fat.toFixed(1)}
                            </div>
                            <div className="text-xs mt-1 font-medium">Мазнини</div>
                          </div>
                        </>
                      );
                    })()}
                  </div>
                </div>
              )}

              {/* Keto macros in grams */}
              {isKetoEnabled && (
                <div className="text-center space-y-4">
                  <h3 className="font-bold text-sm text-muted-foreground">КЕТО МАКРОСИ</h3>
                  <div className="flex justify-center items-center gap-4">
                    <div className="text-center">
                      <div className="w-16 h-16 rounded-full text-white flex items-center justify-center text-lg font-bold bg-green-600">
                        {nutrition.protein.toFixed(1)}
                      </div>
                      <div className="text-xs mt-1 font-medium">Протеин</div>
                      <div className="text-xs text-green-600 font-medium">{ketoCalc.proteinPercentage.toFixed(0)}%</div>
                    </div>
                    <div className="text-center">
                      <div className={`w-16 h-16 rounded-full text-white flex items-center justify-center text-lg font-bold ${
                        ketoCalc.netCarbs <= dailyCarbsLimit * 0.7 ? 'bg-green-500' : 
                        ketoCalc.netCarbs <= dailyCarbsLimit ? 'bg-yellow-500' : 'bg-red-500'
                      }`}>
                        {ketoCalc.netCarbs.toFixed(1)}
                      </div>
                      <div className="text-xs mt-1 font-medium">Въглехидр.</div>
                      <div className="text-xs text-blue-600 font-medium">{ketoCalc.carbPercentage.toFixed(0)}%</div>
                    </div>
                    <div className="text-center">
                      <div className="w-16 h-16 rounded-full text-white flex items-center justify-center text-lg font-bold bg-orange-600">
                        {nutrition.fat.toFixed(1)}
                      </div>
                      <div className="text-xs mt-1 font-medium">Мазнини</div>
                      <div className="text-xs text-orange-600 font-medium">{ketoCalc.fatPercentage.toFixed(0)}%</div>
                    </div>
                  </div>
                  {/* Calories */}
                  <div className="mt-4 pt-4 border-t">
                    <div className="text-sm text-muted-foreground mb-1">Калории</div>
                    <div className="text-3xl font-bold text-primary">{Math.round(nutrition.calories)}</div>
                  </div>
                </div>
              )}

              {/* Zone status */}
              {isZoneEnabled && (
                <div className="text-center space-y-4">
                  <h3 className="font-bold text-sm text-muted-foreground">ZONE СТАТУС</h3>
                  <div className="space-y-2">
                    <div className="text-3xl font-bold text-primary">
                      {zoneCalc.blocks.toFixed(1)}
                    </div>
                    <div className="text-sm text-muted-foreground">блокове общо</div>
                    
                    {/* Zone balance indicator */}
                    <div className="mt-4">
                      {(() => {
                        const minBlocks = Math.min(zoneCalc.protein, zoneCalc.carbs, zoneCalc.fat);
                        const maxBlocks = Math.max(zoneCalc.protein, zoneCalc.carbs, zoneCalc.fat);
                        const ratio = minBlocks / maxBlocks;
                        
                        if (ratio >= 0.9) {
                          return (
                            <div className="px-4 py-2 bg-green-500 text-white rounded-full font-bold">
                              В ЗОНАТА!
                            </div>
                          );
                        } else if (ratio >= 0.7) {
                          return (
                            <div className="px-4 py-2 bg-yellow-500 text-white rounded-full font-bold">
                              БЛИЗО ДО ЗОНАТА
                            </div>
                          );
                        } else {
                          return (
                            <div className="px-4 py-2 bg-red-500 text-white rounded-full font-bold">
                              ИЗВЪН ЗОНАТА
                            </div>
                          );
                        }
                      })()}
                    </div>

                    {/* Calories */}
                    <div className="mt-4 pt-4 border-t">
                      <div className="text-sm text-muted-foreground mb-1">Калории</div>
                      <div className="text-3xl font-bold text-primary">{Math.round(nutrition.calories)}</div>
                    </div>
                  </div>
                </div>
              )}

              {/* Keto status */}
              {isKetoEnabled && (
                <div className="text-center space-y-4">
                  <h3 className="font-bold text-sm text-muted-foreground">КЕТО СТАТУС</h3>
                  <div className="space-y-2">
                    <div className={`px-4 py-2 rounded-full font-bold ${
                      ketoCalc.netCarbs <= dailyCarbsLimit * 0.7 ? 'bg-green-500 text-white' : 
                      ketoCalc.netCarbs <= dailyCarbsLimit ? 'bg-yellow-500 text-white' : 
                      'bg-red-500 text-white'
                    }`}>
                      {ketoCalc.status}
                    </div>
                    
                    <div className="text-sm text-muted-foreground">
                      Остават: <span className={`font-medium ${
                        Math.max(0, dailyCarbsLimit - ketoCalc.netCarbs) > dailyCarbsLimit * 0.3 
                          ? 'text-green-600' 
                          : Math.max(0, dailyCarbsLimit - ketoCalc.netCarbs) > 0
                          ? 'text-yellow-600'
                          : 'text-red-600'
                      }`}>
                        {Math.max(0, dailyCarbsLimit - ketoCalc.netCarbs).toFixed(1)}г въглехидрати
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Basic nutrition for calories mode */}
              {!isZoneEnabled && !isKetoEnabled && (
                <div className="text-center space-y-4">
                  <h3 className="font-bold text-sm text-muted-foreground">ХРАНИТЕЛНИ СТОЙНОСТИ</h3>
                  <div className="text-3xl font-bold text-primary">
                    {Math.round(nutrition.calories)}
                  </div>
                  <div className="text-sm text-muted-foreground">калории общо</div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Add Product Dialog */}
      <AddProductDialog 
        open={showAddProduct} 
        onOpenChange={setShowAddProduct}
      />
    </div>
  );
};

export default Cook;