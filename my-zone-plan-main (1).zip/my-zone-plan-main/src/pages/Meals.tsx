import { useState, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Plus, Search, ChefHat, Settings, Trash2, Calendar, Eye } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { EditDishDialog } from '@/components/meals/EditDishDialog';
import { AddDishToCalendarDialog } from '@/components/meals/AddDishToCalendarDialog';
import { useSubscription } from '@/hooks/useSubscription';
import { useAuth } from '@/hooks/useAuth';
import { ZoneIndicator } from '@/components/ui/zone-indicator';
import { useZoneCalculation } from '@/hooks/useZoneCalculation';
import { useFeatureFlags } from '@/hooks/useFeatureFlags';
import { AddDishDialog } from '@/components/meals/AddDishDialog';

interface Dish {
  id: string;
  name: string;
  description?: string;
  image_url?: string;
  created_at: string;
  dish_ingredients: Array<{
    grams: number;
    products: {
      id: string;
      name: string;
      protein_per_100g: number;
      carbs_per_100g: number;
      fat_per_100g: number;
      fiber_per_100g: number;
      calories_per_100g: number;
    };
  }>;
}

const Meals = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [editDialog, setEditDialog] = useState<{ open: boolean; dish: Dish | null }>({ open: false, dish: null });
  const [addToCalendarDialog, setAddToCalendarDialog] = useState<{ open: boolean; dish: Dish | null }>({ open: false, dish: null });
  const { isPro } = useSubscription();
  const { user } = useAuth();
  const [showAddDish, setShowAddDish] = useState(false);
  const { calculateZoneBlocks } = useZoneCalculation();
  const { isZoneEnabled } = useFeatureFlags();
  const queryClient = useQueryClient();

  // Fetch dishes
  const { data: dishes = [], isLoading } = useQuery({
    queryKey: ['dishes'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data, error } = await supabase
        .from('dishes')
        .select(`
          *,
          dish_ingredients (
            grams,
            products (
              id,
              name,
              protein_per_100g,
              carbs_per_100g,
              fat_per_100g,
              fiber_per_100g,
              calories_per_100g
            )
          )
        `)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    }
  });

  // Calculate nutrition for a dish
  const calculateNutrition = (dish: Dish) => {
    return dish.dish_ingredients?.reduce(
      (total, ingredient) => {
        const product = ingredient.products;
        const ratio = ingredient.grams / 100;
        return {
          calories: total.calories + (product.calories_per_100g * ratio),
          protein: total.protein + (product.protein_per_100g * ratio),
          carbs: total.carbs + (product.carbs_per_100g * ratio),
          fat: total.fat + (product.fat_per_100g * ratio),
          fiber: total.fiber + (product.fiber_per_100g * ratio),
        };
      },
      { calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 }
    ) || { calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 };
  };

  // Using shared useZoneCalculation for Zone blocks

  const mealTypeLabels = {
    breakfast: 'Закуска',
    lunch: 'Обяд',
    dinner: 'Вечеря',
    snack: 'Междинно'
  } as const;

  // Delete dish mutation
  const deleteDishMutation = useMutation({
    mutationFn: async (dishId: string) => {
      const { error } = await supabase
        .from('dishes')
        .delete()
        .eq('id', dishId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dishes'] });
      toast.success('Ястието е изтрито успешно!');
    },
    onError: () => {
      toast.error('Грешка при изтриване на ястието');
    }
  });

  const filteredMeals = useMemo(() => {
    return dishes.filter(dish => {
      const matchesSearch = dish.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           (dish.description && dish.description.toLowerCase().includes(searchTerm.toLowerCase()));
      return matchesSearch;
    });
  }, [dishes, searchTerm]);

  return (
    <div className="container mx-auto px-6 py-8 space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-foreground">Ястия</h1>
        <Button 
          onClick={() => setShowAddDish(true)}
          size="sm"
          className="flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Ново ястие
        </Button>
      </div>

      {/* Search */}
      <div className="relative w-full">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
        <Input
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Търси ястия..."
          className="pl-10"
        />
      </div>

      {/* Dishes Grid */}
      {isLoading ? (
        <div className="text-center py-8">
          <p className="text-muted-foreground">Зареждане...</p>
        </div>
      ) : filteredMeals.length === 0 ? (
        <Card>
          <CardContent className="text-center py-16">
            <ChefHat className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
            <CardTitle className="text-xl mb-2">Няма ястия</CardTitle>
            <CardDescription className="mb-6 max-w-sm mx-auto">
              Създайте първото си ястие, за да започнете готвенето
            </CardDescription>
            <Button onClick={() => setShowAddDish(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Създай ястие
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredMeals.map(dish => {
            const nutrition = calculateNutrition(dish);
            const zoneData = calculateZoneBlocks(nutrition as any);

            return (
              <Card key={dish.id} className="h-full hover:shadow-md transition-shadow overflow-hidden group cursor-pointer animate-fade-in relative flex flex-col">
                <div className="w-full h-40 md:h-48 bg-gradient-to-br from-muted to-muted/50 flex items-center justify-center relative overflow-hidden">
                  {(dish as any).image_url ? (
                    <img 
                      src={(dish as any).image_url} 
                      alt={dish.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <ChefHat className="w-16 h-16 text-muted-foreground/50" />
                  )}
                  <Badge 
                    variant="outline" 
                    className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm border-white/20"
                  >
                    {mealTypeLabels[(dish as any).meal_type as keyof typeof mealTypeLabels] || 'Хранене'}
                  </Badge>
                  {(dish as any).is_public && (
                    <Badge 
                      variant="secondary" 
                      className="absolute bottom-3 left-3 bg-white/90 text-foreground border-0"
                    >
                      <Eye className="w-3 h-3 mr-1" />
                      Публично
                    </Badge>
                  )}
                  <div className="absolute top-2 right-2 z-10 flex gap-1">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="h-8 w-8 p-0 bg-white/80 hover:bg-white hover:text-primary border border-white/20 backdrop-blur-sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        setEditDialog({ open: true, dish });
                      }}
                    >
                      <Settings className="w-4 h-4" />
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-8 w-8 p-0 bg-white/80 hover:bg-white hover:text-destructive border border-white/20 backdrop-blur-sm"
                          onClick={(e) => e.stopPropagation()}
                          disabled={false}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Изтриване на ястие</AlertDialogTitle>
                          <AlertDialogDescription>
                            Сигурни ли сте, че искате да изтриете "{dish.name}"?
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Отказ</AlertDialogCancel>
                          <AlertDialogAction onClick={() => deleteDishMutation.mutate(dish.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                            Изтрий
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>

                <CardHeader className="pb-2 px-3 pt-3">
                  <div className="space-y-2">
                    <CardTitle className="text-base md:text-lg leading-tight font-semibold line-clamp-2">
                      {dish.name}
                    </CardTitle>
                    {dish.description && (
                      <CardDescription className="text-sm line-clamp-2">
                        {dish.description}
                      </CardDescription>
                    )}
                  </div>
                </CardHeader>
                
                <CardContent className="pt-0 px-3 pb-3 space-y-3 flex-1 flex flex-col">
                  {/* Calories highlight */}
                  <div className="text-center py-2 bg-gradient-to-r from-primary/5 via-primary/10 to-primary/5 rounded-lg border border-primary/20">
                    <div className="text-xl md:text-2xl font-bold text-primary">{Math.round(nutrition.calories)}</div>
                    <div className="text-xs text-muted-foreground font-medium">калории общо</div>
                  </div>
                  
                  {/* Macros grid */}
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div className="space-y-1">
                      <div className="text-sm md:text-lg font-semibold text-green-600">{nutrition.protein.toFixed(1)}г</div>
                      <div className="text-xs text-muted-foreground">Протеин</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-sm md:text-lg font-semibold text-blue-600">{nutrition.carbs.toFixed(1)}г</div>
                      <div className="text-xs text-muted-foreground">Въглехидр.</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-sm md:text-lg font-semibold text-orange-600">{nutrition.fat.toFixed(1)}г</div>
                      <div className="text-xs text-muted-foreground">Мазнини</div>
                    </div>
                  </div>
  
                  {/* Zone blocks with circles and status colors */}
                  {isZoneEnabled && (
                    <ZoneIndicator 
                      zoneData={zoneData}
                      compact={true}
                      className="justify-center"
                    />
                  )}
                  
                  {/* Add to calendar button */}
                  <div className="mt-auto">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full border-primary/30 hover:bg-primary hover:text-primary-foreground transition-all duration-200"
                      onClick={(e) => {
                        e.stopPropagation();
                        setAddToCalendarDialog({ open: true, dish });
                      }}
                    >
                      <Calendar className="w-4 h-4 mr-2" />
                      Добави в календар
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <EditDishDialog
        open={editDialog.open}
        onOpenChange={(open) => setEditDialog({ open, dish: null })}
        dish={editDialog.dish}
      />

      <AddDishToCalendarDialog
        open={addToCalendarDialog.open}
        onOpenChange={(open) => setAddToCalendarDialog({ open, dish: null })}
        dish={addToCalendarDialog.dish}
        isPro={isPro}
      />

      <AddDishDialog open={showAddDish} onOpenChange={setShowAddDish} />
    </div>
  );
};

export default Meals;
