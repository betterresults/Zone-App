import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Trash2, Search, Eye, EyeOff, Download, Upload, FileDown } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Navigate } from 'react-router-dom';

interface Product {
  id: string;
  name: string;
  brand?: string;
  category: string;
  calories_per_100g: number;
  protein_per_100g: number;
  carbs_per_100g: number;
  fat_per_100g: number;
  fiber_per_100g: number;
  is_public: boolean;
  user_id?: string;
  created_at: string;
  image_url?: string;
  profiles?: {
    display_name?: string;
    email?: string;
  };
}

const AdminProducts = () => {
  const { toast } = useToast();
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUser, setSelectedUser] = useState<string>('all');
  const [activeTab, setActiveTab] = useState<'our' | 'user'>('our');
  const [users, setUsers] = useState<{id: string, display_name: string, email: string}[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isImporting, setIsImporting] = useState(false);

  useEffect(() => {
    loadProducts();
  }, []);

  useEffect(() => {
    if (activeTab === 'our') {
      // Show only public products
      let filtered = products.filter(product => product.is_public);
      if (searchTerm) {
        filtered = filtered.filter(product =>
          product.name.toLowerCase().includes(searchTerm.toLowerCase())
        );
      }
      setFilteredProducts(filtered);
    } else {
      // Show user products with filtering
      let filtered = products.filter(product => !product.is_public || product.user_id);
      if (searchTerm) {
        filtered = filtered.filter(product =>
          product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          product.profiles?.display_name?.toLowerCase().includes(searchTerm.toLowerCase())
        );
      }
      if (selectedUser !== 'all') {
        filtered = filtered.filter(product => product.user_id === selectedUser);
      }
      setFilteredProducts(filtered);
    }
  }, [searchTerm, selectedUser, activeTab, products]);

  const loadProducts = async () => {
    try {
      setIsLoading(true);
      // Load all products (admin can see everything)
      const { data, error } = await supabase
        .from('products')
        .select(`
          *
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Get user profiles and unique users
      if (data && data.length > 0) {
        const userIds = [...new Set(data.filter(p => p.user_id).map(p => p.user_id))];
        
        if (userIds.length > 0) {
          const { data: profilesData } = await supabase
            .from('profiles')
            .select('user_id, display_name, email')
            .in('user_id', userIds);

          // Merge profiles data with products  
          const productsWithProfiles = data.map(product => ({
            ...product,
            profiles: product.user_id ? profilesData?.find(p => p.user_id === product.user_id) : null
          }));
          
          setProducts(productsWithProfiles as Product[]);
          
          // Set unique users for filter
          const uniqueUsers = profilesData?.map(profile => ({
            id: profile.user_id,
            display_name: profile.display_name || profile.email || 'Неизвестен',
            email: profile.email || ''
          })) || [];
          setUsers(uniqueUsers);
        } else {
          setProducts(data as Product[]);
          setUsers([]);
        }
      } else {
        setProducts([]);
        setUsers([]);
      }
    } catch (error) {
      console.error('Error loading products:', error);
      toast({
        title: 'Грешка',
        description: 'Неуспешно зареждане на продуктите',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const toggleProductVisibility = async (productId: string, isPublic: boolean) => {
    try {
      const { error } = await supabase
        .from('products')
        .update({ is_public: !isPublic })
        .eq('id', productId);

      if (error) throw error;

      toast({
        title: 'Успех',
        description: `Продуктът е ${!isPublic ? 'публикуван' : 'скрит'} успешно`
      });

      loadProducts();
    } catch (error) {
      console.error('Error toggling product visibility:', error);
      toast({
        title: 'Грешка',
        description: 'Неуспешна промяна на видимостта',
        variant: 'destructive'
      });
    }
  };

  const deleteProduct = async (productId: string) => {
    try {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', productId);

      if (error) throw error;

      toast({
        title: 'Успех',
        description: 'Продуктът е изтрит успешно'
      });

      loadProducts();
    } catch (error) {
      console.error('Error deleting product:', error);
      toast({
        title: 'Грешка',
        description: 'Неуспешно изтриване на продукта',
        variant: 'destructive'
      });
    }
  };

  const exportProducts = () => {
    const csvHeaders = [
      'name', 'brand', 'category', 'calories_per_100g', 
      'protein_per_100g', 'carbs_per_100g', 'fat_per_100g', 
      'fiber_per_100g', 'is_public', 'image_url'
    ].join(',');

    const csvRows = products.map(product => [
      `"${product.name}"`,
      `"${product.brand || ''}"`,
      `"${product.category}"`,
      product.calories_per_100g,
      product.protein_per_100g,
      product.carbs_per_100g,
      product.fat_per_100g,
      product.fiber_per_100g,
      product.is_public,
      `"${product.image_url || ''}"`
    ].join(','));

    const csvContent = [csvHeaders, ...csvRows].join('\n');
    
    // Add BOM for proper UTF-8 encoding in Excel
    const BOM = '\uFEFF';
    const blob = new Blob([BOM + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `products_${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }

    toast({
      title: 'Успех',
      description: `Експортирани ${products.length} продукта в CSV файл`
    });
  };

  const downloadSampleCsv = () => {
    const sampleData = [
      ['name', 'brand', 'category', 'calories_per_100g', 'protein_per_100g', 'carbs_per_100g', 'fat_per_100g', 'fiber_per_100g', 'is_public', 'image_url'],
      ['"Краве мляко"', '"Верея"', '"dairy"', '64', '3.2', '4.8', '3.6', '0', 'true', '"https://example.com/milk.jpg"'],
      ['"Овесени ядки"', '"Ечемик"', '"grains"', '389', '16.9', '66.3', '6.9', '10.6', 'true', '"https://example.com/oats.jpg"'],
      ['"Пилешко филе"', '""', '"meat"', '165', '31', '0', '3.6', '0', 'false', '"https://example.com/chicken.jpg"']
    ];

    const csvContent = sampleData.map(row => row.join(',')).join('\n');
    // Add BOM for proper UTF-8 encoding in Excel
    const BOM = '\uFEFF';
    const blob = new Blob([BOM + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', 'sample_products.csv');
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }

    toast({
      title: 'Успех',
      description: 'Примерният CSV файл е изтеглен'
    });
  };

  const handleFileImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.csv')) {
      toast({
        title: 'Грешка',
        description: 'Моля изберете CSV файл',
        variant: 'destructive'
      });
      return;
    }

    try {
      setIsImporting(true);
      
      const text = await file.text();
      
      const { data, error } = await supabase.functions.invoke('bulk-import-products', {
        body: { csvData: text }
      });

      if (error) throw error;

      toast({
        title: 'Успех',
        description: data.message || `Импортирани ${data.imported} продукта`
      });

      loadProducts();
      
      // Reset file input
      event.target.value = '';
      
    } catch (error) {
      console.error('Import error:', error);
      toast({
        title: 'Грешка',
        description: error.message || 'Неуспешен импорт на продуктите',
        variant: 'destructive'
      });
    } finally {
      setIsImporting(false);
    }
  };


  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Всички продукти</h1>
          <p className="text-muted-foreground">Управление на всички продукти в системата</p>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={downloadSampleCsv} variant="outline" size="sm">
            <FileDown className="w-4 h-4 mr-2" />
            Примерен CSV
          </Button>
          <Button onClick={exportProducts} variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Експорт CSV
          </Button>
          <div className="relative">
            <input
              type="file"
              accept=".csv"
              onChange={handleFileImport}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              disabled={isImporting}
            />
            <Button variant="default" size="sm" disabled={isImporting}>
              <Upload className="w-4 h-4 mr-2" />
              {isImporting ? 'Импортиране...' : 'Импорт CSV'}
            </Button>
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as 'our' | 'user')} className="space-y-6">
        <TabsList>
          <TabsTrigger value="our">Нашите продукти</TabsTrigger>
          <TabsTrigger value="user">Потребителски продукти</TabsTrigger>
        </TabsList>

        <TabsContent value="our" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Търсене</CardTitle>
              <CardDescription>Намерете конкретен продукт от нашите</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-2">
                <Search className="w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Търсене по име..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="max-w-sm"
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Нашите продукти ({filteredProducts.length})</CardTitle>
              <CardDescription>
                Публични продукти в системата
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="text-center py-8">Зареждане на продуктите...</div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Снимка</TableHead>
                        <TableHead>Име</TableHead>
                        <TableHead>Категория</TableHead>
                        <TableHead>Калории/100г</TableHead>
                        <TableHead>Дата</TableHead>
                        <TableHead>Действия</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredProducts.map((product) => (
                        <TableRow key={product.id}>
                          <TableCell>
                            {product.image_url ? (
                              <img 
                                src={product.image_url} 
                                alt={product.name}
                                className="w-12 h-12 object-cover rounded-md"
                                onError={(e) => {
                                  e.currentTarget.style.display = 'none';
                                }}
                              />
                            ) : (
                              <div className="w-12 h-12 bg-muted rounded-md flex items-center justify-center text-muted-foreground text-xs">
                                Няма
                              </div>
                            )}
                          </TableCell>
                          <TableCell className="font-medium">{product.name}</TableCell>
                          <TableCell>{product.category}</TableCell>
                          <TableCell>{product.calories_per_100g}</TableCell>
                          <TableCell>
                            {new Date(product.created_at).toLocaleDateString('bg-BG')}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center space-x-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => toggleProductVisibility(product.id, product.is_public)}
                              >
                                {product.is_public ? (
                                  <EyeOff className="w-4 h-4" />
                                ) : (
                                  <Eye className="w-4 h-4" />
                                )}
                              </Button>
                              
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button size="sm" variant="destructive">
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Изтриване на продукт</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Сигурни ли сте, че искате да изтриете "{product.name}"? 
                                      Това действие не може да бъде отменено.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Отказ</AlertDialogCancel>
                                    <AlertDialogAction onClick={() => deleteProduct(product.id)}>
                                      Изтрий
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                  
                  {filteredProducts.length === 0 && !isLoading && (
                    <div className="text-center py-8 text-muted-foreground">
                      {searchTerm ? 'Няма намерени продукти' : 'Няма публични продукти'}
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="user" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Търсене и филтриране</CardTitle>
              <CardDescription>Намерете продукти по потребител</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <Search className="w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Търсене по име..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="max-w-sm"
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <label className="text-sm font-medium">Потребител:</label>
                  <select
                    value={selectedUser}
                    onChange={(e) => setSelectedUser(e.target.value)}
                    className="px-3 py-2 border rounded-md bg-background"
                  >
                    <option value="all">Всички потребители</option>
                    {users.map(user => (
                      <option key={user.id} value={user.id}>
                        {user.display_name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Потребителски продукти ({filteredProducts.length})</CardTitle>
              <CardDescription>
                Продукти създадени от потребители
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="text-center py-8">Зареждане на продуктите...</div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Снимка</TableHead>
                        <TableHead>Име</TableHead>
                        <TableHead>Категория</TableHead>
                        <TableHead>Калории/100г</TableHead>
                        <TableHead>Създател</TableHead>
                        <TableHead>Статус</TableHead>
                        <TableHead>Дата</TableHead>
                        <TableHead>Действия</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredProducts.map((product) => (
                        <TableRow key={product.id}>
                          <TableCell>
                            {product.image_url ? (
                              <img 
                                src={product.image_url} 
                                alt={product.name}
                                className="w-12 h-12 object-cover rounded-md"
                                onError={(e) => {
                                  e.currentTarget.style.display = 'none';
                                }}
                              />
                            ) : (
                              <div className="w-12 h-12 bg-muted rounded-md flex items-center justify-center text-muted-foreground text-xs">
                                Няма
                              </div>
                            )}
                          </TableCell>
                          <TableCell className="font-medium">{product.name}</TableCell>
                          <TableCell>{product.category}</TableCell>
                          <TableCell>{product.calories_per_100g}</TableCell>
                          <TableCell>
                            {product.profiles?.display_name || product.profiles?.email || 'Неизвестен'}
                          </TableCell>
                          <TableCell>
                            <Badge variant={product.is_public ? 'default' : 'secondary'}>
                              {product.is_public ? 'Публичен' : 'Личен'}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {new Date(product.created_at).toLocaleDateString('bg-BG')}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center space-x-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => toggleProductVisibility(product.id, product.is_public)}
                              >
                                {product.is_public ? (
                                  <EyeOff className="w-4 h-4" />
                                ) : (
                                  <Eye className="w-4 h-4" />
                                )}
                              </Button>
                              
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button size="sm" variant="destructive">
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Изтриване на продукт</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Сигурни ли сте, че искате да изтриете "{product.name}"? 
                                      Това действие не може да бъде отменено.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Отказ</AlertDialogCancel>
                                    <AlertDialogAction onClick={() => deleteProduct(product.id)}>
                                      Изтрий
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                  
                  {filteredProducts.length === 0 && !isLoading && (
                    <div className="text-center py-8 text-muted-foreground">
                      {searchTerm || selectedUser !== 'all' ? 'Няма намерени продукти' : 'Няма потребителски продукти'}
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminProducts;