import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Trash2, Search, Eye, EyeOff } from 'lucide-react';
import { useAdmin } from '@/hooks/useAdmin';
import { Navigate } from 'react-router-dom';

interface Recipe {
  id: string;
  name: string;
  description?: string;
  meal_type: string;
  servings: number;
  is_public: boolean;
  user_id: string;
  created_at: string;
  profiles?: {
    display_name?: string;
    email?: string;
  };
}

const AdminRecipes = () => {
  const { isAdmin, loading } = useAdmin();
  const { toast } = useToast();
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [filteredRecipes, setFilteredRecipes] = useState<Recipe[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (isAdmin) {
      loadRecipes();
    }
  }, [isAdmin]);

  useEffect(() => {
    if (searchTerm) {
      const filtered = recipes.filter(recipe =>
        recipe.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        recipe.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        recipe.profiles?.display_name?.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredRecipes(filtered);
    } else {
      setFilteredRecipes(recipes);
    }
  }, [searchTerm, recipes]);

  const loadRecipes = async () => {
    try {
      setIsLoading(true);
      // Since there's no direct relation, we need to manually join via user_id
      const { data, error } = await supabase
        .from('recipes')
        .select(`*`)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Get user profiles separately
      if (data && data.length > 0) {
        const userIds = [...new Set(data.map(r => r.user_id))];
        
        const { data: profilesData } = await supabase
          .from('profiles')
          .select('user_id, display_name, email')
          .in('user_id', userIds);

        // Merge profiles data with recipes  
        const recipesWithProfiles = data.map(recipe => ({
          ...recipe,
          profiles: profilesData?.find(p => p.user_id === recipe.user_id)
        }));
        
        setRecipes(recipesWithProfiles as Recipe[]);
      } else {
        setRecipes([]);
      }
    } catch (error) {
      console.error('Error loading recipes:', error);
      toast({
        title: 'Грешка',
        description: 'Неуспешно зареждане на рецептите',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const toggleRecipeVisibility = async (recipeId: string, isPublic: boolean) => {
    try {
      const { error } = await supabase
        .from('recipes')
        .update({ is_public: !isPublic })
        .eq('id', recipeId);

      if (error) throw error;

      toast({
        title: 'Успех',
        description: `Рецептата е ${!isPublic ? 'публикувана' : 'скрита'} успешно`
      });

      loadRecipes();
    } catch (error) {
      console.error('Error toggling recipe visibility:', error);
      toast({
        title: 'Грешка',
        description: 'Неуспешна промяна на видимостта',
        variant: 'destructive'
      });
    }
  };

  const deleteRecipe = async (recipeId: string) => {
    try {
      const { error } = await supabase
        .from('recipes')
        .delete()
        .eq('id', recipeId);

      if (error) throw error;

      toast({
        title: 'Успех',
        description: 'Рецептата е изтрита успешно'
      });

      loadRecipes();
    } catch (error) {
      console.error('Error deleting recipe:', error);
      toast({
        title: 'Грешка',
        description: 'Неуспешно изтриване на рецептата',
        variant: 'destructive'
      });
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">Зареждане...</div>;
  }

  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-destructive mb-4">Достъп отказан</h1>
          <p className="text-muted-foreground">Нямате права за достъп до тази страница.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Всички рецепти</h1>
          <p className="text-muted-foreground">Управление на всички рецепти в системата</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Търсене и филтриране</CardTitle>
          <CardDescription>Намерете конкретна рецепта</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2">
            <Search className="w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Търсене по име, описание или създател..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Рецепти ({filteredRecipes.length})</CardTitle>
          <CardDescription>
            Общо {recipes.length} рецепти в системата
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">Зареждане на рецептите...</div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Име</TableHead>
                    <TableHead>Описание</TableHead>
                    <TableHead>Тип ястие</TableHead>
                    <TableHead>Порции</TableHead>
                    <TableHead>Създател</TableHead>
                    <TableHead>Статус</TableHead>
                    <TableHead>Дата</TableHead>
                    <TableHead>Действия</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRecipes.map((recipe) => (
                    <TableRow key={recipe.id}>
                      <TableCell className="font-medium">{recipe.name}</TableCell>
                      <TableCell className="max-w-xs truncate">
                        {recipe.description || '-'}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {recipe.meal_type === 'breakfast' ? 'Закуска' :
                           recipe.meal_type === 'lunch' ? 'Обяд' :
                           recipe.meal_type === 'dinner' ? 'Вечеря' : 'Закуска'}
                        </Badge>
                      </TableCell>
                      <TableCell>{recipe.servings}</TableCell>
                      <TableCell>
                        {recipe.profiles?.display_name || recipe.profiles?.email || 'Неизвестен'}
                      </TableCell>
                      <TableCell>
                        <Badge variant={recipe.is_public ? 'default' : 'secondary'}>
                          {recipe.is_public ? 'Публична' : 'Лична'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {new Date(recipe.created_at).toLocaleDateString('bg-BG')}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => toggleRecipeVisibility(recipe.id, recipe.is_public)}
                          >
                            {recipe.is_public ? (
                              <EyeOff className="w-4 h-4" />
                            ) : (
                              <Eye className="w-4 h-4" />
                            )}
                          </Button>
                          
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button size="sm" variant="destructive">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Изтриване на рецепта</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Сигурни ли сте, че искате да изтриете "{recipe.name}"? 
                                  Това действие не може да бъде отменено.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Отказ</AlertDialogCancel>
                                <AlertDialogAction onClick={() => deleteRecipe(recipe.id)}>
                                  Изтрий
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              
              {filteredRecipes.length === 0 && !isLoading && (
                <div className="text-center py-8 text-muted-foreground">
                  {searchTerm ? 'Няма намерени рецепти' : 'Няма добавени рецепти'}
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminRecipes;