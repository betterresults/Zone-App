import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { ThumbsUp, ThumbsDown, Bug, Lightbulb, MessageSquare, User } from 'lucide-react';

interface FeedbackRecord {
  id: string;
  user_id: string;
  feedback_type: string;
  category: string | null;
  title: string;
  description: string;
  status: string;
  priority: string;
  admin_notes: string | null;
  created_at: string;
  updated_at: string;
  profiles: {
    display_name: string;
    email: string;
  } | null;
}

type FeedbackStatus = 'new' | 'in_progress' | 'resolved' | 'closed';
type FeedbackPriority = 'low' | 'medium' | 'high' | 'critical';

const AdminFeedback = () => {
  const [feedback, setFeedback] = useState<FeedbackRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedFeedback, setSelectedFeedback] = useState<FeedbackRecord | null>(null);
  const [adminNotes, setAdminNotes] = useState('');
  const [status, setStatus] = useState<FeedbackStatus>('new');
  const [priority, setPriority] = useState<FeedbackPriority>('medium');
  const { toast } = useToast();

  const feedbackTypes = {
    'like': { label: 'Харесва', icon: ThumbsUp, color: 'bg-green-500' },
    'dislike': { label: 'Не харесва', icon: ThumbsDown, color: 'bg-red-500' },
    'bug': { label: 'Бъг', icon: Bug, color: 'bg-orange-500' },
    'improvement': { label: 'Подобрение', icon: Lightbulb, color: 'bg-blue-500' },
    'other': { label: 'Друго', icon: MessageSquare, color: 'bg-purple-500' }
  };

  const statusLabels = {
    'new': { label: 'Ново', color: 'bg-blue-500', description: 'Ново съобщение, което не е прегледано' },
    'in_progress': { label: 'В процес', color: 'bg-yellow-500', description: 'Работи се по съобщението' },
    'resolved': { label: 'Решено', color: 'bg-green-500', description: 'Съобщението е решено успешно' },
    'closed': { label: 'Затворено', color: 'bg-gray-500', description: 'Съобщението е затворено без действие' }
  };

  const priorityLabels = {
    'low': { label: 'Нисък', color: 'bg-gray-400', description: 'Ниска важност' },
    'medium': { label: 'Среден', color: 'bg-yellow-500', description: 'Средна важност' },
    'high': { label: 'Висок', color: 'bg-orange-500', description: 'Висока важност' },
    'critical': { label: 'Критичен', color: 'bg-red-600', description: 'Критична важност' }
  };

  const fetchFeedback = async () => {
    setLoading(true);
    try {
      // First get all feedback
      const { data: feedbackData, error: feedbackError } = await supabase
        .from('beta_feedback')
        .select('*')
        .order('created_at', { ascending: false });

      if (feedbackError) {
        console.error('Error fetching feedback:', feedbackError);
        return;
      }

      // Get unique user IDs
      const userIds = [...new Set(feedbackData?.map(f => f.user_id) || [])];
      
      // Get profiles for these users
      const { data: profilesData, error: profilesError } = await supabase
        .from('profiles')
        .select('user_id, display_name, email')
        .in('user_id', userIds);

      if (profilesError) {
        console.error('Error fetching profiles:', profilesError);
      }

      // Map profiles to feedback
      const profilesMap = (profilesData || []).reduce((acc, profile) => {
        acc[profile.user_id] = profile;
        return acc;
      }, {} as Record<string, any>);

      const enrichedFeedback = (feedbackData || []).map(feedback => ({
        ...feedback,
        profiles: profilesMap[feedback.user_id] || null
      }));

      setFeedback(enrichedFeedback);
    } catch (error) {
      console.error('Error fetching feedback:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateFeedback = async () => {
    if (!selectedFeedback) return;

    try {
      // Check what changes are being made
      const oldStatus = selectedFeedback.status;
      const oldAdminNotes = selectedFeedback.admin_notes;
      const hasStatusChange = oldStatus !== status;
      const hasNewAdminResponse = adminNotes && adminNotes !== oldAdminNotes;

      const { error } = await supabase
        .from('beta_feedback')
        .update({
          status: status as FeedbackStatus,
          priority: priority as FeedbackPriority,
          admin_notes: adminNotes || selectedFeedback.admin_notes
        })
        .eq('id', selectedFeedback.id);

      if (error) {
        toast({
          title: "Грешка",
          description: "Възникна проблем при обновяването.",
          variant: "destructive"
        });
        return;
      }

      // Send notification if there's a status change or new admin response
      if (hasStatusChange || hasNewAdminResponse) {
        try {
          const { error: notificationError } = await supabase.functions.invoke('send-feedback-notification', {
            body: {
              feedback_id: selectedFeedback.id,
              status_change: hasStatusChange,
              admin_response: hasNewAdminResponse,
              new_status: status
            }
          });

          if (notificationError) {
            console.error('Error sending notification:', notificationError);
            // Don't fail the update if notification fails
          }
        } catch (notificationError) {
          console.error('Error sending notification:', notificationError);
          // Continue with the update even if notification fails
        }
      }

      toast({
        title: "Успех",
        description: "Съобщението беше обновено."
      });

      setSelectedFeedback(null);
      setAdminNotes('');
      setStatus('new');
      setPriority('medium');
      fetchFeedback();
    } catch (error) {
      console.error('Error updating feedback:', error);
    }
  };

  const openEditModal = (item: FeedbackRecord) => {
    setSelectedFeedback(item);
    setAdminNotes(item.admin_notes || '');
    setStatus(item.status as FeedbackStatus);
    setPriority(item.priority as FeedbackPriority);
  };

  useEffect(() => {
    fetchFeedback();
    
    // Set up realtime subscription
    const channel = supabase
      .channel('schema-db-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'beta_feedback'
        },
        () => {
          fetchFeedback(); // Refresh data when changes occur
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  if (loading) {
    return (
      <div className="container mx-auto py-8 px-4">
        <div className="text-center">Зареждане...</div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">Управление на съобщения</h1>
        <p className="text-muted-foreground">
          Преглед и управление на съобщенията от бета тестерите
        </p>
        <div className="mt-4 flex gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
            <span>Нови: {feedback.filter(f => f.status === 'new').length}</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
            <span>В процес: {feedback.filter(f => f.status === 'in_progress').length}</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span>Решени: {feedback.filter(f => f.status === 'resolved').length}</span>
          </div>
        </div>
      </div>

      <div className="grid gap-6">
        {feedback.length === 0 ? (
          <Card>
            <CardContent className="text-center py-8">
              <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p className="text-muted-foreground">Няма съобщения за показване</p>
            </CardContent>
          </Card>
        ) : (
          feedback.map((item) => {
            const typeInfo = feedbackTypes[item.feedback_type as keyof typeof feedbackTypes];
            const statusInfo = statusLabels[item.status as keyof typeof statusLabels];
            const priorityInfo = priorityLabels[item.priority as keyof typeof priorityLabels];

            return (
              <Card key={item.id} className="shadow-sm hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-2 flex-1">
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-full ${typeInfo.color} flex items-center justify-center`}>
                          <typeInfo.icon className="w-4 h-4 text-white" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{item.title}</CardTitle>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                            <User className="w-4 h-4" />
                            <span>{item.profiles?.display_name || item.profiles?.email || 'Непознат потребител'}</span>
                            <span>•</span>
                            <span>{new Date(item.created_at).toLocaleDateString('bg-BG', {
                              year: 'numeric',
                              month: 'long',
                              day: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit'
                            })}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-col gap-2">
                      <Badge variant="outline" className={`text-white ${statusInfo.color} px-3 py-1`}>
                        {statusInfo.label}
                      </Badge>
                      <Badge variant="outline" className={`text-white ${priorityInfo.color} px-2 py-1 text-xs`}>
                        {priorityInfo.label}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex gap-2">
                      <Badge variant="secondary" className="text-xs">
                        {typeInfo.label}
                      </Badge>
                      {item.category && (
                        <Badge variant="outline" className="text-xs">
                          {item.category}
                        </Badge>
                      )}
                    </div>
                    
                    <div className="p-4 bg-muted/30 rounded-lg">
                      <p className="text-sm leading-relaxed">{item.description}</p>
                    </div>
                    
                    {item.admin_notes && (
                      <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <MessageSquare className="w-4 h-4 text-primary" />
                          <strong className="text-primary text-sm">Отговор от администратора:</strong>
                        </div>
                        <p className="text-sm leading-relaxed">{item.admin_notes}</p>
                      </div>
                    )}
                    
                    <div className="flex justify-between items-center pt-2 border-t">
                      <div className="text-xs text-muted-foreground">
                        {item.status === 'new' && '🔵 Очаква преглед'}
                        {item.status === 'in_progress' && '🟡 В процес на работа'}
                        {item.status === 'resolved' && '🟢 Успешно решено'}
                        {item.status === 'closed' && '⚫ Затворено'}
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openEditModal(item)}
                        className="h-8 px-3"
                      >
                        Управлявай
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      {/* Edit Modal */}
      {selectedFeedback && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <CardHeader>
              <CardTitle>Управление на съобщение</CardTitle>
              <CardDescription className="space-y-2">
                <div className="font-medium">{selectedFeedback.title}</div>
                <div className="text-xs">
                  От: {selectedFeedback.profiles?.display_name || selectedFeedback.profiles?.email || 'Непознат потребител'}
                  • {new Date(selectedFeedback.created_at).toLocaleDateString('bg-BG')}
                </div>
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Original message */}
              <div className="p-4 bg-muted/50 rounded-lg">
                <h4 className="font-medium mb-2">Съобщение от потребителя:</h4>
                <p className="text-sm leading-relaxed">{selectedFeedback.description}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Статус</label>
                  <Select value={status} onValueChange={(value: FeedbackStatus) => setStatus(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(statusLabels).map(([key, info]) => (
                        <SelectItem key={key} value={key}>
                          <div className="flex items-center gap-2">
                            <div className={`w-3 h-3 rounded-full ${info.color}`}></div>
                            <span>{info.label}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    {statusLabels[status]?.description}
                  </p>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Приоритет</label>
                  <Select value={priority} onValueChange={(value: FeedbackPriority) => setPriority(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(priorityLabels).map(([key, info]) => (
                        <SelectItem key={key} value={key}>
                          <div className="flex items-center gap-2">
                            <div className={`w-3 h-3 rounded-full ${info.color}`}></div>
                            <span>{info.label}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    {priorityLabels[priority]?.description}
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Отговор и бележки</label>
                <Textarea
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  placeholder="Напишете отговор към потребителя или бележки за вътрешно ползване..."
                  rows={4}
                  className="resize-none"
                />
                <p className="text-xs text-muted-foreground">
                  Този текст ще бъде виден от потребителя като отговор от екипа.
                </p>
              </div>

              <div className="flex gap-3 justify-end pt-4 border-t">
                <Button
                  variant="outline"
                  onClick={() => {
                    setSelectedFeedback(null);
                    setAdminNotes('');
                    setStatus('new');
                    setPriority('medium');
                  }}
                >
                  Отказ
                </Button>
                <Button 
                  onClick={updateFeedback}
                  className="min-w-[100px]"
                >
                  Запази промените
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default AdminFeedback;