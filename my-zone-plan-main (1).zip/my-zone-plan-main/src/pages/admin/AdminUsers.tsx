import { useEffect, useState } from 'react';
import { useAdmin, type UserProfile } from '@/hooks/useAdmin';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { 
  Ban, 
  CheckCircle, 
  UserPlus, 
  UserMinus, 
  Trash2, 
  Edit,
  Crown,
  Search,
  User,
  Shield,
  Clock,
  XCircle,
  Calendar,
  CreditCard,
  FlaskConical,
  Mail
} from 'lucide-react';
import { Navigate } from 'react-router-dom';
import { SendEmailDialog } from '@/components/admin/SendEmailDialog';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

const AdminUsers = () => {
  const { 
    isAdmin, 
    loading, 
    users, 
    loadUsers, 
    blockUser, 
    unblockUser, 
    makeAdmin, 
    removeAdmin, 
    deleteUser, 
    updateUserProfile,
    updateSubscription,
    cancelSubscription
  } = useAdmin();

  const [searchTerm, setSearchTerm] = useState('');
  const [filteredUsers, setFilteredUsers] = useState<UserProfile[]>([]);
  const [editingUser, setEditingUser] = useState<UserProfile | null>(null);
  const [blockReason, setBlockReason] = useState('');
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [managingSubscription, setManagingSubscription] = useState<UserProfile | null>(null);

  useEffect(() => {
    if (isAdmin) {
      loadUsers();
    }
  }, [isAdmin, loadUsers]);

  useEffect(() => {
    if (searchTerm) {
      const filtered = users.filter(user =>
        user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.display_name?.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredUsers(filtered);
    } else {
      setFilteredUsers(users);
    }
  }, [searchTerm, users]);

  const handleBlockUser = async () => {
    if (selectedUser && blockReason.trim()) {
      await blockUser(selectedUser.user_id, blockReason);
      setSelectedUser(null);
      setBlockReason('');
    }
  };

  const handleUpdateUser = async () => {
    if (editingUser) {
      await updateUserProfile(editingUser.user_id, {
        display_name: editingUser.display_name,
        email: editingUser.email
      });
      setEditingUser(null);
    }
  };

  const handleResendConfirmation = async (email: string) => {
    try {
      const confirmationLink = `${window.location.origin}/beta-welcome`;
      
      const { error } = await supabase.functions.invoke('send-admin-email', {
        body: {
          to: email,
          subject: 'Потвърдете имейла си за MyZone.life',
          template: 'confirmation',
          confirmationLink: confirmationLink,
          email: email
        }
      });

      if (error) {
        toast.error('Неуспешно изпращане на имейл за потвърждение');
        console.error('Resend error:', error);
      } else {
        toast.success('Изпратен е нов имейл за потвърждение');
      }
    } catch (err) {
      console.error(err);
      toast.error('Възникна грешка при изпращане');
    }
  };
  const isUserAdmin = (user: UserProfile) => {
    return user.user_roles?.some(role => role.role === 'admin');
  };

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">Зареждане...</div>;
  }

  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-destructive mb-4">Достъп отказан</h1>
          <p className="text-muted-foreground">Нямате права за достъп до тази страница.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Управление на потребители</h1>
          <p className="text-muted-foreground">Преглед и управление на всички потребители</p>
        </div>
        <SendEmailDialog users={filteredUsers} />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Търсене</CardTitle>
          <CardDescription>Намерете конкретен потребител</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2">
            <Search className="w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Търсене по имейл или име..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Потребители ({filteredUsers.length})</CardTitle>
          <CardDescription>
            Общо {users.length} регистрирани потребители
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
                <TableHeader>
                 <TableRow>
                   <TableHead>Име</TableHead>
                   <TableHead>Имейл</TableHead>
                   <TableHead>Роля</TableHead>
                   <TableHead>Статус</TableHead>
                   <TableHead>План</TableHead>
                   <TableHead>Регистрация</TableHead>
                   <TableHead>Действия</TableHead>
                 </TableRow>
                </TableHeader>
              <TableBody>
                {filteredUsers.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <span>{user.display_name || 'Без име'}</span>
                        {user.subscription?.subscription_source === 'beta' && (
                          <span className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs bg-primary/10 text-primary border border-primary/20">
                            <FlaskConical className="w-3 h-3" />
                            Beta
                          </span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{user.email}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        {isUserAdmin(user) ? (
                          <div className="flex items-center gap-1">
                            <Crown className="w-4 h-4 text-red-500" />
                            <Shield className="w-3 h-3 text-red-500" />
                          </div>
                        ) : (
                          <User className="w-4 h-4 text-muted-foreground" />
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        {user.blocked ? (
                          <>
                            <XCircle className="w-4 h-4 text-red-500" />
                            <span className="sr-only">Блокиран</span>
                          </>
                        ) : (
                          <>
                            <CheckCircle className="w-4 h-4 text-green-500" />
                            <span className="sr-only">Активен</span>
                          </>
                        )}
                      </div>
                    </TableCell>
                     <TableCell>
                       <div className="flex items-center gap-2">
                         {user.subscription?.subscribed ? (
                           <>
                             <CreditCard className="w-4 h-4 text-blue-500" />
                             <div className="flex flex-col">
                               <span className="text-sm font-medium text-blue-600">
                                 {user.subscription.subscription_source === 'beta' 
                                   ? 'Beta Tester (PRO)' 
                                   : user.subscription.subscription_tier || 'Premium'}
                               </span>
                               {user.subscription.subscription_end && (
                                 <span className="text-xs text-muted-foreground">
                                   До {new Date(user.subscription.subscription_end).toLocaleDateString('bg-BG')}
                                 </span>
                               )}
                             </div>
                           </>
                         ) : (
                           <span className="text-sm text-muted-foreground">Безплатен</span>
                         )}
                       </div>
                     </TableCell>
                    <TableCell>
                      {new Date(user.created_at).toLocaleDateString('bg-BG')}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        {/* Resend Confirmation Email */}
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleResendConfirmation(user.email)}
                          title="Изпрати отново потвърждение"
                        >
                          <Mail className="w-4 h-4" />
                        </Button>
                        {/* Edit Button */}
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => setEditingUser(user)}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Редактиране на потребител</DialogTitle>
                              <DialogDescription>
                                Променете данните на потребителя
                              </DialogDescription>
                            </DialogHeader>
                            {editingUser && (
                              <div className="space-y-4">
                                <div>
                                  <Label htmlFor="displayName">Име</Label>
                                  <Input
                                    id="displayName"
                                    value={editingUser.display_name || ''}
                                    onChange={(e) => setEditingUser({
                                      ...editingUser,
                                      display_name: e.target.value
                                    })}
                                  />
                                </div>
                                <div>
                                  <Label htmlFor="email">Имейл</Label>
                                  <Input
                                    id="email"
                                    value={editingUser.email}
                                    onChange={(e) => setEditingUser({
                                      ...editingUser,
                                      email: e.target.value
                                    })}
                                  />
                                </div>
                              </div>
                            )}
                            <DialogFooter>
                              <Button variant="outline" onClick={() => setEditingUser(null)}>
                                Отказ
                              </Button>
                              <Button onClick={handleUpdateUser}>
                                Запази
                              </Button>
                            </DialogFooter>
                          </DialogContent>
                         </Dialog>

                         {/* Manage Subscription Button */}
                        <Dialog>
                           <DialogTrigger asChild>
                             <Button 
                               size="sm" 
                               variant="outline"
                               onClick={() => setManagingSubscription(user)}
                               className="gap-1"
                             >
                               <CreditCard className="w-4 h-4" />
                               <span className="hidden sm:inline">План</span>
                             </Button>
                           </DialogTrigger>
                           <DialogContent>
                             <DialogHeader>
                               <DialogTitle>Управление на план за {user.display_name || user.email}</DialogTitle>
                               <DialogDescription>
                                 Променете subscription плана на потребителя
                               </DialogDescription>
                             </DialogHeader>
                             <div className="space-y-4">
                               <div>
                                 <Label>Текущ статус</Label>
                                 <div className="flex items-center gap-2 mt-1">
                                   {user.subscription?.subscribed ? (
                                     <>
                                       <CreditCard className="w-4 h-4 text-blue-500" />
                                       <span className="text-sm">
                                         {user.subscription.subscription_tier || 'Premium'}
                                         {user.subscription.subscription_end && (
                                           <> до {new Date(user.subscription.subscription_end).toLocaleDateString('bg-BG')}</>
                                         )}
                                       </span>
                                     </>
                                   ) : (
                                     <span className="text-sm text-muted-foreground">Безплатен план</span>
                                   )}
                                 </div>
                               </div>
                               
                               <div className="space-y-3">
                                 <div className="text-sm font-medium">
                                   {user.subscription?.subscribed ? 'Промяна на план:' : 'Активиране на план:'}
                                 </div>
                                 <div className="grid grid-cols-2 gap-2">
                                   <Dialog>
                                     <DialogTrigger asChild>
                                       <Button size="sm" variant="outline">
                                         Месечен (1м)
                                       </Button>
                                     </DialogTrigger>
                                     <DialogContent>
                                       <DialogHeader>
                                         <DialogTitle>Потвърждение</DialogTitle>
                                         <DialogDescription>
                                           Сигурни ли сте, че искате да активирате месечен план за {user.display_name || user.email}?
                                         </DialogDescription>
                                       </DialogHeader>
                                       <DialogFooter>
                                         <Button variant="outline">Отказ</Button>
                                         <Button onClick={() => {
                                           updateSubscription(user.user_id, 'Месечен', 1, user.email);
                                           setManagingSubscription(null);
                                         }}>
                                           Потвърди
                                         </Button>
                                       </DialogFooter>
                                     </DialogContent>
                                   </Dialog>
                                   
                                   <Dialog>
                                     <DialogTrigger asChild>
                                       <Button size="sm" variant="outline">
                                         6-месечен
                                       </Button>
                                     </DialogTrigger>
                                     <DialogContent>
                                       <DialogHeader>
                                         <DialogTitle>Потвърждение</DialogTitle>
                                         <DialogDescription>
                                           Сигурни ли сте, че искате да активирате 6-месечен план за {user.display_name || user.email}?
                                         </DialogDescription>
                                       </DialogHeader>
                                       <DialogFooter>
                                         <Button variant="outline">Отказ</Button>
                                         <Button onClick={() => {
                                           updateSubscription(user.user_id, '6-месечен', 6, user.email);
                                           setManagingSubscription(null);
                                         }}>
                                           Потвърди
                                         </Button>
                                       </DialogFooter>
                                     </DialogContent>
                                   </Dialog>
                                   
                                   <Dialog>
                                     <DialogTrigger asChild>
                                       <Button size="sm" variant="outline">
                                         Годишен
                                       </Button>
                                     </DialogTrigger>
                                     <DialogContent>
                                       <DialogHeader>
                                         <DialogTitle>Потвърждение</DialogTitle>
                                         <DialogDescription>
                                           Сигурни ли сте, че искате да активирате годишен план за {user.display_name || user.email}?
                                         </DialogDescription>
                                       </DialogHeader>
                                       <DialogFooter>
                                         <Button variant="outline">Отказ</Button>
                                         <Button onClick={() => {
                                           updateSubscription(user.user_id, 'Годишен', 12, user.email);
                                           setManagingSubscription(null);
                                         }}>
                                           Потвърди
                                         </Button>
                                       </DialogFooter>
                                     </DialogContent>
                                   </Dialog>
                                   
                                   <Dialog>
                                     <DialogTrigger asChild>
                                       <Button size="sm" variant="outline">
                                         Безсрочен
                                       </Button>
                                     </DialogTrigger>
                                     <DialogContent>
                                       <DialogHeader>
                                         <DialogTitle>Потвърждение</DialogTitle>
                                         <DialogDescription>
                                           Сигурни ли сте, че искате да активирате безсрочен план за {user.display_name || user.email}?
                                         </DialogDescription>
                                       </DialogHeader>
                                       <DialogFooter>
                                         <Button variant="outline">Отказ</Button>
                                         <Button onClick={() => {
                                           updateSubscription(user.user_id, 'Безсрочен', 120, user.email);
                                           setManagingSubscription(null);
                                         }}>
                                           Потвърди
                                         </Button>
                                       </DialogFooter>
                                     </DialogContent>
                                   </Dialog>
                                 </div>
                               </div>
                               
                               {user.subscription?.subscribed && (
                                 <div className="border-t pt-3">
                                   <Dialog>
                                     <DialogTrigger asChild>
                                       <Button 
                                         size="sm"
                                         variant="destructive"
                                         className="w-full"
                                       >
                                         Премахни план
                                       </Button>
                                     </DialogTrigger>
                                     <DialogContent>
                                       <DialogHeader>
                                         <DialogTitle>Потвърждение за премахване</DialogTitle>
                                         <DialogDescription>
                                           Сигурни ли сте, че искате да премахнете плана на {user.display_name || user.email}?
                                         </DialogDescription>
                                       </DialogHeader>
                                       <DialogFooter>
                                         <Button variant="outline">Отказ</Button>
                                         <Button variant="destructive" onClick={() => {
                                           cancelSubscription(user.user_id, user.email);
                                           setManagingSubscription(null);
                                         }}>
                                           Премахни
                                         </Button>
                                       </DialogFooter>
                                     </DialogContent>
                                   </Dialog>
                                 </div>
                                )}
                             </div>
                           </DialogContent>
                         </Dialog>

                        {/* Block/Unblock Button */}
                        {user.blocked ? (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => unblockUser(user.user_id)}
                          >
                            <CheckCircle className="w-4 h-4" />
                          </Button>
                        ) : (
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => setSelectedUser(user)}
                              >
                                <Ban className="w-4 h-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Блокиране на потребител</DialogTitle>
                                <DialogDescription>
                                  Моля, посочете причина за блокирането
                                </DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4">
                                <Textarea
                                  placeholder="Причина за блокиране..."
                                  value={blockReason}
                                  onChange={(e) => setBlockReason(e.target.value)}
                                />
                              </div>
                              <DialogFooter>
                                <Button 
                                  variant="outline" 
                                  onClick={() => {
                                    setSelectedUser(null);
                                    setBlockReason('');
                                  }}
                                >
                                  Отказ
                                </Button>
                                <Button 
                                  variant="destructive" 
                                  onClick={handleBlockUser}
                                  disabled={!blockReason.trim()}
                                >
                                  Блокирай
                                </Button>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>
                        )}

                        {/* Admin Role Toggle */}
                        {isUserAdmin(user) ? (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => removeAdmin(user.user_id)}
                          >
                            <UserMinus className="w-4 h-4" />
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => makeAdmin(user.user_id)}
                          >
                            <UserPlus className="w-4 h-4" />
                          </Button>
                        )}

                        {/* Delete Button */}
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button size="sm" variant="destructive">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Изтриване на потребител</AlertDialogTitle>
                              <AlertDialogDescription>
                                Сигурни ли сте, че искате да изтриете този потребител? 
                                Това действие не може да бъде отменено и ще изтрие всички 
                                негови данни.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Отказ</AlertDialogCancel>
                              <AlertDialogAction onClick={() => deleteUser(user.user_id)}>
                                Изтрий
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            
            {filteredUsers.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                {searchTerm ? 'Няма намерени потребители' : 'Няма регистрирани потребители'}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminUsers;