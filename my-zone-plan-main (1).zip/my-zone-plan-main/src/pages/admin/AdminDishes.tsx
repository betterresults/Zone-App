import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Trash2, Search, Eye, EyeOff } from 'lucide-react';
import { useAdmin } from '@/hooks/useAdmin';
import { Navigate } from 'react-router-dom';

interface Dish {
  id: string;
  name: string;
  description?: string;
  meal_type: string;
  is_public: boolean;
  user_id: string;
  created_at: string;
  source_recipe_id?: string;
  profiles?: {
    display_name?: string;
    email?: string;
  };
  recipes?: {
    name: string;
  };
}

const AdminDishes = () => {
  const { isAdmin, loading } = useAdmin();
  const { toast } = useToast();
  const [dishes, setDishes] = useState<Dish[]>([]);
  const [filteredDishes, setFilteredDishes] = useState<Dish[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (isAdmin) {
      loadDishes();
    }
  }, [isAdmin]);

  useEffect(() => {
    if (searchTerm) {
      const filtered = dishes.filter(dish =>
        dish.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        dish.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        dish.profiles?.display_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        dish.recipes?.name?.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredDishes(filtered);
    } else {
      setFilteredDishes(dishes);
    }
  }, [searchTerm, dishes]);

  const loadDishes = async () => {
    try {
      setIsLoading(true);
      // Load dishes first
      const { data, error } = await supabase
        .from('dishes')
        .select(`*`)
        .order('created_at', { ascending: false });

      if (error) throw error;

      if (data && data.length > 0) {
        // Get user profiles separately
        const userIds = [...new Set(data.map(d => d.user_id))];
        
        const { data: profilesData } = await supabase
          .from('profiles')
          .select('user_id, display_name, email')
          .in('user_id', userIds);

        // Get recipe names for dishes that have source_recipe_id
        const recipeIds = [...new Set(data.filter(d => d.source_recipe_id).map(d => d.source_recipe_id))];
        let recipesData = [];
        
        if (recipeIds.length > 0) {
          const { data: recipeResults } = await supabase
            .from('recipes')
            .select('id, name')
            .in('id', recipeIds);
          recipesData = recipeResults || [];
        }

        // Merge all data
        const dishesWithProfiles = data.map(dish => ({
          ...dish,
          profiles: profilesData?.find(p => p.user_id === dish.user_id),
          recipes: dish.source_recipe_id ? recipesData.find(r => r.id === dish.source_recipe_id) : null
        }));
        
        setDishes(dishesWithProfiles as Dish[]);
      } else {
        setDishes([]);
      }
    } catch (error) {
      console.error('Error loading dishes:', error);
      toast({
        title: 'Грешка',
        description: 'Неуспешно зареждане на ястията',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const toggleDishVisibility = async (dishId: string, isPublic: boolean) => {
    try {
      const { error } = await supabase
        .from('dishes')
        .update({ is_public: !isPublic })
        .eq('id', dishId);

      if (error) throw error;

      toast({
        title: 'Успех',
        description: `Ястието е ${!isPublic ? 'публикувано' : 'скрито'} успешно`
      });

      loadDishes();
    } catch (error) {
      console.error('Error toggling dish visibility:', error);
      toast({
        title: 'Грешка',
        description: 'Неуспешна промяна на видимостта',
        variant: 'destructive'
      });
    }
  };

  const deleteDish = async (dishId: string) => {
    try {
      const { error } = await supabase
        .from('dishes')
        .delete()
        .eq('id', dishId);

      if (error) throw error;

      toast({
        title: 'Успех',
        description: 'Ястието е изтрито успешно'
      });

      loadDishes();
    } catch (error) {
      console.error('Error deleting dish:', error);
      toast({
        title: 'Грешка',
        description: 'Неуспешно изтриване на ястието',
        variant: 'destructive'
      });
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">Зареждане...</div>;
  }

  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-destructive mb-4">Достъп отказан</h1>
          <p className="text-muted-foreground">Нямате права за достъп до тази страница.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Всички ястия</h1>
          <p className="text-muted-foreground">Управление на всички ястия в системата</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Търсене и филтриране</CardTitle>
          <CardDescription>Намерете конкретно ястие</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2">
            <Search className="w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Търсене по име, описание или създател..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Ястия ({filteredDishes.length})</CardTitle>
          <CardDescription>
            Общо {dishes.length} ястия в системата
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">Зареждане на ястията...</div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Име</TableHead>
                    <TableHead>Описание</TableHead>
                    <TableHead>Тип ястие</TableHead>
                    <TableHead>Източник</TableHead>
                    <TableHead>Създател</TableHead>
                    <TableHead>Статус</TableHead>
                    <TableHead>Дата</TableHead>
                    <TableHead>Действия</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredDishes.map((dish) => (
                    <TableRow key={dish.id}>
                      <TableCell className="font-medium">{dish.name}</TableCell>
                      <TableCell className="max-w-xs truncate">
                        {dish.description || '-'}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {dish.meal_type === 'breakfast' ? 'Закуска' :
                           dish.meal_type === 'lunch' ? 'Обяд' :
                           dish.meal_type === 'dinner' ? 'Вечеря' : 'Закуска'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {dish.recipes?.name ? (
                          <Badge variant="secondary">От рецепта: {dish.recipes.name}</Badge>
                        ) : (
                          <span className="text-muted-foreground">Ръчно създадено</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {dish.profiles?.display_name || dish.profiles?.email || 'Неизвестен'}
                      </TableCell>
                      <TableCell>
                        <Badge variant={dish.is_public ? 'default' : 'secondary'}>
                          {dish.is_public ? 'Публично' : 'Лично'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {new Date(dish.created_at).toLocaleDateString('bg-BG')}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => toggleDishVisibility(dish.id, dish.is_public)}
                          >
                            {dish.is_public ? (
                              <EyeOff className="w-4 h-4" />
                            ) : (
                              <Eye className="w-4 h-4" />
                            )}
                          </Button>
                          
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button size="sm" variant="destructive">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Изтриване на ястие</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Сигурни ли сте, че искате да изтриете "{dish.name}"? 
                                  Това действие не може да бъде отменено.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Отказ</AlertDialogCancel>
                                <AlertDialogAction onClick={() => deleteDish(dish.id)}>
                                  Изтрий
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              
              {filteredDishes.length === 0 && !isLoading && (
                <div className="text-center py-8 text-muted-foreground">
                  {searchTerm ? 'Няма намерени ястия' : 'Няма добавени ястия'}
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminDishes;