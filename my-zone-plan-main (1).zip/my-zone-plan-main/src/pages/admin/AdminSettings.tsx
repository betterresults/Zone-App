import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAdmin } from "@/hooks/useAdmin";
import { useAuth } from "@/hooks/useAuth";
import { Shield, Database, Users, Settings2, LogOut } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";
import { ThemeManager } from "@/components/admin/ThemeManager";

export default function AdminSettings() {
  const { stats, loadStats } = useAdmin();
  const { signOut } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    const { error } = await signOut();
    if (error) {
      toast({
        title: "Грешка",
        description: "Неуспешно излизане от акаунта",
        variant: "destructive"
      });
    } else {
      toast({
        title: "Успешно излязохте",
        description: "До скоро!"
      });
      navigate("/");
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-3">
        <Shield className="w-8 h-8 text-red-500" />
        <div>
          <h1 className="text-3xl font-bold">Админ настройки</h1>
          <p className="text-muted-foreground">Системни настройки и конфигурация</p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Theme Management - Full width */}
        <div className="md:col-span-2">
          <ThemeManager />
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5" />
              Системна информация
            </CardTitle>
            <CardDescription>
              Обща информация за системата
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between">
              <span>Версия на системата:</span>
              <span className="font-mono">v1.0.0</span>
            </div>
            <div className="flex justify-between">
              <span>База данни:</span>
              <span className="text-green-600">Активна</span>
            </div>
            <div className="flex justify-between">
              <span>Последна резервна копия:</span>
              <span className="text-muted-foreground">Никога</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Потребителско управление
            </CardTitle>
            <CardDescription>
              Настройки за потребителите
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between">
              <span>Автоматично одобрение:</span>
              <span className="text-green-600">Включено</span>
            </div>
            <div className="flex justify-between">
              <span>Максимален брой акаунти:</span>
              <span>Без ограничение</span>
            </div>
            <Button variant="outline" size="sm">
              Конфигурирай
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings2 className="w-5 h-5" />
              Системни операции
            </CardTitle>
            <CardDescription>
              Операции за поддръжка на системата
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button 
              variant="outline" 
              className="w-full"
              onClick={loadStats}
            >
              Обнови статистики
            </Button>
            <Button variant="outline" className="w-full">
              Почисти кеша
            </Button>
            <Button variant="destructive" className="w-full">
              Рестартирай системата
            </Button>
            <div className="pt-4 border-t">
              <Button 
                variant="outline" 
                className="w-full flex items-center gap-2"
                onClick={handleSignOut}
              >
                <LogOut className="w-4 h-4" />
                Излез от акаунта
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}