import { useState } from 'react';
import { useIsMobile } from '@/hooks/use-mobile';
import { useSubscription } from '@/hooks/useSubscription';
import { ProFeatureGuard } from '@/components/subscription/ProFeatureGuard';
import { WeeklyMenuHeader } from '@/components/weekly-menu/WeeklyMenuHeader';
import { WeeklyMenuGrid } from '@/components/weekly-menu/WeeklyMenuGrid';
import { AdvancedMealDialog } from '@/components/weekly-menu/AdvancedMealDialog';
import { useWeeklyMenuData } from '@/components/weekly-menu/hooks/useWeeklyMenuData';
import WeeklyMenuMobile from './WeeklyMenuMobile';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';

interface MealSelectionDialog {
  open: boolean;
  dayIndex: number;
  mealType: string;
  dayName: string;
  existingMeals?: any[];
}

const WeeklyMenu = () => {
  const { user } = useAuth();
  const { isPro } = useSubscription();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isMobile = useIsMobile();

  const {
    currentWeek,
    setCurrentWeek,
    weekPlan,
    setWeekPlan,
    weeklyPlans,
    products,
    recipes,
    isLoading,
    addMealToWeekMutation,
    deleteMealFromWeekMutation,
    saveWeekPlanNow,
  } = useWeeklyMenuData();

  // Fetch dishes for meal selection
  const { data: dishes = [] } = useQuery({
    queryKey: ['user-dishes'],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const { data, error } = await supabase
        .from('dishes')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    },
    enabled: !!user?.id,
  });

  const [showPlanDialog, setShowPlanDialog] = useState(false);
  const [showTemplateDialog, setShowTemplateDialog] = useState(false);
  const [templateName, setTemplateName] = useState('');
  const [mealDialog, setMealDialog] = useState<MealSelectionDialog>({
    open: false,
    dayIndex: 0,
    mealType: '',
    dayName: '',
    existingMeals: []
  });

  const weekDays = ['П', 'В', 'С', 'Ч', 'П', 'С', 'Н'];
  const weekDayNames = ['Понеделник', 'Вторник', 'Сряда', 'Четвъртък', 'Петък', 'Събота', 'Неделя'];
  
  const mealTypeLabels: Record<string, string> = {
    breakfast: 'Закуска',
    lunch: 'Обяд', 
    dinner: 'Вечеря',
    snack: 'Междинно',
    snack1: 'Междинно (сутрин)',
    snack2: 'Междинно (следобед)',
    snack3: 'Междинно (вечер)'
  };

  const availableMeals = [
    { value: 'breakfast', label: 'Закуска' },
    { value: 'snack1', label: 'Междинно (сутрин)' },
    { value: 'lunch', label: 'Обяд' },
    { value: 'snack2', label: 'Междинно (следобед)' }, 
    { value: 'dinner', label: 'Вечеря' },
    { value: 'snack3', label: 'Междинно (вечер)' }
  ];

  // Save template mutation
  const saveTemplateMutation = useMutation({
    mutationFn: async () => {
      if (!user || !templateName.trim()) throw new Error('Missing data');

      const { error } = await supabase
        .from('weekly_menu_templates')
        .insert({
          user_id: user.id,
          template_name: templateName.trim(),
          template_data: {
            meals: weeklyPlans,
            settings: weekPlan
          }
        });

      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "Успех",
        description: "Шаблонът е запазен успешно",
      });
      setTemplateName('');
      setShowTemplateDialog(false);
    },
    onError: (error) => {
      console.error('Error saving template:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно запазване на шаблона",
        variant: "destructive",
      });
    },
  });

  const handleDeleteMeal = (mealId: string) => {
    deleteMealFromWeekMutation.mutate(mealId);
  };

  const handleMealClick = (dayIndex: number, mealType: string, dayName: string, existingMeals?: any[]) => {
    setMealDialog({
      open: true,
      dayIndex,
      mealType,
      dayName,
      existingMeals: existingMeals || []
    });
  };

  const handleSaveCombination = (dayIndex: number, mealType: string, dayName: string) => {
    // This would open a dialog to save the current combination as a new dish
    console.log('Save combination for', dayName, mealType);
  };

  // New function to handle saving meals from advanced dialog
  const handleSaveMeals = async (meals: any[]) => {
    if (!user) return;
    
    const mealGroupId = crypto.randomUUID();
    
    try {
      // Delete existing meals for this slot if editing
      if (mealDialog.existingMeals?.length) {
        const existingIds = mealDialog.existingMeals.map(meal => meal.id);
        if (existingIds.length > 0) {
          await supabase
            .from('weekly_meal_plans')
            .delete()
            .in('id', existingIds)
            .eq('user_id', user.id);
        }
      }
      
      for (const meal of meals) {
        const mealData: any = {
          user_id: user.id,
          week_start_date: format(currentWeek, 'yyyy-MM-dd'),
          day_of_week: mealDialog.dayIndex,
          meal_type: mealDialog.mealType === 'snack1' || mealDialog.mealType === 'snack2' || mealDialog.mealType === 'snack3' 
            ? 'snack' 
            : mealDialog.mealType,
          servings: meal.servings || 1,
          grams: meal.grams || null,
          meal_group_id: meals.length > 1 ? mealGroupId : null
        };
        
        if (meal.type === 'dish') {
          mealData.dish_id = meal.item.id;
        } else if (meal.type === 'recipe') {
          mealData.recipe_id = meal.item.id;
        } else {
          mealData.product_id = meal.item.id;
        }
        
        const { error } = await supabase
          .from('weekly_meal_plans')
          .insert(mealData);
          
        if (error) throw error;
      }
      
      // Refresh the data - invalidate all cross-page queries
      queryClient.invalidateQueries({ predicate: (q) => Array.isArray(q.queryKey) && (q.queryKey[0] === 'weeklyMealPlans' || q.queryKey[0] === 'today-meals-with-dishes' || q.queryKey[0] === 'meals' || q.queryKey[0] === 'weekly-plans') });
      await queryClient.refetchQueries({ predicate: (q) => Array.isArray(q.queryKey) && q.queryKey[0] === 'weeklyMealPlans' });
      
      toast({
        title: "Успех",
        description: `${meals.length === 1 ? 'Храненето е' : 'Храненията са'} запазени успешно`,
      });
    } catch (error) {
      console.error('Error saving meals:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно запазване на храненията",
        variant: "destructive",
      });
    }
  };

  const handleSaveAsCombination = async (meals: any[], name: string) => {
    if (!user) return;
    
    // Create a new dish that represents this combination
    const { data: newDish, error: dishError } = await supabase
      .from('dishes')
      .insert({
        user_id: user.id,
        name: name,
        description: `Комбинация от ${meals.length} ястия`,
        meal_type: 'combination'
      })
      .select()
      .single();
    
    if (dishError) throw dishError;
    
    // Add ingredients from all meals to the new dish
    for (const meal of meals) {
      if (meal.type === 'product') {
        await supabase
          .from('dish_ingredients')
          .insert({
            dish_id: newDish.id,
            product_id: meal.item.id,
            grams: meal.grams || 100
          });
      }
      // For dishes and recipes, we'd need to copy their ingredients
      // This is more complex and would require additional logic
    }
    
    // Refresh dishes query
    queryClient.invalidateQueries({ queryKey: ['user-dishes'] });
  };

  const handleSaveTemplate = () => {
    if (templateName.trim()) {
      saveTemplateMutation.mutate();
    }
  };

  if (isLoading) {
    return <div className="p-6">Зареждане...</div>;
  }

  return (
    <ProFeatureGuard 
      feature="Седмично планиране на храната"
      description="Планирайте храненията си за цялата седмица и създавайте автоматични списъци за пазаруване"
    >
      {isMobile ? (
        <WeeklyMenuMobile />
      ) : (
        <div className="container mx-auto px-2 sm:px-4 lg:px-6 py-4 lg:py-6 space-y-4 lg:space-y-6">
          <WeeklyMenuHeader
            currentWeek={currentWeek}
            onWeekChange={setCurrentWeek}
            showPlanDialog={showPlanDialog}
            onShowPlanDialogChange={setShowPlanDialog}
            showTemplateDialog={showTemplateDialog}
            onShowTemplateDialogChange={setShowTemplateDialog}
            weekPlan={weekPlan}
            onWeekPlanChange={setWeekPlan}
            availableMeals={availableMeals}
            templateName={templateName}
            onTemplateNameChange={setTemplateName}
            onSaveTemplate={handleSaveTemplate}
            saveTemplateMutation={saveTemplateMutation}
            onSaveWeekPlan={() => {
              saveWeekPlanNow();
              setShowPlanDialog(false);
            }}
          />

          <WeeklyMenuGrid
            weekPlan={weekPlan}
            weeklyPlans={weeklyPlans}
            mealTypeLabels={mealTypeLabels}
            onMealClick={handleMealClick}
            onMealDelete={handleDeleteMeal}
            onSaveCombination={handleSaveCombination}
            weekDayNames={weekDayNames}
            weekDays={weekDays}
            currentWeek={currentWeek}
          />

          <AdvancedMealDialog
            mealDialog={mealDialog}
            onMealDialogChange={setMealDialog}
            mealTypeLabels={mealTypeLabels}
            products={products}
            recipes={recipes}
            dishes={dishes}
            onSaveMeals={handleSaveMeals}
            onSaveAsCombination={handleSaveAsCombination}
          />
        </div>
      )}
    </ProFeatureGuard>
  );
};

export default WeeklyMenu;