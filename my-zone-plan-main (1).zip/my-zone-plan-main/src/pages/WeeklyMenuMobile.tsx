import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ChevronLeft, ChevronRight, Utensils, Plus, Settings, Clock, Save, Star, Eye, ShoppingCart, Trash2, Edit, MoreVertical } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { GenerateShoppingListDialog } from '@/components/weekly-menu/GenerateShoppingListDialog';
import { format, addDays, startOfWeek } from 'date-fns';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface WeekPlan {
  meals: string[];
  withTimes: boolean;
  times: Record<string, string>;
}

interface MealSelectionDialog {
  open: boolean;
  dayIndex: number;
  mealType: string;
  dayName: string;
  existingMeals?: any[];
}

const WeeklyMenuMobile = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [currentWeek, setCurrentWeek] = useState(() => startOfWeek(new Date(), { weekStartsOn: 1 }));
  const [selectedDay, setSelectedDay] = useState(() => {
    const today = new Date();
    return today.getDay() === 0 ? 6 : today.getDay() - 1; // Convert Sunday (0) to 6, Monday (1) to 0, etc.
  });
  const [showPlanDialog, setShowPlanDialog] = useState(false);
  const [showTemplateDialog, setShowTemplateDialog] = useState(false);
  const [showTemplatePreview, setShowTemplatePreview] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<any>(null);
  const [templateName, setTemplateName] = useState('');
  const [showShoppingDialog, setShowShoppingDialog] = useState(false);
  const [mealDialog, setMealDialog] = useState<MealSelectionDialog>({
    open: false,
    dayIndex: 0,
    mealType: '',
    dayName: '',
    existingMeals: []
  });
  const [weekPlan, setWeekPlan] = useState<WeekPlan>({
    meals: ['breakfast', 'lunch', 'dinner'],
    withTimes: false,
    times: {}
  });

  const weekDays = ['П', 'В', 'С', 'Ч', 'П', 'С', 'Н'];
  const weekDayNames = ['Понеделник', 'Вторник', 'Сряда', 'Четвъртък', 'Петък', 'Събота', 'Неделя'];
  
  const mealTypeLabels: Record<string, string> = {
    breakfast: 'Закуска',
    lunch: 'Обяд', 
    dinner: 'Вечеря',
    snack: 'Междинно',
    snack1: 'Междинно (сутрин)',
    snack2: 'Междинно (обяд)',
    snack3: 'Междинно (вечер)'
  };

  const availableMeals = [
    { value: 'breakfast', label: 'Закуска' },
    { value: 'snack1', label: 'Междинно (сутрин)' },
    { value: 'lunch', label: 'Обяд' },
    { value: 'snack2', label: 'Междинно (обяд)' }, 
    { value: 'dinner', label: 'Вечеря' },
    { value: 'snack3', label: 'Междинно (вечер)' }
  ];

  // Fetch weekly meal plans
  const { data: weeklyPlans = [], error: weeklyPlansError, isLoading } = useQuery({
    queryKey: ['weekly-plans', format(currentWeek, 'yyyy-MM-dd')],
    queryFn: async () => {
      if (!user) return [];
      
      try {
        const { data, error } = await supabase
          .from('weekly_meal_plans')
          .select(`
            *,
            dishes(name, meal_type),
            recipes(name, meal_type, servings),
            products(name)
          `)
          .eq('user_id', user.id)
          .eq('week_start_date', format(currentWeek, 'yyyy-MM-dd'))
          .order('day_of_week')
          .order('meal_type');
        
        if (error) {
          console.error('Error fetching weekly plans:', error);
          return [];
        }
        return data || [];
      } catch (error) {
        console.error('Network error fetching weekly plans:', error);
        return [];
      }
    },
    enabled: !!user,
    retry: false,
    refetchOnWindowFocus: false,
    refetchOnMount: true
  });

  // Fetch user preferences
  const { data: userPreferences } = useQuery({
    queryKey: ['user-preferences'],
    queryFn: async () => {
      if (!user) return null;
      
      const { data, error } = await supabase
        .from('user_preferences')
        .select('*')
        .eq('user_id', user.id)
        .in('preference_key', ['weekly_plan_settings', 'current_week_date']);
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!user
  });

  // Load preferences when they change
  useEffect(() => {
    if (userPreferences) {
      const planSettings = userPreferences.find(p => p.preference_key === 'weekly_plan_settings');
      
      if (planSettings?.preference_value) {
        setWeekPlan(planSettings.preference_value as unknown as WeekPlan);
      }
      
      // Don't override with saved week date - always show current week by default
      // Only use saved week date when explicitly navigating
    }
  }, [userPreferences]);

  // Fetch templates
  const { data: templates = [] } = useQuery({
    queryKey: ['weekly-templates'],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from('weekly_menu_templates')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!user
  });

  // Fetch dishes for meal selection
  const { data: dishes = [] } = useQuery({
    queryKey: ['user-dishes'],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from('dishes')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!user && mealDialog.open
  });

  // Fetch recipes for meal selection
  const { data: recipes = [] } = useQuery({
    queryKey: ['user-recipes'],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from('recipes')
        .select('*')
        .or(`user_id.eq.${user.id},is_public.eq.true`)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!user && mealDialog.open
  });

  // Fetch products for meal selection
  const { data: products = [] } = useQuery({
    queryKey: ['products'],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .or(`user_id.eq.${user.id},is_public.eq.true`)
        .order('name');
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!user && mealDialog.open
  });

  // Mutation for adding meals (without replacing)
  const addMealMutation = useMutation({
    mutationFn: async ({ dayIndex, mealType, item, type, servings, grams, isReplacing = false }: {
      dayIndex: number;
      mealType: string;
      item: any;
      type: 'dish' | 'recipe' | 'product';
      servings?: number;
      grams?: number;
      isReplacing?: boolean;
    }) => {
      if (!user) throw new Error('Not authenticated');
      
      const dbMealType = (typeof mealType === 'string' && mealType.startsWith('snack')) ? 'snack' : (mealType as 'breakfast' | 'lunch' | 'dinner' | 'snack');
      
      // Only remove existing meals if we're replacing
      if (isReplacing) {
        await supabase
          .from('weekly_meal_plans')
          .delete()
          .eq('user_id', user.id)
          .eq('week_start_date', format(currentWeek, 'yyyy-MM-dd'))
          .eq('day_of_week', dayIndex)
          .eq('meal_type', dbMealType);
      }
      
      // Insert new meal  
      const mealData: any = {
        user_id: user.id,
        week_start_date: format(currentWeek, 'yyyy-MM-dd'),
        day_of_week: dayIndex,
        meal_type: dbMealType,
        servings: servings || 1,
        grams: grams || null
      };
      
      // Add the appropriate foreign key
      if (type === 'dish') {
        mealData.dish_id = item.id;
      } else if (type === 'recipe') {
        mealData.recipe_id = item.id;  
      } else {
        mealData.product_id = item.id;
      }
      
      const { error } = await supabase
        .from('weekly_meal_plans')
        .insert(mealData);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['weekly-plans'] });
      setMealDialog({ open: false, dayIndex: 0, mealType: '', dayName: '' });
      // Removed success toast for seamless experience
    },
    onError: (error) => {
      toast({
        title: "Грешка",
        description: "Неуспешно добавяне на храната.",
        variant: "destructive"
      });
    }
  });

  // Mutation for saving week plan settings
  const saveWeekPlanMutation = useMutation({
    mutationFn: async (plan: WeekPlan) => {
      if (!user) throw new Error('Not authenticated');
      
      const { error } = await supabase
        .from('user_preferences')
        .upsert({
          user_id: user.id,
          preference_key: 'weekly_plan_settings',
          preference_value: plan as any
        }, {
          onConflict: 'user_id,preference_key'
        });
      
      if (error) throw error;
      
      setWeekPlan(plan);
      setShowPlanDialog(false);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['user-preferences'] });
      toast({
        title: "Планът е запазен!",
        description: "Настройките за седмицата са запазени."
      });
    },
    onError: () => {
      toast({
        title: "Грешка",
        description: "Неуспешно запазване на настройките.",
        variant: "destructive"
      });
    }
  });

  // Mutation for saving as template
  const saveAsTemplateMutation = useMutation({
    mutationFn: async (name: string) => {
      if (!user) throw new Error('Not authenticated');
      
      const templateData = {
        weekPlan,
        meals: weeklyPlans.map(plan => ({
          day_of_week: plan.day_of_week,
          meal_type: plan.meal_type,
          dish_id: plan.dish_id,
          recipe_id: plan.recipe_id,
          product_id: plan.product_id,
          servings: plan.servings,
          grams: plan.grams,
          notes: plan.notes
        }))
      };
      
      const { error } = await supabase
        .from('weekly_menu_templates')
        .insert({
          user_id: user.id,
          template_name: name,
          template_data: templateData as any
        });
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['weekly-templates'] });
      setShowTemplateDialog(false);
      setTemplateName('');
      toast({
        title: "Шаблон запазен!",
        description: "Седмичното меню е запазено като шаблон."
      });
    },
    onError: () => {
      toast({
        title: "Грешка",
        description: "Неуспешно запазване на шаблона.",
        variant: "destructive"
      });
    }
  });

  // Mutation for applying template
  const applyTemplateMutation = useMutation({
    mutationFn: async (template: any) => {
      if (!user) throw new Error('Not authenticated');
      
      // Clear existing meal plans for current week
      await supabase
        .from('weekly_meal_plans')
        .delete()
        .eq('user_id', user.id)
        .eq('week_start_date', format(currentWeek, 'yyyy-MM-dd'));
      
      const templateData = template.template_data;
      
      if (templateData.weekPlan) {
        const newWeekPlan = templateData.weekPlan;
        setWeekPlan(newWeekPlan);
        
        await supabase
          .from('user_preferences')
          .upsert({
            user_id: user.id,
            preference_key: 'weekly_plan_settings', 
            preference_value: newWeekPlan as any
          }, {
            onConflict: 'user_id,preference_key'
          });
      }
    
      if (templateData.meals && templateData.meals.length > 0) {
        const mealsToInsert = templateData.meals
          .filter((meal: any) => meal.dish_id || meal.recipe_id || meal.product_id)
          .map((meal: any) => ({
            user_id: user.id,
            week_start_date: format(currentWeek, 'yyyy-MM-dd'),
            day_of_week: meal.day_of_week,
            meal_type: meal.meal_type,
            dish_id: meal.dish_id || null,
            recipe_id: meal.recipe_id || null,
            product_id: meal.product_id || null,
            servings: meal.servings || 1,
            grams: meal.grams || null,
            notes: meal.notes || null
          }));
        
        if (mealsToInsert.length > 0) {
          const { error } = await supabase
            .from('weekly_meal_plans')
            .insert(mealsToInsert);
          
          if (error) throw error;
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['weekly-plans'] });
      queryClient.invalidateQueries({ queryKey: ['user-preferences'] });
      setShowTemplatePreview(false);
      toast({
        title: "Шаблон приложен!",
        description: `Седмичното меню е заредено от шаблона за седмица ${getWeekNumber()}.`
      });
    },
    onError: () => {
      toast({
        title: "Грешка", 
        description: "Неуспешно прилагане на шаблона.",
        variant: "destructive"
      });
    }
  });

  // Mutation for deleting template
  const deleteTemplateMutation = useMutation({
    mutationFn: async (templateId: string) => {
      if (!user) throw new Error('Not authenticated');
      
      const { error } = await supabase
        .from('weekly_menu_templates')
        .delete()
        .eq('id', templateId)
        .eq('user_id', user.id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['weekly-templates'] });
      toast({
        title: "Шаблон изтрит!",
        description: "Шаблонът е премахнат успешно."
      });
    },
    onError: () => {
      toast({
        title: "Грешка",
        description: "Неуспешно изтриване на шаблона.",
        variant: "destructive"
      });
    }
  });

  // Mutation for removing individual meal item
  const removeMealItemMutation = useMutation({
    mutationFn: async ({ mealId }: { mealId: string }) => {
      if (!user) throw new Error('Not authenticated');
      
      const { error } = await supabase
        .from('weekly_meal_plans')
        .delete()
        .eq('id', mealId)
        .eq('user_id', user.id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['weekly-plans'] });
      toast({
        title: "Храната е премахната",
        description: "Храната е успешно премахната от плана."
      });
    },
    onError: () => {
      toast({
        title: "Грешка",
        description: "Неуспешно премахване на храната.",
        variant: "destructive"
      });
    }
  });

  // Mutation for removing entire meal type
  const removeMealTypeMutation = useMutation({
    mutationFn: async ({ dayIndex, mealType }: { dayIndex: number; mealType: string }) => {
      if (!user) throw new Error('Not authenticated');
      
      const dbMealType = (typeof mealType === 'string' && mealType.startsWith('snack')) ? 'snack' : (mealType as 'breakfast' | 'lunch' | 'dinner' | 'snack');
      
      const { error } = await supabase
        .from('weekly_meal_plans')
        .delete()
        .eq('user_id', user.id)
        .eq('week_start_date', format(currentWeek, 'yyyy-MM-dd'))
        .eq('day_of_week', dayIndex)
        .eq('meal_type', dbMealType);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['weekly-plans'] });
      toast({
        title: "Всички храни са премахнати",
        description: "Всички храни от този тип са премахнати от плана."
      });
    },
    onError: () => {
      toast({
        title: "Грешка",
        description: "Неуспешно премахване на храните.",
        variant: "destructive"
      });
    }
  });

  // Don't render anything if there's no user
  if (!user) {
    return (
      <div className="container mx-auto px-3 py-4 space-y-4 max-w-full overflow-hidden">
        <div className="text-center py-8">
          <p className="text-muted-foreground">Моля, влезте в профила си</p>
        </div>
      </div>
    );
  }

  const getWeekNumber = () => {
    const currentYear = new Date().getFullYear();
    const startOfYear = new Date(currentYear, 0, 1);
    const startOfYearWeek = startOfWeek(startOfYear, { weekStartsOn: 1 });
    const diffInDays = Math.floor((currentWeek.getTime() - startOfYearWeek.getTime()) / (24 * 60 * 60 * 1000));
    return Math.floor(diffInDays / 7) + 1;
  };

  const navigateWeek = (direction: 'prev' | 'next') => {
    const newWeek = new Date(currentWeek);
    if (direction === 'prev') {
      newWeek.setDate(newWeek.getDate() - 7);
    } else {
      newWeek.setDate(newWeek.getDate() + 7);
    }
    setCurrentWeek(newWeek);
    setSelectedDay(0);
  };

  // Handle loading and error states in JSX return
  return (
    <div className="container mx-auto px-3 py-4 space-y-4 max-w-full overflow-hidden">
      {isLoading ? (
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Зарежда се...</p>
        </div>
      ) : weeklyPlansError ? (
        <div className="text-center py-8">
          <p className="text-destructive">Грешка при зареждане на седмичното меню</p>
          <Button 
            variant="outline" 
            className="mt-2"
            onClick={() => window.location.reload()}
          >
            Опитай отново
          </Button>
        </div>
      ) : (
        <>
          {/* Mobile Header */}
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-xl font-bold text-foreground">
                  Сед. меню
                </h1>
              </div>
              
              <div className="flex gap-2 flex-wrap justify-center sm:justify-end">
                <Dialog open={showPlanDialog} onOpenChange={setShowPlanDialog}>
                  <DialogTrigger asChild>
                    <Button size="sm" className="gap-1 text-xs h-8">
                      <Settings className="w-3 h-3" />
                      <span className="hidden sm:inline">Настройки</span>
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle>Настройки за седмичен план</DialogTitle>
                    </DialogHeader>
                     <div className="space-y-6">
                       <div className="space-y-3">
                         <Label className="text-base font-medium">Изберете хранения:</Label>
                         <div className="space-y-2">
                           {availableMeals.map((meal) => (
                             <div key={meal.value} className="flex items-center space-x-2">
                               <Checkbox
                                 id={meal.value}
                                 checked={weekPlan.meals.includes(meal.value)}
                                 onCheckedChange={(checked) => {
                                   if (checked) {
                                     setWeekPlan(prev => ({
                                       ...prev,
                                       meals: [...prev.meals, meal.value]
                                     }));
                                   } else {
                                     setWeekPlan(prev => ({
                                       ...prev,
                                       meals: prev.meals.filter(m => m !== meal.value)
                                     }));
                                   }
                                 }}
                               />
                               <Label htmlFor={meal.value}>{meal.label}</Label>
                             </div>
                           ))}
                         </div>
                       </div>

                       <div className="flex items-center space-x-2">
                         <Checkbox
                           id="withTimes"
                           checked={weekPlan.withTimes}
                           onCheckedChange={(checked) => {
                             setWeekPlan(prev => ({
                               ...prev,
                               withTimes: checked as boolean
                             }));
                           }}
                         />
                         <Label htmlFor="withTimes">Показвай часове за храненията</Label>
                       </div>

                       {weekPlan.withTimes && (
                         <div className="space-y-3">
                           <Label className="text-base font-medium">Часове за хранене</Label>
                           {weekPlan.meals.map((mealType) => (
                             <div key={mealType} className="flex items-center justify-between">
                               <Label className="font-normal">
                                 {availableMeals.find(m => m.value === mealType)?.label}
                               </Label>
                               <Input
                                 type="time"
                                 value={weekPlan.times[mealType] || ''}
                                 onChange={(e) => {
                                   setWeekPlan(prev => ({
                                     ...prev,
                                     times: {
                                       ...prev.times,
                                       [mealType]: e.target.value
                                     }
                                   }));
                                 }}
                                 className="w-32"
                               />
                             </div>
                           ))}
                         </div>
                       )}

                       <Button 
                         onClick={() => saveWeekPlanMutation.mutate(weekPlan)}
                         className="w-full"
                         disabled={weekPlan.meals.length === 0}
                       >
                         Запази настройките
                       </Button>
                     </div>
                  </DialogContent>
                </Dialog>

                <Dialog open={showTemplateDialog} onOpenChange={setShowTemplateDialog}>
                  <DialogTrigger asChild>
                    <Button size="sm" variant="outline" className="gap-1 text-xs h-8">
                      <Save className="w-3 h-3" />
                      <span className="hidden sm:inline">Шаблон</span>
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle>Запази като шаблон</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="template-name">Име на шаблона</Label>
                        <Input
                          id="template-name"
                          value={templateName}
                          onChange={(e) => setTemplateName(e.target.value)}
                          placeholder="Въведете име на шаблона"
                          className="mt-1"
                        />
                      </div>
                      <Button 
                        onClick={() => saveAsTemplateMutation.mutate(templateName)}
                        className="w-full"
                        disabled={!templateName.trim() || saveAsTemplateMutation.isPending}
                      >
                        Запази шаблон
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>

                <Button 
                  size="sm" 
                  variant="outline" 
                  className="gap-1 text-xs h-8" 
                  onClick={() => setShowShoppingDialog(true)}
                >
                  <ShoppingCart className="w-3 h-3" />
                  <span className="hidden sm:inline">Количка</span>
                </Button>

                <GenerateShoppingListDialog 
                  open={showShoppingDialog}
                  onOpenChange={setShowShoppingDialog}
                  weekStartDate={currentWeek}
                />

              </div>
            </div>

            {/* Week Navigation */}
            <div className="flex items-center justify-between bg-card rounded-lg p-3 border">
              <Button variant="outline" size="sm" onClick={() => navigateWeek('prev')} className="h-8 w-8 p-0">
                <ChevronLeft className="w-4 h-4" />
              </Button>
              
              <div className="text-center">
                <div className="text-base font-bold text-primary">
                  Седмица {getWeekNumber()}
                </div>
                <div className="text-xs text-muted-foreground">
                  {format(currentWeek, 'dd.MM')} - {format(addDays(currentWeek, 6), 'dd.MM.yyyy')}
                </div>
              </div>
              
              <Button variant="outline" size="sm" onClick={() => navigateWeek('next')} className="h-8 w-8 p-0">
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>

            {/* Day Selector - Mobile Horizontal Scroll */}
            <div className="flex gap-1 overflow-x-auto pb-2 -mx-1 px-1">
              {weekDays.map((day, index) => {
                const dayDate = addDays(currentWeek, index);
                const isSelected = selectedDay === index;
                const dayMeals = weeklyPlans.filter(p => p.day_of_week === index);
                
                return (
                  <Button
                    key={index}
                    variant={isSelected ? "default" : "outline"}
                    size="sm"
                    className="flex-1 min-w-0 h-14 flex flex-col gap-0.5 px-1 text-xs"
                    onClick={() => setSelectedDay(index)}
                  >
                    <div className="font-medium text-xs leading-tight">{day}</div>
                    <div className="text-xs leading-tight opacity-90">{format(dayDate, 'dd')}</div>
                    <div className="flex gap-0.5 justify-center">
                      {weekPlan.meals.slice(0, 3).map(mealType => {
                        const hasMeal = dayMeals.some(p => p.meal_type === mealType);
                        return (
                          <div 
                            key={mealType}
                            className={`w-1 h-1 rounded-full ${
                              hasMeal ? 'bg-green-500' : 'bg-muted-foreground/30'
                            }`}
                          />
                        );
                      })}
                    </div>
                  </Button>
                );
              })}
            </div>
          </div>

          {/* Selected Day Meals */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold">
              {weekDayNames[selectedDay]} - {format(addDays(currentWeek, selectedDay), 'dd.MM.yyyy')}
            </h3>
            
            {weekPlan.meals.map(mealType => {
              const mealsForType = weeklyPlans.filter(p => p.day_of_week === selectedDay && p.meal_type === mealType);
              
              return (
                <Card key={mealType} className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h4 className="font-medium">{mealTypeLabels[mealType]}</h4>
                        </div>
                        
                        {mealsForType.length > 0 ? (
                          <div className="space-y-3">
                            <div className="space-y-2">
                              {mealsForType.map((m) => (
                                <div key={m.id} className="flex items-center justify-between">
                                  <div>
                                    <div className="text-sm font-medium text-green-600">
                                      {m.dishes?.name || m.recipes?.name || m.products?.name}
                                    </div>
                                    {(m.servings || m.grams) && (
                                      <div className="text-xs text-muted-foreground">
                                        {m.servings ? `${m.servings} порции` : `${m.grams}г`}
                                      </div>
                                    )}
                                  </div>
                                  <div className="flex gap-1">
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      className="h-7 w-7 p-0"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setMealDialog({
                                          open: true,
                                          dayIndex: selectedDay,
                                          mealType: mealType,
                                          dayName: weekDayNames[selectedDay],
                                          existingMeals: [m]
                                        });
                                      }}
                                    >
                                      <Edit className="w-3 h-3" />
                                    </Button>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      className="h-7 w-7 p-0 text-destructive hover:bg-destructive hover:text-destructive-foreground"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        removeMealItemMutation.mutate({
                                          mealId: m.id
                                        });
                                      }}
                                    >
                                      <Trash2 className="w-3 h-3" />
                                    </Button>
                                  </div>
                                </div>
                              ))}
                            </div>
                            <div className="flex gap-1">
                              <Button
                                variant="outline"
                                size="sm"
                                className="h-7 w-7 p-0 text-destructive hover:bg-destructive hover:text-destructive-foreground"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  removeMealTypeMutation.mutate({
                                    dayIndex: selectedDay,
                                    mealType: mealType
                                  });
                                }}
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="h-7 w-7 p-0"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setMealDialog({
                                    open: true,
                                    dayIndex: selectedDay,
                                    mealType: mealType,
                                    dayName: weekDayNames[selectedDay]
                                  });
                                }}
                              >
                                <Plus className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <div className="text-sm text-muted-foreground">
                            Няма добавена храна
                          </div>
                        )}
                      </div>
                      
                      {mealsForType.length === 0 && (
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="h-8 w-8 p-0"
                          onClick={() => setMealDialog({
                            open: true,
                            dayIndex: selectedDay,
                            mealType: mealType,
                            dayName: weekDayNames[selectedDay]
                          })}
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
                );
              })}
            </div>

           {/* Templates Section */}
           <div className="mt-12 space-y-4">
             <div className="border-t pt-6">
               <h3 className="text-lg font-semibold flex items-center gap-2">
                 <Star className="w-5 h-5 text-amber-500" />
                 Шаблони
               </h3>
             </div>
             <div className="grid gap-2">
               {templates.map((template) => (
                 <Card key={template.id} className="p-3">
                   <div className="flex items-center justify-between">
                     <div className="flex-1 min-w-0">
                       <h4 className="font-medium truncate">{template.template_name}</h4>
                       <p className="text-sm text-muted-foreground">
                         Създаден на {format(new Date(template.created_at), 'dd.MM.yyyy')}
                       </p>
                     </div>
                     <div className="flex gap-1 ml-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-8 w-8 p-0"
                          onClick={() => {
                            setSelectedTemplate(template);
                            setShowTemplatePreview(true);
                          }}
                        >
                          <Eye className="w-3 h-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-8 w-8 p-0"
                          onClick={() => applyTemplateMutation.mutate(template)}
                          disabled={applyTemplateMutation.isPending}
                        >
                          <Star className="w-3 h-3" />
                        </Button>
                       <DropdownMenu>
                         <DropdownMenuTrigger asChild>
                           <Button
                             size="sm"
                             variant="ghost"
                             className="h-8 w-8 p-0"
                           >
                             <MoreVertical className="w-3 h-3" />
                           </Button>
                         </DropdownMenuTrigger>
                         <DropdownMenuContent align="end">
                           <DropdownMenuItem
                             onClick={() => deleteTemplateMutation.mutate(template.id)}
                             className="text-destructive focus:text-destructive"
                           >
                             <Trash2 className="w-4 h-4 mr-2" />
                             Изтрий
                           </DropdownMenuItem>
                         </DropdownMenuContent>
                       </DropdownMenu>
                     </div>
                   </div>
                 </Card>
               ))}
               
               {templates.length === 0 && (
                 <Card className="p-6 text-center text-muted-foreground">
                   <Star className="w-8 h-8 mx-auto mb-2 opacity-50" />
                   <p>Няма запазени шаблони</p>
                   <p className="text-sm">Създайте меню и го запазете като шаблон</p>
                 </Card>
               )}
             </div>
           </div>
         </>
       )}

       {/* Template Preview Dialog */}
       <Dialog open={showTemplatePreview} onOpenChange={setShowTemplatePreview}>
         <DialogContent className="max-w-[95vw] max-h-[90vh] overflow-y-auto">
           <DialogHeader>
             <DialogTitle>{selectedTemplate?.template_name}</DialogTitle>
           </DialogHeader>
           {selectedTemplate && (
             <div className="space-y-4">
               <div className="text-sm text-muted-foreground">
                 Създаден на {format(new Date(selectedTemplate.created_at), 'dd.MM.yyyy')}
               </div>
               
               {selectedTemplate.template_data?.weekPlan && (
                 <div>
                   <h4 className="font-medium mb-2">Настройки:</h4>
                   <div className="text-sm space-y-1">
                     <p>Ястия: {selectedTemplate.template_data.weekPlan.meals?.map((meal: string) => 
                       availableMeals.find(m => m.value === meal)?.label
                     ).join(', ')}</p>
                     <p>С часове: {selectedTemplate.template_data.weekPlan.withTimes ? 'Да' : 'Не'}</p>
                   </div>
                 </div>
               )}

               {selectedTemplate.template_data?.meals && (
                 <div>
                   <h4 className="font-medium mb-2">Ястия по дни:</h4>
                   <div className="space-y-2 text-sm">
                     {weekDayNames.map((dayName, dayIndex) => {
                       const dayMeals = selectedTemplate.template_data.meals.filter(
                         (meal: any) => meal.day_of_week === dayIndex
                       );
                       return (
                         <div key={dayIndex}>
                           <strong>{dayName}:</strong>
                           {dayMeals.length > 0 ? (
                             <ul className="ml-4 mt-1">
                               {dayMeals.map((meal: any, index: number) => (
                                 <li key={index}>
                                   {availableMeals.find(m => m.value === meal.meal_type)?.label}
                                 </li>
                               ))}
                             </ul>
                           ) : (
                             <p className="text-muted-foreground ml-4">Няма планирани ястия</p>
                           )}
                         </div>
                       );
                     })}
                   </div>
                 </div>
               )}
               
               <div className="flex gap-2">
                 <Button 
                   onClick={() => {
                     applyTemplateMutation.mutate(selectedTemplate);
                     setShowTemplatePreview(false);
                   }}
                   disabled={applyTemplateMutation.isPending}
                   className="flex-1"
                 >
                   <Star className="mr-2 h-4 w-4" />
                   Приложи шаблона
                 </Button>
               </div>
             </div>
           )}
         </DialogContent>
       </Dialog>

      {/* Meal Selection Dialog */}
      <Dialog open={mealDialog.open} onOpenChange={(open) => setMealDialog({ ...mealDialog, open })}>
        <DialogContent className="sm:max-w-[425px] max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {mealDialog.existingMeals && mealDialog.existingMeals.length > 0 
                ? `Замени храна за ${mealDialog.dayName} - ${mealTypeLabels[mealDialog.mealType]}`
                : `Добави храна за ${mealDialog.dayName} - ${mealTypeLabels[mealDialog.mealType]}`
              }
            </DialogTitle>
          </DialogHeader>
          
          <Tabs defaultValue="dishes" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="dishes">Ястия</TabsTrigger>
              <TabsTrigger value="products">Продукти</TabsTrigger>
            </TabsList>
            
            <TabsContent value="dishes" className="space-y-4">
              <div className="grid gap-2 max-h-64 overflow-y-auto">
                {dishes.map((dish) => (
                  <Card key={`dish-${dish.id}`} className="cursor-pointer hover:shadow-md transition-shadow">
                    <CardContent className="p-3">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <p className="font-medium text-sm">{dish.name}</p>
                          <Badge variant="secondary" className="text-xs mt-1">
                            Ястие
                          </Badge>
                        </div>
                        <Button
                          size="sm"
                          onClick={() => addMealMutation.mutate({
                            dayIndex: mealDialog.dayIndex,
                            mealType: mealDialog.mealType,
                            item: dish,
                            type: 'dish',
                            isReplacing: !!(mealDialog.existingMeals && mealDialog.existingMeals.length > 0)
                          })}
                          disabled={addMealMutation.isPending}
                        >
                          {mealDialog.existingMeals && mealDialog.existingMeals.length > 0 ? 'Замени' : 'Добави'}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="products" className="space-y-4">
              <div className="grid gap-2 max-h-64 overflow-y-auto">
                {products.map((product) => (
                  <Card key={`product-${product.id}`} className="cursor-pointer hover:shadow-md transition-shadow">
                    <CardContent className="p-3">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <p className="font-medium text-sm">{product.name}</p>
                          <Badge variant="secondary" className="text-xs mt-1">
                            Продукт
                          </Badge>
                        </div>
                        <Button
                          size="sm"
                          onClick={() => addMealMutation.mutate({
                            dayIndex: mealDialog.dayIndex,
                            mealType: mealDialog.mealType,
                            item: product,
                            type: 'product',
                            grams: 100,
                            isReplacing: !!(mealDialog.existingMeals && mealDialog.existingMeals.length > 0)
                          })}
                          disabled={addMealMutation.isPending}
                        >
                          {mealDialog.existingMeals && mealDialog.existingMeals.length > 0 ? 'Замени' : 'Добави'}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default WeeklyMenuMobile;