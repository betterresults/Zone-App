import { useState, useMemo, useEffect } from 'react';
import { format, startOfWeek, addDays, isToday, isSameDay, startOfDay } from 'date-fns';
import { bg } from 'date-fns/locale';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Calendar, CheckCircle2, Circle, Flame, Target, TrendingUp, Clock, ChevronLeft, ChevronRight, BarChart3, Settings, Trash2, List, Edit, ChevronDown, Info, Play } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Habit, useHabits } from '@/hooks/useHabits';
import { useHabitSettings } from '@/hooks/useHabitSettings';
import { CategoryManager } from '@/components/habits/CategoryManager';
import { AddHabitDialog } from '@/components/habits/AddHabitDialog';
import { WeekView } from '@/components/habits/WeekView';
import { DayView } from '@/components/habits/DayView';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ProFeatureGuard } from '@/components/subscription/ProFeatureGuard';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useIsMobile } from '@/hooks/use-mobile';
import { FullscreenHabitTimer } from '@/components/habits/FullscreenHabitTimer';
import { FullscreenWorkoutTimer } from '@/components/fitness/FullscreenWorkoutTimer';
import { WorkoutTimerForHabit } from '@/components/fitness/WorkoutTimerForHabit';
import { useWorkoutExercises } from '@/hooks/useExercises';
import { useHabitSessions } from '@/hooks/useHabitSessions';
import { HabitStatistics } from '@/components/habits/HabitStatistics';

const CATEGORY_LABELS = {
  'health': 'Здраве',
  'fitness': 'Фитнес', 
  'nutrition': 'Хранене',
  'self-care': 'Грижа за себе си',
  'productivity': 'Продуктивност',
  'learning': 'Учене',
  'relationships': 'Отношения',
  'hobbies': 'Хобита',
  'general': 'Общо',
};

const Habits = () => {
  const [showAddHabit, setShowAddHabit] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [activeCategory, setActiveCategory] = useState('all');
  const [fixAttempted, setFixAttempted] = useState(false);
  const [activeTab, setActiveTab] = useState('manage');
  const [viewMode, setViewMode] = useState<'day' | 'week'>('day');
  const [expandedHabit, setExpandedHabit] = useState<string | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [showCategoryManager, setShowCategoryManager] = useState(false);
  
  const [editingHabit, setEditingHabit] = useState<Habit | null>(null);
  const isMobile = useIsMobile();
  const [fullscreenTimerHabit, setFullscreenTimerHabit] = useState<Habit | null>(null);
  const { parseDurationFromDescription } = useHabitSessions();
  const [openCategories, setOpenCategories] = useState<Record<string, boolean>>({});
  const [fullscreenWorkoutHabit, setFullscreenWorkoutHabit] = useState<Habit | null>(null);
  
  // Use habit settings hook
  const { 
    settings, 
    updateDayStatus, 
    updateTimeSettings, 
    isDayActive,
    isUpdating 
  } = useHabitSettings();

  // Initialize local state from settings
  const [dayStart, setDayStart] = useState(settings.day_start_time);
  const [dayEnd, setDayEnd] = useState(settings.day_end_time);

  // Update local state when settings change
  useEffect(() => {
    setDayStart(settings.day_start_time);
    setDayEnd(settings.day_end_time);
  }, [settings]);

  // Handle day status toggle
  const handleDayToggle = (dayIndex: number, currentStatus: boolean) => {
    updateDayStatus.mutate({ 
      dayIndex, 
      isActive: !currentStatus 
    });
  };

  // Load persisted settings from Supabase (user_preferences) on mount
  useEffect(() => {
    (async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;
        const { data } = await supabase
          .from('user_preferences')
          .select('preference_value')
          .eq('user_id', user.id)
          .eq('preference_key', 'habits_time_window')
          .maybeSingle();
        const pref: any = data?.preference_value;
        if (pref?.start && pref?.end) {
          setDayStart(pref.start);
          setDayEnd(pref.end);
          localStorage.setItem('habits-day-start', pref.start);
          localStorage.setItem('habits-day-end', pref.end);
        }
      } catch (e) {
        console.warn('Failed to load habit time window from Supabase:', e);
      }
    })();
  }, []);

  // Persist settings locally and to Supabase when they change
  const saveHabitTimeWindow = async (start: string, end: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      // Upsert-like: update if exists, else insert
      const { data: existing } = await supabase
        .from('user_preferences')
        .select('id')
        .eq('user_id', user.id)
        .eq('preference_key', 'habits_time_window')
        .maybeSingle();

      if (existing?.id) {
        await supabase
          .from('user_preferences')
          .update({ preference_value: { start, end } })
          .eq('id', existing.id);
      } else {
        await supabase
          .from('user_preferences')
          .insert({
            user_id: user.id,
            preference_key: 'habits_time_window',
            preference_value: { start, end }
          });
      }
    } catch (e) {
      console.warn('Failed to save habit time window to Supabase:', e);
    }
  };

  const handleDayStartChange = (value: string) => {
    setDayStart(value);
    localStorage.setItem('habits-day-start', value);
    void saveHabitTimeWindow(value, dayEnd);
    updateTimeSettings.mutate({ dayStart: value, dayEnd });
  };

  const handleDayEndChange = (value: string) => {
    setDayEnd(value);
    localStorage.setItem('habits-day-end', value);
    void saveHabitTimeWindow(dayStart, value);
    updateTimeSettings.mutate({ dayStart, dayEnd: value });
  };

  const { 
    habits, 
    isLoadingHabits, 
    useHabitCompletions, 
    completeHabitMutation, 
    uncompleteHabitMutation,
    isHabitCompleted,
    isHabitActiveOnDay,
    deleteHabitMutation
  } = useHabits();

  // Get current week for the calendar view
  const weekStart = startOfWeek(selectedDate, { weekStartsOn: 1 });
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));

  // Auto-fix and cleanup fitness template duplicates once
  useEffect(() => {
    if (fixAttempted || habits.length === 0) return;
    (async () => {
      try {
        const mapBgToEn: Record<string, string> = {
          'Понеделник': 'monday',
          'Вторник': 'tuesday',
          'Сряда': 'wednesday',
          'Четвъртък': 'thursday',
          'Петък': 'friday',
          'Събота': 'saturday',
          'Неделя': 'sunday',
        };

        // 1) Normalize repeat_days for fitness habits named "Тренировка - <ден>"
        for (const h of habits) {
          if (
            h.category === 'fitness' &&
            Array.isArray(h.repeat_days) &&
            h.repeat_days.length >= 1 &&
            typeof h.name === 'string' &&
            h.name.startsWith('Тренировка - ')
          ) {
            const label = h.name.split(' - ')[1]?.trim();
            const expected = label ? mapBgToEn[label] : undefined;
            if (expected && (!h.repeat_days.includes(expected) || h.repeat_days.length !== 1)) {
              await supabase
                .from('habits')
                .update({ repeat_days: [expected] })
                .eq('id', h.id);
            }
          }
        }

        // 2) Deactivate obvious duplicates for fitness template habits (same day + same name)
        const fitness = habits.filter(h => h.category === 'fitness');
        const byKey = new Map<string, Habit[]>();
        for (const h of fitness) {
          const day = Array.isArray(h.repeat_days) ? h.repeat_days[0] : '';
          const key = `${day}|${(h.name || '').toLowerCase().trim()}`;
          if (!byKey.has(key)) byKey.set(key, []);
          byKey.get(key)!.push(h);
        }
        const toDeactivate: string[] = [];
        for (const group of byKey.values()) {
          if (group.length <= 1) continue;
          // keep the earliest created, deactivate the rest
          const sorted = [...group].sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
          const [, ...dups] = sorted;
          for (const d of dups) {
            // Be safe: only auto-deactivate template-like entries
            const looksTemplate = d.fitness_template_id || (d.name?.toLowerCase().startsWith('тренировка -')) || (d.description?.toLowerCase().includes('шаблон') ?? false);
            if (looksTemplate) toDeactivate.push(d.id);
          }
        }
        if (toDeactivate.length) {
          await supabase.from('habits').update({ is_active: false }).in('id', toDeactivate);
        }
      } catch (e) {
        console.warn('Fitness habit auto-fix skipped:', e);
      } finally {
        setFixAttempted(true);
      }
    })();
  }, [habits, fixAttempted]);

  // Get habit completions for the current week
  const { data: completions = [] } = useHabitCompletions(
    weekStart,
    addDays(weekStart, 6)
  );

  // Filter habits by category
  const filteredHabits = useMemo(() => {
    if (activeCategory === 'all') return habits;
    return habits.filter(habit => habit.category === activeCategory);
  }, [habits, activeCategory]);

  // For display: hide obvious fitness duplicates (same day + same name), but preserve one-time habits
  const displayHabits = useMemo(() => {
    const seen = new Set<string>();
    const result: typeof filteredHabits = [] as any;
    for (const h of filteredHabits) {
      // Don't filter one-time habits - they should always show
      if (h.one_time_date) {
        result.push(h);
        continue;
      }
      
      // Only filter recurring fitness habits for duplicates
      if (h.category === 'fitness' && !h.one_time_date) {
        const day = Array.isArray(h.repeat_days) ? h.repeat_days[0] : '';
        const key = `${day}|${(h.name || '').toLowerCase().trim()}`;
        if (seen.has(key)) continue;
        seen.add(key);
      }
      result.push(h);
    }
    return result;
  }, [filteredHabits]);

  // Filter display habits for the selected day only
  const displayHabitsForSelectedDay = useMemo(() => {
    return displayHabits.filter(h => isHabitActiveOnDay(h, selectedDate));
  }, [displayHabits, isHabitActiveOnDay, selectedDate]);

  // Get unique categories from habits
  const availableCategories = useMemo(() => {
    const categories = new Set(habits.map(habit => habit.category));
    return Array.from(categories).map(category => ({
      value: category,
      label: CATEGORY_LABELS[category as keyof typeof CATEGORY_LABELS] || category
    }));
  }, [habits]);

  const habitsByCategory = useMemo(() => {
    const grouped: Record<string, { label: string; habits: (Habit & { isPastOneTime?: boolean })[] }> = {};
    const today = new Date();
    
    for (const h of habits) {
      if (!h.category) continue;
      
      // Check if one-time habit is in the past
      const isInactive = h.one_time_date && new Date(h.one_time_date) < today;
      
      const label = CATEGORY_LABELS[h.category as keyof typeof CATEGORY_LABELS] || h.category;
      if (!grouped[h.category]) grouped[h.category] = { label, habits: [] };
      grouped[h.category].habits.push({ ...h, isPastOneTime: isInactive });
    }
    return grouped;
  }, [habits]);

  const toggleCategory = (categoryId: string) => {
    setOpenCategories((prev) => ({ ...prev, [categoryId]: !prev[categoryId] }));
  };

  // Calculate stats
  const stats = useMemo(() => {
    const today = startOfDay(new Date());
    const todayHabits = habits.filter(habit => isHabitActiveOnDay(habit, today));
    const completedToday = todayHabits.filter(habit => isHabitCompleted(habit.id, today, completions));
    
    // Weekly stats
    const thisWeekCompletions = completions.length;
    const thisWeekTarget = habits.reduce((total, habit) => {
      return total + weekDays.filter(day => isHabitActiveOnDay(habit, day)).length;
    }, 0);

    return {
      totalHabits: habits.length,
      activeToday: todayHabits.length,
      completedToday: completedToday.length,
      todayPercentage: todayHabits.length > 0 ? Math.round((completedToday.length / todayHabits.length) * 100) : 0,
      thisWeekCompletions,
      thisWeekTarget,
      weeklyPercentage: thisWeekTarget > 0 ? Math.round((thisWeekCompletions / thisWeekTarget) * 100) : 0
    };
  }, [habits, completions, isHabitActiveOnDay, isHabitCompleted, weekDays]);

  const handleToggleHabit = async (habitId: string, date: Date) => {
    const habit = habits.find(h => h.id === habitId);
    const targetDurationMinutes = parseDurationFromDescription(habit?.description);
    if (targetDurationMinutes) {
      setFullscreenTimerHabit(habit as Habit);
      return;
    }

    const isCompleted = isHabitCompleted(habitId, date, completions);
    try {
      if (isCompleted) {
        await uncompleteHabitMutation.mutateAsync({ habitId, date });
      } else {
        await completeHabitMutation.mutateAsync({ habitId, date });
      }
    } catch (error) {
      console.error('Error toggling habit:', error);
    }
  };

  const handleDeleteHabit = async (habitId: string) => {
    try {
      await deleteHabitMutation.mutateAsync(habitId);
    } catch (error) {
      toast.error('Грешка при изтриване на навика');
    }
  };

  const goToPreviousWeek = () => {
    setSelectedDate(addDays(selectedDate, -7));
  };

  const goToNextWeek = () => {
    setSelectedDate(addDays(selectedDate, 7));
  };

  const goToToday = () => {
    setSelectedDate(new Date());
  };

  return (
    <ProFeatureGuard feature="Навици">
      <div className="container mx-auto px-1 sm:px-2 md:px-4 lg:px-6 py-2 sm:py-4 md:py-8 space-y-3 md:space-y-6 max-w-full overflow-x-hidden">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full max-w-full">
          <div className="space-y-2 max-w-full overflow-hidden">
            <TabsList className="grid grid-cols-3 gap-1 h-auto">
              <TabsTrigger value="manage" className="gap-1 flex-col p-2 min-h-[60px]">
                <List className="w-4 h-4" />
                <span className="text-xs">Управление</span>
              </TabsTrigger>
              <TabsTrigger value="statistics" className="gap-1 flex-col p-2 min-h-[60px]">
                <BarChart3 className="w-4 h-4" />
                <span className="text-xs">Статистики</span>
              </TabsTrigger>
              <TabsTrigger value="settings" className="gap-1 flex-col p-2 min-h-[60px]">
                <Settings className="w-4 h-4" />
                <span className="text-xs">Настройки</span>
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="manage" className="space-y-4 md:space-y-6">
            {/* Habits Table by Categories */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-lg">Твоите навици и задачи</CardTitle>
                  </div>
                  <Button onClick={() => setShowAddHabit(true)} size="sm" className="flex items-center gap-2">
                    <Plus className="w-4 h-4" />
                    <span className="hidden sm:inline">Добави навик/задача</span>
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {Object.keys(habitsByCategory).length === 0 ? (
                  <div className="text-center py-8">
                     <p className="text-muted-foreground mb-4">Няма създадени навици или задачи</p>
                     <Button onClick={() => setShowAddHabit(true)}>Създай първи навик или задача</Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {Object.entries(habitsByCategory).map(([categoryId, categoryData], index) => (
                      <div key={categoryId}>
                        <Collapsible
                          open={openCategories[categoryId] || false}
                          onOpenChange={() => toggleCategory(categoryId)}
                        >
                        <CollapsibleTrigger asChild>
                           <Button variant="ghost" className="w-full justify-between h-auto p-4 hover:bg-muted/30 rounded-xl border bg-gradient-to-r from-background to-muted/20 group">
                             <div className="flex items-center gap-3">
                               <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                                 <span className="text-sm font-medium text-primary">
                                   {categoryData.label.charAt(0)}
                                 </span>
                               </div>
                               <div className="text-left">
                                 <div className="font-medium text-base text-foreground group-hover:text-foreground">{categoryData.label}</div>
                                 <div className="text-sm text-muted-foreground group-hover:text-muted-foreground">{categoryData.habits.length} {categoryData.habits.length === 1 ? 'навик/задача' : 'навици/задачи'}</div>
                               </div>
                             </div>
                             <ChevronDown className={`h-5 w-5 transition-transform text-foreground group-hover:text-foreground ${openCategories[categoryId] ? 'rotate-180' : ''}`} />
                          </Button>
                        </CollapsibleTrigger>
                          <CollapsibleContent className="mt-3">
                            <div className="space-y-3 pl-4 border-l-2 border-primary/10">
                              {categoryData.habits.map((habit) => (
                                <div
                                  key={habit.id}
                                  className={`group border rounded-lg p-3 hover:bg-muted/50 transition-colors ${
                                    habit.isPastOneTime ? 'opacity-60 bg-muted/20' : ''
                                  }`}
                                >
                                  <div className="flex items-start gap-3 justify-between w-full">
                                    <div className="flex items-start gap-3 flex-1 min-w-0">
                                      <div
                                        className="w-4 h-4 rounded-full border-2 flex-shrink-0 mt-1"
                                        style={{ backgroundColor: habit.color, borderColor: habit.color }}
                                      />
                                      <div className="flex-1 min-w-0">
                                        <div className="flex items-center gap-2">
                                          <h4 className="font-medium text-sm md:text-base truncate">{habit.name}</h4>
                                          {habit.isPastOneTime && (
                                            <Badge variant="secondary" className="text-xs">
                                              Изтекъл
                                            </Badge>
                                          )}
                                        </div>
                                        {habit.description && (
                                          <p className="text-xs md:text-sm text-muted-foreground line-clamp-2 mt-1">{habit.description}</p>
                                        )}
                                        <div className="flex items-center gap-2 mt-2 flex-wrap">
                                          {habit.time_of_day && (
                                            <Badge variant="outline" className="text-xs">
                                              <Clock className="w-3 h-3 mr-1" /> {habit.time_of_day}
                                            </Badge>
                                          )}
                                          {habit.one_time_date && (
                                            <Badge variant="outline" className="text-xs">
                                              {format(new Date(habit.one_time_date), 'd MMM yyyy', { locale: bg })}
                                            </Badge>
                                          )}
                                        </div>
                                      </div>
                                    </div>
                                    <div className="flex items-center gap-2 justify-end">
                                      {/* Start button for habits with duration */}
                                      {habit.duration_minutes && habit.duration_minutes > 0 && (
                                        <Button
                                          variant="default"
                                          size="sm"
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            if (habit.category === 'fitness') {
                                              setFullscreenWorkoutHabit(habit);
                                            } else {
                                              setFullscreenTimerHabit(habit);
                                            }
                                          }}
                                          className="h-8 px-3 gap-2"
                                        >
                                          <Play className="w-4 h-4" />
                                          <span className="hidden sm:inline">Старт</span>
                                        </Button>
                                      )}
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          setEditingHabit(habit);
                                          setShowAddHabit(true);
                                        }}
                                        className="text-foreground/60 hover:text-foreground hover:bg-accent/50 h-8 w-8 p-0 transition-colors"
                                      >
                                        <Edit className="w-4 h-4" />
                                      </Button>
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => handleDeleteHabit(habit.id)}
                                        className="text-destructive/60 hover:text-destructive hover:bg-destructive/10 h-8 w-8 p-0 transition-colors"
                                      >
                                        <Trash2 className="w-4 h-4" />
                                      </Button>
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </CollapsibleContent>
                        </Collapsible>
                        {/* Add separator between categories */}
                        {index < Object.entries(habitsByCategory).length - 1 && (
                          <div className="h-px bg-gradient-to-r from-transparent via-border to-transparent my-4" />
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Today's Habits Preview - Collapsible */}
            <Collapsible>
              <CollapsibleTrigger asChild>
                <Card className="cursor-pointer hover:shadow-sm transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-center">
                      <div className="text-center flex-1">
                        <CardTitle className="text-lg">
                          {format(selectedDate, 'EEEE, d MMMM', { locale: bg })}
                        </CardTitle>
                        <CardDescription>
                          {displayHabitsForSelectedDay.length} {displayHabitsForSelectedDay.length === 1 ? 'навик' : 'навика'} за днес
                        </CardDescription>
                      </div>
                      <ChevronDown className="w-5 h-5 flex-shrink-0" />
                    </div>
                  </CardHeader>
                </Card>
              </CollapsibleTrigger>
              <CollapsibleContent>
                <div className="mt-4 w-full overflow-hidden">
                  <DayView 
                    selectedDate={selectedDate}
                    setSelectedDate={setSelectedDate}
                    displayHabits={displayHabitsForSelectedDay}
                    isLoadingHabits={isLoadingHabits}
                    filteredHabits={filteredHabits}
                    completions={completions}
                    isHabitActiveOnDay={isHabitActiveOnDay}
                    isHabitCompleted={isHabitCompleted}
                    handleToggleHabit={handleToggleHabit}
                    setShowAddHabit={setShowAddHabit}
                    expandedHabit={expandedHabit}
                    setExpandedHabit={setExpandedHabit}
                    dayStart={dayStart}
                    dayEnd={dayEnd}
                    onDeleteHabit={handleDeleteHabit}
                    parseDurationFromDescription={parseDurationFromDescription}
                    setFullscreenTimerHabit={setFullscreenTimerHabit}
                    hideHeader={true}
                  />
                </div>
              </CollapsibleContent>
            </Collapsible>
          </TabsContent>

          <TabsContent value="statistics" className="space-y-6">
            <HabitStatistics />
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <div className="max-w-2xl mx-auto space-y-6">
              {/* Categories Management */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5" />
                    Категории
                  </CardTitle>
                  <CardDescription>
                    Управлявайте категориите за вашите навици и задачи
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button onClick={() => setShowCategoryManager(true)}>
                    Управление на категории
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="space-y-4 pt-4">
                  <div>
                    <div className="flex items-center gap-2 mb-4">
                      <h3 className="text-base font-medium">Настройки за дните</h3>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Info className="w-4 h-4 text-muted-foreground cursor-help" />
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="max-w-xs">Тук можете да настроите кои дни да са активни и неактивни, от колко сутринта до колко вечерта могат да се добавят навици.</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                    <div className="space-y-0.5">
                      {[
                        { id: 0, name: 'ПОН', fullName: 'Понеделник' },
                        { id: 1, name: 'ВТО', fullName: 'Вторник' },
                        { id: 2, name: 'СРЯ', fullName: 'Сряда' },
                        { id: 3, name: 'ЧЕТ', fullName: 'Четвъртък' },
                        { id: 4, name: 'ПЕТ', fullName: 'Петък' },
                        { id: 5, name: 'САБ', fullName: 'Събота' },
                        { id: 6, name: 'НЕД', fullName: 'Неделя' }
                       ].map((day) => {
                         const isActive = isDayActive(day.id);
                         return (
                          <div 
                            key={day.id}
                            className={`flex items-center space-x-2 p-1.5 rounded-md transition-all border ${
                              isActive 
                                ? 'border-primary bg-primary/5' 
                                : 'border-border/50 hover:border-primary/50 hover:bg-muted/30'
                            }`}
                          >
                            {/* Day indicator */}
                            <div className="flex-shrink-0 w-8 text-center">
                              <div className={`text-xs font-bold ${
                                isActive ? 'text-primary' : 'text-muted-foreground'
                              }`}>
                                {day.name}
                              </div>
                            </div>
                            
                            {/* Toggle Switch */}
                            <div className="flex-shrink-0">
                              <Switch
                                checked={isActive}
                                onCheckedChange={() => handleDayToggle(day.id, isActive)}
                                className="scale-65"
                                disabled={isUpdating}
                              />
                            </div>
                            
                            {/* Time inputs - centered */}
                            <div className="flex-1 flex justify-center">
                              {isActive ? (
                                <div className="flex items-center gap-1 text-xs">
                                  <Input
                                    type="time"
                                    value={dayStart}
                                    onChange={(e) => handleDayStartChange(e.target.value)}
                                    className="w-16 h-6 text-xs text-center border-0 bg-transparent focus:bg-background p-0"
                                  />
                                  <span className="text-muted-foreground px-1">-</span>
                                  <Input
                                    type="time"
                                    value={dayEnd}
                                    onChange={(e) => handleDayEndChange(e.target.value)}
                                    className="w-16 h-6 text-xs text-center border-0 bg-transparent focus:bg-background p-0"
                                  />
                                </div>
                              ) : (
                                <div className="text-xs text-muted-foreground italic">
                                  Неактивен
                                </div>
                              )}
                            </div>
                            
                            {/* Indicator */}
                            <div className="flex-shrink-0 flex items-center gap-1">
                              {isActive ? (
                                <div className="w-2 h-2 rounded-sm bg-green-500" title="Активен" />
                              ) : (
                                <div className="w-2 h-2 rounded-sm bg-muted-foreground/30" title="Неактивен" />
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        <AddHabitDialog
          open={showAddHabit}
          onOpenChange={setShowAddHabit}
          editingHabit={editingHabit}
        />

        <FullscreenHabitTimer
          habit={fullscreenTimerHabit}
          isOpen={!!fullscreenTimerHabit}
          onClose={() => setFullscreenTimerHabit(null)}
        />

        {fullscreenWorkoutHabit && fullscreenWorkoutHabit.one_time_date && (
          <WorkoutTimerForHabit
            habit={fullscreenWorkoutHabit}
            onClose={() => setFullscreenWorkoutHabit(null)}
          />
        )}

        <CategoryManager
          open={showCategoryManager}
          onOpenChange={setShowCategoryManager}
        />
      </div>
    </ProFeatureGuard>
  );
};

export default Habits;
