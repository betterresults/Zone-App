import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useProfile } from '@/hooks/useProfile';
import { useCalorieTarget, calculateCalories } from '@/hooks/useCalorieTarget';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ZoneCalculator } from '@/components/zone/ZoneCalculator';
import { WeightTracker } from '@/components/WeightTracker';
import { User, Droplets, Clock, LogOut, Calculator, Scale, Dumbbell, Target, Crown, Bell, Trash2, Sun, Moon, Palette } from 'lucide-react';
import { SubscriptionCard } from '@/components/subscription/SubscriptionCard';
import { toast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { format, startOfWeek, addDays } from 'date-fns';
import { useSubscription } from '@/hooks/useSubscription';
import { useActivityTracker } from '@/hooks/useActivityTracker';
import { NotificationSettings } from '@/components/settings/NotificationSettings';
import { HabitCategorySettings } from '@/components/habits/HabitCategorySettings';

export default function Settings() {
  const { user, signOut } = useAuth();
  const { profile, loading, updateProfile, refetch, calculateZoneBlocks } = useProfile();
  const { isPro } = useSubscription();
  const { trackActivity } = useActivityTracker();
  const [hydrationEnabled, setHydrationEnabled] = useState(profile?.hydration_enabled ?? true);
  const [fastingEnabled, setFastingEnabled] = useState(profile?.fasting_enabled ?? true);
  const [fitnessEnabled, setFitnessEnabled] = useState(profile?.fitness_enabled ?? true);
  const [zoneEnabled, setZoneEnabled] = useState(profile?.zone_enabled ?? true);
  const [ketoEnabled, setKetoEnabled] = useState(profile?.keto_enabled ?? false);
  const [dailyCarbsLimit, setDailyCarbsLimit] = useState(profile?.daily_carbs_limit ?? 30);
  const [customWaterGoal, setCustomWaterGoal] = useState(profile?.daily_water_goal_ml || 2000);
  const [customFastingGoal, setCustomFastingGoal] = useState(profile?.fasting_goal_hours || 16);

  // Apply saved theme on mount
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme') || 'light';
    if (savedTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, []);

  // Check for URL params to auto-navigate to subscription tab and handle success
  const [activeTab, setActiveTab] = useState(() => {
    const hash = window.location.hash.slice(1); // Remove the # symbol
    const urlParams = new URLSearchParams(window.location.search);
    if (hash === 'subscription' || urlParams.get('tab') === 'subscription') {
      return 'subscription';
    }
    return 'profile';
  });

  // Listen for hash changes and handle Stripe success
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.slice(1);
      if (hash === 'subscription') {
        setActiveTab('subscription');
      }
    };

    // Check for successful subscription payment from Stripe
    const urlParams = new URLSearchParams(window.location.search);
    const success = urlParams.get('success');
    const tab = urlParams.get('tab');
    
    if (success === 'true' && tab === 'subscription') {
      setActiveTab('subscription');
      
      // Track sale with Partnero after successful subscription
      if ((window as any).po && user) {
        try {
          (window as any).po('sale', {
            transaction_id: `subscription_${user.id}_${Date.now()}`,
            currency_code: 'EUR',
            amount: 4.99, // Default to monthly plan amount in EUR
            customer_email: user.email
          });
          
          // Call edge function to send sale data to Partnero API
          supabase.functions.invoke('partnero-track-sale', {
            body: {
              customer_email: user.email,
              amount: 4.99,
              currency: 'EUR',
              transaction_id: `subscription_${user.id}_${Date.now()}`
            }
          }).catch(err => console.error('Error tracking sale with Partnero API:', err));
        } catch (err) {
          console.error('Error tracking sale with Partnero Universal:', err);
        }
      }
      
      // Clean up URL
      const newUrl = window.location.pathname + window.location.hash;
      window.history.replaceState({}, '', newUrl);
    }

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [user]);

  // Personal data state
  const [personalData, setPersonalData] = useState({
    display_name: profile?.display_name || '',
    first_name: '',
    last_name: '',
    phone: '',
    height_cm: profile?.height_cm || '',
    weight_kg: profile?.weight_kg || '',
    age: profile?.age || '',
    gender: profile?.gender || '',
    activity_level: profile?.activity_level || '',
    weight_goal: profile?.weight_goal || '',
    daily_calorie_target: profile?.daily_calorie_target || ''
  });

  // Auto-update recommendations when form data changes  
  useEffect(() => {
    // Auto-update recommendations in real-time
    const newWater = calculateRecommendedWater();
    const newFasting = calculateRecommendedFasting();
    const newZoneBlocks = calculateRecommendedZoneBlocks();

    // Only update if user was using the previous recommendation
    if (profile?.daily_water_goal_ml === customWaterGoal) {
      setCustomWaterGoal(newWater);
    }
    if (profile?.fasting_goal_hours === customFastingGoal) {
      setCustomFastingGoal(newFasting);
    }
    if (newZoneBlocks && profile?.daily_blocks === customZoneBlocks) {
      setCustomZoneBlocks(newZoneBlocks);
    }
  }, [personalData.weight_kg, personalData.age, personalData.activity_level]);
  
  // Real-time calorie calculation based on form data
  const { recommendedCalories, dailyCalorieTarget, hasCustomTarget } = useCalorieTarget(personalData);

  // Update local state when profile changes
  useEffect(() => {
    if (profile) {
      setHydrationEnabled(profile.hydration_enabled ?? true);
      setFastingEnabled(profile.fasting_enabled ?? true);
      setFitnessEnabled(profile.fitness_enabled ?? true);
      setZoneEnabled(profile.zone_enabled ?? false);
      setKetoEnabled(profile.keto_enabled ?? false);
      setDailyCarbsLimit(profile.daily_carbs_limit ?? 30);
      setCustomWaterGoal(profile.daily_water_goal_ml || 2000);
      setCustomFastingGoal(profile.fasting_goal_hours || 16);
      setCustomZoneBlocks(profile.daily_blocks || 11);
      setPersonalData({
        display_name: profile.display_name || '',
        first_name: profile.first_name || '',
        last_name: profile.last_name || '',
        phone: profile.phone || '',
        height_cm: profile.height_cm || '',
        weight_kg: profile.weight_kg || '',
        age: profile.age || '',
        gender: profile.gender || '',
        activity_level: profile.activity_level || '',
        weight_goal: profile.weight_goal || '',
        daily_calorie_target: profile.daily_calorie_target || ''
      });
    }
  }, [profile]);

  const handlePersonalDataUpdate = async () => {
    try {
      const updates: any = {
        display_name: personalData.display_name || null,
        first_name: personalData.first_name || null,
        last_name: personalData.last_name || null,
        phone: personalData.phone || null,
        height_cm: personalData.height_cm ? Number(personalData.height_cm) : null,
        weight_kg: personalData.weight_kg ? Number(personalData.weight_kg) : null,
        age: personalData.age ? Number(personalData.age) : null,
        gender: personalData.gender ? (personalData.gender as 'male' | 'female') : null,
        activity_level: personalData.activity_level ? (personalData.activity_level as 'sedentary' | 'light' | 'moderate' | 'very_active' | 'extra_active') : null,
        weight_goal: personalData.weight_goal ? (personalData.weight_goal as 'lose' | 'maintain' | 'gain') : null,
        daily_calorie_target: personalData.daily_calorie_target ? Number(personalData.daily_calorie_target) : null
      };

      // Check if user was using recommended zone blocks and auto-update them
      const currentRecommendedBlocks = calculateRecommendedZoneBlocks();
      let oldRecommendedBlocks = null;
      
      if (profile) {
        oldRecommendedBlocks = calculateRecommendedZoneBlocks({
          height_cm: profile.height_cm || '',
          weight_kg: profile.weight_kg || '',
          age: profile.age || '',
          gender: profile.gender || '',
          activity_level: profile.activity_level || '',
          weight_goal: profile.weight_goal || '',
          display_name: profile.display_name || '',
          first_name: profile.first_name || '',
          last_name: profile.last_name || '',
          phone: profile.phone || '',
          daily_calorie_target: profile.daily_calorie_target || ''
        });
      }
      
      // If user has Zone enabled and current daily_blocks match the old recommended blocks,
      // then they were using recommended blocks and we should update to new recommended blocks
      if (profile?.zone_enabled && 
          currentRecommendedBlocks && 
          oldRecommendedBlocks &&
          profile?.daily_blocks === oldRecommendedBlocks) {
        updates.daily_blocks = currentRecommendedBlocks;
        setCustomZoneBlocks(currentRecommendedBlocks);
      }

      // Check if user was using recommended hydration and auto-update it
      const currentRecommendedWater = calculateRecommendedWater();
      let oldRecommendedWater = null;
      
      if (profile) {
        oldRecommendedWater = calculateRecommendedWater({
          height_cm: profile.height_cm || '',
          weight_kg: profile.weight_kg || '',
          age: profile.age || '',
          gender: profile.gender || '',
          activity_level: profile.activity_level || '',
          weight_goal: profile.weight_goal || '',
          display_name: profile.display_name || '',
          first_name: profile.first_name || '',
          last_name: profile.last_name || '',
          phone: profile.phone || '',
          daily_calorie_target: profile.daily_calorie_target || ''
        });
      }
      
      // If user has hydration enabled and current daily_water_goal_ml matches the old recommended water,
      // then they were using recommended hydration and we should update to new recommended hydration
      if (profile?.hydration_enabled && 
          currentRecommendedWater && 
          oldRecommendedWater &&
          profile?.daily_water_goal_ml === oldRecommendedWater) {
        updates.daily_water_goal_ml = currentRecommendedWater;
        setCustomWaterGoal(currentRecommendedWater);
      }
      
      await updateProfile(updates);
      // Don't show success toast for automatic updates
      if (personalData.display_name || personalData.first_name) { // Only show if it's a manual update
        toast({
          title: "Успех",
          description: "Данните са запазени успешно.",
          variant: "success"
        });
        trackActivity('settings', 'update_profile', 'Обнови профилна информация', {
          has_name: !!(personalData.display_name || personalData.first_name || personalData.last_name),
          has_physical_data: !!(personalData.height_cm || personalData.weight_kg || personalData.age),
          has_preferences: !!(personalData.gender || personalData.activity_level || personalData.weight_goal)
        });
      }
    } catch (error) {
      console.error('Profile update error:', error);
      // Only show error toast if it's a significant error
    }
  };

  const handleSignOut = async () => {
    const loadingToast = toast({
      title: "Излизане...",
      description: "Моля изчакайте",
    });

    try {
      const { error } = await signOut();
      
      if (error) {
        toast({
          title: "Грешка",
          description: "Неуспешно излизане от акаунта",
          variant: "destructive"
        });
      } else {
        toast({
          title: "Успех",
          description: "Излязохте успешно от акаунта",
        });
        // Force reload to clear all state
        setTimeout(() => window.location.href = '/', 100);
      }
    } catch (error) {
      toast({
        title: "Грешка",
        description: "Неочаквана грешка при излизане",
        variant: "destructive"
      });
    }
  };

  const handleSaveHydrationSettings = async () => {
    try {
      await updateProfile({
        daily_water_goal_ml: customWaterGoal,
        hydration_enabled: hydrationEnabled
      });
      toast({
        title: "Успех",
        description: "Настройките за хидратация са запазени",
      });
      trackActivity('settings', 'update_preferences', 'Обнови настройки за хидратация', {
        hydration_enabled: hydrationEnabled,
        daily_water_goal_ml: customWaterGoal
      });
    } catch (error) {
      toast({
        title: "Грешка",
        description: "Грешка при запазване на настройките",
        variant: "destructive",
      });
    }
  };

  const handleSaveFastingSettings = async () => {
    try {
      await updateProfile({
        fasting_goal_hours: customFastingGoal,
        fasting_enabled: fastingEnabled
      });
      toast({
        title: "Успех",
        description: "Настройките за фастинг са запазени",
      });
      trackActivity('settings', 'update_preferences', 'Обнови настройки за фастинг', {
        fasting_enabled: fastingEnabled,
        fasting_goal_hours: customFastingGoal
      });
    } catch (error) {
      toast({
        title: "Грешка",
        description: "Грешка при запазване на настройките",
        variant: "destructive",
      });
    }
  };

  const handleToggleHydration = async (enabled: boolean) => {
    setHydrationEnabled(enabled);
    try {
      await updateProfile({ hydration_enabled: enabled });
      trackActivity('hydration', enabled ? 'enable_hydration' : 'disable_hydration', 
        enabled ? 'Включи проследяване на хидратация' : 'Изключи проследяване на хидратация');
    } catch (error) {
      setHydrationEnabled(!enabled); // Revert on error
    }
  };

  const handleToggleFasting = async (enabled: boolean) => {
    setFastingEnabled(enabled);
    try {
      await updateProfile({ fasting_enabled: enabled });
      trackActivity('fasting', enabled ? 'enable_fasting' : 'disable_fasting', 
        enabled ? 'Включи проследяване на фастинг' : 'Изключи проследяване на фастинг');
    } catch (error) {
      setFastingEnabled(!enabled); // Revert on error
    }
  };

  const handleToggleFitness = async (enabled: boolean) => {
    setFitnessEnabled(enabled);
    try {
      await updateProfile({ fitness_enabled: enabled });
      trackActivity('fitness', enabled ? 'enable_fitness' : 'disable_fitness', 
        enabled ? 'Включи проследяване на фитнес' : 'Изключи проследяване на фитнес');
    } catch (error) {
      setFitnessEnabled(!enabled); // Revert on error
    }
  };

  const handleToggleZone = async (enabled: boolean) => {
    setZoneEnabled(enabled);
    try {
      await updateProfile({ 
        zone_enabled: enabled,
        keto_enabled: false // Ensure mutual exclusion
      });
      setKetoEnabled(false);
      trackActivity('zone', enabled ? 'enable_zone' : 'disable_zone', 
        enabled ? 'Включи Zone диета' : 'Изключи Zone диета');
    } catch (error) {
      setZoneEnabled(!enabled); // Revert on error
    }
  };

  const handleToggleKeto = async (enabled: boolean) => {
    setKetoEnabled(enabled);
    try {
      await updateProfile({ 
        keto_enabled: enabled,
        zone_enabled: false, // Ensure mutual exclusion
        daily_carbs_limit: dailyCarbsLimit
      });
      setZoneEnabled(false);
      trackActivity('settings', enabled ? 'update_profile' : 'update_profile', 
        enabled ? 'Включи Кето диета' : 'Изключи Кето диета');
    } catch (error) {
      setKetoEnabled(!enabled); // Revert on error
    }
  };

  const handleDietModeChange = async (mode: 'calories' | 'zone' | 'keto') => {
    try {
      switch (mode) {
        case 'zone':
          await updateProfile({ 
            zone_enabled: true, 
            keto_enabled: false 
          });
          setZoneEnabled(true);
          setKetoEnabled(false);
          trackActivity('zone', 'enable_zone', 'Включи Zone диета');
          break;
        case 'keto':
          await updateProfile({ 
            zone_enabled: false, 
            keto_enabled: true,
            daily_carbs_limit: dailyCarbsLimit
          });
          setZoneEnabled(false);
          setKetoEnabled(true);
          trackActivity('settings', 'update_profile', 'Включи Кето диета');
          break;
        case 'calories':
        default:
          await updateProfile({ 
            zone_enabled: false, 
            keto_enabled: false 
          });
          setZoneEnabled(false);
          setKetoEnabled(false);
          trackActivity('settings', 'update_profile', 'Изключи диетичните режими');
          break;
      }
    } catch (error) {
      console.error('Error updating diet mode:', error);
      toast({
        title: "Грешка",
        description: "Грешка при промяна на диетичния режим",
        variant: "destructive",
      });
    }
  };

  const getCurrentDietMode = () => {
    if (zoneEnabled) return 'zone';
    if (ketoEnabled) return 'keto';
    return 'calories';
  };

  const calculateRecommendedWater = (formData = personalData) => {
    const weight = typeof formData.weight_kg === 'string' ? parseFloat(formData.weight_kg) : formData.weight_kg;
    if (!weight) return 2000;
    
    // Научна препоръка: 35мл на килограм телесно тегло
    // За активни хора: допълнително 12мл на килограм
    const baseAmount = weight * 35;
    const activityBonus = formData.activity_level === 'very_active' || formData.activity_level === 'extra_active' 
      ? weight * 12 : 0;
    return Math.round(baseAmount + activityBonus);
  };

  const calculateRecommendedFasting = (formData = personalData) => {
    const age = typeof formData.age === 'string' ? parseFloat(formData.age) : formData.age;
    if (!age || !formData.gender) return 16;
    
    // Базирано на научни изследвания за интервален фастинг:
    // - Жените: по-кратки периоди (14-16ч) поради хормонален баланс
    // - Мъжете: могат по-дълги периоди (16-18ч)  
    // - Възраст: по-млади започват с по-кратки периоди
    // - Възрастни над 65: по-консервативен подход
    
    let baseHours = 16;
    
    if (formData.gender === 'female') baseHours = 14;
    if (age < 25) baseHours -= 2; // Млади хора започват с по-малко
    if (age > 65) baseHours = 12; // По-консервативно за възрастни
    
    return Math.max(12, Math.min(18, baseHours)); // Ограничения: 12-18 часа
  };

  const [customZoneBlocks, setCustomZoneBlocks] = useState(profile?.daily_blocks || 11);
  const [theme, setTheme] = useState(() => {
    const savedTheme = localStorage.getItem('theme');
    return savedTheme || 'light';
  });

  const calculateRecommendedZoneBlocks = (formData = personalData) => {
    const height = typeof formData.height_cm === 'string' ? parseFloat(formData.height_cm) : formData.height_cm;
    const weight = typeof formData.weight_kg === 'string' ? parseFloat(formData.weight_kg) : formData.weight_kg;
    const age = typeof formData.age === 'string' ? parseFloat(formData.age) : formData.age;
    
    if (!height || !weight || !age || !formData.gender || !formData.activity_level || !formData.weight_goal) {
      return null;
    }

    const params = {
      height_cm: height,
      weight_kg: weight,
      age: age,
      gender: formData.gender as 'male' | 'female',
      activity_level: formData.activity_level as 'sedentary' | 'light' | 'moderate' | 'very_active' | 'extra_active',
      weight_goal: formData.weight_goal as 'lose' | 'maintain' | 'gain'
    };

    return calculateZoneBlocks(params);
  };

  // Diet settings handlers
  const handleSaveZoneSettings = async () => {
    try {
      await updateProfile({
        daily_blocks: customZoneBlocks,
        zone_enabled: zoneEnabled,
        calculated_at: new Date().toISOString()
      });
      toast({
        title: "Успех",
        description: "Настройките за Zone диета са запазени",
      });
      trackActivity('zone', 'calculate_zone', 'Обнови настройки за Zone диета', {
        daily_blocks: customZoneBlocks,
        zone_enabled: zoneEnabled
      });
    } catch (error) {
      toast({
        title: "Грешка",
        description: "Грешка при запазване на настройките",
        variant: "destructive",
      });
    }
  };

  const handleSaveKetoSettings = async () => {
    try {
      await updateProfile({
        daily_carbs_limit: dailyCarbsLimit,
        keto_enabled: ketoEnabled
      });
      toast({
        title: "Успех",
        description: "Настройките за Кето диета са запазени",
      });
      trackActivity('settings', 'update_profile', 'Обнови настройки за Кето диета', {
        daily_carbs_limit: dailyCarbsLimit,
        keto_enabled: ketoEnabled
      });
    } catch (error) {
      toast({
        title: "Грешка",
        description: "Грешка при запазване на настройките",
        variant: "destructive",
      });
    }
  };

  // Theme handlers
  const handleThemeChange = (newTheme: string) => {
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
    
    if (newTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    
    trackActivity('settings', 'change_theme', `Смени тема на ${newTheme}`, { theme: newTheme });
  };

  return (
    <div className="container mx-auto px-6 py-8 space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-foreground">Настройки</h1>
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => {
              localStorage.clear();
              sessionStorage.clear();
              window.location.reload();
            }}
            className="gap-2"
            title="Изчисти кеш"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleSignOut} 
            className="gap-2"
            title="Изход от акаунта"
          >
            <LogOut className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid grid-cols-3 sm:grid-cols-5 gap-1 h-auto">
          <TabsTrigger value="profile" className="gap-1 flex-col p-2 min-h-[60px]" title="Профил">
            <User className="w-4 h-4" />
            <span className="text-xs">Профил</span>
          </TabsTrigger>
          <TabsTrigger value="theme" className="gap-1 flex-col p-2 min-h-[60px]" title="Тема">
            <Palette className="w-4 h-4" />
            <span className="text-xs">Тема</span>
          </TabsTrigger>
          <TabsTrigger value="subscription" className="gap-1 flex-col p-2 min-h-[60px]" title="Абонамент">
            <Crown className="w-4 h-4" />
            <span className="text-xs">Абонамент</span>
          </TabsTrigger>
          <TabsTrigger value="weight" className="gap-1 flex-col p-2 min-h-[60px]" title="Тегло">
            <Scale className="w-4 h-4" />
            <span className="text-xs">Тегло</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="gap-1 flex-col p-2 min-h-[60px]" title="Известия">
            <Bell className="w-4 h-4" />
            <span className="text-xs">Известия</span>
          </TabsTrigger>
        </TabsList>

        {isPro && (
          <TabsList className="grid grid-cols-2 sm:grid-cols-4 gap-1 h-auto">
            <TabsTrigger value="hydration" className="gap-1 flex-col p-2" title="Хидратация">
              <Droplets className="w-4 h-4" />
              <span className="text-xs">Хидратация</span>
            </TabsTrigger>
            <TabsTrigger value="fasting" className="gap-1 flex-col p-2" title="Фастинг">
              <Clock className="w-4 h-4" />
              <span className="text-xs">Фастинг</span>
            </TabsTrigger>
            <TabsTrigger value="diet" className="gap-1 flex-col p-2" title="Диетичен режим">
              <Target className="w-4 h-4" />
              <span className="text-xs">Диета</span>
            </TabsTrigger>
            <TabsTrigger value="fitness" className="gap-1 flex-col p-2" title="Фитнес">
              <Dumbbell className="w-4 h-4" />
              <span className="text-xs">Фитнес</span>
            </TabsTrigger>
          </TabsList>
        )}

        {!isPro && (
          <TabsList className="grid grid-cols-1 sm:grid-cols-2 gap-1 h-auto opacity-50">
            <TabsTrigger value="hydration" className="gap-1 flex-col p-2 min-h-[60px]" title="Хидратация - Премиум функция" disabled>
              <Droplets className="w-4 h-4" />
              <span className="text-xs">Хидратация</span>
            </TabsTrigger>
            <TabsTrigger value="diet" className="gap-1 flex-col p-2 min-h-[60px]" title="Диетичен режим - Премиум функция" disabled>
              <Target className="w-4 h-4" />
              <span className="text-xs">Диета</span>
            </TabsTrigger>
          </TabsList>
        )}

        <TabsContent value="theme">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Palette className="w-5 h-5" />
                Тема на приложението
              </CardTitle>
              <CardDescription>
                Изберете светла или тъмна тема според предпочитанията си.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Card 
                  className={`cursor-pointer transition-all ${theme === 'light' ? 'ring-2 ring-primary' : 'hover:bg-muted/50'}`}
                  onClick={() => handleThemeChange('light')}
                >
                  <CardContent className="p-4 flex items-center gap-3">
                    <Sun className="w-8 h-8 text-orange-500" />
                    <div>
                      <h3 className="font-medium">Светла тема</h3>
                      <p className="text-sm text-muted-foreground">Светъл фон с тъмен текст</p>
                    </div>
                    {theme === 'light' && (
                      <div className="ml-auto w-4 h-4 rounded-full bg-primary"></div>
                    )}
                  </CardContent>
                </Card>
                
                <Card 
                  className={`cursor-pointer transition-all ${theme === 'dark' ? 'ring-2 ring-primary' : 'hover:bg-muted/50'}`}
                  onClick={() => handleThemeChange('dark')}
                >
                  <CardContent className="p-4 flex items-center gap-3">
                    <Moon className="w-8 h-8 text-blue-500" />
                    <div>
                      <h3 className="font-medium">Тъмна тема</h3>
                      <p className="text-sm text-muted-foreground">Тъмен фон със светъл текст</p>
                    </div>
                    {theme === 'dark' && (
                      <div className="ml-auto w-4 h-4 rounded-full bg-primary"></div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="subscription">
          <SubscriptionCard />
        </TabsContent>

        <TabsContent value="notifications">
          <NotificationSettings />
        </TabsContent>

        <TabsContent value="profile">
          <Card className="w-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-5 h-5" />
                Профил
              </CardTitle>
              <CardDescription>
                Основна информация за вашия акаунт
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-sm font-medium">Имейл</Label>
                <p className="text-sm text-muted-foreground break-all">{user?.email}</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="first-name">Първо име</Label>
                  <Input
                    id="first-name"
                    value={personalData.first_name}
                    onChange={(e) => setPersonalData({...personalData, first_name: e.target.value})}
                    placeholder="Въведете първото си име"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="last-name">Фамилия</Label>
                  <Input
                    id="last-name"
                    value={personalData.last_name}
                    onChange={(e) => setPersonalData({...personalData, last_name: e.target.value})}
                    placeholder="Въведете фамилията си"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">Телефон</Label>
                  <Input
                    id="phone"
                    value={personalData.phone}
                    onChange={(e) => setPersonalData({...personalData, phone: e.target.value})}
                    placeholder="Въведете телефонния си номер"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="profile-gender">Пол</Label>
                  <Select value={personalData.gender} onValueChange={(value) => setPersonalData({...personalData, gender: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Изберете пол" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Мъж</SelectItem>
                      <SelectItem value="female">Жена</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="pt-4">
                <Button onClick={handlePersonalDataUpdate} className="w-full">
                  Запази личните данни
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>


        <TabsContent value="diet" className="w-full overflow-hidden">
          <Card className="w-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5" />
                Диетичен режим
              </CardTitle>
              <CardDescription>
                Изберете как да проследявате храненето си
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <input 
                    type="radio" 
                    id="diet-calories" 
                    name="diet-mode" 
                    value="calories"
                    checked={getCurrentDietMode() === 'calories'}
                    onChange={() => handleDietModeChange('calories')}
                    className="w-4 h-4"
                  />
                  <Label htmlFor="diet-calories" className="flex-1 cursor-pointer">
                    <div>
                      <div className="font-medium">Калории (по подразбиране)</div>
                      <div className="text-sm text-muted-foreground">
                        Проследяване на калории и основни хранителни вещества
                      </div>
                    </div>
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <input 
                    type="radio" 
                    id="diet-zone" 
                    name="diet-mode" 
                    value="zone"
                    checked={getCurrentDietMode() === 'zone'}
                    onChange={() => handleDietModeChange('zone')}
                    className="w-4 h-4"
                  />
                  <Label htmlFor="diet-zone" className="flex-1 cursor-pointer">
                    <div>
                      <div className="font-medium">Zone диета</div>
                      <div className="text-sm text-muted-foreground">
                        Балансиране в съотношение 30:40:30 (протеини:въглехидрати:мазнини)
                      </div>
                    </div>
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <input 
                    type="radio" 
                    id="diet-keto" 
                    name="diet-mode" 
                    value="keto"
                    checked={getCurrentDietMode() === 'keto'}
                    onChange={() => handleDietModeChange('keto')}
                    className="w-4 h-4"
                  />
                  <Label htmlFor="diet-keto" className="flex-1 cursor-pointer">
                    <div>
                      <div className="font-medium">Кето диета</div>
                      <div className="text-sm text-muted-foreground">
                        Ниско въглехидратна, високо мазнини диета за кетоза
                      </div>
                    </div>
                  </Label>
                </div>
              </div>

              {zoneEnabled && (
                <div className="space-y-4 p-4 border rounded-lg bg-muted/30">
                  <h4 className="font-medium flex items-center gap-2">
                    <Calculator className="w-4 h-4" />
                    Zone диета настройки
                  </h4>
                  <div className="space-y-2">
                    <Label htmlFor="zone-blocks">Дневни блокове</Label>
                    <Input
                      id="zone-blocks"
                      type="number"
                      min="8"
                      max="30"
                      step="1"
                      value={customZoneBlocks}
                      onChange={(e) => setCustomZoneBlocks(Number(e.target.value))}
                      className="w-full"
                    />
                  </div>
                  
                  {calculateRecommendedZoneBlocks() && (
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="text-sm text-muted-foreground">
                        Препоръчано за вас: {calculateRecommendedZoneBlocks()} блока
                        <Button
                          variant="link"
                          size="sm"
                          className="p-0 h-auto ml-2"
                          onClick={() => setCustomZoneBlocks(calculateRecommendedZoneBlocks()!)}
                        >
                          Използвай
                        </Button>
                      </p>
                    </div>
                  )}
                  
                  <Button onClick={handleSaveZoneSettings} size="sm" className="w-full">
                    Запази Zone настройките
                  </Button>
                </div>
              )}

              {ketoEnabled && (
                <div className="space-y-4 p-4 border rounded-lg bg-muted/30">
                  <h4 className="font-medium flex items-center gap-2">
                    <Target className="w-4 h-4" />
                    Кето диета настройки
                  </h4>
                  <div className="space-y-2">
                    <Label htmlFor="daily-carbs-limit">Дневен лимит въглехидрати (г)</Label>
                    <Select 
                      value={dailyCarbsLimit.toString()} 
                      onValueChange={(value) => setDailyCarbsLimit(Number(value))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="20">20г - Строго кето</SelectItem>
                        <SelectItem value="25">25г - Класическо кето</SelectItem>
                        <SelectItem value="30">30г - Стандартно кето</SelectItem>
                        <SelectItem value="40">40г - Умерено кето</SelectItem>
                        <SelectItem value="50">50г - Либерално кето</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-sm text-muted-foreground">
                      При кето диета се стремете към 70-75% калории от мазнини, 
                      20-25% от протеини и 5-10% от въглехидрати.
                    </p>
                  </div>
                  
                  <Button onClick={handleSaveKetoSettings} size="sm" className="w-full">
                    Запази Кето настройките
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="weight" className="w-full overflow-hidden">
          <div className="w-full overflow-x-auto">
            <WeightTracker />
          </div>
        </TabsContent>

        <TabsContent value="hydration" className="w-full overflow-hidden">
          <Card className="w-full">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Droplets className="w-5 h-5 text-blue-500" />
                  Хидратация
                </CardTitle>
                <Switch
                  id="hydration-enabled-header"
                  checked={hydrationEnabled}
                  onCheckedChange={handleToggleHydration}
                />
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-sm text-muted-foreground">
                <p>
                  Проследяването на хидратация помага за поддържане на оптимален воден баланс.
                  Препоръчва се 35мл вода на килограм телесно тегло дневно.
                </p>
              </div>
              
              {hydrationEnabled && (
                <div className="space-y-4">
                  <Separator />
                  <div className="space-y-2">
                    <Label htmlFor="water-goal">Дневна цел (мл)</Label>
                    <Input
                      id="water-goal"
                      type="number"
                      min="500"
                      max="5000"
                      step="250"
                      value={customWaterGoal}
                      onChange={(e) => setCustomWaterGoal(Number(e.target.value))}
                      className="w-full"
                    />
                  </div>
                  
                  {profile?.weight_kg && (
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="text-sm text-muted-foreground">
                        Препоръчано за вас: {calculateRecommendedWater()}мл
                        <Button
                          variant="link"
                          size="sm"
                          className="p-0 h-auto ml-2"
                          onClick={() => setCustomWaterGoal(calculateRecommendedWater())}
                        >
                          Използвай
                        </Button>
                      </p>
                    </div>
                  )}
                  
                  <Button onClick={handleSaveHydrationSettings} size="sm" className="w-full">
                    Запази настройките
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {isPro && (
          <TabsContent value="fasting" className="w-full overflow-hidden">
            <Card className="w-full">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-purple-500" />
                  Фастинг
                </CardTitle>
                <Switch
                  id="fasting-enabled-header"
                  checked={fastingEnabled}
                  onCheckedChange={handleToggleFasting}
                />
              </div>
            </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-sm text-muted-foreground">
                  <p>
                    Интервалният фастинг може да подобри метаболизма и общото здраве.
                    Препоръчва се започване с 12-16 часа в зависимост от пола и възрастта.
                  </p>
                </div>
                
               {fastingEnabled && (
                 <div className="space-y-4">
                   <Separator />
                   <div className="space-y-2">
                     <Label htmlFor="fasting-goal">Целеви часове по подразбиране</Label>
                     <Input
                       id="fasting-goal"
                       type="number"
                       min="8"
                       max="48"
                       value={customFastingGoal}
                       onChange={(e) => setCustomFastingGoal(Number(e.target.value))}
                       className="w-full"
                     />
                   </div>
                   
                   {profile?.age && profile?.gender && (
                     <div className="p-3 bg-muted rounded-lg">
                       <p className="text-sm text-muted-foreground">
                         Препоръчано за вас: {calculateRecommendedFasting()}ч
                         <Button
                           variant="link"
                           size="sm"
                           className="p-0 h-auto ml-2"
                           onClick={() => setCustomFastingGoal(calculateRecommendedFasting())}
                         >
                           Използвай
                         </Button>
                       </p>
                     </div>
                   )}
                   
                   <Button onClick={handleSaveFastingSettings} size="sm" className="w-full">
                     Запази настройките
                   </Button>
                 </div>
               )}
              </CardContent>
            </Card>
          </TabsContent>
        )}

        <TabsContent value="fitness" className="w-full overflow-hidden">
          <Card className="w-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Dumbbell className="w-5 h-5" />
                Фитнес
              </CardTitle>
              <CardDescription>
                Физически параметри и настройки за тренировки
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {isPro ? (
                <>
                  {/* Fitness Tracking Toggle */}
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Активирай фитнес проследяването</Label>
                      <p className="text-sm text-muted-foreground">
                        Включете или изключете проследяването на фитнес активностите
                      </p>
                    </div>
                    <Switch
                      checked={fitnessEnabled}
                      onCheckedChange={handleToggleFitness}
                    />
                  </div>
                  
                  <Separator />
                </>
              ) : (
                <>
                  <div className="text-center py-8">
                    <p className="text-muted-foreground mb-4">
                      Фитнес проследяването е налично само за Pro потребители
                    </p>
                    <Button onClick={() => setActiveTab('subscription')}>
                      Преминете към Pro
                    </Button>
                  </div>
                  
                  <Separator />
                </>
              )}

              {/* Physical Data - Always shown */}
              <div className="space-y-4">
                <h4 className="font-medium">Физически данни</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="height">Височина (см)</Label>
                    <Input
                      id="height"
                      type="number"
                      min="100"
                      max="250"
                      value={personalData.height_cm}
                      onChange={(e) => setPersonalData({...personalData, height_cm: e.target.value})}
                      placeholder="например 175"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="weight">Тегло (кг)</Label>
                    <Input
                      id="weight"
                      type="number"
                      min="30"
                      max="200"
                      step="0.1"
                      value={personalData.weight_kg}
                      onChange={(e) => setPersonalData({...personalData, weight_kg: e.target.value})}
                      placeholder="например 70.5"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="age">Възраст (години)</Label>
                    <Input
                      id="age"
                      type="number"
                      min="10"
                      max="120"
                      value={personalData.age}
                      onChange={(e) => setPersonalData({...personalData, age: e.target.value})}
                      placeholder="например 30"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="activity">Ниво на активност</Label>
                    <Select value={personalData.activity_level} onValueChange={(value) => setPersonalData({...personalData, activity_level: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Изберете ниво на активност" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sedentary">
                          <div className="flex flex-col">
                            <span>Седящ начин</span>
                            <span className="text-xs text-muted-foreground">Офис работа, малко или никаква физическа активност</span>
                          </div>
                        </SelectItem>
                        <SelectItem value="light">
                          <div className="flex flex-col">
                            <span>Лека активност</span>
                            <span className="text-xs text-muted-foreground">Лека тренировка 1-3 дни седмично</span>
                          </div>
                        </SelectItem>
                        <SelectItem value="moderate">
                          <div className="flex flex-col">
                            <span>Умерена активност</span>
                            <span className="text-xs text-muted-foreground">Умерена тренировка 3-5 дни седмично</span>
                          </div>
                        </SelectItem>
                        <SelectItem value="very_active">
                          <div className="flex flex-col">
                            <span>Много активен</span>
                            <span className="text-xs text-muted-foreground">Тежка тренировка 6-7 дни седмично</span>
                          </div>
                        </SelectItem>
                        <SelectItem value="extra_active">
                          <div className="flex flex-col">
                            <span>Изключително активен</span>
                            <span className="text-xs text-muted-foreground">Много тежка физическа работа или тренировки 2 пъти дневно</span>
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="weight-goal">Цел за теглото</Label>
                  <Select value={personalData.weight_goal} onValueChange={(value) => setPersonalData({...personalData, weight_goal: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Изберете цел" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="lose">Отслабване</SelectItem>
                      <SelectItem value="maintain">Поддържане</SelectItem>
                      <SelectItem value="gain">Качване на тегло</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Separator />

              {/* Calorie Information - Always shown */}
              <div className="space-y-4">
                <h4 className="font-medium">Дневни калории</h4>
                <div className="bg-muted p-4 rounded-lg">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Препоръчани</p>
                      <p className="text-2xl font-bold text-primary">
                        {recommendedCalories ? `${recommendedCalories}` : 'N/A'}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Актуални</p>
                      <p className="text-2xl font-bold">
                        {dailyCalorieTarget ? `${dailyCalorieTarget}` : 'N/A'}
                      </p>
                      {hasCustomTarget && (
                        <p className="text-xs text-muted-foreground">Персонализирани</p>
                      )}
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="calorie-target">Персонализирана дневна цел (калории)</Label>
                  <Input
                    id="calorie-target"
                    type="number"
                    min="800"
                    max="5000"
                    value={personalData.daily_calorie_target}
                    onChange={(e) => setPersonalData({...personalData, daily_calorie_target: e.target.value})}
                    placeholder={recommendedCalories ? `Препоръка: ${recommendedCalories}` : "например 2000"}
                  />
                  <p className="text-xs text-muted-foreground">
                    Оставете празно за автоматично изчисление
                  </p>
                  {recommendedCalories && (
                    <Button
                      type="button"
                      variant="outline" 
                      size="sm"
                      onClick={() => setPersonalData({...personalData, daily_calorie_target: recommendedCalories.toString()})}
                    >
                      Използвай препоръчаната ({recommendedCalories})
                    </Button>
                  )}
                </div>
              </div>

              <Button onClick={handlePersonalDataUpdate} size="sm" className="w-full">
                Запази данните
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
