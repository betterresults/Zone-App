export interface CompressionOptions {
  maxWidth?: number;
  maxHeight?: number;
  quality?: number;
  maxSizeKB?: number;
}

const DEFAULT_OPTIONS: CompressionOptions = {
  maxWidth: 1200,
  maxHeight: 1200,
  quality: 0.8,
  maxSizeKB: 800, // 800KB max
};

/**
 * Compresses an image from dataURL or File
 * @param input - dataURL string or File object
 * @param options - compression options
 * @returns compressed dataURL
 */
export async function compressImage(
  input: string | File, 
  options: CompressionOptions = {}
): Promise<string> {
  const opts = { ...DEFAULT_OPTIONS, ...options };
  
  return new Promise((resolve, reject) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();
    
    if (!ctx) {
      reject(new Error('Canvas not supported'));
      return;
    }
    
    img.onload = () => {
      // Calculate new dimensions
      let { width, height } = img;
      
      // Maintain aspect ratio while respecting max dimensions
      if (width > opts.maxWidth! || height > opts.maxHeight!) {
        const ratio = Math.min(opts.maxWidth! / width, opts.maxHeight! / height);
        width = Math.round(width * ratio);
        height = Math.round(height * ratio);
      }
      
      // Set canvas size
      canvas.width = width;
      canvas.height = height;
      
      // Draw and compress
      ctx.drawImage(img, 0, 0, width, height);
      
      // Try different quality levels to meet size requirements
      let quality = opts.quality!;
      let dataUrl = canvas.toDataURL('image/jpeg', quality);
      
      // Estimate size (rough calculation: base64 length * 0.75)
      let estimatedSizeKB = (dataUrl.length - 'data:image/jpeg;base64,'.length) * 0.75 / 1024;
      
      // Reduce quality if size is too large
      while (estimatedSizeKB > opts.maxSizeKB! && quality > 0.1) {
        quality -= 0.1;
        dataUrl = canvas.toDataURL('image/jpeg', quality);
        estimatedSizeKB = (dataUrl.length - 'data:image/jpeg;base64,'.length) * 0.75 / 1024;
      }
      
      console.log(`Image compressed: ${img.width}x${img.height} → ${width}x${height}, ~${Math.round(estimatedSizeKB)}KB, quality: ${quality.toFixed(1)}`);
      resolve(dataUrl);
    };
    
    img.onerror = () => reject(new Error('Failed to load image'));
    
    // Handle different input types
    if (typeof input === 'string') {
      img.src = input;
    } else {
      const reader = new FileReader();
      reader.onload = (e) => {
        img.src = e.target?.result as string;
      };
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsDataURL(input);
    }
  });
}

/**
 * Converts dataURL to File object
 */
export function dataURLToFile(dataURL: string, filename: string = 'compressed-image.jpg'): File {
  const arr = dataURL.split(',');
  const mime = arr[0].match(/:(.*?);/)![1];
  const bstr = atob(arr[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  
  return new File([u8arr], filename, { type: mime });
}