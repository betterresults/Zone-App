import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CategoryManager } from './CategoryManager';
import { Settings } from 'lucide-react';

export function HabitCategorySettings() {
  const [showCategoryManager, setShowCategoryManager] = useState(false);

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Категории на навици
          </CardTitle>
          <CardDescription>
            Управлявайте категориите за вашите навици и задачи
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button onClick={() => setShowCategoryManager(true)}>
            Управление на категории
          </Button>
        </CardContent>
      </Card>

      <CategoryManager
        open={showCategoryManager}
        onOpenChange={setShowCategoryManager}
      />
    </>
  );
}