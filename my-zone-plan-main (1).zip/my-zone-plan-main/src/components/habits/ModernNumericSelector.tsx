import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface ModernNumericSelectorProps {
  value: number;
  unit: string;
  onValueChange: (value: number) => void;
  onUnitChange: (unit: string) => void;
  quickOptions: { value: number; label: string }[];
  units: { value: string; label: string }[];
  className?: string;
}

export function ModernNumericSelector({
  value,
  unit,
  onValueChange,
  onUnitChange,
  quickOptions,
  units,
  className = ""
}: ModernNumericSelectorProps) {
  return (
    <div className={`space-y-3 ${className}`}>
      {/* Quick selection buttons */}
      <div className="grid grid-cols-4 gap-2">
        {quickOptions.map((option, index) => (
          <Button
            key={`${option.value}-${option.label}-${index}`}
            type="button"
            variant={value === option.value ? "default" : "outline"}
            onClick={() => onValueChange(option.value)}
            className="h-10 text-sm font-medium"
          >
            {option.label}
          </Button>
        ))}
      </div>
      
      {/* Custom input */}
      <div className="flex gap-2 items-center">
        <Input
          type="number"
          min={1}
          value={value}
          onChange={(e) => onValueChange(Math.max(1, Number(e.target.value || 1)))}
          className="flex-1"
          placeholder="Друго..."
        />
        <Select value={unit} onValueChange={onUnitChange}>
          <SelectTrigger className="w-32">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {units.map((unitOption) => (
              <SelectItem key={unitOption.value} value={unitOption.value}>
                {unitOption.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}