import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

type RepeatType = 'no_repeat' | 'daily' | 'weekly' | 'monthly' | 'weekend' | 'custom';

type CustomBase = 'daily' | 'weekly' | 'monthly';

interface FrequencyInlineProps {
  repeatType: RepeatType;
  onSelectType: (type: RepeatType) => void;
  customBase: CustomBase;
  onChangeCustomBase: (base: CustomBase) => void;
  interval: number;
  onChangeInterval: (n: number) => void;
  // New props for weekly selection
  selectedWeekDays?: string[];
  onChangeWeekDays?: (days: string[]) => void;
  // New props for monthly days selection
  selectedMonthDays?: number[];
  onChangeMonthDays?: (days: number[]) => void;
  // Close callback
  onClose?: () => void;
}

const WEEKDAYS = [
  { key: 'monday', label: 'Пн', fullLabel: 'Понеделник' },
  { key: 'tuesday', label: 'Вт', fullLabel: 'Вторник' },
  { key: 'wednesday', label: 'Ср', fullLabel: 'Сряда' },
  { key: 'thursday', label: 'Чт', fullLabel: 'Четвъртък' },
  { key: 'friday', label: 'Пт', fullLabel: 'Петък' },
  { key: 'saturday', label: 'Сб', fullLabel: 'Събота' },
  { key: 'sunday', label: 'Нд', fullLabel: 'Неделя' },
];

export default function FrequencyInline({
  repeatType,
  onSelectType,
  customBase,
  onChangeCustomBase,
  interval,
  onChangeInterval,
  selectedWeekDays = [],
  onChangeWeekDays,
  selectedMonthDays = [],
  onChangeMonthDays,
  onClose,
}: FrequencyInlineProps) {
  const options: { key: RepeatType; label: string }[] = [
    { key: 'daily', label: 'Ежедневно' },
    { key: 'weekly', label: 'Седмично' },
    { key: 'monthly', label: 'Месечно' },
    { key: 'weekend', label: 'Уикенди' },
    { key: 'custom', label: 'Персонализирано' },
  ];

  const toggleWeekDay = (day: string) => {
    if (!onChangeWeekDays) return;
    const newDays = selectedWeekDays.includes(day)
      ? selectedWeekDays.filter(d => d !== day)
      : [...selectedWeekDays, day];
    onChangeWeekDays(newDays);
  };

  const toggleMonthDay = (day: number) => {
    if (!onChangeMonthDays) return;
    const newDays = selectedMonthDays.includes(day)
      ? selectedMonthDays.filter(d => d !== day)
      : [...selectedMonthDays, day];
    onChangeMonthDays(newDays);
  };

  const getFrequencyLabel = () => {
    const option = options.find(o => o.key === repeatType);
    return option?.label || 'Изберете честота';
  };

  return (
    <div className="space-y-3">
      {/* Main frequency selector */}
      <div className="grid gap-1">
        {options.map((option) => (
          <Button
            key={option.key}
            type="button"
            variant={repeatType === option.key ? "default" : "outline"}
            size="sm"
            onClick={() => {
              onSelectType(option.key);
              // Only close immediately for options that don't need sub-selection
              if (option.key !== 'custom' && option.key !== 'weekly' && option.key !== 'monthly') {
                onClose?.();
              }
            }}
            className="justify-start"
          >
            {option.label}
          </Button>
        ))}
      </div>

      {/* Weekly day selection */}
      {repeatType === 'weekly' && onChangeWeekDays && (
        <div className="space-y-2">
          <div className="flex flex-wrap gap-2">
            {WEEKDAYS.map((day) => (
              <Button
                key={day.key}
                type="button"
                variant={selectedWeekDays.includes(day.key) ? 'default' : 'outline'}
                size="sm"
                onClick={() => toggleWeekDay(day.key)}
                className="h-8 px-2"
              >
                {day.label}
              </Button>
            ))}
          </div>
          <Button
            type="button"
            onClick={onClose}
            className="w-full"
            size="sm"
          >
            Готово
          </Button>
        </div>
      )}

      {/* Monthly day selection */}
      {repeatType === 'monthly' && onChangeMonthDays && (
        <div className="space-y-2">
          <div className="grid grid-cols-7 gap-1">
            {Array.from({ length: 31 }, (_, i) => i + 1).map((day) => (
              <Button
                key={day}
                type="button"
                variant={selectedMonthDays.includes(day) ? 'default' : 'outline'}
                size="sm"
                onClick={() => toggleMonthDay(day)}
                className="h-8 w-8 p-0 text-xs"
              >
                {day}
              </Button>
            ))}
          </div>
          <Button
            type="button"
            onClick={onClose}
            className="w-full"
            size="sm"
          >
            Готово
          </Button>
        </div>
      )}

      {/* Custom frequency settings */}
      {repeatType === 'custom' && (
        <div className="space-y-3">
          <div className="flex flex-wrap gap-2">
            {(['daily','weekly','monthly'] as const).map((base) => (
              <Button
                key={base}
                type="button"
                variant={base === customBase ? 'default' : 'outline'}
                size="sm"
                onClick={() => onChangeCustomBase(base)}
              >
                {base === 'daily' ? 'Дневно' : base === 'weekly' ? 'Седмично' : 'Месечно'}
              </Button>
            ))}
          </div>
          
          <div className="flex items-center gap-3">
            <span className="text-sm">Всеки</span>
            <Input
              type="number"
              min={1}
              value={interval}
              onChange={(e) => onChangeInterval(Math.max(1, Number(e.target.value || 1)))}
              className="w-20 text-center"
            />
            <span className="text-sm">{customBase === 'daily' ? (interval === 1 ? 'ден' : 'дни') : customBase === 'weekly' ? (interval === 1 ? 'седмица' : 'седмици') : (interval === 1 ? 'месец' : 'месеца')}</span>
          </div>
          
          {/* Custom weekly - show day selection */}
          {customBase === 'weekly' && onChangeWeekDays && (
            <div className="flex flex-wrap gap-2">
              {WEEKDAYS.map((day) => (
                <Button
                  key={day.key}
                  type="button"
                  variant={selectedWeekDays.includes(day.key) ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => toggleWeekDay(day.key)}
                  className="h-8 px-2"
                >
                  {day.label}
                </Button>
              ))}
            </div>
          )}
          
          {/* Custom monthly - show day selection */}
          {customBase === 'monthly' && onChangeMonthDays && (
            <div className="grid grid-cols-7 gap-1">
              {Array.from({ length: 31 }, (_, i) => i + 1).map((day) => (
                <Button
                  key={day}
                  type="button"
                  variant={selectedMonthDays.includes(day) ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => toggleMonthDay(day)}
                  className="h-8 w-8 p-0 text-xs"
                >
                  {day}
                </Button>
              ))}
            </div>
          )}

          <Button
            type="button"
            onClick={onClose}
            className="w-full"
            size="sm"
          >
            Готово
          </Button>
        </div>
      )}
    </div>
  );
}
