import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useHabitSettings } from "@/hooks/useHabitSettings";

interface TimePickerInlineProps {
  value?: string; // HH:mm (24h)
  onChange: (val: string) => void;
}

function to24h(h: number, m: number) {
  const hh = String(h).padStart(2, "0");
  const mm = String(m).padStart(2, "0");
  return `${hh}:${mm}`;
}

function from24h(time?: string) {
  if (!time) return { h: 9, m: 0 };
  const [hs, ms] = time.split(":");
  const h = parseInt(hs, 10) || 9;
  const m = parseInt(ms, 10) || 0;
  return { h, m };
}

export default function TimePickerInline({ value, onChange }: TimePickerInlineProps) {
  const { settings } = useHabitSettings();
  const initial = useMemo(() => from24h(value), [value]);
  const [selectedHour, setSelectedHour] = useState<number>(initial.h);
  const [selectedMinute, setSelectedMinute] = useState<number>(initial.m);
  const [showHourPicker, setShowHourPicker] = useState(false);
  const [showMinutePicker, setShowMinutePicker] = useState(false);
  const [customMinute, setCustomMinute] = useState<string>('');

  // Get allowed hours from settings
  const allowedHours = useMemo(() => {
    const startHour = parseInt(settings.day_start_time.split(':')[0]);
    const endHour = parseInt(settings.day_end_time.split(':')[0]);
    const hours = [];
    
    for (let h = startHour; h <= endHour; h++) {
      hours.push(h);
    }
    
    return hours;
  }, [settings.day_start_time, settings.day_end_time]);

  const handleHourChange = (newHour: number) => {
    setSelectedHour(newHour);
    onChange(to24h(newHour, selectedMinute));
  };

  const handleMinuteChange = (newMinute: number) => {
    const safeMinute = Math.max(0, Math.min(59, newMinute));
    setSelectedMinute(safeMinute);
    onChange(to24h(selectedHour, safeMinute));
  };

  const handleCustomMinute = () => {
    const minute = parseInt(customMinute, 10);
    if (!isNaN(minute) && minute >= 0 && minute <= 59) {
      handleMinuteChange(minute);
      setCustomMinute('');
      setShowMinutePicker(false);
    }
  };

  const adjustHour = (delta: number) => {
    const currentIndex = allowedHours.indexOf(selectedHour);
    let newIndex = currentIndex + delta;
    if (newIndex < 0) newIndex = allowedHours.length - 1;
    if (newIndex >= allowedHours.length) newIndex = 0;
    handleHourChange(allowedHours[newIndex]);
  };

  const adjustMinute = (delta: number) => {
    const newMinute = selectedMinute + delta;
    if (newMinute < 0) {
      handleMinuteChange(59);
    } else if (newMinute > 59) {
      handleMinuteChange(0);
    } else {
      handleMinuteChange(newMinute);
    }
  };

  return (
    <div className="space-y-4">
      <div className="text-center">
        <div className="text-2xl sm:text-3xl font-bold mb-2 flex items-center justify-center gap-1">
          <div className="flex flex-col items-center">
            <button 
              className="px-1 py-0.5 text-xs bg-muted/50 rounded hover:bg-muted"
              onClick={() => adjustHour(1)}
            >
              ▲
            </button>
            <Popover open={showHourPicker} onOpenChange={setShowHourPicker}>
              <PopoverTrigger asChild>
                <button 
                  className="px-2 py-1 rounded hover:bg-muted/30" 
                  onClick={() => setShowHourPicker(true)}
                >
                  {String(selectedHour).padStart(2, "0")}
                </button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-2" align="center">
                <div className="grid grid-cols-4 gap-1 max-h-40 overflow-y-auto">
                  {allowedHours.map((hour) => (
                    <Button
                      key={hour}
                      type="button"
                      variant={selectedHour === hour ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        handleHourChange(hour);
                        setShowHourPicker(false);
                      }}
                      className="w-12 h-8 text-sm"
                    >
                      {hour.toString().padStart(2, '0')}
                    </Button>
                  ))}
                </div>
              </PopoverContent>
            </Popover>
            <button 
              className="px-1 py-0.5 text-xs bg-muted/50 rounded hover:bg-muted"
              onClick={() => adjustHour(-1)}
            >
              ▼
            </button>
          </div>
          <span className="text-muted-foreground mx-1">:</span>
          <div className="flex flex-col items-center">
            <button 
              className="px-1 py-0.5 text-xs bg-muted/50 rounded hover:bg-muted"
              onClick={() => adjustMinute(1)}
            >
              ▲
            </button>
            <Popover open={showMinutePicker} onOpenChange={setShowMinutePicker}>
              <PopoverTrigger asChild>
                <button 
                  className="px-2 py-1 rounded hover:bg-muted/30" 
                  onClick={() => setShowMinutePicker(true)}
                >
                  {String(selectedMinute).padStart(2, "0")}
                </button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-3" align="center">
                <div className="space-y-3">
                  <div className="flex flex-wrap gap-1">
                    {[0, 5, 10, 15, 30, 45].map((minute) => (
                      <Button
                        key={minute}
                        type="button"
                        variant={selectedMinute === minute ? "default" : "outline"}
                        size="sm"
                        onClick={() => {
                          handleMinuteChange(minute);
                          setShowMinutePicker(false);
                        }}
                        className="w-12 h-8 text-sm"
                      >
                        {minute.toString().padStart(2, '0')}
                      </Button>
                    ))}
                  </div>
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      min={0}
                      max={59}
                      value={customMinute}
                      onChange={(e) => setCustomMinute(e.target.value)}
                      className="w-16 text-center text-sm"
                      placeholder="00"
                    />
                    <Button
                      type="button"
                      size="sm"
                      onClick={handleCustomMinute}
                      disabled={!customMinute || isNaN(parseInt(customMinute, 10))}
                      className="bg-green-600 hover:bg-green-700 text-white"
                    >
                      ✓
                    </Button>
                  </div>
                </div>
              </PopoverContent>
            </Popover>
            <button 
              className="px-1 py-0.5 text-xs bg-muted/50 rounded hover:bg-muted"
              onClick={() => adjustMinute(-1)}
            >
              ▼
            </button>
          </div>
        </div>
      </div>

      <div className="flex justify-center">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => onChange(to24h(selectedHour, selectedMinute))}
        >
          Запази
        </Button>
      </div>
    </div>
  );
}