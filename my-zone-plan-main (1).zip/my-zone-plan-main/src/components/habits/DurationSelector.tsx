import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";

interface DurationSelectorProps {
  value?: number; // in minutes
  onChange: (minutes: number | undefined) => void;
  onClose?: () => void;
}

const QUICK_OPTIONS = [
  { label: '10 минути', value: 10 },
  { label: '15 минути', value: 15 },
  { label: '30 минути', value: 30 },
  { label: '1 час', value: 60 },
  { label: '1.5 часа', value: 90 },
  { label: '2 часа', value: 120 },
];

export default function DurationSelector({ value, onChange, onClose }: DurationSelectorProps) {
  const [customValue, setCustomValue] = useState(value && !QUICK_OPTIONS.find(opt => opt.value === value) ? value : 15);
  const [customUnit, setCustomUnit] = useState<'minutes' | 'hours'>('minutes');
  const [showCustom, setShowCustom] = useState(false);

  const handleQuickOption = (minutes: number) => {
    onChange(minutes);
    onClose?.();
  };

  const handleCustomSave = () => {
    if (customValue && customValue > 0) {
      const minutes = customUnit === 'hours' ? customValue * 60 : customValue;
      onChange(minutes);
      onClose?.();
    }
  };

  const handleClear = () => {
    onChange(undefined);
    onClose?.();
  };

  const formatDuration = (minutes: number) => {
    if (minutes < 60) {
      return `${minutes} мин`;
    } else if (minutes % 60 === 0) {
      return `${minutes / 60} ч`;
    } else {
      const hours = Math.floor(minutes / 60);
      const mins = minutes % 60;
      return `${hours}ч ${mins}мин`;
    }
  };

  return (
    <div className="space-y-3">
      {/* Quick options */}
      <div className="grid gap-2">
        {QUICK_OPTIONS.map((option) => (
          <Button
            key={option.value}
            type="button"
            variant={value === option.value ? "default" : "outline"}
            size="sm"
            onClick={() => handleQuickOption(option.value)}
            className="justify-start"
          >
            {option.label}
          </Button>
        ))}
        
        {/* Custom option toggle */}
        <Button
          type="button"
          variant={showCustom ? "default" : "outline"}
          size="sm"
          onClick={() => setShowCustom(!showCustom)}
          className="justify-start"
        >
          Персонализирано
        </Button>
      </div>

      {/* Custom input */}
      {showCustom && (
        <div className="space-y-3 p-3 bg-muted/50 rounded-lg">
          <div className="flex gap-2 items-center">
            <Input
              type="number"
              min={1}
              max={customUnit === 'hours' ? 24 : 1440}
              value={customValue}
              onChange={(e) => setCustomValue(Number(e.target.value) || 0)}
              className="w-20 text-center"
              placeholder="0"
            />
            <Select value={customUnit} onValueChange={(unit: 'minutes' | 'hours') => setCustomUnit(unit)}>
              <SelectTrigger className="w-24">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="minutes">мин</SelectItem>
                <SelectItem value="hours">часа</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex gap-2">
            <Button
              type="button"
              size="sm"
              onClick={handleCustomSave}
              disabled={!customValue || customValue <= 0}
              className="flex-1"
            >
              Запази
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setShowCustom(false)}
              className="flex-1"
            >
              Отказ
            </Button>
          </div>
        </div>
      )}

      {/* Clear option */}
      <Button
        type="button"
        variant="ghost"
        size="sm"
        onClick={handleClear}
        className="w-full justify-start text-muted-foreground"
      >
        Без продължителност
      </Button>
    </div>
  );
}