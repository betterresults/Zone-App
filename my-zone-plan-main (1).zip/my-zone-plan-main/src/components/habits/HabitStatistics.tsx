import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useHabitStats } from '@/hooks/useHabitStats';
import { CalendarDays, TrendingUp, Target, Flame, CheckCircle, XCircle, Minus } from 'lucide-react';
import { format } from 'date-fns';

export function HabitStatistics() {
  const [selectedDate] = useState(new Date());
  const { dailyStats, weeklySummary, monthlySummary, streakData, isLoading } = useHabitStats(selectedDate);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="pb-2">
                <div className="h-4 bg-muted rounded w-3/4"></div>
              </CardHeader>
              <CardContent>
                <div className="h-8 bg-muted rounded w-1/2 mb-2"></div>
                <div className="h-3 bg-muted rounded w-full"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const getStatusColor = (status: 'completed' | 'missed' | 'skipped') => {
    switch (status) {
      case 'completed':
        return 'bg-success/20 text-success border-success/20';
      case 'missed':
        return 'bg-destructive/20 text-destructive border-destructive/20';
      case 'skipped':
        return 'bg-warning/20 text-warning border-warning/20';
      default:
        return 'bg-muted/20 text-muted-foreground border-muted/20';
    }
  };

  const getStatusIcon = (status: 'completed' | 'missed' | 'skipped') => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4" />;
      case 'missed':
        return <XCircle className="w-4 h-4" />;
      case 'skipped':
        return <Minus className="w-4 h-4" />;
      default:
        return null;
    }
  };

  const getStatusText = (status: 'completed' | 'missed' | 'skipped') => {
    switch (status) {
      case 'completed':
        return 'Завършено';
      case 'missed':
        return 'Пропуснато';
      case 'skipped':
        return 'Прескочено';
      default:
        return status;
    }
  };

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Седмичен прогрес</CardTitle>
            <CalendarDays className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {weeklySummary?.completionRate.toFixed(0) || 0}%
            </div>
            <p className="text-xs text-muted-foreground">
              {weeklySummary?.completedHabits || 0} от {weeklySummary?.totalHabits || 0} завършени
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Месечен прогрес</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {monthlySummary?.completionRate.toFixed(0) || 0}%
            </div>
            <p className="text-xs text-muted-foreground">
              {monthlySummary?.completedHabits || 0} от {monthlySummary?.totalHabits || 0} завършени
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Най-дълга поредица</CardTitle>
            <Flame className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {Math.max(...(streakData?.map(s => s.longestStreak) || [0]))} дни
            </div>
            <p className="text-xs text-muted-foreground">
              Най-добър резултат досега
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Daily Stats for Selected Date */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5" />
            Дневна статистика
          </CardTitle>
          <CardDescription>
            Резултати за {format(selectedDate, 'dd.MM.yyyy')}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {dailyStats.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              Няма данни за избраната дата
            </p>
          ) : (
            <div className="space-y-3">
              {dailyStats.map((stat: any) => (
                <div key={stat.id} className="flex items-center justify-between p-3 rounded-lg border">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: stat.habits?.color || '#8B5CF6' }}
                    />
                    <span className="font-medium">{stat.habits?.name}</span>
                    <Badge variant="outline" className="text-xs">
                      {stat.habits?.habit_type === 'task' ? 'Задача' : 'Навик'}
                    </Badge>
                  </div>
                  <Badge className={getStatusColor(stat.status)}>
                    <div className="flex items-center gap-1">
                      {getStatusIcon(stat.status)}
                      {getStatusText(stat.status)}
                    </div>
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Streak Information */}
      {streakData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Flame className="w-5 h-5" />
              Текущи поредици
            </CardTitle>
            <CardDescription>
              Последователни дни на завършване
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {streakData
                .filter(streak => streak.currentStreak > 0)
                .map((streak) => (
                  <div key={streak.habitId} className="p-3 rounded-lg border bg-card">
                    <div className="text-2xl font-bold text-primary">
                      {streak.currentStreak}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      дни поредица
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Рекорд: {streak.longestStreak} дни
                    </p>
                  </div>
                ))}
            </div>
            {streakData.filter(streak => streak.currentStreak > 0).length === 0 && (
              <p className="text-muted-foreground text-center py-4">
                Няма активни поредици в момента
              </p>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}