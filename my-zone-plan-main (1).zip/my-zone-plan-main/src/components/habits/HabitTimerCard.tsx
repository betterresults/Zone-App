import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Play, Pause, Square, Clock, Target } from 'lucide-react';
import { useHabitSessions } from '@/hooks/useHabitSessions';
import type { Habit } from '@/hooks/useHabits';
import { format, differenceInSeconds } from 'date-fns';
import { cn } from '@/lib/utils';

interface HabitTimerCardProps {
  habit: Habit;
  className?: string;
}

export function HabitTimerCard({ habit, className }: HabitTimerCardProps) {
  const { 
    getActiveSession, 
    startSessionMutation, 
    endSessionMutation,
    parseDurationFromDescription 
  } = useHabitSessions();
  
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const activeSession = getActiveSession(habit.id);
  const targetDurationMinutes = parseDurationFromDescription(habit.description);
  
  // Update elapsed time every second for active sessions
  useEffect(() => {
    if (!activeSession) {
      setElapsedSeconds(0);
      return;
    }

    const updateElapsed = () => {
      const startTime = new Date(activeSession.started_at);
      const now = new Date();
      setElapsedSeconds(differenceInSeconds(now, startTime));
    };

    // Update immediately
    updateElapsed();
    
    // Update every second
    const interval = setInterval(updateElapsed, 1000);
    return () => clearInterval(interval);
  }, [activeSession]);

  const handleStart = () => {
    startSessionMutation.mutate({
      habitId: habit.id,
      targetDurationMinutes
    });
  };

  const handleStop = () => {
    if (activeSession) {
      endSessionMutation.mutate(activeSession.id);
    }
  };

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  const getProgress = () => {
    if (!targetDurationMinutes || elapsedSeconds === 0) return 0;
    return Math.min((elapsedSeconds / (targetDurationMinutes * 60)) * 100, 100);
  };

  const isOverTarget = targetDurationMinutes && elapsedSeconds > targetDurationMinutes * 60;

  return (
    <Card className={cn("w-full", className)}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div 
              className="w-3 h-3 rounded-full" 
              style={{ backgroundColor: habit.color }}
            />
            <h3 className="font-medium text-sm truncate max-w-[150px]">
              {habit.name}
            </h3>
          </div>
          
          <Badge 
            variant={activeSession ? "default" : "secondary"}
            className="text-xs"
          >
            {activeSession ? "Активен" : "Неактивен"}
          </Badge>
        </div>

        {/* Timer Display */}
        <div className="text-center mb-4">
          <div className="text-2xl font-mono font-bold mb-1">
            {formatTime(elapsedSeconds)}
          </div>
          
          {targetDurationMinutes && (
            <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground mb-2">
              <Target className="w-3 h-3" />
              <span>Цел: {targetDurationMinutes} мин</span>
              {isOverTarget && (
                <span className="text-orange-500 font-medium">
                  (+{Math.floor((elapsedSeconds - targetDurationMinutes * 60) / 60)} мин)
                </span>
              )}
            </div>
          )}
          
          {targetDurationMinutes && (
            <Progress 
              value={getProgress()} 
              className="h-2"
            />
          )}
        </div>

        {/* Controls */}
        <div className="flex gap-2">
          {!activeSession ? (
            <Button 
              onClick={handleStart}
              disabled={startSessionMutation.isPending}
              size="sm" 
              className="flex-1 gap-2"
            >
              <Play className="w-4 h-4" />
              Започни
            </Button>
          ) : (
            <Button 
              onClick={handleStop}
              disabled={endSessionMutation.isPending}
              size="sm" 
              className="flex-1 gap-2"
              variant="outline"
            >
              <Square className="w-4 h-4" />
              Спри
            </Button>
          )}
        </div>

        {/* Description */}
        {habit.description && (
          <div className="mt-3 text-xs text-muted-foreground border-t pt-2">
            {habit.description}
          </div>
        )}
      </CardContent>
    </Card>
  );
}