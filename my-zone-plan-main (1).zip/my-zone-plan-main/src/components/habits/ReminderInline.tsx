import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useEffect, useMemo, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface ReminderInlineProps {
  minutes: number;
  onChange: (minutes: number) => void;
}

type Unit = 'minutes' | 'hours' | 'days';

const UNITS: { key: Unit; label: string; factor: number }[] = [
  { key: 'minutes', label: 'Минути', factor: 1 },
  { key: 'hours', label: 'Часове', factor: 60 },
  { key: 'days', label: 'Дни', factor: 1440 }
];

export default function ReminderInline({ minutes, onChange }: ReminderInlineProps) {
  const initialUnit: Unit = useMemo(() => {
    if (minutes >= 1440) return 'days';
    if (minutes >= 60) return 'hours';
    return 'minutes';
  }, [minutes]);

  const [unit, setUnit] = useState<Unit>(initialUnit);
  const [value, setValue] = useState<number>(() => {
    const factor = UNITS.find(u => u.key === initialUnit)!.factor;
    return Math.round((minutes || 0) / factor);
  });

  // keep local state in sync when parent changes externally
  useEffect(() => {
    const u = minutes >= 1440 ? 'days' : minutes >= 60 ? 'hours' : 'minutes';
    setUnit(u as Unit);
    const factor = UNITS.find(x => x.key === (u as Unit))!.factor;
    setValue(Math.round((minutes || 0) / factor));
  }, [minutes]);

  const commit = (v = value, u: Unit = unit) => {
    const factor = UNITS.find(x => x.key === u)!.factor;
    const newMinutes = Math.max(0, v) * factor;
    onChange(newMinutes);
  };

  const changeBy = (delta: number) => {
    const next = Math.max(0, value + delta);
    setValue(next);
    commit(next, unit);
  };

  return (
    <div className="mt-1">
      <div className="flex items-center justify-center gap-2">
        <Button type="button" variant="outline" size="sm" onClick={() => changeBy(-1)} aria-label="Минус" className="h-8 w-8 p-0">
          <ChevronLeft className="w-3 h-3" />
        </Button>
        <Input
          type="number"
          min={0}
          value={Number.isNaN(value) ? 0 : value}
          onChange={(e) => {
            const v = parseInt(e.target.value, 10);
            const safe = isNaN(v) ? 0 : v;
            setValue(safe);
            commit(safe, unit);
          }}
          className="h-9 w-16 text-center text-sm font-semibold"
        />
        <Button type="button" variant="outline" size="sm" onClick={() => changeBy(1)} aria-label="Плюс" className="h-8 w-8 p-0">
          <ChevronRight className="w-3 h-3" />
        </Button>

        <Select
          value={unit}
          onValueChange={(val) => {
            const u = val as Unit;
            setUnit(u);
            commit(value, u);
          }}
        >
          <SelectTrigger className="w-24 h-9 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="z-50">
            {UNITS.map((u) => (
              <SelectItem key={u.key} value={u.key} className="text-xs">{u.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}

