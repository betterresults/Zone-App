import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Plus, Trash2, Edit, Palette } from 'lucide-react';
import { useHabitCategories, useCreateHabitCategory, useUpdateHabitCategory, useDeleteHabitCategory } from '@/hooks/useHabitCategories';
import { useHabits } from '@/hooks/useHabits';

const COLORS = [
  '#EF4444', '#F97316', '#EAB308', '#22C55E', '#3B82F6', '#8B5CF6', '#EC4899', '#6B7280'
];

const ICONS = [
  'Circle', 'Heart', 'Dumbbell', 'BookOpen', 'Coffee', 'Brain', 'Target', 'Star'
];

interface CategoryManagerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CategoryManager({ open, onOpenChange }: CategoryManagerProps) {
  const { data: categories = [], isLoading } = useHabitCategories();
  const { habits } = useHabits();
  const createCategory = useCreateHabitCategory();
  const updateCategory = useUpdateHabitCategory();
  const deleteCategory = useDeleteHabitCategory();
  
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [newCategoryColor, setNewCategoryColor] = useState('#8B5CF6');
  const [newCategoryIcon, setNewCategoryIcon] = useState('Circle');
  const [showAddForm, setShowAddForm] = useState(false);

  const handleCreate = async () => {
    if (!newCategoryName.trim()) return;
    
    await createCategory.mutateAsync({
      name: newCategoryName.trim(),
      color: newCategoryColor,
      icon: newCategoryIcon,
      is_default: false,
    });
    
    setNewCategoryName('');
    setNewCategoryColor('#8B5CF6');
    setNewCategoryIcon('Circle');
    setShowAddForm(false);
  };

  const handleUpdate = async (id: string, name: string, color: string) => {
    await updateCategory.mutateAsync({ id, name: name.trim(), color });
    setEditingId(null);
  };

  const handleDelete = async (id: string) => {
    const category = categories.find(c => c.id === id);
    if (!category) return;
    
    // Check if category is being used by any habits
    const habitsUsingCategory = habits?.filter(h => h.category === category.name) || [];
    if (habitsUsingCategory.length > 0) {
      // Show error message instead of deleting
      return;
    }
    
    await deleteCategory.mutateAsync(id);
  };

  const isCategoryInUse = (categoryName: string) => {
    return habits?.some(h => h.category === categoryName) || false;
  };

  if (isLoading) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent>
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Управление на категории</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Existing Categories */}
          <div className="space-y-2">
            {categories.map((category) => (
              <div key={category.id} className="flex items-center justify-between p-3 rounded-lg border">
                <div className="flex items-center gap-3">
                  <div
                    className="w-4 h-4 rounded-full"
                    style={{ backgroundColor: category.color }}
                  />
                  {editingId === category.id ? (
                    <Input
                      defaultValue={category.name}
                      className="h-8 w-32"
                      onBlur={(e) => handleUpdate(category.id, e.target.value, category.color)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          handleUpdate(category.id, e.currentTarget.value, category.color);
                        }
                        if (e.key === 'Escape') {
                          setEditingId(null);
                        }
                      }}
                      autoFocus
                    />
                  ) : (
                    <span className="font-medium">{category.name}</span>
                  )}
                  {category.is_default && (
                    <Badge variant="secondary" className="text-xs">По подразбиране</Badge>
                  )}
                </div>
                
                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setEditingId(category.id)}
                    className="h-8 w-8 p-0"
                  >
                    <Edit className="w-3 h-3" />
                  </Button>
                  
                  {!category.is_default && !isCategoryInUse(category.name) && (
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Потвърждение</AlertDialogTitle>
                          <AlertDialogDescription>
                            Сигурни ли сте, че искате да изтриете категория "{category.name}"?
                            Това действие не може да бъде отменено.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Отказ</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => handleDelete(category.id)}
                            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          >
                            Изтрий
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  )}
                  
                  {isCategoryInUse(category.name) && !category.is_default && (
                    <div className="text-xs text-muted-foreground">
                      Използва се
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Add New Category */}
          {showAddForm ? (
            <div className="p-3 rounded-lg border-2 border-dashed border-muted-foreground/25 space-y-3">
              <Input
                placeholder="Име на категория"
                value={newCategoryName}
                onChange={(e) => setNewCategoryName(e.target.value)}
                maxLength={50}
              />
              
              <div className="flex flex-wrap gap-2">
                {COLORS.map((color) => (
                  <button
                    key={color}
                    type="button"
                    className={`w-6 h-6 rounded-full border-2 transition-all ${
                      newCategoryColor === color ? 'border-gray-900 scale-110' : 'border-gray-200'
                    }`}
                    style={{ backgroundColor: color }}
                    onClick={() => setNewCategoryColor(color)}
                  />
                ))}
              </div>
              
              <div className="flex gap-2">
                <Button onClick={handleCreate} disabled={!newCategoryName.trim()}>
                  Създай
                </Button>
                <Button variant="ghost" onClick={() => {
                  setShowAddForm(false);
                  setNewCategoryName('');
                  setNewCategoryColor('#8B5CF6');
                }}>
                  Отказ
                </Button>
              </div>
            </div>
          ) : (
            <Button
              variant="ghost"
              onClick={() => setShowAddForm(true)}
              className="w-full border-2 border-dashed border-muted-foreground/25 h-12"
            >
              <Plus className="w-4 h-4 mr-2" />
              Добави нова категория
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
