import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export type FrequencyType = 'one_time' | 'daily' | 'weekdays' | 'weekends' | 'weekly' | 'custom_weekly' | 'monthly' | 'custom';

interface EnhancedFrequencySelectorProps {
  selectedFrequency: FrequencyType;
  onFrequencyChange: (frequency: FrequencyType) => void;
  selectedDays: string[];
  onDaysChange: (days: string[]) => void;
  customInterval?: number;
  onCustomIntervalChange?: (interval: number) => void;
}

const WEEKDAYS = [
  { key: 'monday', label: 'Пн' },
  { key: 'tuesday', label: 'Вт' },
  { key: 'wednesday', label: 'Ср' },
  { key: 'thursday', label: 'Чт' },
  { key: 'friday', label: 'Пт' },
  { key: 'saturday', label: 'Сб' },
  { key: 'sunday', label: 'Нд' },
];

export default function EnhancedFrequencySelector({
  selectedFrequency,
  onFrequencyChange,
  selectedDays,
  onDaysChange,
  customInterval = 1,
  onCustomIntervalChange
}: EnhancedFrequencySelectorProps) {
  const [showCustomOptions, setShowCustomOptions] = useState(false);

  const toggleDay = (day: string) => {
    if (selectedDays.includes(day)) {
      onDaysChange(selectedDays.filter(d => d !== day));
    } else {
      onDaysChange([...selectedDays, day]);
    }
  };

  const quickOptions = [
    {
      type: 'one_time' as FrequencyType,
      label: 'Еднократно',
      description: 'Само веднъж',
      action: () => {
        onFrequencyChange('one_time');
        onDaysChange([]);
      }
    },
    {
      type: 'daily' as FrequencyType,
      label: 'Всеки ден',
      description: 'Всички дни от седмицата',
      action: () => {
        onFrequencyChange('daily');
        onDaysChange(['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']);
      }
    },
    {
      type: 'weekdays' as FrequencyType,
      label: 'Работни дни',
      description: 'Понеделник - Петък',
      action: () => {
        onFrequencyChange('weekdays');
        onDaysChange(['monday', 'tuesday', 'wednesday', 'thursday', 'friday']);
      }
    },
    {
      type: 'weekends' as FrequencyType,
      label: 'Уикенди',
      description: 'Събота и Неделя',
      action: () => {
        onFrequencyChange('weekends');
        onDaysChange(['saturday', 'sunday']);
      }
    },
    {
      type: 'weekly' as FrequencyType,
      label: 'Седмично',
      description: 'Веднъж седмично',
      action: () => {
        onFrequencyChange('weekly');
        // Default to Monday if no days selected
        if (selectedDays.length === 0) {
          onDaysChange(['monday']);
        }
      }
    }
  ];

  const customOptions = [
    {
      type: 'custom_weekly' as FrequencyType,
      label: 'Всеки N седмици',
      description: 'На избрани дни, всеки няколко седмици'
    },
    {
      type: 'monthly' as FrequencyType,
      label: 'Месечно',
      description: 'Веднъж в месеца'
    },
    {
      type: 'custom' as FrequencyType,
      label: 'Персонализирано',
      description: 'Избери точни дни'
    }
  ];

  return (
    <div className="space-y-3">
      {/* Quick options */}
      <div className="grid gap-2">
        {quickOptions.map((option) => (
          <Button
            key={option.type}
            type="button"
            variant={selectedFrequency === option.type ? "default" : "outline"}
            className="justify-start h-auto p-3"
            onClick={option.action}
          >
            <div className="text-left">
              <div className="font-medium">{option.label}</div>
              <div className="text-xs text-muted-foreground">{option.description}</div>
            </div>
          </Button>
        ))}
      </div>

      {/* Toggle for custom options */}
      <Button
        type="button"
        variant="ghost"
        size="sm"
        onClick={() => setShowCustomOptions(!showCustomOptions)}
        className="w-full text-muted-foreground hover:text-foreground"
      >
        {showCustomOptions ? 'Скрий допълнителни опции' : 'Покажи още опции'}
      </Button>

      {/* Custom options */}
      {showCustomOptions && (
        <div className="space-y-2 pt-2 border-t">
          {customOptions.map((option) => (
            <Button
              key={option.type}
              type="button"
              variant={selectedFrequency === option.type ? "default" : "outline"}
              className="justify-start h-auto p-3 w-full"
              onClick={() => {
                onFrequencyChange(option.type);
                if (option.type === 'custom' && selectedDays.length === 0) {
                  onDaysChange(['monday']);
                }
              }}
            >
              <div className="text-left">
                <div className="font-medium">{option.label}</div>
                <div className="text-xs text-muted-foreground">{option.description}</div>
              </div>
            </Button>
          ))}
        </div>
      )}

      {/* Day selector for weekly, custom_weekly, and custom types */}
      {(selectedFrequency === 'weekly' || selectedFrequency === 'custom_weekly' || selectedFrequency === 'custom') && (
        <div className="space-y-3 pt-3 border-t">
          <p className="text-sm font-medium">Избери дни от седмицата:</p>
          <div className="grid grid-cols-7 gap-1">
            {WEEKDAYS.map((day) => (
              <button
                key={day.key}
                type="button"
                onClick={() => toggleDay(day.key)}
                className={cn(
                  "p-2 text-xs rounded-md border transition-colors",
                  selectedDays.includes(day.key)
                    ? "bg-primary text-primary-foreground border-primary"
                    : "border-border hover:bg-muted"
                )}
              >
                {day.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Interval selector for custom_weekly */}
      {selectedFrequency === 'custom_weekly' && onCustomIntervalChange && (
        <div className="space-y-3 pt-3 border-t">
          <p className="text-sm font-medium">Повтаряй всеки:</p>
          <div className="flex items-center gap-3">
            <Input
              type="number"
              min="1"
              max="52"
              value={customInterval}
              onChange={(e) => onCustomIntervalChange(Math.max(1, Number(e.target.value)))}
              className="w-20 text-center"
            />
            <span className="text-sm">
              {customInterval === 1 ? 'седмица' : customInterval < 5 ? 'седмици' : 'седмици'}
            </span>
          </div>
        </div>
      )}
    </div>
  );
}