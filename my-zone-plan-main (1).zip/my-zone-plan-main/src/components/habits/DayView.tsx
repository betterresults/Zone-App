import { useState } from 'react';
import { format, addDays, subDays, isToday } from 'date-fns';
import { bg } from 'date-fns/locale';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, Circle, Calendar, Plus, ChevronLeft, ChevronRight, Clock, Dumbbell, ChevronDown, ChevronUp, Trash2, Play, Edit } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import type { Habit, HabitCompletion } from '@/hooks/useHabits';
import { AddHabitDialog } from './AddHabitDialog';

interface DayViewProps {
  selectedDate: Date;
  setSelectedDate: (date: Date) => void;
  displayHabits: Habit[];
  isLoadingHabits: boolean;
  filteredHabits: Habit[];
  completions: HabitCompletion[];
  isHabitActiveOnDay: (habit: Habit, date: Date) => boolean;
  isHabitCompleted: (habitId: string, date: Date, completions: HabitCompletion[]) => boolean;
  handleToggleHabit: (habitId: string, date: Date) => Promise<void>;
  setShowAddHabit: (show: boolean) => void;
  expandedHabit: string | null;
  setExpandedHabit: (id: string | null) => void;
  dayStart: string;
  dayEnd: string;
  onDeleteHabit: (habitId: string) => void;
  parseDurationFromDescription: (description?: string) => number | undefined;
  setFullscreenTimerHabit: (habit: Habit | null) => void;
  hideHeader?: boolean;
}

export function DayView({
  selectedDate,
  setSelectedDate,
  displayHabits,
  isLoadingHabits,
  filteredHabits,
  completions,
  isHabitActiveOnDay,
  isHabitCompleted,
  handleToggleHabit,
  setShowAddHabit,
  expandedHabit,
  setExpandedHabit,
  dayStart,
  dayEnd,
  onDeleteHabit,
  parseDurationFromDescription,
  setFullscreenTimerHabit,
  hideHeader = false
}: DayViewProps) {
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [clickedTime, setClickedTime] = useState<string | null>(null);
  const [editingHabit, setEditingHabit] = useState<Habit | null>(null);
  
  const handleHabitClick = (habit: Habit, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingHabit(habit);
    setShowAddDialog(true);
  };

  const handleAddHabit = (time: string) => {
    setEditingHabit(null);
    setClickedTime(time);
    setShowAddDialog(true);
  };
  
  const goToPreviousDay = () => {
    setSelectedDate(subDays(selectedDate, 1));
  };

  const goToNextDay = () => {
    setSelectedDate(addDays(selectedDate, 1));
  };

  const goToToday = () => {
    setSelectedDate(new Date());
  };

  // Generate time slots based on dayStart and dayEnd
  const generateTimeSlots = () => {
    const slots = [];
    const startHour = parseInt(dayStart.split(':')[0]);
    const endHour = parseInt(dayEnd.split(':')[0]);
    
    for (let hour = startHour; hour <= endHour; hour++) {
      slots.push(`${hour.toString().padStart(2, '0')}:00`);
    }
    return slots;
  };

  const timeSlots = generateTimeSlots();
  // Use all displayHabits since they're already filtered by isHabitActiveOnDay in the parent component
  const activeHabits = displayHabits;

  const getHabitDetails = (habit: Habit) => {
    if (habit.category === 'fitness' && habit.name?.startsWith('Тренировка')) {
      return {
        type: 'workout',
        exercises: [
          'Загрявка - 10 мин',
          'Основна тренировка - 30 мин', 
          'Стречинг - 10 мин'
        ]
      };
    }
    
    return {
      type: 'simple',
      description: habit.description
    };
  };

  if (isLoadingHabits) {
    return <div>Зареждане...</div>;
  }

  return (
    <div className="space-y-3 md:space-y-6 overflow-x-hidden w-full">
      {/* Header */}
      {!hideHeader && (
        <Card className="w-full">
          <CardHeader className="pb-2 md:pb-3 px-3 md:px-6 py-3 md:py-6">
            <div className="flex items-center justify-between gap-2">
              <Button variant="ghost" size="sm" onClick={goToPreviousDay} className="h-8 w-8 p-0">
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <div className="text-center flex-1 overflow-hidden">
                <CardTitle className="text-sm md:text-lg flex items-center justify-center gap-2 truncate">
                  <span className="truncate">
                    {format(selectedDate, 'EEEE, dd MMMM yyyy', { locale: bg })}
                  </span>
                  {isToday(selectedDate) && (
                    <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary/80 font-medium whitespace-nowrap">
                      днес
                    </span>
                  )}
                </CardTitle>
              </div>
              <Button variant="ghost" size="sm" onClick={goToNextDay} className="h-8 w-8 p-0">
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </CardHeader>
        </Card>
      )}

      {/* Time-based schedule */}
      <Card className="w-full">
        <CardContent className="px-2 sm:px-3 md:px-6 pb-2 md:pb-6 pt-3 md:pt-6">
          <div className="space-y-0.5 md:space-y-2 max-w-full overflow-x-hidden">
            {timeSlots.map((timeSlot) => {
              // Group by hour: show habits whose hour matches this slot
              const slotHour = timeSlot.slice(0, 2);
              const timeHabits = activeHabits.filter(habit => {
                const tod = habit.time_of_day || '';
                if (!tod) return false;
                const habitHour = tod.slice(0, 2);
                return habitHour === slotHour;
              });
              
              return (
                <div key={timeSlot} className="flex gap-2 md:gap-3 max-w-full items-center min-h-[32px] md:min-h-[40px]">
                  <div className="w-10 md:w-12 flex-shrink-0">
                    <div className="text-xs md:text-sm font-medium text-muted-foreground">
                      {timeSlot}
                    </div>
                  </div>
                  
                  <div className="flex-1 min-w-0 overflow-x-hidden">
                    {timeHabits.length > 0 ? (
                      timeHabits.map((habit) => {
                        const isCompleted = isHabitCompleted(habit.id, selectedDate, completions);
                        const details = getHabitDetails(habit);
                        const isExpanded = expandedHabit === habit.id;
                        
                        return (
                          <div 
                            key={habit.id}
                            className={`p-2 md:p-3 rounded-lg border transition-colors max-w-full ${
                              isCompleted 
                                ? 'border-primary bg-primary/5' 
                                : 'border-muted hover:border-primary/50'
                            }`}
                          >
                            <div className="flex items-center gap-2 md:gap-3 min-w-0 overflow-x-hidden">
                              {parseDurationFromDescription(habit.description) ? (
                                // Timer habit - show play button
                                 <Button
                                   variant="ghost"
                                   size="sm"
                                   onClick={(e) => {
                                     e.stopPropagation();
                                     setFullscreenTimerHabit(habit);
                                   }}
                                   className="h-6 w-6 p-0 text-primary hover:bg-primary/10 flex-shrink-0"
                                 >
                                   <Play className="w-3 h-3" />
                                 </Button>
                              ) : (
                                // Regular habit - show checkbox
                                <div 
                                  className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors cursor-pointer ${
                                    isCompleted 
                                      ? 'bg-primary border-primary' 
                                      : 'border-muted-foreground hover:border-primary'
                                  }`}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleToggleHabit(habit.id, selectedDate);
                                  }}
                                >
                                  {isCompleted && <div className="w-2 h-2 bg-white rounded-full" />}
                                </div>
                              )}
                              
                              <div className="flex-1 min-w-0 overflow-hidden">
                                <div className="text-sm font-medium truncate">{habit.name}</div>
                                <div className="flex items-center justify-between gap-2 mt-1">
                                  <div className="flex items-center gap-2">
                                    {habit.time_of_day && (
                                      <div className="flex items-center gap-1">
                                        <Clock className="w-4 h-4 text-primary" />
                                        <span className="text-lg font-bold text-foreground tracking-wide">
                                          {habit.time_of_day.slice(0, 5)}
                                        </span>
                                      </div>
                                    )}
                                    {parseDurationFromDescription(habit.description) && (
                                      <span className="text-xs text-primary bg-primary/10 px-1.5 py-0.5 rounded">
                                        {parseDurationFromDescription(habit.description)}мин
                                      </span>
                                    )}
                                  </div>
                                  
                                  {/* Action buttons */}
                                  <div className="flex items-center gap-1 flex-shrink-0">
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleHabitClick(habit, e);
                                      }}
                                      className="h-7 w-7 p-0 hover:bg-primary/10"
                                    >
                                      <Edit className="w-3 h-3" />
                                    </Button>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        onDeleteHabit(habit.id);
                                      }}
                                      className="h-7 w-7 p-0 hover:bg-destructive/10 text-destructive"
                                    >
                                      <Trash2 className="w-3 h-3" />
                                    </Button>
                                    {details.type === 'workout' && (
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          setExpandedHabit(isExpanded ? null : habit.id);
                                        }}
                                        className="h-7 w-7 p-0"
                                      >
                                        {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                                      </Button>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </div>
                            
                            {/* Show workout details for workout habits */}
                            {details.type === 'workout' && isExpanded && (
                              <div className="mt-2 pl-4 md:pl-5">
                                <div className="flex items-center gap-2 text-xs md:text-sm font-medium text-muted-foreground mb-2 md:mb-3">
                                  <Dumbbell className="w-3 md:w-4 h-3 md:h-4" />
                                  Програма за тренировка
                                </div>
                                {details.exercises?.map((exercise, index) => (
                                  <div key={index} className="flex items-center gap-2 md:gap-3 p-1.5 md:p-2 rounded-md bg-muted/50 mb-1">
                                    <Circle className="w-3 md:w-4 h-3 md:h-4 text-muted-foreground" />
                                    <span className="text-xs md:text-sm">{exercise}</span>
                                  </div>
                                ))}
                              </div>
                            )}
                            
                            {/* Only show description for non-fitness habits */}
                            {details.description && habit.category !== 'fitness' && (
                              <div className="mt-2 md:mt-3 pl-4 md:pl-5 text-xs md:text-sm text-muted-foreground">
                                {details.description}
                              </div>
                            )}
                          </div>
                        );
                      })
                    ) : (
                      <button
                        onClick={() => handleAddHabit(timeSlot)}
                        className="flex items-center justify-center w-6 h-6 md:w-8 md:h-8 text-muted-foreground hover:text-foreground hover:bg-muted/50 rounded-md border border-dashed border-muted-foreground/30 hover:border-muted-foreground/60 transition-colors"
                      >
                        <Plus className="h-3 w-3 md:h-4 md:w-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Legacy view for habits without start_time */}
      {filteredHabits.length === 0 ? (
        <Card>
          <CardContent className="p-4 md:p-6 text-center">
            <Calendar className="w-12 md:w-16 h-12 md:h-16 mx-auto mb-3 md:mb-4 text-muted-foreground" />
            <p className="text-sm md:text-base text-muted-foreground mb-3 md:mb-4">Няма създадени навици</p>
            <Button onClick={() => setShowAddHabit(true)} size="sm" className="text-xs md:text-sm">
              <Plus className="w-3 md:w-4 h-3 md:h-4 mr-2" />
              Добави първия си навик
            </Button>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Show habits without time */}
          {activeHabits.filter(habit => !habit.time_of_day).length > 0 && (
            <Card>
              <CardHeader className="px-3 md:px-6 py-3 md:py-6">
                <CardTitle className="text-base md:text-xl">Други навици</CardTitle>
              </CardHeader>
              <CardContent className="px-3 md:px-6">
                <div className="space-y-2 md:space-y-3">
                  {activeHabits.filter(habit => !habit.time_of_day).map((habit) => {
                    const isCompleted = isHabitCompleted(habit.id, selectedDate, completions);
                    const details = getHabitDetails(habit);
                    const isExpanded = expandedHabit === habit.id;
                    
                    return (
                      <div 
                        key={habit.id}
                        className={`p-2 md:p-4 rounded-lg border transition-colors cursor-pointer ${
                          isCompleted 
                            ? 'border-primary bg-primary/5' 
                            : 'border-muted hover:border-primary/50'
                        }`}
                        onClick={(e) => handleHabitClick(habit, e)}
                      >
                        <div className="flex items-center gap-2 md:gap-3 min-w-0">
                          <div 
                            className={`w-5 md:w-6 h-5 md:h-6 rounded-full border-2 flex items-center justify-center transition-colors ${
                              isCompleted 
                                ? 'bg-primary border-primary' 
                                : 'border-muted-foreground hover:border-primary'
                            }`}
                          >
                            {isCompleted && <div className="w-2 md:w-3 h-2 md:h-3 bg-white rounded-full" />}
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 min-w-0">
                              <div 
                                className="w-2 md:w-3 h-2 md:h-3 rounded-full" 
                                style={{ backgroundColor: habit.color }}
                              />
                              <span className="text-sm md:text-base font-medium truncate block">{habit.name}</span>
                              {habit.time_of_day && (
                                <div className="flex items-center gap-1 text-xs md:text-sm text-muted-foreground shrink-0">
                                  <Clock className="w-3 h-3" />
                                  {(habit.time_of_day || '').slice(0,5)}
                                </div>
                              )}
                            </div>
                            
                            {/* Show workout details for workout habits */}
                            {details.type === 'workout' && isExpanded && (
                              <div className="mt-2 pl-4 md:pl-5">
                                <div className="flex items-center gap-2 text-xs md:text-sm font-medium text-muted-foreground mb-2 md:mb-3">
                                  <Dumbbell className="w-3 md:w-4 h-3 md:h-4" />
                                  Програма за тренировка
                                </div>
                                {details.exercises?.map((exercise, index) => (
                                  <div key={index} className="flex items-center gap-2 md:gap-3 p-1.5 md:p-2 rounded-md bg-muted/50 mb-1">
                                    <Circle className="w-3 md:w-4 h-3 md:h-4 text-muted-foreground" />
                                    <span className="text-xs md:text-sm">{exercise}</span>
                                  </div>
                                ))}
                              </div>
                            )}
                            
                            {/* Only show description for non-fitness habits */}
                            {details.description && habit.category !== 'fitness' && (
                              <div className="mt-2 md:mt-3 pl-4 md:pl-5 text-xs md:text-sm text-muted-foreground">
                                {details.description}
                              </div>
                            )}
                          </div>

                          <div className="flex items-center gap-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleHabitClick(habit, e);
                              }}
                              className="h-6 md:h-7 w-6 md:w-7 p-0 hover:bg-primary/10"
                            >
                              <Edit className="w-3 md:w-4 h-3 md:h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation();
                                onDeleteHabit(habit.id);
                              }}
                              className="h-6 md:h-7 w-6 md:w-7 p-0 text-destructive hover:text-destructive hover:bg-destructive/10"
                            >
                              <Trash2 className="w-3 md:w-4 h-3 md:h-4" />
                            </Button>
                            {details.type === 'workout' && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setExpandedHabit(isExpanded ? null : habit.id);
                                }}
                                className="h-6 md:h-7 w-6 md:w-7 p-0"
                              >
                                {isExpanded ? <ChevronUp className="w-3 md:w-4 h-3 md:h-4" /> : <ChevronDown className="w-3 md:w-4 h-3 md:h-4" />}
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}
      
      <AddHabitDialog 
        open={showAddDialog} 
        onOpenChange={setShowAddDialog}
        initialDate={selectedDate}
        initialTime={clickedTime || undefined}
        editingHabit={editingHabit}
      />
    </div>
  );
}