import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useHabitSettings } from "@/hooks/useHabitSettings";

interface ReminderTimeSelectorProps {
  value?: string; // HH:mm format
  onChange: (time: string) => void;
}

export default function ReminderTimeSelector({ value, onChange }: ReminderTimeSelectorProps) {
  const { settings } = useHabitSettings();
  
  const parseTime = (timeStr?: string) => {
    if (!timeStr) return { hour: 9, minute: 0 };
    const [h, m] = timeStr.split(':').map(Number);
    return { hour: h || 9, minute: m || 0 };
  };

  const formatTime = (hour: number, minute: number) => {
    return `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
  };

  const { hour, minute } = parseTime(value);
  const [selectedHour, setSelectedHour] = useState(hour);
  const [selectedMinute, setSelectedMinute] = useState(minute);
  const [showHourPicker, setShowHourPicker] = useState(false);
  const [showMinutePicker, setShowMinutePicker] = useState(false);

  const getAvailableHours = () => {
    const startHour = parseInt(settings.day_start_time.split(':')[0]);
    const endHour = parseInt(settings.day_end_time.split(':')[0]);
    const hours = [];
    for (let h = startHour; h <= endHour; h++) {
      hours.push(h);
    }
    return hours;
  };

  const availableHours = getAvailableHours();

  const handleHourChange = (newHour: number) => {
    setSelectedHour(newHour);
    onChange(formatTime(newHour, selectedMinute));
  };

  const handleMinuteChange = (newMinute: number) => {
    setSelectedMinute(newMinute);
    onChange(formatTime(selectedHour, newMinute));
  };

  const adjustHour = (delta: number) => {
    const currentIndex = availableHours.indexOf(selectedHour);
    let newIndex = currentIndex + delta;
    if (newIndex < 0) newIndex = availableHours.length - 1;
    if (newIndex >= availableHours.length) newIndex = 0;
    handleHourChange(availableHours[newIndex]);
  };

  const adjustMinute = (delta: number) => {
    let newMinute = selectedMinute + delta;
    if (newMinute < 0) newMinute = 55;
    if (newMinute > 59) newMinute = 0;
    // Round to nearest 5 minutes
    newMinute = Math.round(newMinute / 5) * 5;
    if (newMinute === 60) newMinute = 0;
    handleMinuteChange(newMinute);
  };

  return (
    <div className="mt-3">
      <div className="text-sm text-muted-foreground mb-3 text-center">
        В колко часа да получиш напомняне?
      </div>
      
      <div className="flex items-center justify-center gap-2">
        {/* Hour selector */}
        <Button 
          type="button" 
          variant="outline" 
          size="sm" 
          onClick={() => adjustHour(-1)} 
          className="h-8 w-8 p-0"
        >
          <ChevronLeft className="w-3 h-3" />
        </Button>

        <Popover open={showHourPicker} onOpenChange={setShowHourPicker}>
          <PopoverTrigger asChild>
            <Button
              type="button"
              variant="outline"
              className="w-12 h-9 font-mono text-sm"
            >
              {selectedHour.toString().padStart(2, '0')}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-2" align="center">
            <div className="grid grid-cols-4 gap-1 max-h-40 overflow-y-auto">
              {availableHours.map((h) => (
                <Button
                  key={h}
                  type="button"
                  variant={selectedHour === h ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    handleHourChange(h);
                    setShowHourPicker(false);
                  }}
                  className="w-12 h-8 text-sm"
                >
                  {h.toString().padStart(2, '0')}
                </Button>
              ))}
            </div>
          </PopoverContent>
        </Popover>

        <Button 
          type="button" 
          variant="outline" 
          size="sm" 
          onClick={() => adjustHour(1)} 
          className="h-8 w-8 p-0"
        >
          <ChevronRight className="w-3 h-3" />
        </Button>

        <span className="text-lg font-mono text-muted-foreground">:</span>

        {/* Minute selector */}
        <Button 
          type="button" 
          variant="outline" 
          size="sm" 
          onClick={() => adjustMinute(-5)} 
          className="h-8 w-8 p-0"
        >
          <ChevronLeft className="w-3 h-3" />
        </Button>

        <Popover open={showMinutePicker} onOpenChange={setShowMinutePicker}>
          <PopoverTrigger asChild>
            <Button
              type="button"
              variant="outline"
              className="w-12 h-9 font-mono text-sm"
            >
              {selectedMinute.toString().padStart(2, '0')}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-2" align="center">
            <div className="grid grid-cols-4 gap-1">
              {[0, 5, 10, 15, 30, 45].map((m) => (
                <Button
                  key={m}
                  type="button"
                  variant={selectedMinute === m ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    handleMinuteChange(m);
                    setShowMinutePicker(false);
                  }}
                  className="w-12 h-8 text-sm"
                >
                  {m.toString().padStart(2, '0')}
                </Button>
              ))}
            </div>
          </PopoverContent>
        </Popover>

        <Button 
          type="button" 
          variant="outline" 
          size="sm" 
          onClick={() => adjustMinute(5)} 
          className="h-8 w-8 p-0"
        >
          <ChevronRight className="w-3 h-3" />
        </Button>
      </div>
    </div>
  );
}