import { useState } from 'react';
import { format, addDays, startOfWeek, addWeeks, subWeeks } from 'date-fns';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react';
import { AddHabitDialog } from './AddHabitDialog';
import type { Habit, HabitCompletion } from '@/hooks/useHabits';

interface WeekViewProps {
  weekStart: Date;
  weekDays: Date[];
  displayHabits: Habit[];
  isLoadingHabits: boolean;
  filteredHabits: Habit[];
  completions: HabitCompletion[];
  isHabitActiveOnDay: (habit: Habit, date: Date) => boolean;
  isHabitCompleted: (habitId: string, date: Date, completions: HabitCompletion[]) => boolean;
  handleToggleHabit: (habitId: string, date: Date) => Promise<void>;
  setShowAddHabit: (show: boolean) => void;
  goToPreviousWeek: () => void;
  goToNextWeek: () => void;
  goToToday: () => void;
  setSelectedDate: (date: Date) => void;
  setViewMode: (mode: 'week' | 'day') => void;
  dayStart: string;
  dayEnd: string;
}

export function WeekView({
  weekStart,
  weekDays,
  displayHabits,
  isLoadingHabits,
  filteredHabits,
  completions,
  isHabitActiveOnDay,
  isHabitCompleted,
  handleToggleHabit,
  setShowAddHabit,
  goToPreviousWeek,
  goToNextWeek,
  goToToday,
  setSelectedDate,
  setViewMode,
  dayStart,
  dayEnd
}: WeekViewProps) {
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [clickedDate, setClickedDate] = useState<Date | null>(null);
  const [clickedTime, setClickedTime] = useState<string | null>(null);
  
  const weekDayAbbr = ['П', 'В', 'С', 'Ч', 'П', 'С', 'Н'];
  
  const handleAddHabit = (date: Date, time: string) => {
    setClickedDate(date);
    setClickedTime(time);
    setShowAddDialog(true);
  };

  const handleDayClick = (day: Date) => {
    setSelectedDate(day);
    setViewMode('day');
  };

  // Generate time slots based on dayStart and dayEnd
  const generateTimeSlots = () => {
    const slots = [];
    const startHour = parseInt(dayStart.split(':')[0]);
    const endHour = parseInt(dayEnd.split(':')[0]);
    
    for (let hour = startHour; hour <= endHour; hour++) {
      slots.push(`${hour.toString().padStart(2, '0')}:00`);
    }
    return slots;
  };

  const timeSlots = generateTimeSlots();

  if (isLoadingHabits) {
    return <div>Зареждане...</div>;
  }

  return (
    <div className="space-y-4">
      {/* Header with week navigation */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">
          Седмица {format(weekStart, 'dd.MM')} - {format(addDays(weekStart, 6), 'dd.MM.yyyy')}
        </h3>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={goToPreviousWeek} className="h-7 w-7 p-0">
            <ChevronLeft className="w-3 h-3" />
          </Button>
          <Button variant="outline" size="sm" onClick={goToNextWeek} className="h-7 w-7 p-0">
            <ChevronRight className="w-3 h-3" />
          </Button>
        </div>
      </div>

      {/* Weekly grid similar to WeeklyMenu */}
      <div className="bg-card rounded-xl border shadow-sm overflow-auto">
        <div className="grid grid-cols-8 gap-0 min-w-[640px]">
          {/* Header Row */}
          <div className="bg-muted/30 p-2 text-center border-b border-r">
            <div className="text-xs font-medium text-muted-foreground">Час</div>
          </div>
          {weekDayAbbr.map((day, index) => (
            <div 
              key={index} 
              className="bg-muted/30 p-2 text-center border-b border-r last:border-r-0 cursor-pointer hover:bg-muted/50"
              onClick={() => handleDayClick(weekDays[index])}
            >
              <div className="text-xs font-medium">{day}</div>
              <div className="text-xs text-muted-foreground">
                {format(weekDays[index], 'dd.MM')}
              </div>
            </div>
          ))}

          {/* Time Slot Rows */}
          {timeSlots.map((timeSlot) => (
            <div key={timeSlot} className="contents">
              {/* Time Header */}
              <div className="p-3 border-b border-r bg-muted/20 flex flex-col justify-center">
                <div className="text-xs font-medium text-center">{timeSlot}</div>
              </div>
              
              {/* Day Slots */}
              {Array.from({ length: 7 }, (_, dayIndex) => {
                const dayDate = weekDays[dayIndex];
                
                // Find habits for this time slot and day
                const dayHabits = displayHabits.filter(habit => {
                  const hhmm = (habit.time_of_day || '').slice(0,5);
                  return isHabitActiveOnDay(habit, dayDate) && hhmm === timeSlot;
                });
                
                return (
                  <div key={dayIndex} className="border-b border-r last:border-r-0 p-2 min-h-[60px]">
                    <div className="space-y-1">
                      {dayHabits.map((habit) => {
                        const isCompleted = isHabitCompleted(habit.id, dayDate, completions);
                        
                        return (
                          <div
                            key={habit.id}
                            className={`p-2 rounded text-xs cursor-pointer border transition-colors ${
                              isCompleted 
                                ? 'bg-primary/20 border-primary text-primary' 
                                : 'bg-muted/30 border-muted-foreground/20 hover:bg-muted/50'
                            }`}
                            style={{ borderLeftColor: habit.color, borderLeftWidth: '3px' }}
                            onClick={() => handleToggleHabit(habit.id, dayDate)}
                          >
                            <div className="font-medium">{habit.name}</div>
                          </div>
                        );
                      })}
                      
                      {/* Add habit button for empty slots */}
                      {dayHabits.length === 0 && (
                        <button
                          onClick={() => handleAddHabit(dayDate, timeSlot)}
                          className="w-full p-2 text-xs text-muted-foreground hover:text-foreground hover:bg-muted/30 rounded border border-dashed border-muted-foreground/30 hover:border-muted-foreground/60 transition-colors"
                        >
                          <Plus className="h-3 w-3 mx-auto" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      <AddHabitDialog 
        open={showAddDialog} 
        onOpenChange={setShowAddDialog}
        initialDate={clickedDate || undefined}
        initialTime={clickedTime || undefined}
      />
    </div>
  );
}