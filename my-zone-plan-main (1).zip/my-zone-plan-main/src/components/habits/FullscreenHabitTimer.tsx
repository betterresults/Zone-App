import { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Card, CardContent } from '@/components/ui/card';
import { Play, Pause, Square, X, Target, Clock } from 'lucide-react';
import { useHabitSessions } from '@/hooks/useHabitSessions';
import { differenceInSeconds } from 'date-fns';
import { cn } from '@/lib/utils';
import type { Habit } from '@/hooks/useHabits';

interface FullscreenHabitTimerProps {
  habit: Habit | null;
  isOpen: boolean;
  onClose: () => void;
}

export function FullscreenHabitTimer({ habit, isOpen, onClose }: FullscreenHabitTimerProps) {
  const { 
    getActiveSession, 
    startSessionMutation, 
    endSessionMutation,
    parseDurationFromDescription 
  } = useHabitSessions();
  
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  // Lock page scroll while fullscreen timer is open
  useEffect(() => {
    if (!isOpen) return;
    const { style } = document.documentElement;
    const prevOverflow = style.overflow;
    style.overflow = 'hidden';
    return () => {
      style.overflow = prevOverflow;
    };
  }, [isOpen]);

  const activeSession = habit ? getActiveSession(habit.id) : undefined;
  const targetDurationMinutes = parseDurationFromDescription(habit?.description);

  // Update elapsed time every second for active sessions
  useEffect(() => {
    if (!activeSession || isPaused) {
      return;
    }

    const updateElapsed = () => {
      const startTime = new Date(activeSession.started_at);
      const now = new Date();
      setElapsedSeconds(differenceInSeconds(now, startTime));
    };

    // Update immediately
    updateElapsed();
    
    // Update every second
    const interval = setInterval(updateElapsed, 1000);
    return () => clearInterval(interval);
  }, [activeSession, isPaused]);

  const handleStart = () => {
    if (!habit) return;
    if (!activeSession) {
      startSessionMutation.mutate({
        habitId: habit.id,
        targetDurationMinutes
      });
    }
    setIsPaused(false);
  };

  const handlePause = () => {
    setIsPaused(!isPaused);
  };

  const handleStop = () => {
    if (activeSession) {
      endSessionMutation.mutate(activeSession.id);
    }
    setIsPaused(false);
    onClose(); // Automatically close the timer when stopped
  };

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getProgress = () => {
    if (!targetDurationMinutes || elapsedSeconds === 0) return 0;
    return Math.min((elapsedSeconds / (targetDurationMinutes * 60)) * 100, 100);
  };

  const isCompleted = targetDurationMinutes && elapsedSeconds >= targetDurationMinutes * 60;
  const remainingMinutes = targetDurationMinutes ? Math.max(0, targetDurationMinutes - Math.floor(elapsedSeconds / 60)) : 0;

  if (!isOpen || !habit) return null;

  return createPortal(
    <div className="fixed inset-0 z-[100000] bg-background flex items-center justify-center overflow-hidden">
      <Card className="w-full h-full max-w-none rounded-none border-0 shadow-none">
        <CardContent className="p-4 sm:p-8 h-full flex flex-col">
          {/* Header */}
          <div className="flex items-center justify-between mb-4 sm:mb-8 flex-shrink-0 pr-16 sm:pr-0">
            <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
              <div 
                className="w-5 h-5 sm:w-6 sm:h-6 rounded-full flex-shrink-0" 
                style={{ backgroundColor: habit.color }}
              />
              <h1 className="text-lg sm:text-2xl font-bold truncate">{habit.name}</h1>
            </div>
            <Button
              variant="outline"
              size="icon"
              onClick={onClose}
              className="h-10 w-10 sm:h-12 sm:w-12 bg-muted/10 border-2 hover:bg-destructive hover:text-destructive-foreground hover:border-destructive absolute top-2 right-2 sm:static"
            >
              <X className="w-5 h-5 sm:w-8 sm:h-8" />
            </Button>
          </div>

          {/* Main Timer Display */}
          <div className="text-center mb-6 sm:mb-12 flex-1 flex flex-col justify-center">
            {/* Large Timer */}
            <div className="text-8xl sm:text-9xl md:text-[16rem] lg:text-[20rem] font-mono font-bold mb-6 sm:mb-8 text-primary select-none leading-none">
              {formatTime(elapsedSeconds)}
            </div>

            {targetDurationMinutes && (
              <div className="space-y-4 sm:space-y-6">
                {/* Goal with progress info */}
                <div className="flex items-center justify-center gap-2 text-base sm:text-xl text-muted-foreground">
                  <Target className="w-5 h-5 sm:w-6 sm:h-6" />
                  <span>
                    Цел: {targetDurationMinutes} минути
                    {elapsedSeconds > 0 && (
                      <span className="text-primary font-medium"> / {Math.floor(elapsedSeconds / 60)} направени</span>
                    )}
                  </span>
                </div>

                <Progress 
                  value={getProgress()} 
                  className="h-4 sm:h-6 w-full max-w-sm sm:max-w-lg mx-auto"
                />

                <div className="text-lg sm:text-2xl font-medium">
                  {isCompleted ? (
                    <span className="text-green-600 font-bold">
                      ✓ Завършено! Браво!
                    </span>
                  ) : (
                    <span className="text-muted-foreground">
                      Остават: {remainingMinutes} минути
                    </span>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Controls */}
          <div className="flex justify-center gap-3 sm:gap-6 flex-shrink-0 px-2 mb-8 mt-auto">
            {!activeSession ? (
              <Button 
                onClick={handleStart}
                disabled={startSessionMutation.isPending}
                size="lg" 
                className="gap-3 sm:gap-4 px-8 sm:px-12 py-4 sm:py-6 text-lg sm:text-xl font-semibold"
              >
                <Play className="w-6 h-6 sm:w-8 sm:h-8" />
                Започни
              </Button>
            ) : (
              <div className="flex gap-3 sm:gap-6 flex-wrap justify-center">
                <Button 
                  onClick={handlePause}
                  size="lg" 
                  variant="outline"
                  className="gap-3 sm:gap-4 px-6 sm:px-10 py-4 sm:py-6 text-lg sm:text-xl font-semibold"
                >
                  {isPaused ? <Play className="w-6 h-6 sm:w-8 sm:h-8" /> : <Pause className="w-6 h-6 sm:w-8 sm:h-8" />}
                  {isPaused ? 'Продължи' : 'Пауза'}
                </Button>
                
                <Button 
                  onClick={handleStop}
                  disabled={endSessionMutation.isPending}
                  size="lg" 
                  variant="destructive"
                  className="gap-3 sm:gap-4 px-6 sm:px-10 py-4 sm:py-6 text-lg sm:text-xl font-semibold"
                >
                  <Square className="w-6 h-6 sm:w-8 sm:h-8" />
                  Спри
                </Button>
              </div>
            )}
          </div>

          {/* Status Message */}
          {activeSession && (
            <div className="mt-4 sm:mt-6 text-center">
              <div className={cn(
                "inline-flex items-center gap-2 px-3 sm:px-4 py-2 rounded-full text-xs sm:text-sm",
                isPaused ? "bg-yellow-100 text-yellow-800" : "bg-green-100 text-green-800"
              )}>
                <Clock className="w-3 h-3 sm:w-4 sm:h-4" />
                {isPaused ? "На пауза" : "В ход"}
              </div>
            </div>
          )}

          {/* Habit Description */}
          {habit.description && (
            <div className="mt-4 sm:mt-8 p-3 sm:p-4 bg-muted/50 rounded-lg">
              <h3 className="font-medium mb-2 text-sm sm:text-base">Описание:</h3>
              <p className="text-xs sm:text-sm text-muted-foreground">{habit.description}</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  , document.body);

}