import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import TimePickerInline from '@/components/habits/TimePickerInline';
import FrequencyInline from '@/components/habits/FrequencyInline';
import ReminderInline from '@/components/habits/ReminderInline';
import ReminderTimeSelector from '@/components/habits/ReminderTimeSelector';
import DurationSelector from '@/components/habits/DurationSelector';
import { X, Calendar as CalendarIcon, Repeat, Clock, Bell, Tag, ChevronRight, Timer, Copy, Target, Zap, Plus, RotateCcw, Timer as TimerIcon } from 'lucide-react';
import { format } from 'date-fns';
import { bg } from 'date-fns/locale';
import { useHabits, Habit } from '@/hooks/useHabits';
import { useImportantTasks } from '@/hooks/useImportantTasks';
import { useHabitCategories, useCreateHabitCategory } from '@/hooks/useHabitCategories';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { useQueryClient } from '@tanstack/react-query';
import { useIsMobile } from '@/hooks/use-mobile';

interface AddHabitDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initialDate?: Date;
  initialTime?: string;
  editingHabit?: Habit | null;
}

const HABIT_COLORS = [
  '#EF4444', // red
  '#F97316', // orange
  '#EAB308', // yellow
  '#22C55E', // green
  '#3B82F6', // blue
  '#8B5CF6', // purple
  '#EC4899', // pink
  '#6B7280', // gray
];

const WEEKDAYS = [
  { key: 'monday', label: 'Пн' },
  { key: 'tuesday', label: 'Вт' },
  { key: 'wednesday', label: 'Ср' },
  { key: 'thursday', label: 'Чт' },
  { key: 'friday', label: 'Пт' },
  { key: 'saturday', label: 'Сб' },
  { key: 'sunday', label: 'Нд' },
];

const HABIT_COLORS_FOR_NEW_CATEGORY = [
  '#EF4444', // red
  '#F97316', // orange
  '#EAB308', // yellow
  '#22C55E', // green
  '#06B6D4', // cyan
  '#3B82F6', // blue
  '#8B5CF6', // purple
  '#EC4899', // pink
  '#F59E0B', // amber
  '#10B981', // emerald
  '#8B5CF6', // violet
  '#F472B6', // rose
];

export function AddHabitDialog({ open, onOpenChange, initialDate, initialTime, editingHabit }: AddHabitDialogProps) {
  const { toast } = useToast();
  const { data: categories } = useHabitCategories();
  const { createHabitMutation, updateHabitMutation } = useHabits();
  const { canAddImportantTask, importantTasksCount } = useImportantTasks();
  const createCategoryMutation = useCreateHabitCategory();
  const queryClient = useQueryClient();
  const isMobile = useIsMobile();

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: 'general',
    color: '#8B5CF6',
    time_of_day: '',
    repeat_days: [] as string[],
    reminder_enabled: false,
    reminder_minutes_before: 15,
    reminder_time: '',
    one_time_date: '',
    habit_type: 'habit' as 'habit' | 'task',
    duration_minutes: undefined as number | undefined,
    is_important: false
  });

  const [selectedDate, setSelectedDate] = useState<Date>(initialDate || new Date());
  const [repeatType, setRepeatType] = useState<'no_repeat' | 'daily' | 'weekly' | 'monthly' | 'weekend' | 'custom'>('daily');
  const [customBase, setCustomBase] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  const [interval, setInterval] = useState(1);
  const [selectedWeekDays, setSelectedWeekDays] = useState<string[]>(['monday']);
  const [selectedMonthDays, setSelectedMonthDays] = useState<number[]>([1]);
  const [showTimePopover, setShowTimePopover] = useState(false);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showCategoryPopover, setShowCategoryPopover] = useState(false);
  const [showFrequencyPopover, setShowFrequencyPopover] = useState(false);
  const [habitType, setHabitType] = useState<'habit' | 'task'>('habit');
  const [showAddCategory, setShowAddCategory] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [newCategoryColor, setNewCategoryColor] = useState('#8B5CF6');
  const [showDurationPopover, setShowDurationPopover] = useState(false);

  const isEditing = !!editingHabit;
  const isOneTime = repeatType === 'no_repeat';

  useEffect(() => {
    if (initialTime) {
      setFormData(prev => ({ ...prev, time_of_day: initialTime }));
    }
    if (initialDate) {
      setSelectedDate(initialDate);
      setFormData(prev => ({ ...prev, one_time_date: format(initialDate, 'yyyy-MM-dd') }));
    }
  }, [initialTime, initialDate]);

  useEffect(() => {
    if (editingHabit && open) {
      setFormData({
        name: editingHabit.name,
        description: editingHabit.description || '',
        category: editingHabit.category || 'general',
        color: editingHabit.color || '#8B5CF6',
        time_of_day: editingHabit.time_of_day || '',
        repeat_days: editingHabit.repeat_days || [],
        reminder_enabled: editingHabit.reminder_enabled || false,
        reminder_minutes_before: editingHabit.reminder_minutes_before || 15,
        reminder_time: editingHabit.reminder_time || '',
        one_time_date: editingHabit.one_time_date || '',
        habit_type: editingHabit.habit_type || 'habit',
        duration_minutes: editingHabit.duration_minutes || undefined,
        is_important: editingHabit.is_important || false
      });
      
      setHabitType(editingHabit.habit_type || 'habit');
      
      if (editingHabit.one_time_date) {
        setRepeatType('no_repeat');
        setSelectedDate(new Date(editingHabit.one_time_date));
      } else if (editingHabit.repeat_days) {
        const days = editingHabit.repeat_days;
        if (days.length === 7) {
          setRepeatType('daily');
        } else if (days.length === 2 && days.includes('saturday') && days.includes('sunday')) {
          setRepeatType('weekend');
        } else if (days.some(d => !isNaN(Number(d)))) {
          setRepeatType('monthly');
          setSelectedMonthDays(days.map(d => Number(d)).filter(n => !isNaN(n)));
        } else {
          setRepeatType('weekly');
          setSelectedWeekDays(days);
        }
      }
    } else if (!editingHabit && open) {
      // Reset form for new habit/task
      setFormData({
        name: '',
        description: '',
        category: 'general',
        color: '#8B5CF6',
        time_of_day: initialTime || '',
        repeat_days: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'],
        reminder_enabled: false,
        reminder_minutes_before: 15,
        reminder_time: '',
        one_time_date: initialDate ? format(initialDate, 'yyyy-MM-dd') : '',
        habit_type: 'habit',
        duration_minutes: undefined,
        is_important: false
      });
      setHabitType('habit');
      setRepeatType(initialDate ? 'no_repeat' : 'daily');
      setSelectedWeekDays(['monday']);
      setSelectedMonthDays([1]);
      setCustomBase('daily');
      setInterval(1);
      if (initialDate) {
        setSelectedDate(initialDate);
      }
    }
  }, [editingHabit, open, initialTime, initialDate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      toast({
        title: "Грешка",
        description: "Моля въведете име за навика или задачата",
        variant: "destructive"
      });
      return;
    }

    try {
      const habitData = {
        name: formData.name.trim(),
        description: formData.description.trim() || null,
        category: formData.category,
        color: formData.color,
        time_of_day: formData.time_of_day || null,
        repeat_days: formData.repeat_days,
        reminder_enabled: formData.reminder_enabled,
        reminder_minutes_before: formData.reminder_enabled ? formData.reminder_minutes_before : null,
        reminder_time: formData.reminder_time || null,
        one_time_date: formData.one_time_date || null,
        habit_type: formData.habit_type,
        duration_minutes: formData.duration_minutes || null,
        is_important: formData.is_important
      };

      if (isEditing) {
        await updateHabitMutation.mutateAsync({
          ...habitData,
          id: editingHabit.id,
          is_active: true
        });
        toast({
          title: "Успех!",
          description: `${habitType === 'habit' ? 'Навикът' : 'Задачата'} беше актуализиран${habitType === 'habit' ? '' : 'а'} успешно`,
        });
      } else {
        await createHabitMutation.mutateAsync({
          ...habitData,
          is_active: true
        });
        toast({
          title: "Успех!",
          description: `${habitType === 'habit' ? 'Навикът' : 'Задачата'} беше създаден${habitType === 'habit' ? '' : 'а'} успешно`,
        });
      }

      onOpenChange(false);
      
    } catch (error) {
      console.error('Error saving habit:', error);
      toast({
        title: "Грешка",
        description: `Възникна грешка при ${isEditing ? 'актуализирането' : 'създаването'}`,
        variant: "destructive"
      });
    }
  };

  const handleCreateCategory = async () => {
    if (!newCategoryName.trim()) return;

    try {
      const newCategory = await createCategoryMutation.mutateAsync({
        name: newCategoryName.trim(),
        color: newCategoryColor,
        icon: 'Circle',
        is_default: false
      });

      // Update form to use the new category
      setFormData(prev => ({ ...prev, category: newCategory.name }));
      
      // Reset the form
      setShowAddCategory(false);
      setShowCategoryPopover(false);
      setNewCategoryName('');
      setNewCategoryColor('#8B5CF6');

      toast({
        title: "Успех!",
        description: "Категорията беше създадена успешно",
      });

      // Refresh categories
      queryClient.invalidateQueries({ queryKey: ['habit-categories'] });
    } catch (error) {
      console.error('Error creating category:', error);
      toast({
        title: "Грешка",
        description: "Възникна грешка при създаването на категорията",
        variant: "destructive"
      });
    }
  };

  const getTimeLabel = () => {
    if (!formData.time_of_day) return 'Всяко време';
    const [hours, minutes] = formData.time_of_day.split(':');
    return `${hours}:${minutes}`;
  };

  const getFrequencyLabel = () => {
    switch (repeatType) {
      case 'no_repeat': return 'Без повторение';
      case 'daily': return 'Ежедневно';
      case 'weekly': return `Седмично`;
      case 'monthly': return `Месечно`;
      case 'weekend': return 'Уикенди';
      case 'custom':
        if (customBase === 'daily') return `Всеки ${interval} дни`;
        if (customBase === 'weekly') return `Всеки ${interval} седмици`;
        return `Всеки ${interval} месеца`;
      default: return 'Изберете честота';
    }
  };

  const getReminderLabel = () => {
    if (!formData.reminder_enabled) return 'Изключено';
    const minutes = formData.reminder_minutes_before;
    if (minutes === 0) return 'Всякакво напомняне';
    if (minutes < 60) return `${minutes} мин преди`;
    if (minutes < 1440) return `${Math.round(minutes / 60)} ч преди`;
    return `${Math.round(minutes / 1440)} дни преди`;
  };

  const getDurationLabel = () => {
    if (!formData.duration_minutes) return 'Не е зададена';
    const minutes = formData.duration_minutes;
    if (minutes < 60) {
      return `${minutes} мин`;
    } else if (minutes % 60 === 0) {
      return `${minutes / 60} ч`;
    } else {
      const hours = Math.floor(minutes / 60);
      const mins = minutes % 60;
      return `${hours}ч ${mins}мин`;
    }
  };

  const toggleRepeatDay = (day: string) => {
    setSelectedWeekDays(prev => 
      prev.includes(day) 
        ? prev.filter(d => d !== day)
        : [...prev, day]
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md h-[95vh] overflow-hidden p-0 gap-0">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="relative p-6 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col flex-1 overflow-hidden">
            {/* Title and Colors */}
            <div className="p-3 border-b border-border/50 bg-background/50">
              {/* Type Selection - only show when creating new */}
              {!isEditing && (
                <div className="flex gap-2 mb-3">
                  <Button
                    type="button"
                    variant={habitType === 'habit' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => {
                      setHabitType('habit');
                      setFormData(prev => ({ ...prev, habit_type: 'habit' }));
                    }}
                    className="flex-1"
                  >
                    <Target className="w-4 h-4 mr-2" />
                    Навик
                  </Button>
                  <Button
                    type="button"
                    variant={habitType === 'task' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => {
                      setHabitType('task');
                      setRepeatType('no_repeat');
                      setFormData(prev => ({ 
                        ...prev, 
                        habit_type: 'task',
                        repeat_days: [],
                        one_time_date: format(selectedDate, 'yyyy-MM-dd')
                      }));
                    }}
                    className="flex-1"
                  >
                    <Zap className="w-4 h-4 mr-2" />
                    Задача
                  </Button>
                </div>
              )}

              <Input
                placeholder={habitType === 'habit' ? 'Име на навика' : 'Име на задачата'}
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                className="mb-3"
                maxLength={100}
              />
              
              <div className="flex flex-wrap gap-2 justify-center">
                {HABIT_COLORS.map((color) => (
                  <button
                    key={color}
                    type="button"
                    className={`w-8 h-8 rounded-full border-2 transition-all ${
                      formData.color === color ? 'border-gray-900 scale-110' : 'border-gray-200'
                    }`}
                    style={{ backgroundColor: color }}
                    onClick={() => setFormData(prev => ({ ...prev, color }))}
                  />
                ))}
              </div>
            </div>

            {/* Options List */}
            <div className="bg-muted/20 mx-3 rounded-xl mb-3 overflow-hidden flex-1 min-h-0">
              {/* Date - only for tasks or one-time habits */}
              {(habitType === 'task' || isOneTime) && (
                <div className="flex items-center justify-between p-3 border-b border-border/50 hover:bg-muted/30 transition-colors">
                  <div className="flex items-center gap-3">
                    <CalendarIcon className="w-5 h-5 text-muted-foreground" />
                    <span className="font-medium">Дата</span>
                  </div>
                  <Popover open={showDatePicker} onOpenChange={setShowDatePicker}>
                    <PopoverTrigger asChild>
                      <div className="flex items-center gap-2 text-muted-foreground cursor-pointer hover:bg-muted/50 rounded px-2 py-1">
                        <span className="text-sm">{format(selectedDate, 'dd.MM.yyyy')}</span>
                        <ChevronRight className="w-4 h-4" />
                      </div>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="center">
                      <Calendar
                        mode="single"
                        selected={selectedDate}
                        onSelect={(date) => {
                          if (date) {
                            setSelectedDate(date);
                            setFormData(prev => ({ ...prev, one_time_date: format(date, 'yyyy-MM-dd') }));
                            setShowDatePicker(false);
                          }
                        }}
                        initialFocus
                        className={cn("p-2 pointer-events-auto w-64 h-64")}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              )}

              {/* Frequency - only show for habits */}
              {habitType === 'habit' && !isOneTime && (
                <div className="flex items-center justify-between p-3 border-b border-border/50 hover:bg-muted/30 transition-colors">
                  <div className="flex items-center gap-3">
                    <Repeat className="w-5 h-5 text-muted-foreground" />
                    <span className="font-medium">Честота</span>
                  </div>
                  <Popover open={showFrequencyPopover} onOpenChange={setShowFrequencyPopover}>
                    <PopoverTrigger asChild>
                      <div className="flex items-center gap-2 text-muted-foreground cursor-pointer hover:bg-muted/50 rounded px-2 py-1">
                        <span className="text-sm">{getFrequencyLabel()}</span>
                        <ChevronRight className="w-4 h-4" />
                      </div>
                    </PopoverTrigger>
                    <PopoverContent className="w-[90vw] max-w-md p-3" align="center">
                      <div className="space-y-3">
                        <h4 className="font-medium text-center">Избери честота</h4>
                        <FrequencyInline
                          repeatType={repeatType}
                          onSelectType={(type) => {
                            setRepeatType(type);
                            // Update repeat_days based on frequency type
                            if (type === 'daily') {
                              setFormData(prev => ({ ...prev, repeat_days: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'] }));
                            } else if (type === 'weekly') {
                              setFormData(prev => ({ ...prev, repeat_days: selectedWeekDays }));
                            } else if (type === 'monthly') {
                              setFormData(prev => ({ ...prev, repeat_days: selectedMonthDays.map(d => d.toString()) }));
                            } else if (type === 'weekend') {
                              setFormData(prev => ({ ...prev, repeat_days: ['saturday', 'sunday'] }));
                            } else if (type === 'no_repeat') {
                              setFormData(prev => ({ ...prev, repeat_days: [] }));
                            }
                          }}
                          customBase={customBase}
                          onChangeCustomBase={setCustomBase}
                          interval={interval}
                          onChangeInterval={setInterval}
                          selectedWeekDays={selectedWeekDays}
                          onChangeWeekDays={(days) => {
                            setSelectedWeekDays(days);
                            if (repeatType === 'weekly' || (repeatType === 'custom' && customBase === 'weekly')) {
                              setFormData(prev => ({ ...prev, repeat_days: days }));
                            }
                          }}
                          selectedMonthDays={selectedMonthDays}
                          onChangeMonthDays={(days) => {
                            setSelectedMonthDays(days);
                            if (repeatType === 'monthly' || (repeatType === 'custom' && customBase === 'monthly')) {
                              setFormData(prev => ({ ...prev, repeat_days: days.map(d => d.toString()) }));
                            }
                          }}
                          onClose={() => setShowFrequencyPopover(false)}
                        />
                      </div>
                    </PopoverContent>
                  </Popover>
                </div>
              )}

              {/* Important Task Switch - only for tasks */}
              {habitType === 'task' && (
                <div className="flex items-center justify-between p-3 border-b border-border/50 hover:bg-muted/30 transition-colors">
                  <div className="flex items-center gap-3">
                    <Target className="w-5 h-5 text-muted-foreground" />
                    <div className="flex flex-col">
                      <span className="font-medium">Важна задача</span>
                      <span className="text-xs text-muted-foreground">
                        Макс. 3 на ден {!canAddImportantTask ? `(${importantTasksCount}/3)` : `(${importantTasksCount}/3)`}
                      </span>
                    </div>
                  </div>
                  <Switch
                    checked={formData.is_important}
                    disabled={!formData.is_important && !canAddImportantTask}
                    onCheckedChange={(checked) => {
                      if (checked && !canAddImportantTask && !editingHabit) {
                        toast({
                          title: "Лимит достигнат",
                          description: `Можеш да имаш максимум 3 важни задачи на ден. (Сега имаш ${importantTasksCount})`,
                          variant: "destructive",
                        });
                        return;
                      }
                      setFormData(prev => ({ ...prev, is_important: checked }))
                    }}
                  />
                </div>
              )}

              {/* Category */}
              <div className="flex items-center justify-between p-3 border-b border-border/50 hover:bg-muted/30 transition-colors">
                <div className="flex items-center gap-3">
                  <Tag className="w-5 h-5 text-muted-foreground" />
                  <span className="font-medium">Категория</span>
                </div>
                <Popover open={showCategoryPopover} onOpenChange={setShowCategoryPopover}>
                  <PopoverTrigger asChild>
                    <div className="flex items-center gap-2 text-muted-foreground cursor-pointer hover:bg-muted/50 rounded px-2 py-1">
                      <div className="flex items-center gap-2">
                        <div
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: categories?.find(c => c.name === formData.category)?.color || '#8B5CF6' }}
                        />
                        <span className="text-sm">{formData.category}</span>
                      </div>
                      <ChevronRight className="w-4 h-4" />
                    </div>
                  </PopoverTrigger>
                  <PopoverContent className="w-[90vw] max-w-xs p-3" align="center">
                    <div className="space-y-3">
                      <h4 className="font-medium text-center">Избери категория</h4>
                      
                      {showAddCategory ? (
                        <div className="space-y-3">
                          <Input
                            placeholder="Име на категория"
                            value={newCategoryName}
                            onChange={(e) => setNewCategoryName(e.target.value)}
                            maxLength={50}
                          />
                          
                          <div className="flex flex-wrap gap-2">
                            {HABIT_COLORS_FOR_NEW_CATEGORY.map((color) => (
                              <button
                                key={color}
                                type="button"
                                className={`w-6 h-6 rounded-full border-2 transition-all ${
                                  newCategoryColor === color ? 'border-gray-900 scale-110' : 'border-gray-200'
                                }`}
                                style={{ backgroundColor: color }}
                                onClick={() => setNewCategoryColor(color)}
                              />
                            ))}
                          </div>
                          
                          <div className="flex gap-2">
                            <Button
                              type="button"
                              size="sm"
                              onClick={handleCreateCategory}
                              disabled={!newCategoryName.trim()}
                            >
                              Създай
                            </Button>
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setShowAddCategory(false);
                                setNewCategoryName('');
                                setNewCategoryColor('#8B5CF6');
                              }}
                            >
                              Отказ
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <div className="grid gap-1 max-h-40 overflow-y-auto">
                            {categories?.map((category) => (
                              <Button
                                key={category.id}
                                type="button"
                                variant={formData.category === category.name ? "default" : "outline"}
                                size="sm"
                                onClick={() => {
                                  setFormData(prev => ({ ...prev, category: category.name }));
                                  setShowCategoryPopover(false);
                                }}
                                className="justify-start"
                              >
                                <div className="flex items-center gap-2">
                                  <div
                                    className="w-3 h-3 rounded-full"
                                    style={{ backgroundColor: category.color }}
                                  />
                                  {category.name}
                                </div>
                              </Button>
                            ))}
                          </div>
                          
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => setShowAddCategory(true)}
                            className="w-full justify-start text-muted-foreground"
                          >
                            <Plus className="w-4 h-4 mr-2" />
                            Добави нова категория
                          </Button>
                        </div>
                      )}
                    </div>
                  </PopoverContent>
                </Popover>
              </div>

              {/* Duration */}
              <div className="flex items-center justify-between p-3 border-b border-border/50 hover:bg-muted/30 transition-colors">
                <div className="flex items-center gap-3">
                  <TimerIcon className="w-5 h-5 text-muted-foreground" />
                  <span className="font-medium">Продължителност</span>
                </div>
                <Popover open={showDurationPopover} onOpenChange={setShowDurationPopover}>
                  <PopoverTrigger asChild>
                    <div className="flex items-center gap-2 text-muted-foreground cursor-pointer hover:bg-muted/50 rounded px-2 py-1">
                      <span className="text-sm">{getDurationLabel()}</span>
                      <ChevronRight className="w-4 h-4" />
                    </div>
                  </PopoverTrigger>
                  <PopoverContent className="w-[90vw] max-w-xs p-3" align="center">
                    <DurationSelector
                      value={formData.duration_minutes}
                      onChange={(minutes) => {
                        setFormData(prev => ({ ...prev, duration_minutes: minutes }));
                        setShowDurationPopover(false);
                      }}
                      onClose={() => setShowDurationPopover(false)}
                    />
                  </PopoverContent>
                </Popover>
              </div>

              {/* Time */}
              <div className="flex items-center justify-between p-3 border-b border-border/50 hover:bg-muted/30 transition-colors">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-muted-foreground" />
                  <span className="font-medium">Време</span>
                </div>
                <div className="flex items-center gap-2">
                  <Popover open={showTimePopover} onOpenChange={setShowTimePopover}>
                    <PopoverTrigger asChild>
                      <div className="flex items-center gap-2 text-muted-foreground cursor-pointer hover:bg-muted/50 rounded px-2 py-1">
                        <span className="text-sm">{getTimeLabel()}</span>
                        <ChevronRight className="w-4 h-4" />
                      </div>
                    </PopoverTrigger>
                    <PopoverContent className="w-[90vw] max-w-xs p-3" align="center">
                      <TimePickerInline
                        value={formData.time_of_day}
                        onChange={(time) => {
                          setFormData(prev => ({ ...prev, time_of_day: time }));
                          setShowTimePopover(false);
                        }}
                      />
                    </PopoverContent>
                  </Popover>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    aria-label="Изчисти часа"
                    onClick={() => setFormData(prev => ({ ...prev, time_of_day: '' }))}
                  >
                    <RotateCcw className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Reminder */}
              <div className="p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <Bell className="w-5 h-5 text-muted-foreground" />
                    <span className="font-medium">Напомняне</span>
                  </div>
                  <Switch
                    checked={formData.reminder_enabled}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, reminder_enabled: checked }))}
                  />
                </div>
                {formData.reminder_enabled && (
                  <>
                    {!formData.time_of_day ? (
                      <div className="space-y-3">
                        <ReminderTimeSelector
                          value={formData.reminder_time}
                          onChange={(time) => setFormData(prev => ({ ...prev, reminder_time: time }))}
                        />
                        <div className="text-xs text-muted-foreground text-center">
                          Ще получиш напомняне точно в този час
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <div className="text-sm text-muted-foreground text-center">
                          Колко минути преди {formData.time_of_day}?
                        </div>
                        <ReminderInline
                          minutes={formData.reminder_minutes_before}
                          onChange={(minutes) => setFormData(prev => ({ ...prev, reminder_minutes_before: minutes }))}
                        />
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
            
            {/* Submit Button */}
            <div className="p-3 border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
              <Button type="submit" className="w-full h-11 font-medium">
                {isEditing ? 'Запази промените' : (habitType === 'habit' ? 'Създай навик' : 'Създай задача')}
              </Button>
            </div>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
}
