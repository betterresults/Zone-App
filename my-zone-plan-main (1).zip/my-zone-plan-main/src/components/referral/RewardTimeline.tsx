import React from 'react';
import { Badge } from '@/components/ui/badge';

interface Milestone {
  id: number;
  count: number;
  reward: string;
  description: string;
  icon: string;
  color: string;
  achieved: boolean;
  type: 'free' | 'premium';
}

interface RewardTimelineProps {
  freeReferrals: number;
  premiumReferrals: number;
}

export const RewardTimeline = ({ freeReferrals, premiumReferrals }: RewardTimelineProps) => {
  const freeMilestones: Milestone[] = [
    {
      id: 1,
      count: 3,
      reward: "1 месец безплатно",
      description: "Първите 3 безплатни приятели",
      icon: "🎁",
      color: "bg-blue-500",
      achieved: freeReferrals >= 3,
      type: 'free'
    },
    {
      id: 2,
      count: 6,
      reward: "2 месеца безплатно",
      description: "6 безплатни приятели",
      icon: "🏆",
      color: "bg-green-500", 
      achieved: freeReferrals >= 6,
      type: 'free'
    },
    {
      id: 3,
      count: 9,
      reward: "3 месеца безплатно",
      description: "9 безплатни приятели",
      icon: "⭐",
      color: "bg-indigo-500",
      achieved: freeReferrals >= 9,
      type: 'free'
    },
    {
      id: 4,
      count: 12,
      reward: "4 месеца безплатно",
      description: "12 безплатни приятели",
      icon: "💫",
      color: "bg-cyan-500",
      achieved: freeReferrals >= 12,
      type: 'free'
    },
    {
      id: 5,
      count: 15,
      reward: "5 месеца + 1 бонус месец",
      description: "15 безплатни приятели (финал)",
      icon: "🎉",
      color: "bg-orange-500",
      achieved: freeReferrals >= 15,
      type: 'free'
    }
  ];

  const premiumMilestones: Milestone[] = [
    {
      id: 6,
      count: 1,
      reward: "1 месец безплатно",
      description: "Първия премиум приятел",
      icon: "💎",
      color: "bg-purple-500",
      achieved: premiumReferrals >= 1,
      type: 'premium'
    },
    {
      id: 7,
      count: 2,
      reward: "2 месеца безплатно",
      description: "2 премиум приятели",
      icon: "🌟",
      color: "bg-pink-500",
      achieved: premiumReferrals >= 2,
      type: 'premium'
    },
    {
      id: 8,
      count: 3,
      reward: "3 месеца безплатно",
      description: "3 премиум приятели",
      icon: "🔥",
      color: "bg-red-500",
      achieved: premiumReferrals >= 3,
      type: 'premium'
    },
    {
      id: 9,
      count: 5,
      reward: "1 година безплатно",
      description: "5 премиум приятели (мин. 3 мес. всеки)",
      icon: "👑",
      color: "bg-yellow-500",
      achieved: premiumReferrals >= 5,
      type: 'premium'
    },
    {
      id: 10,
      count: 10,
      reward: "Завинаги безплатно + печалба",
      description: "10 премиум приятели (мин. 6 мес. всеки)",
      icon: "🚀",
      color: "bg-gradient-to-r from-purple-500 to-pink-500",
      achieved: premiumReferrals >= 10,
      type: 'premium'
    }
  ];

  const renderTimeline = (milestones: Milestone[], title: string, totalCount: number, gradientClass: string) => (
    <div className="relative">
      {/* Timeline header */}
      <div className={`p-4 rounded-t-lg border-b ${gradientClass}`}>
        <h4 className="text-lg font-bold text-foreground text-center">{title}</h4>
        <div className="text-center mt-2">
          <span className="text-2xl font-bold text-primary">{totalCount}</span>
          <span className="text-sm text-muted-foreground ml-2">приятели</span>
        </div>
      </div>

      {/* Progress line */}
      <div className="absolute left-8 top-20 bottom-0 w-1 bg-muted"></div>
      
      <div className="space-y-4 p-4">
        {milestones.map((milestone, index) => {
          const isNext = !milestone.achieved && milestones.slice(0, index).every(m => m.achieved);
          
          return (
            <div key={milestone.id} className="relative flex items-center gap-4">
              {/* Milestone dot */}
              <div className={`
                relative z-10 w-12 h-12 rounded-full border-4 border-background flex items-center justify-center text-lg
                ${milestone.achieved 
                  ? 'bg-green-500 text-white' 
                  : isNext 
                  ? 'bg-primary text-white animate-pulse' 
                  : 'bg-muted text-muted-foreground'
                }
              `}>
                {milestone.achieved ? '✅' : milestone.icon}
              </div>
              
              {/* Milestone content */}
              <div className={`
                flex-1 p-3 rounded-lg border transition-all duration-300
                ${milestone.achieved 
                  ? 'bg-green-500/10 border-green-500/20' 
                  : isNext 
                  ? 'bg-primary/10 border-primary/20' 
                  : 'bg-muted/30 border-muted'
                }
              `}>
                <div className="flex justify-between items-start">
                  <div>
                    <h5 className={`
                      font-semibold text-base
                      ${milestone.achieved ? 'text-green-600 dark:text-green-400' : 'text-foreground'}
                    `}>
                      {milestone.reward}
                    </h5>
                    <p className="text-xs text-muted-foreground mt-1">
                      {milestone.description}
                    </p>
                  </div>
                  <Badge 
                    variant={milestone.achieved ? "default" : "secondary"}
                    className={milestone.achieved ? "bg-green-500 hover:bg-green-600" : ""}
                  >
                    {milestone.count}
                  </Badge>
                </div>
                
                {/* Progress bar for current milestone */}
                {isNext && (
                  <div className="mt-2">
                    <div className="flex justify-between text-xs text-muted-foreground mb-1">
                      <span>Прогрес</span>
                      <span>{Math.min(totalCount, milestone.count)} / {milestone.count}</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-1.5">
                      <div 
                        className="bg-primary h-1.5 rounded-full transition-all duration-500" 
                        style={{
                          width: `${Math.min(100, (totalCount / milestone.count) * 100)}%`
                        }}
                      ></div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );

  return (
    <div className="bg-card rounded-xl border overflow-hidden">
      <div className="p-6 border-b bg-gradient-to-r from-primary/5 to-accent/5">
        <h3 className="text-xl font-bold text-foreground text-center">
          🏆 Награди за покани
        </h3>
        <p className="text-sm text-muted-foreground text-center mt-2">
          Две отделни програми с различни награди
        </p>
      </div>
      
      {/* Two separate timelines */}
      <div className="grid lg:grid-cols-2 gap-0">
        {/* Free referrals timeline */}
        <div className="border-r border-muted/50">
          {renderTimeline(
            freeMilestones, 
            "🆓 Безплатни приятели", 
            freeReferrals,
            "bg-gradient-to-br from-blue-500/10 to-cyan-500/10"
          )}
        </div>
        
        {/* Premium referrals timeline */}
        <div>
          {renderTimeline(
            premiumMilestones, 
            "💎 Премиум приятели", 
            premiumReferrals,
            "bg-gradient-to-br from-purple-500/10 to-pink-500/10"
          )}
        </div>
      </div>
      
      {/* Bottom info */}
      <div className="p-4 bg-gradient-to-r from-primary/5 to-accent/5 border-t">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div className="text-center p-3 bg-blue-500/10 rounded-lg">
            <div className="font-semibold text-blue-600 dark:text-blue-400">Безплатни приятели</div>
            <div className="text-muted-foreground text-xs mt-1">Всеки 3 приятели = 1 месец, максимум 15</div>
          </div>
          <div className="text-center p-3 bg-purple-500/10 rounded-lg">
            <div className="font-semibold text-purple-600 dark:text-purple-400">Премиум приятели</div>
            <div className="text-muted-foreground text-xs mt-1">1 приятел = 1 месец, специални условия за големи награди</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RewardTimeline;