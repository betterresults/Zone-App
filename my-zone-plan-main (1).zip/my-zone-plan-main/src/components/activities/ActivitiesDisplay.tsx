import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Target, 
  Calendar, 
  Zap, 
  AlertTriangle, 
  CheckCircle2, 
  ChevronUp, 
  ChevronDown, 
  Play, 
  Square 
} from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';

interface ActivitiesDisplayProps {
  selectedDate: Date;
  todayEvents: any[];
  sortedTasks: any[];
  todayHabits: any[];
  importantIncompleteTasks: any[];
  regularTasks: any[];
  completedTasks: any[];
  todayCompletions: any[];
  todaySessions: any[];
  completedActivities: number;
  totalActivities: number;
  habitProgress: number;
  isHabitCompleted: (habitId: string, date: Date, completions: any[]) => boolean;
  handleToggleHabit: (habitId: string) => void;
  parseDurationFromDescription: (description?: string) => number | null;
  getActiveSession: (habitId: string) => any;
  setFullscreenTimerHabit: (habit: any) => void;
  startSessionMutation: any;
  endSessionMutation: any;
  expandedHabits: Set<string>;
  showHeader?: boolean;
}

export function ActivitiesDisplay({
  selectedDate,
  todayEvents,
  sortedTasks,
  todayHabits,
  importantIncompleteTasks,
  regularTasks,
  completedTasks,
  todayCompletions,
  todaySessions,
  completedActivities,
  totalActivities,
  habitProgress,
  isHabitCompleted,
  handleToggleHabit,
  parseDurationFromDescription,
  getActiveSession,
  setFullscreenTimerHabit,
  startSessionMutation,
  endSessionMutation,
  expandedHabits,
  showHeader = true
}: ActivitiesDisplayProps) {
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);
  const isMobile = useIsMobile();
  const today = selectedDate;

  const content = (
    <>
      {showHeader && (
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Target className="w-5 h-5 text-zone-carbs" />
            Събития, навици и задачи днес
          </CardTitle>
          <CardDescription className="text-sm">
            {completedActivities} от {totalActivities} завършени
          </CardDescription>
        </CardHeader>
      )}
      <CardContent className="space-y-4">
        {showHeader && (
          <>
            <Progress value={totalActivities > 0 ? habitProgress : 0} className="w-full h-2" />
            <div className="text-center">
              <div className="text-xl lg:text-2xl font-bold text-zone-carbs">
                {habitProgress}%
              </div>
              <div className="text-xs lg:text-sm text-muted-foreground">днешен прогрес</div>
            </div>
          </>
        )}
        
        {/* Compact Category Cards */}
        <div className="grid grid-cols-1 gap-3">
          
          {/* Important Tasks - Always shown at top */}
          {importantIncompleteTasks.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-red-700 dark:text-red-400 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" />
                Важни задачи
              </h4>
              {importantIncompleteTasks.map((task) => {
                const isCompleted = isHabitCompleted(task.id, today, todayCompletions);
                
                return (
                  <Card key={task.id} className="border-2 border-red-200 shadow-sm hover:shadow-md transition-all duration-200 bg-red-50/30 dark:bg-red-900/10" style={{ background: `linear-gradient(0deg, ${(task.color || '#DC2626')}15, ${(task.color || '#DC2626')}15)` }}>
                    <CardContent className="p-3 cursor-pointer" onClick={(e) => { e.stopPropagation(); handleToggleHabit(task.id); }}>
                      <div className="flex items-center justify-between">
                        <div className="flex-1 min-w-0 pr-12">
                          <h3 className="font-semibold text-base mb-1 text-red-800 dark:text-red-200">
                            {task.name}
                          </h3>
                          {task.time_of_day && (
                            <span className="text-base text-red-700 dark:text-red-300 font-bold">
                              {task.time_of_day.slice(0, 5)}
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-red-100 dark:bg-red-900/50">
                            <AlertTriangle className="w-3 h-3 text-red-600 dark:text-red-400" />
                            <span className="text-xs font-medium text-red-700 dark:text-red-300">Важна</span>
                          </div>
                          
                          <div 
                            className={`${isMobile ? 'w-4 h-4' : 'w-5 h-5'} rounded-full border-2 flex items-center justify-center transition-colors flex-shrink-0 ${
                              isCompleted 
                                ? 'bg-zone-carbs border-zone-carbs' 
                                : 'border-red-500 hover:border-red-600 hover:bg-red-50'
                            }`}
                          >
                            {isCompleted && <div className={`${isMobile ? 'w-1.5 h-1.5' : 'w-2 h-2'} bg-white rounded-full`} />}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}

          {/* Events Category Card */}
          {todayEvents.length > 0 && (
            <Card className="cursor-pointer border shadow-sm bg-blue-50/30 dark:bg-blue-900/10 hover:shadow-md transition-all"
                  onClick={() => setExpandedCategory(expandedCategory === 'events' ? null : 'events')}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center">
                      <Calendar className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-base">Събития</h3>
                      <p className="text-sm text-muted-foreground">
                        {todayEvents.length} планирани
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300">
                      {todayEvents.length}
                    </Badge>
                    {expandedCategory === 'events' ? (
                      <ChevronUp className="w-4 h-4 text-muted-foreground" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-muted-foreground" />
                    )}
                  </div>
                </div>
                
                {/* Expanded Events */}
                {expandedCategory === 'events' && (
                  <div className="mt-4 space-y-2">
                    {todayEvents.map((event) => (
                      <Card key={event.id} className="border shadow-sm" style={{ background: `linear-gradient(0deg, ${event.color || '#3B82F6'}22, ${event.color || '#3B82F6'}22)` }}>
                        <CardContent className="p-3">
                          <div className="flex items-center justify-between">
                            <div className="flex-1 min-w-0">
                              <h3 className="font-medium text-base mb-1">
                                {event.title}
                              </h3>
                              {event.start_time && (
                                <span className="text-base text-foreground font-bold">
                                  {event.start_time.slice(0, 5)}
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-1 bg-blue-100 dark:bg-blue-900/50 px-2 py-1 rounded-full">
                              <Calendar className="w-3 h-3 text-blue-600 dark:text-blue-400" />
                              <span className="text-xs font-medium text-blue-700 dark:text-blue-300">Събитие</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}
          
          {/* Tasks Category Card */}
          {sortedTasks.length > 0 && (
            <Card className="cursor-pointer border shadow-sm bg-purple-50/30 dark:bg-purple-900/10 hover:shadow-md transition-all"
                  onClick={() => setExpandedCategory(expandedCategory === 'tasks' ? null : 'tasks')}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-purple-100 dark:bg-purple-900/50 flex items-center justify-center">
                      <Zap className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-base">Задачи</h3>
                      <p className="text-sm text-muted-foreground">
                        {sortedTasks.filter(task => isHabitCompleted(task.id, today, todayCompletions)).length} от {sortedTasks.length} завършени
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300">
                      {sortedTasks.length}
                    </Badge>
                    {expandedCategory === 'tasks' ? (
                      <ChevronUp className="w-4 h-4 text-muted-foreground" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-muted-foreground" />
                    )}
                  </div>
                </div>
                
                 {/* Expanded Tasks */}
                 {expandedCategory === 'tasks' && (
                   <div className="mt-4 space-y-2">
                     {/* Regular incomplete tasks */}
                     {regularTasks.map((task) => {
                       const isCompleted = isHabitCompleted(task.id, today, todayCompletions);
                       
                       return (
                         <Card key={task.id} className={`border shadow-sm hover:shadow-md transition-all duration-200 ${isCompleted ? 'opacity-60' : ''} relative`} style={{ background: `linear-gradient(0deg, ${(task.color || '#8B5CF6')}22, ${(task.color || '#8B5CF6')}22)` }}>
                           <CardContent className="p-3 cursor-pointer" onClick={(e) => { e.stopPropagation(); handleToggleHabit(task.id); }}>
                             {isCompleted && (
                               <div className="absolute top-2 right-2 flex items-center gap-1 bg-green-100 dark:bg-green-900/50 px-1.5 py-0.5 rounded-full">
                                 <CheckCircle2 className="w-3 h-3 text-green-600 dark:text-green-400" />
                                 <span className="text-xs font-medium text-green-700 dark:text-green-300">✓</span>
                               </div>
                             )}
                             
                             <div className="flex items-center justify-between">
                               <div className="flex-1 min-w-0 pr-12">
                                 <h3 className={`font-medium text-base mb-1 ${isCompleted ? 'text-muted-foreground' : ''}`}>
                                   {task.name}
                                 </h3>
                                 {task.time_of_day && (
                                   <span className="text-base text-foreground font-bold">
                                     {task.time_of_day.slice(0, 5)}
                                   </span>
                                 )}
                               </div>
                               <div className="flex items-center gap-2">
                                 <div className={`flex items-center gap-1 px-2 py-1 rounded-full ${
                                   task.is_important 
                                     ? 'bg-red-100 dark:bg-red-900/50' 
                                     : 'bg-purple-100 dark:bg-purple-900/50'
                                 }`}>
                                   <Zap className={`w-3 h-3 ${
                                     task.is_important 
                                       ? 'text-red-600 dark:text-red-400' 
                                       : 'text-purple-600 dark:text-purple-400'
                                   }`} />
                                   <span className={`text-xs font-medium ${
                                     task.is_important 
                                       ? 'text-red-700 dark:text-red-300' 
                                       : 'text-purple-700 dark:text-purple-300'
                                   }`}>
                                     {task.is_important ? 'Важна' : 'Задача'}
                                   </span>
                                 </div>
                                 
                                 <div 
                                   className={`${isMobile ? 'w-4 h-4' : 'w-5 h-5'} rounded-full border-2 flex items-center justify-center transition-colors flex-shrink-0 ${
                                     isCompleted 
                                       ? 'bg-zone-carbs border-zone-carbs' 
                                       : 'border-muted-foreground hover:border-zone-carbs'
                                   }`}
                                 >
                                   {isCompleted && <div className={`${isMobile ? 'w-1.5 h-1.5' : 'w-2 h-2'} bg-white rounded-full`} />}
                                 </div>
                               </div>
                             </div>
                           </CardContent>
                         </Card>
                       );
                     })}
                     
                     {/* Completed tasks - smaller and grey at bottom */}
                     {completedTasks.length > 0 && (
                       <div className="mt-4 pt-4 border-t border-muted-foreground/20">
                         <h5 className="text-xs font-medium text-muted-foreground mb-2">Завършени задачи</h5>
                         <div className="space-y-1">
                           {completedTasks.map((task) => {
                             const isCompleted = isHabitCompleted(task.id, today, todayCompletions);
                             
                             return (
                               <Card key={task.id} className="border shadow-sm bg-muted/30 opacity-50 scale-95" style={{ background: `linear-gradient(0deg, ${(task.color || '#8B5CF6')}10, ${(task.color || '#8B5CF6')}10)` }}>
                                 <CardContent className="p-2 cursor-pointer" onClick={(e) => { e.stopPropagation(); handleToggleHabit(task.id); }}>
                                   <div className="flex items-center justify-between">
                                     <div className="flex-1 min-w-0 pr-8">
                                       <h3 className="font-medium text-sm text-muted-foreground line-through">
                                         {task.name}
                                       </h3>
                                       {task.time_of_day && (
                                         <span className="text-sm text-muted-foreground">
                                           {task.time_of_day.slice(0, 5)}
                                         </span>
                                       )}
                                     </div>
                                     <div className="flex items-center gap-2">
                                       <div className="flex items-center gap-1 bg-green-100 dark:bg-green-900/50 px-1.5 py-0.5 rounded-full">
                                         <CheckCircle2 className="w-2 h-2 text-green-600 dark:text-green-400" />
                                         <span className="text-xs font-medium text-green-700 dark:text-green-300">✓</span>
                                       </div>
                                       
                                       <div 
                                         className={`${isMobile ? 'w-3 h-3' : 'w-4 h-4'} rounded-full border-2 flex items-center justify-center transition-colors flex-shrink-0 bg-zone-carbs border-zone-carbs`}
                                       >
                                         <div className={`${isMobile ? 'w-1 h-1' : 'w-1.5 h-1.5'} bg-white rounded-full`} />
                                       </div>
                                     </div>
                                   </div>
                                 </CardContent>
                               </Card>
                             );
                           })}
                         </div>
                       </div>
                     )}
                   </div>
                 )}
              </CardContent>
            </Card>
          )}
          
          {/* Habits Category Card */}
          {todayHabits.length > 0 && (
            <Card className="cursor-pointer border shadow-sm bg-green-50/30 dark:bg-green-900/10 hover:shadow-md transition-all"
                  onClick={() => setExpandedCategory(expandedCategory === 'habits' ? null : 'habits')}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900/50 flex items-center justify-center">
                      <Target className="w-5 h-5 text-green-600 dark:text-green-400" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-base">Навици</h3>
                      <p className="text-sm text-muted-foreground">
                        {todayHabits.filter(habit => isHabitCompleted(habit.id, today, todayCompletions)).length} от {todayHabits.length} завършени
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300">
                      {todayHabits.length}
                    </Badge>
                    {expandedCategory === 'habits' ? (
                      <ChevronUp className="w-4 h-4 text-muted-foreground" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-muted-foreground" />
                    )}
                  </div>
                </div>
                
                {/* Expanded Habits */}
                {expandedCategory === 'habits' && (
                  <div className="mt-4 space-y-2">
                    {/* Active/Incomplete Habits */}
                    {todayHabits.filter(habit => !isHabitCompleted(habit.id, today, todayCompletions)).map((habit) => {
                      const isCompleted = isHabitCompleted(habit.id, today, todayCompletions);
                      const targetDurationMinutes = parseDurationFromDescription(habit.description);
                      const hasTimer = !!targetDurationMinutes;
                      const habitSessions = todaySessions.filter(s => s.habit_id === habit.id && s.ended_at);
                      const activeSession = getActiveSession(habit.id);
                      
                      const totalCompletedMinutes = habitSessions.reduce((sum, session) => sum + (session.actual_duration_minutes || 0), 0);
                      const currentElapsed = (() => {
                        if (!activeSession) return 0;
                        const startTime = new Date(activeSession.started_at);
                        const now = new Date();
                        return Math.floor((now.getTime() - startTime.getTime()) / 1000);
                      })();
                      const currentElapsedMinutes = Math.floor(currentElapsed / 60);
                      const totalMinutes = totalCompletedMinutes + currentElapsedMinutes;
                      const isHabitFullyCompleted = targetDurationMinutes && totalMinutes >= targetDurationMinutes;
                      
                      return (
                        <Card key={habit.id} className={`border shadow-sm hover:shadow-md transition-all duration-200 ${isHabitFullyCompleted ? 'opacity-60' : ''} relative`} style={{ background: `linear-gradient(0deg, ${(habit.color || '#8B5CF6')}22, ${(habit.color || '#8B5CF6')}22)` }}>
                          <CardContent className="p-3 cursor-pointer" onClick={(e) => { e.stopPropagation(); handleToggleHabit(habit.id); }}>
                            {isHabitFullyCompleted && (
                              <div className="absolute top-2 right-2 flex items-center gap-1 bg-green-100 dark:bg-green-900/50 px-1.5 py-0.5 rounded-full">
                                <CheckCircle2 className="w-3 h-3 text-green-600 dark:text-green-400" />
                                <span className="text-xs font-medium text-green-700 dark:text-green-300">✓</span>
                              </div>
                            )}
                            
                            <div className="flex items-center justify-between">
                              <div className="flex-1 min-w-0 pr-12">
                                <h3 className={`font-medium text-base mb-1 ${isHabitFullyCompleted ? 'text-muted-foreground' : ''}`}>
                                  {habit.name}
                                </h3>
                                {hasTimer && (
                                  <div className={`text-sm ${isHabitFullyCompleted ? 'text-muted-foreground/70' : 'text-muted-foreground'}`}>
                                    {totalMinutes >= targetDurationMinutes ? (
                                      <span className="font-medium">{totalMinutes} / {targetDurationMinutes} минути</span>
                                    ) : (
                                      <>
                                        {totalMinutes} / {targetDurationMinutes >= 60 && targetDurationMinutes % 60 === 0 
                                          ? `${targetDurationMinutes / 60} ${targetDurationMinutes / 60 === 1 ? 'час' : 'часа'}`
                                          : `${targetDurationMinutes} минути`
                                        }
                                      </>
                                    )}
                                  </div>
                                )}
                                {habit.time_of_day && (
                                  <span className="text-base sm:text-lg md:text-xl text-foreground font-bold mt-1 block">
                                    {habit.time_of_day.slice(0, 5)}
                                  </span>
                                )}
                              </div>
                              
                              <div className="flex items-center gap-2">
                                <div className="flex items-center gap-1 bg-green-100 dark:bg-green-900/50 px-2 py-1 rounded-full">
                                  <Target className="w-3 h-3 text-green-600 dark:text-green-400" />
                                  <span className="text-xs font-medium text-green-700 dark:text-green-300">Навик</span>
                                </div>
                                
                                {hasTimer && activeSession && (
                                  <div className="flex flex-col items-end">
                                    <div className={`text-2xl font-mono font-bold leading-none ${isHabitFullyCompleted ? 'text-muted-foreground' : ''}`}>
                                      {Math.floor(currentElapsed / 3600) > 0 
                                        ? `${Math.floor(currentElapsed / 3600)}:${Math.floor((currentElapsed % 3600) / 60).toString().padStart(2, '0')}`
                                        : Math.floor(currentElapsed / 60).toString()
                                      }
                                    </div>
                                    <div className="text-xs text-muted-foreground mt-0.5">
                                      {Math.floor(currentElapsed / 3600) > 0 ? 'часа' : 'минути'}
                                    </div>
                                  </div>
                                )}
                               
                                {hasTimer ? (
                                  <Button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setFullscreenTimerHabit(habit);
                                    }}
                                    disabled={startSessionMutation.isPending || endSessionMutation.isPending}
                                    size="sm"
                                    className="w-9 h-9 rounded-full p-0"
                                    variant={activeSession ? "outline" : "default"}
                                  >
                                    {!activeSession ? (
                                      <Play className="w-4 h-4" />
                                    ) : (
                                      <Square className="w-4 h-4" />
                                    )}
                                  </Button>
                                ) : (
                                  <div 
                                    className={`${isMobile ? 'w-4 h-4' : 'w-5 h-5'} rounded-full border-2 flex items-center justify-center transition-colors flex-shrink-0 ${
                                      isCompleted 
                                        ? 'bg-zone-carbs border-zone-carbs' 
                                        : 'border-muted-foreground hover:border-zone-carbs'
                                    }`}
                                  >
                                    {isCompleted && <div className={`${isMobile ? 'w-1.5 h-1.5' : 'w-2 h-2'} bg-white rounded-full`} />}
                                  </div>
                                )}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                    
                    {/* Completed Habits - smaller and grey at bottom */}
                    {todayHabits.filter(habit => isHabitCompleted(habit.id, today, todayCompletions)).length > 0 && (
                      <div className="mt-4 pt-4 border-t border-muted-foreground/20">
                        <h5 className="text-xs font-medium text-muted-foreground mb-2">Завършени навици</h5>
                        <div className="space-y-1">
                          {todayHabits.filter(habit => isHabitCompleted(habit.id, today, todayCompletions)).map((habit) => {
                            const isCompleted = isHabitCompleted(habit.id, today, todayCompletions);
                            
                            return (
                              <Card key={habit.id} className="border shadow-sm bg-muted/30 opacity-50 scale-95" style={{ background: `linear-gradient(0deg, ${(habit.color || '#8B5CF6')}10, ${(habit.color || '#8B5CF6')}10)` }}>
                                <CardContent className="p-2 cursor-pointer" onClick={(e) => { e.stopPropagation(); handleToggleHabit(habit.id); }}>
                                  <div className="flex items-center justify-between">
                                    <div className="flex-1 min-w-0 pr-8">
                                      <h3 className="font-medium text-sm text-muted-foreground line-through">
                                        {habit.name}
                                      </h3>
                                       {habit.time_of_day && (
                                         <span className="text-sm text-muted-foreground line-through">
                                           {habit.time_of_day.slice(0, 5)}
                                         </span>
                                       )}
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <div className="flex items-center gap-1 bg-green-100 dark:bg-green-900/50 px-1.5 py-0.5 rounded-full">
                                        <CheckCircle2 className="w-2 h-2 text-green-600 dark:text-green-400" />
                                        <span className="text-xs font-medium text-green-700 dark:text-green-300">✓</span>
                                      </div>
                                      
                                      <div 
                                        className={`${isMobile ? 'w-3 h-3' : 'w-4 h-4'} rounded-full border-2 flex items-center justify-center transition-colors flex-shrink-0 bg-zone-carbs border-zone-carbs`}
                                      >
                                        <div className={`${isMobile ? 'w-1 h-1' : 'w-1.5 h-1.5'} bg-white rounded-full`} />
                                      </div>
                                    </div>
                                  </div>
                                </CardContent>
                              </Card>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </CardContent>
    </>
  );

  return showHeader ? (
    <Card className="bg-gradient-to-r from-zone-carbs/5 to-zone-fat/5">
      {content}
    </Card>
  ) : (
    <div className="space-y-4">
      {content}
    </div>
  );
}