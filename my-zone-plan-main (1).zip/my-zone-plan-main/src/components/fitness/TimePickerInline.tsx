import { Button } from '@/components/ui/button';
import { ChevronUp, ChevronDown } from 'lucide-react';

interface TimePickerInlineProps {
  value: string; // format: "HH:MM"
  onChange: (time: string) => void;
  className?: string;
  size?: 'sm' | 'md';
}

export function TimePickerInline({ value, onChange, className = "", size = 'md' }: TimePickerInlineProps) {
  const [hStr, mStr] = value.split(':');
  const hours = parseInt(hStr || '0', 10) || 0;
  const minutes = parseInt(mStr || '0', 10) || 0;

  const numClass = size === 'sm' ? 'text-lg min-w-[2rem]' : 'text-2xl min-w-[2.5rem]';
  const btnSizeClass = size === 'sm' ? 'h-4 w-6' : 'h-5 w-7';

  const updateHours = (newHours: number) => {
    const clampedHours = (newHours + 24) % 24;
    const formattedTime = `${clampedHours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
    onChange(formattedTime);
  };

  const updateMinutes = (newMinutes: number) => {
    const wrapped = (newMinutes + 60) % 60;
    const formattedTime = `${hours.toString().padStart(2, '0')}:${wrapped.toString().padStart(2, '0')}`;
    onChange(formattedTime);
  };

  return (
    <div className={`flex items-center justify-center gap-1 ${className}`}>
      {/* Hours */}
      <div className="flex flex-col items-center">
        <Button
          variant="ghost"
          size="sm"
          className={`${btnSizeClass} p-0 hover:bg-primary/10`}
          onClick={() => updateHours(hours + 1)}
          aria-label="Increase hour"
        >
          <ChevronUp className="w-3 h-3" />
        </Button>
        
        <div className="flex">
          <button
            onClick={() => updateHours(hours + 1)}
            className={`${numClass} font-bold px-1 py-1 hover:bg-primary/10 rounded transition-colors text-center`}
            aria-label="Hour"
          >
            {hours.toString().padStart(2, '0')}
          </button>
        </div>
        
        <Button
          variant="ghost"
          size="sm"
          className={`${btnSizeClass} p-0 hover:bg-primary/10`}
          onClick={() => updateHours(hours - 1)}
          aria-label="Decrease hour"
        >
          <ChevronDown className="w-3 h-3" />
        </Button>
      </div>

      {/* Separator */}
      <div className={`${size === 'sm' ? 'text-lg' : 'text-2xl'} font-bold px-1`}>:</div>

      {/* Minutes */}
      <div className="flex flex-col items-center">
        <Button
          variant="ghost"
          size="sm"
          className={`${btnSizeClass} p-0 hover:bg-primary/10`}
          onClick={() => updateMinutes(minutes + 15)}
          aria-label="Increase minutes"
        >
          <ChevronUp className="w-3 h-3" />
        </Button>
        
        <div className="flex">
          <button
            onClick={() => updateMinutes(minutes + 15)}
            className={`${numClass} font-bold px-1 py-1 hover:bg-primary/10 rounded transition-colors text-center`}
            aria-label="Minutes"
          >
            {minutes.toString().padStart(2, '0')}
          </button>
        </div>
        
        <Button
          variant="ghost"
          size="sm"
          className={`${btnSizeClass} p-0 hover:bg-primary/10`}
          onClick={() => updateMinutes(minutes - 15)}
          aria-label="Decrease minutes"
        >
          <ChevronDown className="w-3 h-3" />
        </Button>
      </div>
    </div>
  );
}
