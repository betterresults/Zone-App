import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { TimeDisplay } from './TimeDisplay';

interface RestBetweenExercisesSettingsProps {
  value: number; // seconds
  onChange: (seconds: number) => void;
  className?: string;
}

export const RestBetweenExercisesSettings = ({ 
  value, 
  onChange, 
  className = "" 
}: RestBetweenExercisesSettingsProps) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const minutes = parseFloat(e.target.value) || 0;
    onChange(Math.max(0, minutes * 60)); // Convert to seconds, minimum 0
  };

  return (
    <div className={`space-y-2 ${className}`}>
      <Label className="text-sm font-medium">
        Почивка между упражнения
      </Label>
      <div className="flex items-center gap-3">
        <Input
          type="number"
          min="0"
          step="0.5"
          value={value / 60} // Convert seconds to minutes for display
          onChange={handleChange}
          className="w-20"
          placeholder="2"
        />
        <span className="text-sm text-muted-foreground">минути</span>
        <div className="text-sm text-muted-foreground">
          (<TimeDisplay seconds={value} showToggle={false} />)
        </div>
      </div>
    </div>
  );
};