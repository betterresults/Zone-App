import React, { useState } from 'react';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Clock } from 'lucide-react';
import { TimePickerPopover } from './TimePickerPopover';

interface ModernDayToggleProps {
  day: {
    id: number;
    name: string;
    fullName: string;
  };
  isActive: boolean;
  time?: string;
  onToggle: (dayId: number) => void;
  onTimeChange: (dayId: number, time: string) => void;
}

export function ModernDayToggle({ day, isActive, time = '09:00', onToggle, onTimeChange }: ModernDayToggleProps) {
  const [showTimePicker, setShowTimePicker] = useState(false);

  return (
    <div 
      className={`
        relative p-4 rounded-xl border-2 transition-all duration-300 group
        ${isActive 
          ? 'bg-gradient-to-br from-primary/20 to-primary/30 border-primary shadow-lg shadow-primary/20' 
          : 'bg-card hover:bg-accent/50 border-border hover:border-primary/30'
        }
      `}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="text-center">
            <div className={`text-lg font-bold ${isActive ? 'text-primary' : 'text-foreground'}`}>
              {day.name}
            </div>
            <div className={`text-xs ${isActive ? 'text-primary/80' : 'text-muted-foreground'}`}>
              {day.fullName}
            </div>
          </div>
        </div>
        
        <Switch
          checked={isActive}
          onCheckedChange={() => onToggle(day.id)}
          className="data-[state=checked]:bg-primary"
        />
      </div>
      
      {isActive && (
        <div className="mt-3 pt-3 border-t border-primary/20">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowTimePicker(true)}
            className="w-full justify-start gap-2 text-primary hover:text-primary hover:bg-primary/10"
          >
            <Clock className="w-3 h-3" />
            <span className="font-medium">{time}</span>
          </Button>
        </div>
      )}

      <TimePickerPopover
        value={time}
        onChange={(newTime) => onTimeChange(day.id, newTime)}
        open={showTimePicker}
        onOpenChange={setShowTimePicker}
        dayName={day.fullName}
      />
    </div>
  );
}