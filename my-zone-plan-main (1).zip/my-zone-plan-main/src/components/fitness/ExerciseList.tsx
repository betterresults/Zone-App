import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  GripVertical, 
  Edit, 
  Trash2, 
  Timer, 
  Weight,
  Target,
  ArrowDown
} from 'lucide-react';
import { WorkoutExercise } from '@/hooks/useExercises';
import { TimeDisplay } from './TimeDisplay';

interface ExerciseListProps {
  exercises: WorkoutExercise[];
  restBetweenExercises: number;
  onReorder: (exercises: { id: string; exercise_order: number }[]) => void;
  onEdit?: (exercise: WorkoutExercise) => void;
  onDelete?: (id: string) => void;
}

export function ExerciseList({ 
  exercises, 
  restBetweenExercises,
  onReorder, 
  onEdit, 
  onDelete 
}: ExerciseListProps) {
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);

  const handleDragStart = (index: number) => {
    setDraggedIndex(index);
  };

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    
    if (draggedIndex === null || draggedIndex === index) return;

    const newExercises = [...exercises];
    const draggedItem = newExercises[draggedIndex];
    
    // Remove from old position
    newExercises.splice(draggedIndex, 1);
    // Insert at new position
    newExercises.splice(index, 0, draggedItem);
    
    // Update exercise_order for all
    const reordered = newExercises.map((ex, idx) => ({
      id: ex.id,
      exercise_order: idx
    }));
    
    onReorder(reordered);
    setDraggedIndex(index);
  };

  const handleDragEnd = () => {
    setDraggedIndex(null);
  };

  if (exercises.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        Няма добавени упражнения
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {exercises.map((exercise, index) => (
        <div key={exercise.id}>
          <Card 
            draggable
            onDragStart={() => handleDragStart(index)}
            onDragOver={(e) => handleDragOver(e, index)}
            onDragEnd={handleDragEnd}
            className={`cursor-move transition-all ${
              draggedIndex === index ? 'opacity-50' : ''
            }`}
          >
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className="mt-1 cursor-grab active:cursor-grabbing">
                  <GripVertical className="w-5 h-5 text-muted-foreground" />
                </div>
                
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h4 className="font-semibold text-base">
                        {index + 1}. {exercise.exercise?.name}
                      </h4>
                      {exercise.exercise?.category && (
                        <Badge variant="secondary" className="text-xs mt-1">
                          {exercise.exercise.category}
                        </Badge>
                      )}
                    </div>
                    
                    <div className="flex gap-1">
                      {onEdit && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => onEdit(exercise)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                      )}
                      {onDelete && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-destructive hover:text-destructive"
                          onClick={() => onDelete(exercise.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-3 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Target className="w-4 h-4" />
                      <span>{exercise.sets} серии</span>
                    </div>
                    
                    {exercise.reps && (
                      <div className="flex items-center gap-1">
                        <span>×</span>
                        <span>{exercise.reps} повторения</span>
                      </div>
                    )}
                    
                    {exercise.duration_seconds && exercise.duration_seconds > 0 && (
                      <div className="flex items-center gap-1">
                        <Timer className="w-4 h-4" />
                        <TimeDisplay seconds={exercise.duration_seconds} showToggle={false} />
                      </div>
                    )}
                    
                    {exercise.weight_kg && exercise.weight_kg > 0 && (
                      <div className="flex items-center gap-1">
                        <Weight className="w-4 h-4" />
                        <span>{exercise.weight_kg}кг</span>
                      </div>
                    )}
                    
                    <div className="flex items-center gap-1">
                      <Timer className="w-4 h-4" />
                      <span>Почивка: <TimeDisplay seconds={exercise.rest_seconds} showToggle={false} /></span>
                    </div>
                  </div>
                  
                  {exercise.notes && (
                    <p className="mt-2 text-sm text-muted-foreground">
                      {exercise.notes}
                    </p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Show rest between exercises except for last exercise */}
          {index < exercises.length - 1 && (
            <div className="flex items-center justify-center py-2 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <div className="h-8 w-px bg-border" />
                <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-muted/50">
                  <ArrowDown className="w-4 h-4" />
                  <span>Почивка: <TimeDisplay seconds={restBetweenExercises} showToggle={false} /></span>
                </div>
                <div className="h-8 w-px bg-border" />
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}