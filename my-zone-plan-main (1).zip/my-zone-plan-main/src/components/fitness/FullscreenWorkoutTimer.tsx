import { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Card, CardContent } from '@/components/ui/card';
import { Play, Pause, Square, X, Target, Clock, SkipForward, Volume2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { TimeDisplay } from './TimeDisplay';
import { useWorkoutTimer, WorkoutCalculation } from '@/hooks/useWorkoutTimer';
import type { WorkoutExercise } from '@/hooks/useExercises';

interface FullscreenWorkoutTimerProps {
  exercises: WorkoutExercise[];
  workoutName: string;
  isOpen: boolean;
  onClose: () => void;
  restBetweenExercises?: number; // секунди
}

type TimerState = 'ready' | 'exercise' | 'rest-between-sets' | 'rest-between-exercises' | 'completed';

interface WorkoutProgress {
  currentExerciseIndex: number;
  currentSet: number;
  currentRep?: number;
  remainingTime: number;
  state: TimerState;
}

export function FullscreenWorkoutTimer({ 
  exercises, 
  workoutName, 
  isOpen, 
  onClose,
  restBetweenExercises = 120 
}: FullscreenWorkoutTimerProps) {
  const { calculateWorkoutTime } = useWorkoutTimer();
  
  const [progress, setProgress] = useState<WorkoutProgress>({
    currentExerciseIndex: 0,
    currentSet: 1,
    remainingTime: 0,
    state: 'ready'
  });
  
  const [isPaused, setIsPaused] = useState(false);
  const [totalElapsedSeconds, setTotalElapsedSeconds] = useState(0);

  // Calculate total workout time
  const workoutCalculation = calculateWorkoutTime(
    exercises.map(exercise => ({
      sets: exercise.sets,
      reps: exercise.reps,
      duration_seconds: exercise.duration_seconds,
      rest_seconds: exercise.rest_seconds
    })),
    restBetweenExercises
  );

  // Lock page scroll while fullscreen timer is open
  useEffect(() => {
    if (!isOpen) return;
    const { style } = document.documentElement;
    const prevOverflow = style.overflow;
    style.overflow = 'hidden';
    return () => {
      style.overflow = prevOverflow;
    };
  }, [isOpen]);

  // Timer logic
  useEffect(() => {
    if (progress.state === 'ready' || progress.state === 'completed' || isPaused) {
      return;
    }

    const interval = setInterval(() => {
      setTotalElapsedSeconds(prev => prev + 1);
      
      setProgress(prev => {
        const newRemainingTime = prev.remainingTime - 1;
        
        if (newRemainingTime <= 0) {
          // Sound notification here in the future
          playNotificationSound();
          
          return getNextState(prev);
        }
        
        return {
          ...prev,
          remainingTime: newRemainingTime
        };
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [progress.state, isPaused, exercises, restBetweenExercises]);

  const playNotificationSound = () => {
    // Simple beep sound using Web Audio API
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.value = 800;
      oscillator.type = 'sine';
      
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
      
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.5);
    } catch (error) {
      console.warn('Could not play notification sound:', error);
    }
  };

  const getNextState = (currentProgress: WorkoutProgress): WorkoutProgress => {
    const currentExercise = exercises[currentProgress.currentExerciseIndex];
    
    if (currentProgress.state === 'exercise') {
      // Exercise finished, check if we need rest between sets
      if (currentProgress.currentSet < currentExercise.sets) {
        return {
          ...currentProgress,
          currentSet: currentProgress.currentSet + 1,
          remainingTime: currentExercise.rest_seconds,
          state: 'rest-between-sets'
        };
      } else {
        // Exercise completely finished, move to next exercise or rest between exercises
        if (currentProgress.currentExerciseIndex < exercises.length - 1) {
          return {
            ...currentProgress,
            currentExerciseIndex: currentProgress.currentExerciseIndex + 1,
            currentSet: 1,
            remainingTime: restBetweenExercises,
            state: 'rest-between-exercises'
          };
        } else {
          return {
            ...currentProgress,
            state: 'completed'
          };
        }
      }
    } else if (currentProgress.state === 'rest-between-sets') {
      // Rest finished, continue with next set
      const exerciseTime = getExerciseTime(currentExercise);
      return {
        ...currentProgress,
        remainingTime: exerciseTime,
        state: 'exercise'
      };
    } else if (currentProgress.state === 'rest-between-exercises') {
      // Rest finished, start next exercise
      const nextExercise = exercises[currentProgress.currentExerciseIndex];
      const exerciseTime = getExerciseTime(nextExercise);
      return {
        ...currentProgress,
        remainingTime: exerciseTime,
        state: 'exercise'
      };
    }
    
    return currentProgress;
  };

  const getExerciseTime = (exercise: WorkoutExercise): number => {
    if (exercise.duration_seconds && exercise.duration_seconds > 0) {
      return exercise.duration_seconds;
    }
    // For strength exercises, assume 3 seconds per rep
    return (exercise.reps || 1) * 3;
  };

  const handleStart = () => {
    if (progress.state === 'ready') {
      const firstExercise = exercises[0];
      const exerciseTime = getExerciseTime(firstExercise);
      
      setProgress({
        currentExerciseIndex: 0,
        currentSet: 1,
        remainingTime: exerciseTime,
        state: 'exercise'
      });
    }
    setIsPaused(false);
  };

  const handlePause = () => {
    setIsPaused(!isPaused);
  };

  const handleStop = () => {
    setProgress({
      currentExerciseIndex: 0,
      currentSet: 1,
      remainingTime: 0,
      state: 'ready'
    });
    setIsPaused(false);
    setTotalElapsedSeconds(0);
    onClose();
  };

  const handleSkip = () => {
    setProgress(prev => getNextState({ ...prev, remainingTime: 0 }));
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getCurrentExercise = () => exercises[progress.currentExerciseIndex];
  const getOverallProgress = () => {
    if (workoutCalculation.totalWorkoutTime === 0) return 0;
    return Math.min((totalElapsedSeconds / workoutCalculation.totalWorkoutTime) * 100, 100);
  };

  const getStateText = () => {
    switch (progress.state) {
      case 'exercise':
        return `Серия ${progress.currentSet} от ${getCurrentExercise()?.sets}`;
      case 'rest-between-sets':
        return 'Почивка между серии';
      case 'rest-between-exercises':
        return 'Почивка между упражнения';
      case 'completed':
        return 'Тренировка завършена!';
      default:
        return 'Готов за започване';
    }
  };

  if (!isOpen || exercises.length === 0) return null;

  const currentExercise = getCurrentExercise();

  return createPortal(
    <div className="fixed inset-0 z-[100000] bg-background flex items-center justify-center overflow-hidden">
      <Card className="w-full h-full max-w-none rounded-none border-0 shadow-none">
        <CardContent className="p-4 sm:p-8 h-full flex flex-col">
          {/* Header */}
          <div className="flex items-center justify-between mb-4 sm:mb-6 flex-shrink-0">
            <div className="flex items-center gap-3 min-w-0 flex-1">
              <Target className="w-6 h-6 text-primary flex-shrink-0" />
              <h1 className="text-lg sm:text-2xl font-bold truncate">{workoutName}</h1>
            </div>
            <Button
              variant="outline"
              size="icon"
              onClick={onClose}
              className="h-10 w-10 sm:h-12 sm:w-12"
            >
              <X className="w-5 h-5 sm:w-6 sm:h-6" />
            </Button>
          </div>

          {/* Progress Overview */}
          <div className="mb-4 sm:mb-6 space-y-2">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>Общо време: <TimeDisplay seconds={workoutCalculation.totalWorkoutTime} /></span>
              <span>Изминало: {formatTime(totalElapsedSeconds)}</span>
            </div>
            <Progress value={getOverallProgress()} className="h-2" />
          </div>

          {/* Current Exercise Info */}
          {progress.state !== 'ready' && currentExercise && (
            <div className="mb-6 sm:mb-8 text-center">
              <div className="text-lg sm:text-xl font-medium mb-2">
                Упражнение {progress.currentExerciseIndex + 1} от {exercises.length}
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold mb-4">{currentExercise.exercise?.name}</h2>
              <div className="text-base sm:text-lg text-muted-foreground">
                {getStateText()}
              </div>
            </div>
          )}

          {/* Main Timer Display */}
          <div className="text-center mb-6 sm:mb-8 flex-1 flex flex-col justify-center">
            {progress.state === 'ready' ? (
              <div className="space-y-6">
                <div className="text-4xl sm:text-6xl font-bold text-muted-foreground">
                  Готов за започване
                </div>
                <div className="text-lg sm:text-xl">
                  {exercises.length} упражнения • <TimeDisplay seconds={workoutCalculation.totalWorkoutTime} />
                </div>
              </div>
            ) : progress.state === 'completed' ? (
              <div className="space-y-6">
                <div className="text-4xl sm:text-6xl font-bold text-green-600">
                  ✓ Браво!
                </div>
                <div className="text-lg sm:text-xl text-muted-foreground">
                  Тренировка завършена за {formatTime(totalElapsedSeconds)}
                </div>
              </div>
            ) : (
              <div className={cn(
                "text-6xl sm:text-8xl md:text-9xl font-mono font-bold select-none leading-none",
                progress.state === 'exercise' ? "text-primary" : "text-orange-500"
              )}>
                {formatTime(progress.remainingTime)}
              </div>
            )}
          </div>

          {/* Exercise Details */}
          {progress.state === 'exercise' && currentExercise && (
            <div className="mb-6 text-center">
              <div className="flex justify-center gap-4 text-sm text-muted-foreground">
                {currentExercise.exercise?.category === 'cardio' ? (
                  <>
                    {currentExercise.distance_meters && (
                      <span>{currentExercise.distance_meters}м</span>
                    )}
                  </>
                ) : (
                  <>
                    {currentExercise.reps && (
                      <span>{currentExercise.reps} повторения</span>
                    )}
                    {currentExercise.weight_kg && (
                      <span>{currentExercise.weight_kg}кг</span>
                    )}
                  </>
                )}
              </div>
            </div>
          )}

          {/* Controls */}
          <div className="flex justify-center gap-3 sm:gap-4 flex-shrink-0 flex-wrap">
            {progress.state === 'ready' ? (
              <Button 
                onClick={handleStart}
                size="lg" 
                className="gap-3 px-8 py-4 text-lg font-semibold"
              >
                <Play className="w-6 h-6" />
                Започни тренировка
              </Button>
            ) : progress.state === 'completed' ? (
              <Button 
                onClick={handleStop}
                size="lg" 
                className="gap-3 px-8 py-4 text-lg font-semibold"
              >
                <X className="w-6 h-6" />
                Затвори
              </Button>
            ) : (
              <>
                <Button 
                  onClick={handlePause}
                  size="lg" 
                  variant="outline"
                  className="gap-2 px-6 py-4"
                >
                  {isPaused ? <Play className="w-5 h-5" /> : <Pause className="w-5 h-5" />}
                  {isPaused ? 'Продължи' : 'Пауза'}
                </Button>
                
                <Button 
                  onClick={handleSkip}
                  size="lg" 
                  variant="outline"
                  className="gap-2 px-6 py-4"
                >
                  <SkipForward className="w-5 h-5" />
                  Прескочи
                </Button>
                
                <Button 
                  onClick={handleStop}
                  size="lg" 
                  variant="destructive"
                  className="gap-2 px-6 py-4"
                >
                  <Square className="w-5 h-5" />
                  Спри
                </Button>
              </>
            )}
          </div>

          {/* Status */}
          {progress.state !== 'ready' && progress.state !== 'completed' && (
            <div className="mt-4 text-center">
              <div className={cn(
                "inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm",
                isPaused ? "bg-yellow-100 text-yellow-800" : 
                progress.state === 'exercise' ? "bg-green-100 text-green-800" : "bg-blue-100 text-blue-800"
              )}>
                <Clock className="w-4 h-4" />
                {isPaused ? "На пауза" : progress.state === 'exercise' ? "Упражнение" : "Почивка"}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
    , document.body);
}