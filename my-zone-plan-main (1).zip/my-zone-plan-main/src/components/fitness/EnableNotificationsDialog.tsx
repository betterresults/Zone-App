import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { ChevronUp, ChevronDown } from "lucide-react";
import { useState, useEffect } from "react";

interface EnableNotificationsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  defaultMinutes: number;
  onConfirm: (minutes: number) => void;
  onSkip: () => void;
}

export function EnableNotificationsDialog({ 
  open, 
  onOpenChange, 
  defaultMinutes,
  onConfirm, 
  onSkip 
}: EnableNotificationsDialogProps) {
  const [minutes, setMinutes] = useState<number>(defaultMinutes || 30);

  useEffect(() => {
    setMinutes(defaultMinutes || 30);
  }, [defaultMinutes]);

  const inc = () => setMinutes((m) => Math.min(120, (m || 30) + 5));
  const dec = () => setMinutes((m) => Math.max(1, (m || 30) - 5));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Известия за тренировки</DialogTitle>
          <DialogDescription>
            Искате ли да включите известията за тренировки? Може да изберете колко минути преди началото да получите напомняне.
          </DialogDescription>
        </DialogHeader>

        <div className="mt-2 space-y-2">
          <Label className="text-sm font-medium">Известие преди</Label>
          <div className="flex items-center gap-2">
            <Button size="icon" variant="secondary" onClick={inc} aria-label="Увеличи минутите">
              <ChevronUp className="w-4 h-4" />
            </Button>
            <Input
              type="number"
              min={1}
              max={120}
              value={minutes}
              onChange={(e) => setMinutes(Math.max(1, Math.min(120, parseInt(e.target.value) || 0)))}
              className="w-24 text-center text-2xl font-bold h-10"
            />
            <Button size="icon" variant="secondary" onClick={dec} aria-label="Намали минутите">
              <ChevronDown className="w-4 h-4" />
            </Button>
            <span className="text-sm">мин</span>
          </div>
        </div>

        <DialogFooter className="flex-col sm:flex-row gap-2">
          <Button variant="outline" onClick={onSkip} className="w-full sm:w-auto">
            Не, благодаря
          </Button>
          <Button onClick={() => onConfirm(minutes)} className="w-full sm:w-auto">
            Да, включи известията
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
