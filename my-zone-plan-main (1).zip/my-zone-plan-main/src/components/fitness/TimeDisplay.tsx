import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Clock, Timer } from 'lucide-react';

interface TimeDisplayProps {
  seconds: number;
  showToggle?: boolean;
  className?: string;
}

export const TimeDisplay = ({ seconds, showToggle = false, className = "" }: TimeDisplayProps) => {
  const [showAsMinutes, setShowAsMinutes] = useState(true);

  const formatTime = (totalSeconds: number, asMinutes: boolean) => {
    if (asMinutes) {
      const mins = Math.floor(totalSeconds / 60);
      const secs = totalSeconds % 60;
      return `${mins}:${secs.toString().padStart(2, '0')}`;
    }
    return `${totalSeconds}с`;
  };

  return (
    <div className={`flex items-center gap-1 ${className}`}>
      <span className="font-mono text-sm">
        {formatTime(seconds, showAsMinutes)}
      </span>
      {showToggle && (
        <Button
          size="sm"
          variant="ghost"
          onClick={() => setShowAsMinutes(!showAsMinutes)}
          className="h-6 w-6 p-0"
          title={showAsMinutes ? 'Покажи в секунди' : 'Покажи в минути:секунди'}
        >
          {showAsMinutes ? <Timer className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
        </Button>
      )}
    </div>
  );
};