import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Clock } from 'lucide-react';

interface TimePickerPopoverProps {
  value: string; // format: "HH:MM"
  onChange: (time: string) => void;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  dayName: string;
}

export function TimePickerPopover({ value, onChange, open, onOpenChange, dayName }: TimePickerPopoverProps) {
  const [hours, minutes] = value.split(':').map(Number);
  const [selectedHours, setSelectedHours] = useState(hours);
  const [selectedMinutes, setSelectedMinutes] = useState(minutes);

  const handleSave = () => {
    const formattedTime = `${selectedHours.toString().padStart(2, '0')}:${selectedMinutes.toString().padStart(2, '0')}`;
    onChange(formattedTime);
    onOpenChange(false);
  };

  const handleCancel = () => {
    setSelectedHours(hours);
    setSelectedMinutes(minutes);
    onOpenChange(false);
  };

  const hourOptions = Array.from({ length: 24 }, (_, i) => i);
  const minuteOptions = [0, 15, 30, 45];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Clock className="w-4 h-4" />
            Час за тренировка - {dayName}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="space-y-3">
            <label className="text-sm font-medium">Часове</label>
            <div className="grid grid-cols-6 gap-1 max-h-32 overflow-y-auto">
              {hourOptions.map((hour) => (
                <Button
                  key={hour}
                  variant={selectedHours === hour ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedHours(hour)}
                  className="h-8"
                >
                  {hour.toString().padStart(2, '0')}
                </Button>
              ))}
            </div>
          </div>
          
          <div className="space-y-3">
            <label className="text-sm font-medium">Минути</label>
            <div className="grid grid-cols-4 gap-2">
              {minuteOptions.map((minute) => (
                <Button
                  key={minute}
                  variant={selectedMinutes === minute ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedMinutes(minute)}
                  className="h-8"
                >
                  {minute.toString().padStart(2, '0')}
                </Button>
              ))}
            </div>
          </div>
          
          <div className="flex gap-2 pt-4">
            <Button variant="outline" onClick={handleCancel} className="flex-1">
              Отказ
            </Button>
            <Button onClick={handleSave} className="flex-1">
              Запази
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}