import { useWorkoutExercises } from '@/hooks/useExercises';
import { FullscreenWorkoutTimer } from './FullscreenWorkoutTimer';
import { Habit } from '@/hooks/useHabits';
import { useProfile } from '@/hooks/useProfile';

interface WorkoutTimerForHabitProps {
  habit: Habit;
  onClose: () => void;
}

export function WorkoutTimerForHabit({ habit, onClose }: WorkoutTimerForHabitProps) {
  const { profile } = useProfile();
  const sessionDate = habit.one_time_date || new Date().toISOString().split('T')[0];
  const { workoutExercises } = useWorkoutExercises(sessionDate);
  
  // Get rest between exercises from profile or default
  const restBetweenExercises = (profile as any)?.rest_between_exercises_seconds || 120;

  if (!workoutExercises || workoutExercises.length === 0) {
    return null;
  }

  return (
    <FullscreenWorkoutTimer
      exercises={workoutExercises}
      workoutName={habit.name}
      isOpen={true}
      onClose={onClose}
      restBetweenExercises={restBetweenExercises}
    />
  );
}