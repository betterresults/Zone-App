import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useWorkoutExercises } from '@/hooks/useExercises';
import { useAuth } from '@/hooks/useAuth';
import { Plus, Target, Copy, Play } from 'lucide-react';
import { ExerciseSelector } from './ExerciseSelector';
import { ExerciseList } from './ExerciseList';
import { TimeDisplay } from './TimeDisplay';
import { useWorkoutTimer } from '@/hooks/useWorkoutTimer';
import { FullscreenWorkoutTimer } from './FullscreenWorkoutTimer';
import { toast } from 'sonner';

interface WorkoutLogProps {
  sessionDate: string;
  dayName: string;
  dayOfWeek: number; // 0-6
  trainingTime: string; // HH:MM format
  allTrainingDays: number[];
  restBetweenExercises?: number; // секунди
}

export const WorkoutLog = ({ sessionDate, dayName, dayOfWeek, trainingTime, allTrainingDays, restBetweenExercises = 120 }: WorkoutLogProps) => {
  const { user } = useAuth();
  const { 
    workoutExercises, 
    deleteWorkoutExerciseMutation, 
    reorderWorkoutExercisesMutation,
    copyWorkoutToOtherDays 
  } = useWorkoutExercises(sessionDate);
  const { calculateWorkoutTime } = useWorkoutTimer();
  const [showExerciseSelector, setShowExerciseSelector] = useState(false);
  const [showWorkoutTimer, setShowWorkoutTimer] = useState(false);

  // Калкулация на общото време за тренировка
  const workoutCalculation = calculateWorkoutTime(
    workoutExercises.map(exercise => ({
      sets: exercise.sets,
      reps: exercise.reps,
      duration_seconds: exercise.duration_seconds,
      rest_seconds: exercise.rest_seconds
    })),
    restBetweenExercises
  );

  const handleReorder = (exercises: { id: string; exercise_order: number }[]) => {
    reorderWorkoutExercisesMutation.mutate(exercises);
  };

  const copyToAllDays = async () => {
    if (!workoutExercises.length) {
      toast.error('Няма упражнения за копиране');
      return;
    }

    try {
      // Копираме към всички други дни от текущата седмица
      const otherDays = allTrainingDays.filter(day => day !== dayOfWeek);
      await copyWorkoutToOtherDays.mutateAsync({
        sourceDate: sessionDate,
        targetDays: otherDays,
        exercises: workoutExercises
      });
      toast.success(`Тренировката е приложена към ${otherDays.length} други дни!`);
    } catch (error) {
      console.error('Error copying workout:', error);
      toast.error('Грешка при прилагане на тренировката');
    }
  };

  return (
    <div className="space-y-4">
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <h3 className="font-medium text-center sm:text-left">Тренировка за {dayName} в {trainingTime}ч</h3>
          {workoutExercises.length > 0 && (
            <div className="flex items-center gap-2">
              <TimeDisplay 
                seconds={workoutCalculation.totalWorkoutTime} 
                showToggle={true}
                className="text-sm text-muted-foreground"
              />
              <Button 
                size="sm" 
                variant="default" 
                className="gap-2"
                onClick={() => setShowWorkoutTimer(true)}
              >
                <Play className="w-4 h-4" />
                <span className="hidden xs:inline">Започни тренировка</span>
                <span className="xs:hidden">Старт</span>
              </Button>
            </div>
          )}
        </div>
        {workoutExercises.length > 0 && (
          <div className="flex flex-col sm:flex-row gap-2">
            <Button 
              size="sm" 
              onClick={() => setShowExerciseSelector(true)}
              className="gap-2 flex-1"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden xs:inline">Добави упражнение</span>
              <span className="xs:hidden">Добави</span>
            </Button>
            {allTrainingDays.length > 1 && (
              <Button 
                size="sm" 
                variant="outline"
                onClick={copyToAllDays}
                disabled={copyWorkoutToOtherDays.isPending}
                className="gap-2 flex-1"
              >
                <Copy className="w-4 h-4" />
                <span className="hidden xs:inline">Приложи за всички дни</span>
                <span className="xs:hidden">Приложи</span>
              </Button>
            )}
          </div>
        )}
      </div>

      {workoutExercises.length === 0 ? (
        <Card className="rounded-2xl">
          <CardContent className="text-center py-8 space-y-4">
            <div className="text-muted-foreground">
              <Target className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p>Още няма добавени упражнения</p>
            </div>
            <Button 
              size="sm" 
              onClick={() => setShowExerciseSelector(true)}
              className="gap-2"
            >
              <Plus className="w-4 h-4" />
              Добави упражнение
            </Button>
          </CardContent>
        </Card>
      ) : (
        <ScrollArea className="h-96">
          <ExerciseList
            exercises={workoutExercises}
            restBetweenExercises={restBetweenExercises}
            onReorder={handleReorder}
            onDelete={(id) => deleteWorkoutExerciseMutation.mutate(id)}
          />
        </ScrollArea>
      )}

      <ExerciseSelector 
        open={showExerciseSelector}
        onOpenChange={setShowExerciseSelector}
        sessionDate={sessionDate}
      />

      <FullscreenWorkoutTimer
        exercises={workoutExercises}
        workoutName={`Тренировка за ${dayName}`}
        isOpen={showWorkoutTimer}
        onClose={() => setShowWorkoutTimer(false)}
        restBetweenExercises={restBetweenExercises}
      />
    </div>
  );
};