import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { useExercises, useWorkoutExercises, Exercise } from '@/hooks/useExercises';
import { Plus, Dumbbell, Timer, Target, Zap } from 'lucide-react';

interface ExerciseSelectorProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sessionDate: string;
}

export const ExerciseSelector = ({ open, onOpenChange, sessionDate }: ExerciseSelectorProps) => {
  const { exercises, isLoading } = useExercises();
  const { addWorkoutExerciseMutation } = useWorkoutExercises(sessionDate);
  const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(null);
  const [exerciseData, setExerciseData] = useState({
    sets: 1,
    reps: 10,
    weight_kg: 0,
    duration_seconds: 0,
    duration_unit: 'минути' as 'секунди' | 'минути',
    distance_meters: 0,
    distance_unit: 'километри' as 'метри' | 'километри',
    rest_seconds: 60,
    notes: ''
  });

  const categoryLabels: Record<string, string> = {
    strength: 'Силови',
    cardio: 'Кардио',
    core: 'Корем',
    flexibility: 'Гъвкавост',
    balance: 'Баланс'
  };

  const difficultyColors: Record<string, string> = {
    beginner: 'bg-green-100 text-green-800',
    intermediate: 'bg-yellow-100 text-yellow-800',
    advanced: 'bg-red-100 text-red-800'
  };

  const groupedExercises = exercises.reduce((acc, exercise) => {
    if (!acc[exercise.category]) {
      acc[exercise.category] = [];
    }
    acc[exercise.category].push(exercise);
    return acc;
  }, {} as Record<string, Exercise[]>);

  // Sort exercises within categories - put popular ones first
  Object.keys(groupedExercises).forEach(category => {
    if (category === 'cardio') {
      groupedExercises[category].sort((a, b) => {
        const order = ['Бягане', 'Ходене', 'Каране на велосипед', 'Скачане на въже', 'Бърпита'];
        const aIndex = order.indexOf(a.name);
        const bIndex = order.indexOf(b.name);
        if (aIndex === -1 && bIndex === -1) return a.name.localeCompare(b.name);
        if (aIndex === -1) return 1;
        if (bIndex === -1) return -1;
        return aIndex - bIndex;
      });
    } else {
      groupedExercises[category].sort((a, b) => a.name.localeCompare(b.name));
    }
  });

  const handleAddExercise = () => {
    if (!selectedExercise) return;

    const dataToSubmit: any = {
      exercise_id: selectedExercise.id,
      session_date: sessionDate,
      sets: exerciseData.sets,
      rest_seconds: exerciseData.rest_seconds,
      notes: exerciseData.notes || undefined
    };

    // Add relevant data based on exercise category
    if (selectedExercise.category === 'cardio') {
      if (exerciseData.duration_seconds > 0) {
        const durationInSeconds = exerciseData.duration_unit === 'минути' 
          ? exerciseData.duration_seconds * 60 
          : exerciseData.duration_seconds;
        dataToSubmit.duration_seconds = durationInSeconds;
      }
      if (exerciseData.distance_meters > 0) {
        const distanceInMeters = exerciseData.distance_unit === 'километри'
          ? exerciseData.distance_meters * 1000
          : exerciseData.distance_meters;
        dataToSubmit.distance_meters = distanceInMeters;
      }
    } else {
      if (exerciseData.reps > 0) {
        dataToSubmit.reps = exerciseData.reps;
      }
      if (exerciseData.weight_kg > 0) {
        dataToSubmit.weight_kg = exerciseData.weight_kg;
      }
    }

    addWorkoutExerciseMutation.mutate(dataToSubmit);
    setSelectedExercise(null);
    setExerciseData({
      sets: 1,
      reps: 10,
      weight_kg: 0,
      duration_seconds: 0,
      duration_unit: 'минути',
      distance_meters: 0,
      distance_unit: 'километри',
      rest_seconds: 60,
      notes: ''
    });
    onOpenChange(false);
  };

  const resetForm = () => {
    setSelectedExercise(null);
    setExerciseData({
      sets: 1,
      reps: 10,
      weight_kg: 0,
      duration_seconds: 0,
      duration_unit: 'минути',
      distance_meters: 0,
      distance_unit: 'километри',
      rest_seconds: 60,
      notes: ''
    });
  };

  return (
    <Dialog open={open} onOpenChange={(isOpen) => {
      onOpenChange(isOpen);
      if (!isOpen) resetForm();
    }}>
      <DialogContent className="w-[95vw] max-w-[95vw] sm:max-w-3xl max-h-[90vh] overflow-hidden p-0 rounded-2xl">
        <DialogHeader className="p-4 pb-0">
          <DialogTitle className="flex items-center gap-2">
            <Dumbbell className="w-5 h-5" />
            Добави упражнение
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col h-[75vh] p-4">
          {/* Exercise Selection */}
          <div className="flex-1 min-h-0">
            <Tabs defaultValue="strength" className="h-full">
              <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 sticky top-0 z-10 bg-background mb-3 h-12 rounded-xl">
                <TabsTrigger value="strength" className="text-xs rounded-lg data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Силови</TabsTrigger>
                <TabsTrigger value="cardio" className="text-xs rounded-lg data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Кардио</TabsTrigger>
                <TabsTrigger value="core" className="text-xs rounded-lg data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Корем</TabsTrigger>
                <TabsTrigger value="flexibility" className="text-xs rounded-lg data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Гъвкавост</TabsTrigger>
              </TabsList>

              {Object.entries(groupedExercises).map(([category, categoryExercises]) => (
                <TabsContent key={category} value={category} className="h-[calc(100%-72px)] mt-0">
                  <ScrollArea className="h-full">
                    <div className="grid gap-2">
                      {categoryExercises.map((exercise) => (
                        <Card
                          key={exercise.id}
                          className={`cursor-pointer transition-all duration-200 hover:bg-accent/30 hover:shadow-md p-3 rounded-xl ${
                            selectedExercise?.id === exercise.id ? 'ring-2 ring-primary bg-accent/50' : ''
                          }`}
                          onClick={() => setSelectedExercise(exercise)}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1 min-w-0">
                              <h4 className="font-medium text-sm leading-tight">{exercise.name}</h4>
                              <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                                {exercise.description}
                              </p>
                              <div className="flex flex-wrap gap-1 mt-2">
                                <Badge className={`${difficultyColors[exercise.difficulty_level]} text-xs px-1.5 py-0.5`}>
                                  {exercise.difficulty_level}
                                </Badge>
                                {exercise.muscle_groups.slice(0, 2).map((muscle) => (
                                  <Badge key={muscle} variant="secondary" className="text-xs px-1.5 py-0.5">
                                    {muscle}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          </div>
                        </Card>
                      ))}
                    </div>
                  </ScrollArea>
                </TabsContent>
              ))}
            </Tabs>
          </div>

          {/* Exercise Configuration */}
          {selectedExercise && (
            <div className="border-t pt-4 mt-4">
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div>
                  <Label htmlFor="sets" className="text-xs">Серии</Label>
                  <Input
                    id="sets"
                    type="number"
                    min="1"
                    value={exerciseData.sets}
                    onChange={(e) => setExerciseData(prev => ({ 
                      ...prev, 
                      sets: parseInt(e.target.value) || 1 
                    }))}
                    className="h-8 text-sm"
                  />
                </div>
                
                {selectedExercise.category === 'cardio' ? (
                  <div>
                    <Label htmlFor="duration" className="text-xs">Време (мин)</Label>
                    <Input
                      id="duration"
                      type="number"
                      min="0"
                      value={exerciseData.duration_seconds}
                      onChange={(e) => setExerciseData(prev => ({ 
                        ...prev, 
                        duration_seconds: parseInt(e.target.value) || 0 
                      }))}
                      className="h-8 text-sm"
                    />
                  </div>
                ) : (
                  <div>
                    <Label htmlFor="reps" className="text-xs">Повторения</Label>
                    <Input
                      id="reps"
                      type="number"
                      min="1"
                      value={exerciseData.reps}
                      onChange={(e) => setExerciseData(prev => ({ 
                        ...prev, 
                        reps: parseInt(e.target.value) || 1 
                      }))}
                      className="h-8 text-sm"
                    />
                  </div>
                )}
              </div>
              
              <Button 
                onClick={handleAddExercise}
                disabled={addWorkoutExerciseMutation.isPending}
                className="w-full h-9"
                size="sm"
              >
                <Plus className="w-4 h-4 mr-2" />
                {addWorkoutExerciseMutation.isPending ? 'Добавяне...' : 'Добави'}
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};