import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { format, startOfWeek, addDays } from 'date-fns';
import { bg } from 'date-fns/locale';
import { Clock, Dumbbell } from 'lucide-react';

interface FitnessSettings {
  training_days: number[];
  training_times: { [day: number]: string };
}

interface CompactWeekSettingsProps {
  settings: FitnessSettings;
  onUpdateSettings: (newSettings: Partial<FitnessSettings>) => void;
  sessions?: any[]; // За показване на кубчета за упражненията 
}

const WEEKDAYS = [
  { id: 0, name: 'ПОН', fullName: 'Понеделник' },
  { id: 1, name: 'ВТО', fullName: 'Вторник' },
  { id: 2, name: 'СРЯ', fullName: 'Сряда' },
  { id: 3, name: 'ЧЕТ', fullName: 'Четвъртък' },
  { id: 4, name: 'ПЕТ', fullName: 'Петък' },
  { id: 5, name: 'САБ', fullName: 'Събота' },
  { id: 6, name: 'НЕД', fullName: 'Неделя' }
];

export function CompactWeekSettings({ settings, onUpdateSettings, sessions = [] }: CompactWeekSettingsProps) {
  const currentWeek = startOfWeek(new Date(), { weekStartsOn: 1 });
  
  const toggleDay = (dayId: number) => {
    const newTrainingDays = settings.training_days.includes(dayId)
      ? settings.training_days.filter(d => d !== dayId)
      : [...settings.training_days, dayId];
    
    onUpdateSettings({ training_days: newTrainingDays });
  };

  const updateTime = (dayId: number, time: string) => {
    const newTimes = { ...settings.training_times, [dayId]: time };
    onUpdateSettings({ training_times: newTimes });
  };

  return (
    <div className="space-y-1">
      {WEEKDAYS.map((day) => {
        const isActive = settings.training_days.includes(day.id);
        const dayTime = settings.training_times[day.id] || '10:00';
        const dayDate = addDays(currentWeek, day.id);
        const dayWorkouts = sessions.filter((session: any) => {
          const sessionDate = new Date(session.session_date);
          return sessionDate.toDateString() === dayDate.toDateString();
        });
        
        return (
          <div 
            key={day.id}
            className={`flex items-center space-x-2 p-2 rounded-lg transition-all border ${
              isActive 
                ? 'border-primary bg-primary/5' 
                : 'border-border/50 hover:border-primary/50 hover:bg-background/80'
            }`}
          >
            {/* Day indicator */}
            <div className="flex-shrink-0 w-10 text-center">
              <div className={`text-xs font-bold ${
                isActive ? 'text-primary' : 'text-muted-foreground'
              }`}>
                {day.name}
              </div>
              <div className="w-4 h-0.5 bg-border mx-auto mt-0.5" />
            </div>
            
            {/* Toggle Switch */}
            <div className="flex-shrink-0">
              <Switch
                checked={isActive}
                onCheckedChange={() => toggleDay(day.id)}
                className="scale-75"
              />
            </div>
            
            {/* Time input - centered */}
            <div className="flex-1 flex justify-center">
              {isActive ? (
                <div className="flex items-center gap-1">
                  <Clock className="w-3 h-3 text-muted-foreground" />
                  <Input
                    type="time"
                    value={dayTime}
                    onChange={(e) => updateTime(day.id, e.target.value)}
                    className="w-20 h-6 text-xs text-center border-0 bg-transparent focus:bg-background"
                  />
                </div>
              ) : (
                <div className="text-xs text-muted-foreground italic">
                  Неактивен
                </div>
              )}
            </div>
            
            {/* Workout indicators */}
            <div className="flex-shrink-0 flex items-center gap-1">
              {isActive && dayWorkouts.length > 0 ? (
                <div className="flex gap-0.5">
                  {dayWorkouts.slice(0, 3).map((_, index) => (
                    <div 
                      key={index}
                      className="w-2 h-2 rounded-sm bg-green-500"
                      title="Има тренировка"
                    />
                  ))}
                  {dayWorkouts.length > 3 && (
                    <div className="text-xs text-muted-foreground font-medium ml-1">
                      +{dayWorkouts.length - 3}
                    </div>
                  )}
                </div>
              ) : isActive ? (
                <div className="w-2 h-2 rounded-sm bg-muted-foreground/30" title="Няма тренировка" />
              ) : null}
            </div>
          </div>
        );
      })}
    </div>
  );
}