import React, { useState } from 'react';
import { AdvancedMealDialog } from '@/components/weekly-menu/AdvancedMealDialog';
import { useAuth } from '@/hooks/useAuth';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { format, startOfWeek, getDay } from 'date-fns';

interface AddMealToTodayDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedDate?: Date;
}

export const AddMealToTodayDialog = ({ open, onOpenChange, selectedDate = new Date() }: AddMealToTodayDialogProps) => {
  const [selectedMealType, setSelectedMealType] = useState<string>('lunch');
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Mock meal dialog structure for AdvancedMealDialog
  const mealDialog = {
    open,
    dayIndex: 0,
    mealType: selectedMealType,
    dayName: format(selectedDate, 'dd.MM.yyyy')
  };

  // Meal type options for daily mode
  const mealTypeOptions = [
    { value: 'breakfast', label: 'Закуска' },
    { value: 'lunch', label: 'Обяд' },
    { value: 'dinner', label: 'Вечеря' },
    { value: 'snack', label: 'Междинно' }
  ];

  const mealTypeLabels = {
    breakfast: 'Закуска',
    lunch: 'Обяд',
    dinner: 'Вечеря',
    snack: 'Междинно'
  };

  // Fetch user dishes
  const { data: dishes = [], refetch: refetchDishes } = useQuery({
    queryKey: ['user-dishes', user?.id],
    queryFn: async () => {
      if (!user) return [];

      const { data, error } = await supabase
        .from('dishes')
        .select(`
          *,
          dish_ingredients(
            grams,
            products(*)
          )
        `)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching dishes:', error);
        throw error;
      }
      return data || [];
    },
    enabled: !!user && open,
    staleTime: 0, // Always fetch fresh data
    refetchOnMount: true
  });

  // Fetch user products
  const { data: products = [], refetch: refetchProducts } = useQuery({
    queryKey: ['user-products', user?.id],
    queryFn: async () => {
      if (!user) return [];

      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('user_id', user.id)
        .order('name');

      if (error) {
        console.error('Error fetching products:', error);
        throw error;
      }
      return data || [];
    },
    enabled: !!user && open,
    staleTime: 0, // Always fetch fresh data
    refetchOnMount: true
  });

  // Empty recipes for now (can be added later)
  const recipes: any[] = [];

  // Save meals function
  const handleSaveMeals = async (meals: any[]) => {
    if (!user || meals.length === 0) return;

    const targetDate = format(selectedDate, 'yyyy-MM-dd');
    
    for (const meal of meals) {
      const mealData: any = {
        user_id: user.id,
        date: targetDate,
        meal_type: selectedMealType,
        is_consumed: true,
      };

      if (meal.type === 'dish') {
        mealData.dish_id = meal.item.id;
        mealData.servings = meal.servings || 1;
      } else if (meal.type === 'product') {
        mealData.product_id = meal.item.id;
        mealData.grams = meal.grams || 100;
      }

      const { error } = await supabase.from('meals').insert(mealData);
      if (error) throw error;

      // Sync to weekly plan for cross-visibility
      const weekStart = startOfWeek(selectedDate, { weekStartsOn: 1 });
      const dow = getDay(selectedDate) === 0 ? 6 : getDay(selectedDate) - 1;

      // Try to find an existing weekly entry for this slot and item
      const matchFilters: any = {
        user_id: user.id,
        week_start_date: format(weekStart, 'yyyy-MM-dd'),
        day_of_week: dow,
        meal_type: selectedMealType === 'snack' ? 'snack' : selectedMealType,
      } as const;

      let query = supabase
        .from('weekly_meal_plans')
        .select('id')
        .eq('user_id', matchFilters.user_id)
        .eq('week_start_date', matchFilters.week_start_date)
        .eq('day_of_week', matchFilters.day_of_week)
        .eq('meal_type', matchFilters.meal_type)
        .limit(1);

      if (mealData.dish_id) query = query.eq('dish_id', mealData.dish_id);
      if (mealData.recipe_id) query = query.eq('recipe_id', mealData.recipe_id);
      if (mealData.product_id) query = query.eq('product_id', mealData.product_id);

      const { data: existing } = await query;

      if (existing && existing.length > 0) {
        await supabase
          .from('weekly_meal_plans')
          .update({
            is_completed: true,
            completed_at: new Date().toISOString(),
            grams: mealData.grams ?? null,
            servings: mealData.servings ?? 1,
          })
          .eq('id', existing[0].id);
      } else {
        await supabase.from('weekly_meal_plans').insert({
          user_id: user.id,
          week_start_date: format(weekStart, 'yyyy-MM-dd'),
          day_of_week: dow,
          meal_type: (selectedMealType === 'snack' ? 'snack' : selectedMealType) as any,
          product_id: mealData.product_id ?? null,
          recipe_id: mealData.recipe_id ?? null,
          dish_id: mealData.dish_id ?? null,
          grams: mealData.grams ?? null,
          servings: mealData.servings ?? 1,
          is_completed: true,
          completed_at: new Date().toISOString(),
        } as any);
      }
    }

    const isToday = format(selectedDate, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd');
    const dateText = isToday ? 'днес' : format(selectedDate, 'dd.MM.yyyy');

    toast({
      title: "Успех",
      description: `Добавихте ${meals.length} хранения за ${dateText}`,
    });
    
    // Invalidate ALL relevant queries for immediate cross-page sync
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ['today-meals-with-dishes'] }),
      queryClient.invalidateQueries({ queryKey: ['calendar-meals'] }),
      queryClient.invalidateQueries({ queryKey: ['meals'] }),
      queryClient.invalidateQueries({ queryKey: ['weeklyMealPlans'] }),
      queryClient.invalidateQueries({ queryKey: ['weekly-plans'] }),
      queryClient.invalidateQueries({ queryKey: ['user-dishes'] }),
      queryClient.invalidateQueries({ queryKey: ['user-products'] })
    ]);
    
    // Refetch immediately to show changes
    await Promise.all([
      refetchDishes(),
      refetchProducts()
    ]);
    
    onOpenChange(false);
  };

  return (
    <AdvancedMealDialog
      mealDialog={mealDialog}
      onMealDialogChange={({ open }) => onOpenChange(open)}
      mealTypeLabels={mealTypeLabels}
      products={products}
      recipes={recipes}
      dishes={dishes}
      onSaveMeals={handleSaveMeals}
      isDailyMode={true}
      mealTypeOptions={mealTypeOptions}
      selectedMealType={selectedMealType}
      onMealTypeChange={setSelectedMealType}
    />
  );
};