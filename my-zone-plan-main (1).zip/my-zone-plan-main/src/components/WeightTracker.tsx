import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useProfile } from '@/hooks/useProfile';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Calendar, Scale, TrendingDown, TrendingUp, Minus } from 'lucide-react';
import { format } from 'date-fns';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface WeightEntry {
  id: string;
  user_id: string;
  weight_kg: number;
  recorded_at: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export const WeightTracker = () => {
  const { user } = useAuth();
  const { profile, updateProfile } = useProfile();
  const queryClient = useQueryClient();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [weight, setWeight] = useState('');
  const [notes, setNotes] = useState('');

  // Fetch weight history
  const { data: weightHistory = [] } = useQuery({
    queryKey: ['weight-history'],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from('weight_history')
        .select('*')
        .eq('user_id', user.id)
        .order('recorded_at', { ascending: false })
        .limit(10);
      
      if (error) throw error;
      return data as WeightEntry[];
    },
    enabled: !!user
  });

  const addWeightMutation = useMutation({
    mutationFn: async ({ weight_kg, notes }: { weight_kg: number; notes?: string }) => {
      if (!user) throw new Error('Not authenticated');
      
      // Add to weight history
      const { error: historyError } = await supabase
        .from('weight_history')
        .insert({
          user_id: user.id,
          weight_kg,
          notes: notes || null,
          recorded_at: new Date().toISOString()
        });
      
      if (historyError) throw historyError;
      
      // Update profile with latest weight
      await updateProfile({ weight_kg });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['weight-history'] });
      setShowAddDialog(false);
      setWeight('');
      setNotes('');
      toast.success('Теглото е записано успешно');
    },
    onError: (error) => {
      console.error('Error adding weight:', error);
      toast.error('Грешка при записване на теглото');
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!weight) return;
    
    const weightNum = parseFloat(weight);
    if (isNaN(weightNum) || weightNum <= 0) {
      toast.error('Моля въведете валидно тегло');
      return;
    }
    
    addWeightMutation.mutate({ weight_kg: weightNum, notes });
  };

  const getWeightTrend = () => {
    if (weightHistory.length < 2) return null;
    
    const latest = weightHistory[0].weight_kg;
    const previous = weightHistory[1].weight_kg;
    const diff = latest - previous;
    
    if (Math.abs(diff) < 0.1) return { trend: 'stable', diff: 0 };
    return {
      trend: diff > 0 ? 'up' : 'down',
      diff: Math.abs(diff)
    };
  };

  const trend = getWeightTrend();

  return (
    <div className="w-full max-w-full overflow-hidden">
      <Card className="w-full">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Scale className="w-5 h-5" />
              Проследяване на теглото
            </CardTitle>
            <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
              <DialogTrigger asChild>
                <Button className="gap-2 shrink-0">
                  <Calendar className="w-4 h-4" />
                  <span className="hidden sm:inline">Запиши тегло</span>
                  <span className="sm:hidden">+</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md mx-4">
                <DialogHeader>
                  <DialogTitle>Ново измерване на тегло</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="weight">Тегло (кг)</Label>
                    <Input
                      id="weight"
                      type="number"
                      step="0.1"
                      min="20"
                      max="300"
                      placeholder="70.5"
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      required
                      className="w-full"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="notes">Бележки (допълнителна информация)</Label>
                    <Textarea
                      id="notes"
                      placeholder="Например: След тренировка, сутрин..."
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      rows={3}
                      className="w-full resize-none"
                    />
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={addWeightMutation.isPending}
                  >
                    {addWeightMutation.isPending ? 'Запазва...' : 'Запази тегло'}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent className="w-full">
          <div className="space-y-4 w-full">
            {/* Current weight display */}
            {profile?.weight_kg && (
              <div className="text-center p-4 bg-muted rounded-lg w-full">
                <div className="text-3xl font-bold text-primary mb-2">
                  {profile.weight_kg} кг
                </div>
                <div className="text-sm text-muted-foreground mb-2">Текущо тегло</div>
                {trend && (
                  <Badge 
                    variant={trend.trend === 'up' ? 'destructive' : trend.trend === 'down' ? 'default' : 'secondary'}
                    className="gap-1"
                  >
                    {trend.trend === 'up' && <TrendingUp className="w-3 h-3" />}
                    {trend.trend === 'down' && <TrendingDown className="w-3 h-3" />}
                    {trend.trend === 'stable' && <Minus className="w-3 h-3" />}
                    {trend.trend === 'stable' ? 'Без промяна' : `${trend.diff.toFixed(1)} кг`}
                  </Badge>
                )}
              </div>
            )}

            {/* Weight history */}
            {weightHistory.length > 0 ? (
              <div className="space-y-3 w-full">
                <h3 className="font-semibold text-sm">История на измерванията</h3>
                <div className="space-y-2 max-h-60 overflow-y-auto w-full">
                  {weightHistory.map((entry) => (
                    <div key={entry.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg w-full">
                      <div className="w-full">
                        <div className="font-semibold">{entry.weight_kg} кг</div>
                        <div className="text-xs text-muted-foreground">
                          {format(new Date(entry.recorded_at), 'dd.MM.yyyy в HH:mm')}
                        </div>
                        {entry.notes && (
                          <div className="text-xs text-muted-foreground mt-1 break-words">
                            {entry.notes}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center p-6 text-muted-foreground w-full">
                <Scale className="w-12 h-12 mx-auto mb-3 opacity-40" />
                <p className="text-sm">Все още няма записи за тегло</p>
                <p className="text-xs mt-1">Започнете да записвате теглото си за проследяване на прогреса</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};