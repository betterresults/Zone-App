import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Calculator, Info } from 'lucide-react';
import { useProfile, type ZoneCalculationParams } from '@/hooks/useProfile';

interface ZoneCalculatorProps {
  onCalculated?: (blocks: number) => void;
}

export const ZoneCalculator = ({ onCalculated }: ZoneCalculatorProps) => {
  const { profile, updateZoneSettings, calculateZoneBlocks } = useProfile();
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<ZoneCalculationParams>({
    height_cm: profile?.height_cm || 170,
    weight_kg: profile?.weight_kg || 70,
    age: profile?.age || 30,
    gender: profile?.gender || 'female',
    activity_level: profile?.activity_level || 'sedentary',
    weight_goal: 'lose'
  });
  const [previewBlocks, setPreviewBlocks] = useState<number | null>(null);

  // Update form data when profile changes
  useEffect(() => {
    if (profile) {
      setFormData({
        height_cm: profile.height_cm || 170,
        weight_kg: profile.weight_kg || 70,
        age: profile.age || 30,
        gender: profile.gender || 'female',
        activity_level: profile.activity_level || 'sedentary',
        weight_goal: 'lose' // Default for now, could be stored in profile later
      });
    }
  }, [profile]);

  const handleInputChange = (field: keyof ZoneCalculationParams, value: string | number) => {
    const newData = { ...formData, [field]: value };
    setFormData(newData);
    
    // Calculate preview if all fields are filled
    if (newData.height_cm && newData.weight_kg && newData.age && newData.gender && newData.activity_level && newData.weight_goal) {
      const blocks = calculateZoneBlocks(newData);
      setPreviewBlocks(blocks);
    } else {
      setPreviewBlocks(null);
    }
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      const blocks = await updateZoneSettings(formData);
      onCalculated?.(blocks);
      setIsOpen(false);
    } catch (error) {
      // Error handling is done in the hook
    } finally {
      setLoading(false);
    }
  };

  const activityLevels = {
    sedentary: 'Заседнал (офисна работа, без упражнения)',
    light: 'Лека активност (лека разходка 1-3 дни/седмица)',
    moderate: 'Умерена активност (умерени упражнения 3-5 дни/седмица)',
    very_active: 'Висока активност (интензивни упражнения 6-7 дни/седмица)',
    extra_active: 'Екстремна активност (2x дневно или физическа работа)'
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="flex items-center gap-2">
          <Calculator className="w-4 h-4" />
          {profile?.daily_blocks ? 'Промени Zone блоковете' : 'Изчисли Zone блоковете'}
        </Button>
      </DialogTrigger>
      
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calculator className="w-5 h-5" />
            Zone калкулатор
          </DialogTitle>
          <DialogDescription>
            Въведете данните си за автоматично изчисляване на нужните Zone блокове на ден
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Current settings display */}
          {profile?.daily_blocks && (
            <Card className="bg-primary/5">
              <CardContent className="pt-6">
                <div className="text-center">
                  <p className="text-sm text-muted-foreground mb-1">Текущи настройки</p>
                  <p className="text-2xl font-bold text-primary">{profile.daily_blocks} блока дневно</p>
                  {profile.calculated_at && (
                    <p className="text-xs text-muted-foreground mt-1">
                      Изчислено на {new Date(profile.calculated_at).toLocaleDateString('bg-BG')}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Basic measurements */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="height">Височина (см)</Label>
                <Input
                  id="height"
                  type="number"
                  value={formData.height_cm}
                  onChange={(e) => handleInputChange('height_cm', parseInt(e.target.value))}
                  min="100"
                  max="250"
                />
              </div>
              
              <div>
                <Label htmlFor="weight">Тегло (кг)</Label>
                <Input
                  id="weight"
                  type="number"
                  step="0.1"
                  value={formData.weight_kg}
                  onChange={(e) => handleInputChange('weight_kg', parseFloat(e.target.value))}
                  min="30"
                  max="200"
                />
              </div>
              
              <div>
                <Label htmlFor="age">Възраст (години)</Label>
                <Input
                  id="age"
                  type="number"
                  value={formData.age}
                  onChange={(e) => handleInputChange('age', parseInt(e.target.value))}
                  min="16"
                  max="100"
                />
              </div>
            </div>

            {/* Selections */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="gender">Пол</Label>
                <Select value={formData.gender} onValueChange={(value: 'male' | 'female') => handleInputChange('gender', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="female">Жена</SelectItem>
                    <SelectItem value="male">Мъж</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="activity">Ниво на активност</Label>
                <Select 
                  value={formData.activity_level} 
                  onValueChange={(value: any) => handleInputChange('activity_level', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(activityLevels).map(([key, label]) => (
                      <SelectItem key={key} value={key}>
                        <div className="text-left">
                          <div className="font-medium">{label.split(' (')[0]}</div>
                          <div className="text-xs text-muted-foreground">
                            ({label.split(' (')[1]?.replace(')', '')}
                          </div>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="goal">Цел</Label>
                <Select 
                  value={formData.weight_goal} 
                  onValueChange={(value: 'lose' | 'maintain' | 'gain') => handleInputChange('weight_goal', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="lose">Загуба на тегло</SelectItem>
                    <SelectItem value="maintain">Поддържане на теглото</SelectItem>
                    <SelectItem value="gain">Набавяне на тегло</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Preview calculation */}
          {previewBlocks && (
            <Card className="bg-zone-balanced/10 border-zone-balanced/20">
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <Calculator className="w-5 h-5 text-zone-balanced" />
                    <span className="font-semibold">Изчислено</span>
                  </div>
                  <div className="text-3xl font-bold text-zone-balanced mb-2">
                    {previewBlocks} блока дневно
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Това означава {Math.round(previewBlocks * 7)}g протеин, {Math.round(previewBlocks * 9)}g нетни въглехидрати 
                    и {Math.round(previewBlocks * 1.5)}g мазнини на ден
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {formData.weight_goal === 'lose' && '🎯 Оптимизирано за загуба на тегло'}
                    {formData.weight_goal === 'maintain' && '⚖️ Оптимизирано за поддържане на теглото'}
                    {formData.weight_goal === 'gain' && '💪 Оптимизирано за набавяне на тегло'}
                  </p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Info panel */}
          <Card className="bg-blue-50/50 border-blue-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <Info className="w-4 h-4 text-blue-600" />
                Как се изчислява?
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0 text-sm text-muted-foreground">
              <p className="mb-2">
                Използва официалната Zone Diet формула на д-р Бари Сиърс, базирана на 
                чистата мускулна маса и нивото на активност.
              </p>
              <p>
                Средната жена трябва 11 блока дневно, средният мъж - 14 блока.
                Вашето изчисление е персонализирано според параметрите ви.
              </p>
            </CardContent>
          </Card>

          {/* Action buttons */}
          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={() => setIsOpen(false)}>
              Отказ
            </Button>
            <Button 
              onClick={handleSave} 
              disabled={loading || !previewBlocks}
              className="flex items-center gap-2"
            >
              {loading && <div className="w-4 h-4 animate-spin rounded-full border-2 border-background border-t-transparent" />}
              Запази настройките
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};