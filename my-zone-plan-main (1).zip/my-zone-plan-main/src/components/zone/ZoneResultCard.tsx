import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Calculator } from 'lucide-react';
import React from 'react';
import { type ZoneCalculation } from '@/hooks/useZoneCalculation';

export interface NutritionTotals {
  protein: number;
  carbs: number;
  fat: number;
  calories: number;
}

interface ZoneResultCardProps {
  nutrition: NutritionTotals;
  zoneCalc: ZoneCalculation;
}

// Reusable Zone Result card – matches the layout used on the Cook page
export const ZoneResultCard: React.FC<ZoneResultCardProps> = ({ nutrition, zoneCalc }) => {
  const minBlocks = Math.min(zoneCalc.protein, zoneCalc.carbs, zoneCalc.fat);
  const maxBlocks = Math.max(zoneCalc.protein, zoneCalc.carbs, zoneCalc.fat);
  const ratio = maxBlocks > 0 ? minBlocks / maxBlocks : 0;

  const getBlockColor = (blockValue: number) => {
    // Използваме новата логика - ако сме в зоната, всички блокове са зелени
    if (zoneCalc.isInZone) {
      return 'bg-green-500';
    } else {
      // Ако не сме в зоната, показваме червено
      return 'bg-red-500';
    }
  };

  const renderStatus = () => {
    if (zoneCalc.isInZone) {
      return <div className="px-4 py-2 bg-green-500 text-white rounded-full font-bold">{zoneCalc.status.toUpperCase()}</div>;
    } else {
      return <div className="px-4 py-2 bg-red-500 text-white rounded-full font-bold">{zoneCalc.status.toUpperCase()}</div>;
    }
  };

  return (
      <Card className="border-2 border-primary/20">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
            <Calculator className="w-4 h-4 sm:w-5 sm:h-5" />
            Zone Резултат
          </CardTitle>
        </CardHeader>
        <CardContent className="p-3 sm:p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 sm:gap-4">
            {/* Total macros */}
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900 p-3 sm:p-4 rounded-lg">
              <h3 className="font-bold text-xs sm:text-sm text-blue-700 dark:text-blue-300 mb-3 text-center">ОБЩО МАКРОСИ</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center bg-white/50 dark:bg-black/20 p-2 rounded">
                  <span className="font-medium">Протеин</span>
                  <span className="font-bold text-blue-600">{nutrition.protein.toFixed(1)}г</span>
                </div>
                <div className="flex justify-between items-center bg-white/50 dark:bg-black/20 p-2 rounded">
                  <span className="font-medium">Въглехидрати</span>
                  <span className="font-bold text-green-600">{nutrition.carbs.toFixed(1)}г</span>
                </div>
                <div className="flex justify-between items-center bg-white/50 dark:bg-black/20 p-2 rounded">
                  <span className="font-medium">Мазнини</span>
                  <span className="font-bold text-orange-600">{nutrition.fat.toFixed(1)}г</span>
                </div>
                <div className="flex justify-between items-center bg-primary/10 p-2 rounded border-2 border-primary/20">
                  <span className="font-bold">Калории</span>
                  <span className="font-bold text-primary text-lg">{Math.round(nutrition.calories)}</span>
                </div>
              </div>
            </div>

            {/* Zone blocks */}
            <div className="text-center space-y-3 sm:space-y-4">
              <h3 className="font-bold text-xs sm:text-sm text-muted-foreground">ZONE БЛОКОВЕ</h3>
              <div className="flex justify-center items-center gap-3 sm:gap-4 flex-wrap">
                <div className="text-center">
                  <div className={`w-12 h-12 sm:w-14 sm:h-14 md:w-16 md:h-16 rounded-full text-white flex items-center justify-center text-base sm:text-lg font-bold ${getBlockColor(zoneCalc.protein)}`}>
                    {zoneCalc.protein.toFixed(1)}
                  </div>
                  <div className="text-xs mt-1 font-medium">Протеин</div>
                </div>
                <div className="text-center">
                  <div className={`w-12 h-12 sm:w-14 sm:h-14 md:w-16 md:h-16 rounded-full text-white flex items-center justify-center text-base sm:text-lg font-bold ${getBlockColor(zoneCalc.carbs)}`}>
                    {zoneCalc.carbs.toFixed(1)}
                  </div>
                  <div className="text-xs mt-1 font-medium">Въглехр.</div>
                </div>
                <div className="text-center">
                  <div className={`w-12 h-12 sm:w-14 sm:h-14 md:w-16 md:h-16 rounded-full text-white flex items-center justify-center text-base sm:text-lg font-bold ${getBlockColor(zoneCalc.fat)}`}>
                    {zoneCalc.fat.toFixed(1)}
                  </div>
                  <div className="text-xs mt-1 font-medium">Мазнини</div>
                </div>
              </div>
            </div>

            {/* Zone status */}
            <div className="text-center space-y-3 sm:space-y-4">
              <h3 className="font-bold text-xs sm:text-sm text-muted-foreground">ZONE СТАТУС</h3>
              <div className="space-y-2">
                <div className="text-2xl sm:text-3xl font-bold text-primary">{zoneCalc.blocks.toFixed(1)}</div>
                <div className="text-sm text-muted-foreground">блокове общо</div>
                <div className="mt-3 sm:mt-4">{renderStatus()}</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
  );
};