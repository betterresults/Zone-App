import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useOneSignal } from '@/hooks/useOneSignal';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';

export const OneSignalDebug = () => {
  const { user } = useAuth();
  const { isInitialized, isSubscribed, loading, requestPermission, repairSubscription } = useOneSignal();
  const [debugInfo, setDebugInfo] = useState<any>({});
  const [testResult, setTestResult] = useState<any>(null);

  useEffect(() => {
    const getDebugInfo = async () => {
      if (!window.OneSignal) return;
      try {
        const subscription = window.OneSignal.User.PushSubscription.optedIn;
        const notificationPermission = window.OneSignal.Notifications.permission;
        const tags = await window.OneSignal.User.getTags();

        // Check service worker files availability
        let workerStatus = 'n/a';
        let updaterStatus = 'n/a';
        try {
          const r1 = await fetch('/OneSignalSDKWorker.js', { cache: 'no-store' });
          workerStatus = `${r1.status} ${r1.ok ? 'OK' : 'ERR'}`;
        } catch (e: any) {
          workerStatus = `error: ${e?.message || e}`;
        }
        try {
          const r2 = await fetch('/OneSignalSDKUpdaterWorker.js', { cache: 'no-store' });
          updaterStatus = `${r2.status} ${r2.ok ? 'OK' : 'ERR'}`;
        } catch (e: any) {
          updaterStatus = `error: ${e?.message || e}`;
        }

        setDebugInfo({
          subscription: subscription ? { id: 'subscribed', optedIn: true } : null,
          notificationPermission,
          isPushNotificationsEnabled: subscription,
          tags,
          userAgent: navigator.userAgent,
          isHTTPS: location.protocol === 'https:',
          workerStatus,
          updaterStatus,
        });
      } catch (error: any) {
        console.error('Debug info error:', error);
        setDebugInfo({ error: error.message });
      }
    };

    if (isInitialized) {
      getDebugInfo();
    }
  }, [isInitialized]);

  const handleRequestPermission = async () => {
    const result = await requestPermission();
    console.log('Permission result:', result);
    
    // Refresh debug info
    setTimeout(() => {
      window.location.reload();
    }, 1000);
  };

  const handleRepair = async () => {
    const ok = await repairSubscription();
    console.log('Repair result:', ok);
    setTimeout(() => window.location.reload(), 800);
  };

  // Opens browser site settings for notifications when permission is blocked
  const openSiteSettings = () => {
    const origin = window.location.origin;
    const ua = navigator.userAgent.toLowerCase();

    // Chromium-based (Chrome, Edge, Brave, Opera)
    if (ua.includes('chrome') || ua.includes('edg') || ua.includes('opr') || ua.includes('brave')) {
      window.location.href = `chrome://settings/content/siteDetails?site=${encodeURIComponent(origin)}`;
      return;
    }
    // Firefox
    if (ua.includes('firefox')) {
      window.open('about:preferences#privacy', '_blank');
      return;
    }
    // Safari / others – show instructions only
    alert('Нотификациите са блокирани от браузъра. Моля, отворете Site Settings за този домейн и задайте Allow на Notifications.');
  };

  const testNotification = async () => {
    if (!user) return;
    
    try {
      setTestResult({ loading: true });
      
      const { data, error } = await supabase.functions.invoke('test-notification', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (error) throw error;
      
      setTestResult(data);
    } catch (error) {
      setTestResult({ 
        success: false, 
        error: (error as any).message,
        status: (error as any).status 
      });
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            OneSignal Debug Info
            <Badge variant={isInitialized ? "default" : "secondary"}>
              {isInitialized ? "Инициализиран" : "Не е инициализиран"}
            </Badge>
          </CardTitle>
          <CardDescription>
            Информация за OneSignal състоянието
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <strong>Loading:</strong> {loading ? 'Да' : 'Не'}
            </div>
            <div>
              <strong>Subscribed:</strong> {isSubscribed ? 'Да' : 'Не'}
            </div>
            <div>
              <strong>User ID:</strong> {user?.id || 'N/A'}
            </div>
            <div>
              <strong>HTTPS:</strong> {debugInfo.isHTTPS ? 'Да' : 'Не'}
            </div>
          </div>

          {debugInfo.notificationPermission && (
            <div>
              <strong>Notification Permission:</strong> {debugInfo.notificationPermission}
            </div>
          )}

          {(debugInfo.workerStatus || debugInfo.updaterStatus) && (
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <strong>SW Worker:</strong> {debugInfo.workerStatus}
              </div>
              <div>
                <strong>SW Updater:</strong> {debugInfo.updaterStatus}
              </div>
            </div>
          )}

          {debugInfo.subscription && (
            <div>
              <strong>Subscription ID:</strong> 
              <code className="ml-2 text-xs bg-muted p-1 rounded">
                {debugInfo.subscription.id}
              </code>
            </div>
          )}

          {debugInfo.tags && Object.keys(debugInfo.tags).length > 0 && (
            <div>
              <strong>Tags:</strong>
              <pre className="text-xs bg-muted p-2 rounded mt-1">
                {JSON.stringify(debugInfo.tags, null, 2)}
              </pre>
            </div>
          )}

          {debugInfo.error && (
            <div className="text-red-600">
              <strong>Error:</strong> {debugInfo.error}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Тестване</CardTitle>
          <CardDescription>
            Тестване на OneSignal функционалност
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!isSubscribed && (
            <>
              {debugInfo.notificationPermission === 'denied' && (
                <div className="border border-destructive/30 bg-destructive/10 text-destructive p-3 rounded-md text-sm">
                  Нотификациите са блокирани от браузъра за този сайт. Разреши ги от Site Settings и опитай пак.
                  <div className="mt-2 flex gap-2">
                    <Button variant="secondary" onClick={openSiteSettings} className="w-full">
                      Отвори настройките на сайта
                    </Button>
                  </div>
                </div>
              )}
              <Button onClick={handleRequestPermission} className="w-full" disabled={debugInfo.notificationPermission === 'denied'}>
                🔔 Заяви разрешение за нотификации
              </Button>
              {debugInfo.notificationPermission === 'granted' && (
                <Button variant="secondary" onClick={handleRepair} className="w-full">
                  🛠️ Поправи абонамента
                </Button>
              )}
            </>
          )}
          
          {isSubscribed && (
            <Button onClick={testNotification} className="w-full">
              📤 Изпрати тестова нотификация
            </Button>
          )}

          {testResult && (
            <div className="mt-4">
              <strong>Резултат от теста:</strong>
              <pre className="text-xs bg-muted p-2 rounded mt-1 overflow-auto">
                {JSON.stringify(testResult, null, 2)}
              </pre>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};