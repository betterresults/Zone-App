import { NavLink, useLocation } from 'react-router-dom';
import { 
  Home, 
  Apple, 
  ChefHat, 
  BookOpen,
  Utensils,
  Calendar, 
  Settings, 
  Info,
  Shield,
  Dumbbell,
  Crown,
  Users,
  Gift,
  Target,
  ShoppingCart,
  MessageSquare
} from 'lucide-react';
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarTrigger,
  useSidebar,
} from '@/components/ui/sidebar';
import { useAdmin } from '@/hooks/useAdmin';
import { useSubscription } from '@/hooks/useSubscription';
import { useBetaTesters } from '@/hooks/useBetaTesters';

interface NavItem {
  title: string;
  url: string;
  icon: React.ComponentType<{ className?: string }>;
  premium?: boolean;
}

const navItems: NavItem[] = [
  { title: 'Начало', url: '/', icon: Home },
  { title: 'Готви', url: '/cook', icon: ChefHat },
  { title: 'Продукти', url: '/products', icon: Apple },
  { title: 'Рецепти', url: '/recipes', icon: BookOpen },
  { title: 'Ястия', url: '/meals', icon: Utensils },
  { title: 'Календар', url: '/calendar', icon: Calendar },
];

const settingsNavItems: NavItem[] = [
  { title: 'Покани приятел', url: '/referral', icon: Gift },
  { title: 'Връзка с нас', url: '/feedback', icon: MessageSquare },
  { title: 'Настройки', url: '/settings', icon: Settings },
  { title: 'Информация', url: '/information', icon: Info },
];

const premiumNavItems: NavItem[] = [
  { title: 'Седмично меню', url: '/weekly-menu', icon: Calendar, premium: true },
  { title: 'Фитнес', url: '/fitness', icon: Dumbbell, premium: true },
  { title: 'Навици', url: '/habits', icon: Target, premium: true },
  { title: 'Пазаруване', url: '/shopping-lists', icon: ShoppingCart, premium: true },
];

const betaNavItems: NavItem[] = [
  // Moved to main nav items
];

const adminNavItems: NavItem[] = [
  { title: 'Админ панел', url: '/admin', icon: Shield },
  { title: 'Продукти', url: '/admin/products', icon: Apple },
  { title: 'Рецепти', url: '/admin/recipes', icon: BookOpen },
  { title: 'Ястия', url: '/admin/dishes', icon: Utensils },
  { title: 'Потребители', url: '/admin/users', icon: Users },
  { title: 'Връзка с нас', url: '/admin/feedback', icon: MessageSquare },
  { title: 'Настройки', url: '/admin/settings', icon: Settings },
];

export function AppSidebar() {
  const { setOpenMobile, isMobile } = useSidebar();
  const location = useLocation();
  const { isAdmin } = useAdmin();
  const { isPro, isBetaTester } = useSubscription();
  const { data: betaTestersCount = 0 } = useBetaTesters();
  const currentPath = location.pathname;

  // Show different menu for admin users
  const mainNavItems = isAdmin 
    ? adminNavItems 
    : isPro 
      ? [...navItems, ...premiumNavItems] 
      : navItems;

  // Settings items are shown only for non-admin users
  const showSettingsGroup = !isAdmin;

  const isActive = (path: string) => currentPath === path;
  const getNavCls = ({ isActive }: { isActive: boolean }) =>
    isActive ? 'bg-primary text-primary-foreground font-medium' : 'hover:bg-muted/50';

  const handleNavClick = () => {
    // Close mobile sidebar when navigating
    if (isMobile) {
      setOpenMobile(false);
    }
  };

  return (
    <Sidebar
      collapsible="icon"
      className="w-56 h-screen"
    >
      <SidebarContent className="bg-card h-full flex flex-col">
        {/* Logo section */}
        <div className="p-4 border-b">
          <div className="flex items-center space-x-2 group-data-[collapsible=icon]:justify-center">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center flex-shrink-0">
              <span className="text-white font-bold text-lg">Z</span>
            </div>
            <span className="text-xl font-bold text-primary group-data-[collapsible=icon]:hidden">Профил</span>
          </div>
        </div>

        <SidebarGroup>
          <SidebarGroupLabel className="sr-only">Навигация</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {mainNavItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                     <NavLink
                       to={item.url}
                       end
                       className={({ isActive }) => `${getNavCls({ isActive })} py-3 px-4 rounded-lg text-base font-medium transition-all duration-200 text-foreground hover:text-accent-foreground flex items-center gap-3`}
                       onClick={handleNavClick}
                     >
                       <item.icon className="w-6 h-6 flex-shrink-0" />
                       <span className="text-base font-semibold">
                         {item.title === 'Седмично меню' ? 'Сед. меню' : item.title}
                       </span>
                       {item.premium && <Crown className="w-4 h-4 text-yellow-500 ml-auto" />}
                       {isAdmin && item.url.startsWith('/admin') && <Shield className="w-4 h-4 text-destructive ml-auto" />}
                     </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Settings group - positioned at bottom for non-admin users with separator */}
        {showSettingsGroup && (
          <div className="mt-auto">
            <div className="border-t mx-4 mb-2"></div>
            <SidebarGroup>
              <SidebarGroupLabel className="sr-only">Настройки</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {settingsNavItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton asChild>
                         <NavLink
                           to={item.url}
                           end
                           className={({ isActive }) => `${getNavCls({ isActive })} py-3 px-4 rounded-lg text-base font-medium transition-all duration-200 text-foreground hover:text-accent-foreground flex items-center gap-3`}
                           onClick={handleNavClick}
                         >
                           <item.icon className="w-6 h-6 flex-shrink-0" />
                           <span className="text-base font-semibold">
                             {item.title}
                           </span>
                         </NavLink>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </div>
        )}
      </SidebarContent>
    </Sidebar>
  );
}