import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Droplets, Loader2 } from 'lucide-react';

export const WaterNotificationTest = () => {
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const sendWaterNotification = async () => {
    if (!user?.id) return;

    setIsLoading(true);
    setResult(null);

    try {
      const { data, error } = await supabase.functions.invoke('send-hydration-notification', {
        body: {
          userId: user.id,
          title: 'Напомняне за вода 💧',
          message: 'Време е да пиете малко вода! Натиснете един от бутоните за да добавите бързо.',
          currentMl: 250,
          goalMl: 2000
        }
      });

      if (error) {
        throw error;
      }

      if (data?.success) {
        setResult('✅ Известието е изпратено успешно! Проверете устройството си.');
      } else {
        setResult('⚠️ Известието е изпратено, но има проблеми: ' + (data?.message || 'Неизвестна грешка'));
      }
    } catch (error: any) {
      console.error('Error sending water notification:', error);
      setResult('❌ Грешка при изпращане: ' + error.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Droplets className="h-5 w-5 text-blue-500" />
        <div>
          <h4 className="font-medium">Тест известие за вода</h4>
          <p className="text-sm text-muted-foreground">
            Ще изпрати известие с 2 бутона: "+200мл" и "+500мл"
          </p>
        </div>
      </div>

      <Button 
        onClick={sendWaterNotification}
        disabled={isLoading || !user?.id}
        className="w-full"
      >
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Изпращане...
          </>
        ) : (
          <>
            <Droplets className="mr-2 h-4 w-4" />
            Изпрати тест известие за вода
          </>
        )}
      </Button>

      {result && (
        <Card>
          <CardContent className="p-3">
            <p className="text-sm">{result}</p>
          </CardContent>
        </Card>
      )}

      <div className="text-xs text-muted-foreground space-y-1">
        <p>• Известието ще има 2 бутона за бързо добавяне на вода</p>
        <p>• При натискане на бутон се добавя вода директно в дневника</p>
        <p>• Това е тест как ще работят автоматичните известия</p>
      </div>
    </div>
  );
};