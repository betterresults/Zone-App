import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { formatDistanceToNow } from 'date-fns';
import { bg } from 'date-fns/locale';
import { 
  Activity, 
  ChefHat, 
  Apple, 
  Utensils, 
  Calendar,
  Settings,
  CreditCard,
  Dumbbell,
  Target,
  Scale,
  Droplets,
  Clock,
  BookOpen,
  Info,
  RefreshCw
} from 'lucide-react';

interface UserActivity {
  id: string;
  user_id: string;
  activity_category: string;
  activity_type: string;
  activity_description: string;
  activity_data: any;
  created_at: string;
  profiles?: {
    display_name: string | null;
    email: string | null;
  } | null;
}

const categoryIcons = {
  cooking: ChefHat,
  products: Apple,
  recipes: BookOpen,
  dishes: Utensils,
  calendar: Calendar,
  referral: RefreshCw,
  settings: Settings,
  subscription: CreditCard,
  fitness: Dumbbell,
  zone: Target,
  weight: Scale,
  hydration: Droplets,
  fasting: Clock,
  weekly_menu: Calendar,
  information: Info
};

const categoryColors = {
  cooking: 'bg-orange-500',
  products: 'bg-green-500',
  recipes: 'bg-blue-500',
  dishes: 'bg-purple-500',
  calendar: 'bg-red-500',
  referral: 'bg-yellow-500',
  settings: 'bg-gray-500',
  subscription: 'bg-pink-500',
  fitness: 'bg-indigo-500',
  zone: 'bg-teal-500',
  weight: 'bg-cyan-500',
  hydration: 'bg-blue-400',
  fasting: 'bg-amber-500',
  weekly_menu: 'bg-violet-500',
  information: 'bg-slate-500'
};

export function ActivityFeed() {
  const [activities, setActivities] = useState<UserActivity[]>([]);
  const [loading, setLoading] = useState(true);

  const loadActivities = async () => {
    try {
      const { data, error } = await supabase
        .from('user_activities')
        .select(`
          *,
          profiles:user_id (
            display_name,
            email
          )
        `)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setActivities((data as any) || []);
    } catch (error) {
      console.error('Error loading activities:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadActivities();

    // Set up real-time subscription
    const channel = supabase
      .channel('user-activities')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'user_activities'
        },
        (payload) => {
          const newActivity = payload.new as UserActivity;
          setActivities(prev => [newActivity, ...prev.slice(0, 49)]);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const getActivityIcon = (category: string) => {
    const Icon = categoryIcons[category as keyof typeof categoryIcons] || Activity;
    return Icon;
  };

  const getActivityColor = (category: string) => {
    return categoryColors[category as keyof typeof categoryColors] || 'bg-gray-500';
  };

const getUserDisplayName = (activity: UserActivity) => {
    const profile = activity.profiles;
    if (profile?.display_name) {
      return profile.display_name;
    }
    if (profile?.email) {
      return profile.email;
    }
    return `Потребител ${activity.user_id.slice(0, 8)}...`;
  };

  const isAdminAction = (activity: UserActivity) => {
    return activity.activity_data?.admin_action === true;
  };

  const getAdminInfo = (activity: UserActivity) => {
    if (activity.activity_data?.admin_action && activity.activity_data?.performed_by_admin) {
      return activity.activity_data.performed_by_admin;
    }
    return null;
  };

  const getCategoryDisplayName = (category: string) => {
    const names = {
      cooking: 'Готвене',
      products: 'Продукти',
      recipes: 'Рецепти',
      dishes: 'Ястия',
      calendar: 'Календар',
      referral: 'Реферали',
      settings: 'Настройки',
      subscription: 'Абонамент',
      fitness: 'Фитнес',
      zone: 'Зона',
      weight: 'Тегло',
      hydration: 'Хидратация',
      fasting: 'Фастинг',
      weekly_menu: 'Седмично меню',
      information: 'Информация'
    };
    return names[category as keyof typeof names] || category;
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="w-5 h-5" />
          Активност в реално време
        </CardTitle>
        <CardDescription>
          Последните действия на потребителите ({activities.length} записа)
        </CardDescription>
        <Button onClick={loadActivities} variant="outline" size="sm" className="w-fit">
          <RefreshCw className="w-4 h-4 mr-2" />
          Обнови
        </Button>
      </CardHeader>
      <CardContent className="p-0">
        <div className="max-h-96 overflow-y-auto">
          {activities.length > 0 ? (
            <div className="space-y-2 p-4">
              {activities.map((activity) => {
                const Icon = getActivityIcon(activity.activity_category);
                const colorClass = getActivityColor(activity.activity_category);
                
                return (
                  <div
                    key={activity.id}
                    className="flex items-start gap-3 p-3 rounded-lg border hover:bg-muted/50 transition-colors"
                  >
                    <div className={`p-2 rounded-full ${colorClass} text-white flex-shrink-0`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="secondary" className="text-xs">
                          {getCategoryDisplayName(activity.activity_category)}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {formatDistanceToNow(new Date(activity.created_at), { 
                            addSuffix: true, 
                            locale: bg 
                          })}
                        </span>
                      </div>
                      <p className="text-sm font-medium text-foreground mb-1">
                        {activity.activity_description}
                      </p>
                      <div className="flex items-center gap-2 mb-1">
                        <p className="text-xs text-muted-foreground">
                          {getUserDisplayName(activity)}
                        </p>
                        {isAdminAction(activity) && (
                          <Badge variant="destructive" className="text-xs">
                            АДМИН ДЕЙСТВИЕ
                          </Badge>
                        )}
                      </div>
                      {activity.activity_data && Object.keys(activity.activity_data).length > 0 && (
                        <details className="mt-2">
                          <summary className="text-xs text-muted-foreground cursor-pointer hover:text-foreground">
                            Детайли
                          </summary>
                          <pre className="text-xs bg-muted p-2 rounded mt-1 overflow-x-auto">
                            {JSON.stringify(activity.activity_data, null, 2)}
                          </pre>
                        </details>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-8 text-center text-muted-foreground">
              <Activity className="w-12 h-12 mx-auto mb-2" />
              <p>Няма налични записи за активност</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}