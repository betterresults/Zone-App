import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Send } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface User {
  user_id: string;
  email: string;
  display_name?: string;
}

interface InstantNotificationDialogProps {
  users: User[];
}

export const InstantNotificationDialog = ({ users }: InstantNotificationDialogProps) => {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [apiResult, setApiResult] = useState<any>(null);
  const [form, setForm] = useState({
    title: '',
    message: '',
    userId: 'all' // 'all' означава до всички
  });

  const handleSend = async () => {
    if (!form.title.trim() || !form.message.trim()) {
      toast({
        title: "Грешка",
        description: "Моля попълнете заглавие и съобщение",
        variant: "destructive"
      });
      return;
    }

    try {
      setLoading(true);
      
      const payload: any = {
        title: form.title,
        message: form.message
      };

      if (form.userId && form.userId !== 'all') {
        payload.userId = form.userId;
      }

      // Извикваме Edge функцията и чакаме реалния резултат
      const { data, error } = await supabase.functions.invoke('send-instant-notification', {
        body: payload,
      });

      if (error) {
        throw new Error(error.message || 'Грешка при изпращане');
      }

      const result = data as any;
      setApiResult(result);

      const os = result?.oneSignalResponse || {};
      const recipients = (typeof os.recipients === 'number') ? os.recipients : (typeof os.successful === 'number' ? os.successful : 0);
      const hasOsErrors = !!os.errors && (Array.isArray(os.errors) ? os.errors.length > 0 : Object.keys(os.errors || {}).length > 0);
      const hasExplicitFailure = result?.success === false || recipients === 0;

      if (hasOsErrors || hasExplicitFailure) {
        toast({
          title: 'Неуспешно изпращане',
          description: `Получатели: ${recipients}. Детайли: виж секцията с резултата по-долу`,
          variant: 'destructive'
        });
        return;
      }

      toast({
        title: 'Успешно изпратено',
        description: `Доставено до ${recipients} получатели`,
      });

      setForm({ title: '', message: '', userId: 'all' });
      setOpen(false);
    } catch (error: any) {
      console.error('Error sending instant notification:', error);
      toast({
        title: "Грешка",
        description: error.message || "Неуспешно изпращане на нотификацията",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const selectedUser = users.find(u => u.user_id === form.userId);
  const isAllUsers = form.userId === 'all';

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="flex items-center gap-2">
          <Send className="w-4 h-4" />
          Моментalna нотификация
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Моментална нотификация</DialogTitle>
          <DialogDescription>
            Изпратете моментална push нотификация
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="recipient">Получател</Label>
            <Select value={form.userId} onValueChange={(value) => setForm({ ...form, userId: value })}>
              <SelectTrigger>
                <SelectValue placeholder="Всички потребители" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Всички потребители</SelectItem>
                {users.map((user) => (
                  <SelectItem key={user.user_id} value={user.user_id}>
                    {user.display_name || user.email}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedUser && !isAllUsers && (
              <p className="text-xs text-muted-foreground">
                Ще се изпрати до: {selectedUser.display_name || selectedUser.email}
              </p>
            )}
            {isAllUsers && (
              <p className="text-xs text-muted-foreground">
                Ще се изпрати до всички потребители
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="title">Заглавие</Label>
            <Input
              id="title"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              placeholder="Въведете заглавие..."
              disabled={loading}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="message">Съобщение</Label>
            <Textarea
              id="message"
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              placeholder="Въведете съобщение..."
              rows={3}
              disabled={loading}
            />
          </div>
        </div>

        {apiResult && (
          <div className="p-3 rounded-md bg-muted">
            <p className="text-sm font-medium mb-1">Резултат от API:</p>
            <pre className="text-xs whitespace-pre-wrap">{JSON.stringify(apiResult, null, 2)}</pre>
          </div>
        )}

        <DialogFooter>
          <Button
            onClick={handleSend}
            disabled={loading || !form.title.trim() || !form.message.trim()}
            className="w-full"
          >
            {loading ? 'Изпращане...' : 'Изпрати нотификация'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};