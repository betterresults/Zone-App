import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { useTheme } from '@/hooks/useTheme';
import { Palette, Plus, Trash2, Settings, Check } from 'lucide-react';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';

interface ThemeColors {
  primary: string;
  primary_foreground: string;
  accent: string;
  accent_foreground: string;
  secondary: string;
  secondary_foreground: string;
  zone_protein: string;
  zone_carbs: string;
  zone_fat: string;
  zone_balanced: string;
  zone_warning: string;
  success: string;
  warning: string;
  destructive: string;
}

const defaultColors: ThemeColors = {
  primary: "142 69% 58%",
  primary_foreground: "0 0% 100%",
  accent: "33 100% 65%",
  accent_foreground: "0 0% 100%",
  secondary: "45 25% 92%",
  secondary_foreground: "210 15% 20%",
  zone_protein: "160 60% 45%",
  zone_carbs: "33 100% 65%",
  zone_fat: "280 60% 65%",
  zone_balanced: "142 69% 58%",
  zone_warning: "45 93% 58%",
  success: "142 69% 58%",
  warning: "45 93% 58%",
  destructive: "0 84.2% 60.2%"
};

const colorLabels = {
  primary: "Основен цвят",
  primary_foreground: "Текст върху основен",
  accent: "Акцентен цвят",
  accent_foreground: "Текст върху акцентен",
  secondary: "Вторичен цвят",
  secondary_foreground: "Текст върху вторичен",
  zone_protein: "Зона - Протеини",
  zone_carbs: "Зона - Въглехидрати", 
  zone_fat: "Зона - Мазнини",
  zone_balanced: "Зона - Балансирано",
  zone_warning: "Зона - Предупреждение",
  success: "Успех",
  warning: "Предупреждение",
  destructive: "Деструктивно"
};

// Convert HSL string to hex for color picker
const hslToHex = (hsl: string): string => {
  const [h, s, l] = hsl.split(' ').map((v, i) => {
    if (i === 0) return parseInt(v);
    return parseInt(v.replace('%', ''));
  });
  
  const hNorm = h / 360;
  const sNorm = s / 100;
  const lNorm = l / 100;

  const c = (1 - Math.abs(2 * lNorm - 1)) * sNorm;
  const x = c * (1 - Math.abs((hNorm * 6) % 2 - 1));
  const m = lNorm - c / 2;

  let r = 0, g = 0, b = 0;

  if (0 <= hNorm && hNorm < 1/6) {
    r = c; g = x; b = 0;
  } else if (1/6 <= hNorm && hNorm < 2/6) {
    r = x; g = c; b = 0;
  } else if (2/6 <= hNorm && hNorm < 3/6) {
    r = 0; g = c; b = x;
  } else if (3/6 <= hNorm && hNorm < 4/6) {
    r = 0; g = x; b = c;
  } else if (4/6 <= hNorm && hNorm < 5/6) {
    r = x; g = 0; b = c;
  } else if (5/6 <= hNorm && hNorm < 1) {
    r = c; g = 0; b = x;
  }

  r = Math.round((r + m) * 255);
  g = Math.round((g + m) * 255);
  b = Math.round((b + m) * 255);

  return "#" + [r, g, b].map(x => x.toString(16).padStart(2, '0')).join('');
};

// Convert hex to HSL string
const hexToHsl = (hex: string): string => {
  try {
    // Remove # if present and validate
    const cleanHex = hex.replace('#', '');
    if (!/^[0-9A-Fa-f]{6}$/.test(cleanHex)) {
      return "0 0% 0%"; // fallback to black
    }

    const r = parseInt(cleanHex.slice(0, 2), 16) / 255;
    const g = parseInt(cleanHex.slice(2, 4), 16) / 255;
    const b = parseInt(cleanHex.slice(4, 6), 16) / 255;

    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    const diff = max - min;

    let h = 0;
    let s = 0;
    const l = (max + min) / 2;

    if (diff !== 0) {
      s = l > 0.5 ? diff / (2 - max - min) : diff / (max + min);

      switch (max) {
        case r: h = ((g - b) / diff + (g < b ? 6 : 0)) / 6; break;
        case g: h = ((b - r) / diff + 2) / 6; break;
        case b: h = ((r - g) / diff + 4) / 6; break;
      }
    }

    return `${Math.round(h * 360)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%`;
  } catch (error) {
    return "0 0% 0%"; // fallback to black
  }
};

// Helpers for validation/normalization
const isValidHex = (v: string) => /^#?[0-9A-Fa-f]{6}$/.test(v);
const normalizeHex = (v: string) => {
  const clean = v.startsWith('#') ? v : `#${v}`;
  return clean.slice(0, 7).toUpperCase();
};
const isValidHslString = (v: string) => /^\d{1,3}\s+\d{1,3}%\s+\d{1,3}%$/.test(v);

export const ThemeManager = () => {
  const { currentTheme, availableThemes, loadAllThemes, activateTheme, saveTheme, deleteTheme } = useTheme();
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingTheme, setEditingTheme] = useState<any>(null);
  const [themeName, setThemeName] = useState('');
  const [colors, setColors] = useState<ThemeColors>(defaultColors);
  const [hexValues, setHexValues] = useState<Record<keyof ThemeColors, string>>(() => {
    const entries = Object.entries(defaultColors).map(([k, v]) => [k, hslToHex(v as string).toUpperCase()]);
    return entries.reduce((acc, [k, v]) => ({ ...acc, [k as keyof ThemeColors]: v as string }), {} as Record<keyof ThemeColors, string>);
  });
  
  useEffect(() => {
    loadAllThemes();
  }, []);

  const openEditor = (theme?: any) => {
    if (theme) {
      setEditingTheme(theme);
      setThemeName(theme.name);
      setColors(theme.colors);
      setHexValues(Object.entries(theme.colors).reduce((acc, [k, v]) => ({ ...acc, [k as keyof ThemeColors]: hslToHex(v as string).toUpperCase() }), {} as Record<keyof ThemeColors, string>));
    } else {
      setEditingTheme(null);
      setThemeName('');
      setColors(defaultColors);
      setHexValues(Object.entries(defaultColors).reduce((acc, [k, v]) => ({ ...acc, [k as keyof ThemeColors]: hslToHex(v as string).toUpperCase() }), {} as Record<keyof ThemeColors, string>));
    }
    setIsEditorOpen(true);
  };

  const handleColorChange = (colorKey: keyof ThemeColors, hexValue: string) => {
    const normalized = normalizeHex(hexValue);
    const hslValue = hexToHsl(normalized);
    setColors(prev => ({ ...prev, [colorKey]: hslValue }));
    setHexValues(prev => ({ ...prev, [colorKey]: normalized.toUpperCase() }));
  };

  const handleSave = async () => {
    if (!themeName.trim()) return;
    
    const result = await saveTheme(themeName, colors, editingTheme?.id);
    if (result.success) {
      setIsEditorOpen(false);
      loadAllThemes();
    }
  };

  const handleDelete = async (themeId: string) => {
    const result = await deleteTheme(themeId);
    if (result.success) {
      loadAllThemes();
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Palette className="w-5 h-5" />
          Управление на теми
        </CardTitle>
        <CardDescription>
          Управлявайте цветовите схеми на сайта
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex justify-between items-center">
          <div>
            <p className="text-sm font-medium">Активна тема:</p>
            <p className="text-sm text-muted-foreground">{currentTheme?.name || 'Няма активна тема'}</p>
          </div>
          <Dialog open={isEditorOpen} onOpenChange={setIsEditorOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => openEditor()} className="flex items-center gap-2">
                <Plus className="w-4 h-4" />
                Нова тема
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingTheme ? 'Редактирай тема' : 'Създай нова тема'}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="theme-name">Име на темата</Label>
                  <Input
                    id="theme-name"
                    value={themeName}
                    onChange={(e) => setThemeName(e.target.value)}
                    placeholder="Например: Тъмна тема"
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {Object.entries(colorLabels).map(([key, label]) => (
                    <div key={key} className="space-y-2">
                      <Label htmlFor={key}>{label}</Label>
                      <div className="space-y-2">
                        {/* Color picker */}
                        <div className="flex gap-2 items-center">
                          <input
                            id={key}
                            type="color"
                            value={hslToHex(colors[key as keyof ThemeColors])}
                            onChange={(e) => handleColorChange(key as keyof ThemeColors, e.target.value)}
                            className="w-12 h-10 border border-border rounded cursor-pointer bg-transparent"
                          />
                          <div className="flex-1 space-y-1">
                            {/* Hex input */}
                            <Input
                              value={hexValues[key as keyof ThemeColors] ?? hslToHex(colors[key as keyof ThemeColors]).toUpperCase()}
                              onChange={(e) => {
                                const val = e.target.value;
                                setHexValues(prev => ({ ...prev, [key]: val } as any));
                              }}
                              onBlur={() => {
                                const current = hexValues[key as keyof ThemeColors];
                                if (isValidHex(current)) {
                                  handleColorChange(key as keyof ThemeColors, normalizeHex(current as string));
                                } else {
                                  setHexValues(prev => ({ ...prev, [key]: hslToHex(colors[key as keyof ThemeColors]).toUpperCase() } as any));
                                }
                              }}
                              placeholder="#02A274"
                              className="text-sm font-mono"
                            />
                            {/* HSL input (smaller, secondary) */}
                            <Input
                              value={colors[key as keyof ThemeColors]}
                              onChange={(e) => setColors(prev => ({ ...prev, [key]: e.target.value }))}
                              onBlur={(e) => {
                                const v = e.target.value;
                                if (isValidHslString(v)) {
                                  setHexValues(prev => ({ ...prev, [key]: hslToHex(v).toUpperCase() } as any));
                                }
                              }}
                              placeholder="hue saturation% lightness%"
                              className="text-xs font-mono text-muted-foreground"
                            />
                          </div>
                        </div>
                        {/* Color preview */}
                        <div 
                          className="h-6 w-full rounded border"
                          style={{ backgroundColor: hslToHex(colors[key as keyof ThemeColors]) }}
                        />
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex justify-end gap-2 pt-4">
                  <Button variant="outline" onClick={() => setIsEditorOpen(false)}>
                    Отказ
                  </Button>
                  <Button onClick={handleSave} disabled={!themeName.trim()}>
                    {editingTheme ? 'Обнови' : 'Създай'}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="space-y-2">
          <Label>Налични теми:</Label>
          <div className="grid gap-2">
            {availableThemes.map((theme) => (
              <div key={theme.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-2">
                  <div className="text-sm font-medium">{theme.name}</div>
                  {theme.is_active && <Badge variant="secondary">Активна</Badge>}
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openEditor(theme)}
                  >
                    <Settings className="w-4 h-4" />
                  </Button>
                  {!theme.is_active && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => activateTheme(theme.id)}
                    >
                      <Check className="w-4 h-4" />
                    </Button>
                  )}
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="outline" size="sm" disabled={theme.is_active}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Изтрий тема</AlertDialogTitle>
                        <AlertDialogDescription>
                          Сигурни ли сте, че искате да изтриете темата "{theme.name}"? 
                          Това действие не може да бъде отменено.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Отказ</AlertDialogCancel>
                        <AlertDialogAction onClick={() => handleDelete(theme.id)}>
                          Изтрий
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};