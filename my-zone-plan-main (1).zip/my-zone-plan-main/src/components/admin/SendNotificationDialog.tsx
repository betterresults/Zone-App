import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Bell, Send, Users } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface SendNotificationDialogProps {
  users: Array<{ user_id: string; email: string; display_name: string | null }>;
}

export const SendNotificationDialog = ({ users }: SendNotificationDialogProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedUser, setSelectedUser] = useState<string>("all");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [notificationType, setNotificationType] = useState<'custom' | 'habit' | 'fitness' | 'hydration'>('custom');
  const { toast } = useToast();

  const handleSendNotification = async () => {
    if (!title || !body) {
      toast({
        title: "Грешка",
        description: "Моля въведете заглавие и съдържание",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      let payload: any = {
        title,
        body,
        data: {
          type: notificationType,
          admin_sent: true,
          timestamp: Date.now()
        }
      };

      // Add actions based on notification type
      if (notificationType === 'habit') {
        payload.actions = [
          { action: 'complete', title: 'Завърши', icon: '/icon-192.png' }
        ];
      } else if (notificationType === 'fitness') {
        payload.actions = [
          { action: 'start_workout', title: 'Започни тренировка', icon: '/icon-192.png' }
        ];
      } else if (notificationType === 'hydration') {
        payload.actions = [
          { action: 'log_water', title: 'Запиши вода', icon: '/icon-192.png' }
        ];
      }

      // If specific user is selected, add userId to payload
      if (selectedUser !== "all") {
        payload.userId = selectedUser;
      }

      if (selectedUser !== "all") {
        // Send to both Web Push and Native (FCM) in parallel for the selected user
        const [webResult, nativeResult] = await Promise.all([
          supabase.functions.invoke('send-push-notification', { body: { ...payload, userId: selectedUser } }),
          supabase.functions.invoke('send-native-push', { body: { userId: selectedUser, title, body, data: payload.data } }),
        ]);

        const webData = (webResult.data as any) || {};
        const nativeData = (nativeResult.data as any) || {};
        const webSent = (typeof webData.sent === 'number' ? webData.sent : webData.totalSent) ?? (Array.isArray(webData.results) ? webData.results.filter((r:any)=>r.success).length : 0);
        const nativeSent = (typeof nativeData.sent === 'number' ? nativeData.sent : 0);

        // Consider failure only if both calls errored out (network/function error)
        const bothErrored = !!webResult.error && !!nativeResult.error;
        if (bothErrored) {
          throw new Error(webResult.error?.message || nativeResult.error?.message || 'Неуспешно изпращане на нотификация');
        }

        const totalDelivered = (webSent || 0) + (nativeSent || 0);
        const recipientText = users.find(u => u.user_id === selectedUser)?.display_name || 
          users.find(u => u.user_id === selectedUser)?.email || "избрания потребител";

        if (totalDelivered === 0) {
          toast({
            title: "Изпратено (без активни абонаменти)",
            description: `Няма активни уеб абонаменти или нативни токени за ${recipientText}.`,
          });
        } else {
          toast({
            title: "Успех",
            description: `Доставено: Web ${webSent || 0}, Native ${nativeSent || 0} → ${recipientText}`,
          });
        }
      } else {
        // Broadcast to all web subscribers (native broadcast не е имплементиран)
        const { data, error } = await supabase.functions.invoke('send-push-notification', { body: payload });
        if (error) throw error;
        const totalSent = (data as any)?.totalSent ?? (data as any)?.sent ?? 0;
        toast({ title: "Успех", description: `Доставено до ${totalSent} уеб абоната.` });
      }


      const recipientText = selectedUser === "all" ? "всички потребители" : 
        users.find(u => u.user_id === selectedUser)?.display_name || 
        users.find(u => u.user_id === selectedUser)?.email || "избрания потребител";

      toast({
        title: "Успех",
        description: `Нотификацията е изпратена до ${recipientText}`,
      });

      // Reset form
      setTitle("");
      setBody("");
      setNotificationType('custom');
      setSelectedUser("all");
      setIsOpen(false);
    } catch (error: any) {
      console.error('Error sending notification:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно изпращане на нотификация: " + error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getNotificationTypeDescription = () => {
    switch (notificationType) {
      case 'habit':
        return "Нотификация за навици с бутон за завършване";
      case 'fitness':
        return "Нотификация за фитнес с бутон за тренировка";
      case 'hydration':
        return "Нотификация за хидратация с бутон за записване на вода";
      default:
        return "Обикновена нотификация без специални действия";
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Bell className="h-4 w-4 mr-2" />
          Изпрати нотификация
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Изпращане на push нотификация</DialogTitle>
          <DialogDescription id="send-notification-description">
            Изпратете push съобщение до конкретен потребител или до всички.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <Label htmlFor="recipient">Получател</Label>
            <Select value={selectedUser} onValueChange={setSelectedUser}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">
                  <div className="flex items-center">
                    <Users className="h-4 w-4 mr-2" />
                    Всички потребители
                  </div>
                </SelectItem>
                {users.map((user) => (
                  <SelectItem key={user.user_id} value={user.user_id}>
                    {user.display_name || user.email} ({user.email})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="title">Заглавие на нотификацията</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Въведете заглавие..."
              maxLength={50}
            />
            <p className="text-xs text-muted-foreground mt-1">
              {title.length}/50 символа
            </p>
          </div>

          <div>
            <Label htmlFor="body">Съдържание</Label>
            <Textarea
              id="body"
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="Въведете съдържанието на нотификацията..."
              rows={4}
              maxLength={200}
            />
            <p className="text-xs text-muted-foreground mt-1">
              {body.length}/200 символа
            </p>
          </div>

          <div>
            <Label htmlFor="type">Тип нотификация</Label>
            <Select value={notificationType} onValueChange={(value: any) => setNotificationType(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="custom">Обикновена</SelectItem>
                <SelectItem value="habit">Навици</SelectItem>
                <SelectItem value="fitness">Фитнес</SelectItem>
                <SelectItem value="hydration">Хидратация</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-sm text-muted-foreground mt-1">
              {getNotificationTypeDescription()}
            </p>
          </div>

          <Button 
            onClick={handleSendNotification} 
            disabled={isLoading || !title || !body}
            className="w-full"
          >
            {isLoading ? (
              <>Изпраща...</>
            ) : (
              <>
                <Send className="h-4 w-4 mr-2" />
                Изпрати нотификация
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};