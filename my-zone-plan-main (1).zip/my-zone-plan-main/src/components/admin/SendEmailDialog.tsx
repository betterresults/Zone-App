import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Mail, Send } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface SendEmailDialogProps {
  users: Array<{ id: string; email: string; display_name: string | null }>;
}

export const SendEmailDialog = ({ users }: SendEmailDialogProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedUser, setSelectedUser] = useState("");
  const [subject, setSubject] = useState("");
  const [template, setTemplate] = useState<'welcome' | 'confirmation' | 'password-reset' | 'custom'>('custom');
  const [customContent, setCustomContent] = useState("");
  const [confirmationLink, setConfirmationLink] = useState("");
  const [resetLink, setResetLink] = useState("");
  const { toast } = useToast();

  const handleSendEmail = async () => {
    if (!selectedUser || !subject) {
      toast({
        title: "Грешка",
        description: "Моля изберете потребител и въведете тема",
        variant: "destructive",
      });
      return;
    }

    if (template === 'custom' && !customContent) {
      toast({
        title: "Грешка",
        description: "Моля въведете съдържание на имейла",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      const selectedUserData = users.find(u => u.id === selectedUser);
      
      const payload: any = {
        email: selectedUserData?.email,
        subject: subject,
        displayName: selectedUserData?.display_name,
      };

      if (template === 'custom') {
        payload.customContent = customContent;
      } else {
        payload.template = template;
        if (template === 'confirmation') {
          payload.confirmationLink = confirmationLink || `${window.location.origin}/auth`;
        }
        if (template === 'password-reset') {
          payload.resetLink = resetLink || `${window.location.origin}/auth`;
        }
      }

      const { error } = await supabase.functions.invoke('send-admin-email', {
        body: payload,
      });

      if (error) throw error;

      toast({
        title: "Успех",
        description: "Имейлът е изпратен успешно",
      });

      // Reset form
      setSelectedUser("");
      setSubject("");
      setTemplate('custom');
      setCustomContent("");
      setConfirmationLink("");
      setResetLink("");
      setIsOpen(false);
    } catch (error: any) {
      console.error('Error sending email:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно изпращане на имейл: " + error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getTemplatePreview = () => {
    switch (template) {
      case 'welcome':
        return "Шаблон за добре дошли с информация за Beta програмата";
      case 'confirmation':
        return "Шаблон за потвърждение на имейл с линк за верификация";
      case 'password-reset':
        return "Шаблон за забравена парола с линк за възстановяване";
      default:
        return "Персонализирано съдържание";
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Mail className="h-4 w-4 mr-2" />
          Изпрати имейл
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Изпращане на имейл</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <Label htmlFor="user">Получател</Label>
            <Select value={selectedUser} onValueChange={setSelectedUser}>
              <SelectTrigger>
                <SelectValue placeholder="Изберете потребител" />
              </SelectTrigger>
              <SelectContent>
                {users.map((user) => (
                  <SelectItem key={user.id} value={user.id}>
                    {user.display_name || user.email} ({user.email})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="subject">Тема на имейла</Label>
            <Input
              id="subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Въведете тема..."
            />
          </div>

          <div>
            <Label htmlFor="template">Тип имейл</Label>
            <Select value={template} onValueChange={(value: any) => setTemplate(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="welcome">Добре дошли</SelectItem>
                <SelectItem value="confirmation">Потвърждение на имейл</SelectItem>
                <SelectItem value="password-reset">Забравена парола</SelectItem>
                <SelectItem value="custom">Персонализиран</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-sm text-muted-foreground mt-1">
              {getTemplatePreview()}
            </p>
          </div>

          {template === 'confirmation' && (
            <div>
              <Label htmlFor="confirmationLink">Линк за потвърждение (по избор)</Label>
              <Input
                id="confirmationLink"
                value={confirmationLink}
                onChange={(e) => setConfirmationLink(e.target.value)}
                placeholder={`${window.location.origin}/auth`}
              />
            </div>
          )}

          {template === 'password-reset' && (
            <div>
              <Label htmlFor="resetLink">Линк за възстановяване (по избор)</Label>
              <Input
                id="resetLink"
                value={resetLink}
                onChange={(e) => setResetLink(e.target.value)}
                placeholder={`${window.location.origin}/auth`}
              />
            </div>
          )}

          {template === 'custom' && (
            <div>
              <Label htmlFor="content">Съдържание на имейла</Label>
              <Textarea
                id="content"
                value={customContent}
                onChange={(e) => setCustomContent(e.target.value)}
                placeholder="Въведете съдържанието на имейла..."
                rows={8}
              />
              <p className="text-sm text-muted-foreground mt-1">
                Можете да използвате обикновен текст. Новите редове ще бъдат запазени.
              </p>
            </div>
          )}

          <Button 
            onClick={handleSendEmail} 
            disabled={isLoading || !selectedUser || !subject}
            className="w-full"
          >
            {isLoading ? (
              <>Изпраща...</>
            ) : (
              <>
                <Send className="h-4 w-4 mr-2" />
                Изпрати имейл
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};