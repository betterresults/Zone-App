import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { ServingsInput } from '@/components/ui/servings-input';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useUserLimits } from '@/hooks/useUserLimits';
import { useActivityTracker } from '@/hooks/useActivityTracker';

interface SaveRecipeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  cookingItems: Array<{
    id: string;
    product: any;
    grams: number;
    portionName?: string;
  }>;
  totalNutrition: {
    protein: number;
    carbs: number;
    fat: number;
    fiber: number;
    calories: number;
  };
  sourceRecipe?: any; // Recipe being cooked from, if any
}

export const SaveRecipeDialog = ({ open, onOpenChange, cookingItems, totalNutrition, sourceRecipe }: SaveRecipeDialogProps) => {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    instructions: '',
    servings: 1,
    mealType: 'lunch' as 'breakfast' | 'lunch' | 'dinner' | 'snack',
    isPublic: false,
    addToCalendar: false,
    mealDate: new Date().toISOString().split('T')[0]
  });
  const [updateExisting, setUpdateExisting] = useState(false); // Choice to update existing or create new
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { canAdd } = useUserLimits();
  const { trackActivity } = useActivityTracker();

  // Prefill when cooking an existing recipe
  useEffect(() => {
    if (sourceRecipe && open) {
      setFormData(prev => ({
        ...prev,
        name: sourceRecipe.name || '',
        description: sourceRecipe.description || '',
        instructions: sourceRecipe.instructions || '',
        servings: sourceRecipe.servings || 1,
        mealType: (sourceRecipe.meal_type || 'lunch') as any,
        isPublic: !!sourceRecipe.is_public,
      }));
    }
  }, [sourceRecipe, open]);

  const saveRecipeMutation = useMutation({
    mutationFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      if (updateExisting && sourceRecipe) {
        // Update existing recipe
        const { data: recipe, error: recipeError } = await supabase
          .from('recipes')
          .update({
            name: formData.name,
            description: formData.description,
            instructions: formData.instructions,
            servings: formData.servings,
            meal_type: formData.mealType,
            is_public: formData.isPublic
          })
          .eq('id', sourceRecipe.id)
          .select()
          .single();

        if (recipeError) throw recipeError;

        // Delete and re-add ingredients
        await supabase.from('recipe_ingredients').delete().eq('recipe_id', sourceRecipe.id);
        
        const ingredients = cookingItems.map(item => ({
          recipe_id: sourceRecipe.id,
          product_id: item.product.id,
          grams: item.grams
        }));

        const { error: ingredientsError } = await supabase
          .from('recipe_ingredients')
          .insert(ingredients);

        if (ingredientsError) throw ingredientsError;
        // Optionally add to calendar
        if (formData.addToCalendar) {
          const { error: mealError } = await supabase
            .from('meals')
            .insert({
              recipe_id: sourceRecipe.id,
              date: formData.mealDate,
              meal_type: formData.mealType,
              servings: 1,
              user_id: user.id
            });
          if (mealError) throw mealError;
        }

        return recipe;
      } else {
        // Create new recipe (existing logic)
        const { data: recipe, error: recipeError } = await supabase
          .from('recipes')
          .insert({
            name: formData.name,
            description: formData.description,
            instructions: formData.instructions,
            servings: formData.servings,
            meal_type: formData.mealType,
            is_public: formData.isPublic,
            user_id: user.id
          })
          .select()
          .single();

        if (recipeError) throw recipeError;

        // Add ingredients
        const ingredients = cookingItems.map(item => ({
          recipe_id: recipe.id,
          product_id: item.product.id,
          grams: item.grams
        }));

        const { error: ingredientsError } = await supabase
          .from('recipe_ingredients')
          .insert(ingredients);

        if (ingredientsError) throw ingredientsError;

        // Optionally add to calendar
        if (formData.addToCalendar) {
          const { error: mealError } = await supabase
            .from('meals')
            .insert({
              recipe_id: recipe.id,
              date: formData.mealDate,
              meal_type: formData.mealType,
              servings: 1,
              user_id: user.id
            });
          if (mealError) throw mealError;
        }

        return recipe;
      }
  },
  onSuccess: (data) => {
    toast({
      title: updateExisting ? "Рецептата е обновена!" : "Рецептата е запазена!",
      description: formData.addToCalendar ? (updateExisting ? "Рецептата е обновена и добавена в календара." : "Рецептата е създадена и добавена в календара.") : (updateExisting ? "Рецептата е обновена успешно." : "Рецептата е създадена успешно.")
    });
    queryClient.invalidateQueries({ queryKey: ['recipes'] });
    queryClient.invalidateQueries({ queryKey: ['meals'] });
    queryClient.invalidateQueries({ queryKey: ['user-recipes'] });
    queryClient.invalidateQueries({ queryKey: ['user-counts'] });
    trackActivity('cooking', 'save_cooking_result', `${updateExisting ? 'Обнови' : 'Запази'} готвене като рецепта: ${data.name}`, {
      recipe_id: data.id,
      recipe_name: data.name,
      meal_type: data.meal_type,
      servings: data.servings,
      is_public: data.is_public,
      add_to_calendar: formData.addToCalendar,
      products_count: cookingItems.length
    });
    onOpenChange(false);
    resetForm();
  },
  onError: (error) => {
    toast({
      title: "Грешка",
      description: "Неуспешно запазване на рецептата.",
      variant: "destructive"
    });
    console.error('Save recipe error:', error);
  }
});

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      instructions: '',
      servings: 1,
      mealType: 'lunch',
      isPublic: false,
      addToCalendar: false,
      mealDate: new Date().toISOString().split('T')[0]
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      toast({
        title: "Грешка",
        description: "Моля въведете име на рецептата.",
        variant: "destructive"
      });
      return;
    }
    
    if (!canAdd.recipes) {
      toast({
        title: "Достигнат лимит",
        description: "Достигнали сте лимита за рецепти. Моля, премахнете някои от съществуващите рецепти или преминете към Premium.",
        variant: "destructive"
      });
      return;
    }
    
    saveRecipeMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md h-[95vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle>Запази като рецепта</DialogTitle>
          <DialogDescription>
            Създайте рецепта от текущите продукти
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto">
          <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Име на рецептата *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              placeholder="Например: Протеинова салата"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Описание</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Кратко описание на рецептата..."
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="instructions">Инструкции</Label>
            <Textarea
              id="instructions"
              value={formData.instructions}
              onChange={(e) => setFormData(prev => ({ ...prev, instructions: e.target.value }))}
              placeholder="Стъпки за приготвяне..."
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="servings">Порции</Label>
              <ServingsInput
                id="servings"
                value={formData.servings}
                onChange={(value) => setFormData(prev => ({ ...prev, servings: value }))}
                min={1}
                max={50}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="meal-type">Тип хранене</Label>
              <Select value={formData.mealType} onValueChange={(value: any) => setFormData(prev => ({ ...prev, mealType: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="breakfast">Закуска</SelectItem>
                  <SelectItem value="lunch">Обяд</SelectItem>
                  <SelectItem value="dinner">Вечеря</SelectItem>
                  <SelectItem value="snack">Междинно</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="public"
              checked={formData.isPublic}
              onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isPublic: checked }))}
            />
            <Label htmlFor="public">Направи рецептата публична</Label>
          </div>

          {sourceRecipe && (
            <div className="flex items-center space-x-2">
              <Checkbox
                id="update-existing"
                checked={updateExisting}
                onCheckedChange={(checked) => setUpdateExisting(!!checked)}
              />
              <Label htmlFor="update-existing">Обнови съществуващата рецепта</Label>
            </div>
          )}

          <div className="space-y-3 p-3 bg-muted/50 rounded-lg">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="add-to-calendar"
                checked={formData.addToCalendar}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, addToCalendar: checked as boolean }))}
              />
              <Label htmlFor="add-to-calendar">Добави веднага в календара</Label>
            </div>

            {formData.addToCalendar && (
              <div className="grid grid-cols-2 gap-3 ml-6">
                <div className="space-y-1">
                  <Label htmlFor="meal-date" className="text-xs">Дата</Label>
                  <Input
                    id="meal-date"
                    type="date"
                    value={formData.mealDate}
                    onChange={(e) => setFormData(prev => ({ ...prev, mealDate: e.target.value }))}
                    className="text-sm"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">Хранене</Label>
                  <Select value={formData.mealType} onValueChange={(value: any) => setFormData(prev => ({ ...prev, mealType: value }))}>
                    <SelectTrigger className="text-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="breakfast">Закуска</SelectItem>
                      <SelectItem value="lunch">Обяд</SelectItem>
                      <SelectItem value="dinner">Вечеря</SelectItem>
                      <SelectItem value="snack">Междинно</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Отказ
            </Button>
            <Button type="submit" disabled={saveRecipeMutation.isPending}>
              {saveRecipeMutation.isPending
                ? (updateExisting ? 'Обновява...' : 'Запазва...')
                : (updateExisting ? 'Обнови рецепта' : 'Запази рецепта')}
            </Button>
          </div>
        </form>
        </div>
      </DialogContent>
    </Dialog>
  );
};