import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Save, BookOpen, Utensils, Package, Plus, Loader2 } from 'lucide-react';
import { SaveRecipeDialog } from './SaveRecipeDialog';
import { SaveMealDialog } from './SaveMealDialog';
import { SaveProductDialog } from './SaveProductDialog';
import { SaveBothDialog } from './SaveBothDialog';
import { useToast } from '@/hooks/use-toast';

interface SaveMenuProps {
  cookingItems: Array<{
    id: string;
    product: any;
    grams: number;
    portionName?: string;
  }>;
  totalNutrition: {
    protein: number;
    carbs: number;
    fat: number;
    fiber: number;
    calories: number;
  };
  buttonText?: string;
  sourceRecipe?: any; // Recipe being cooked from, if any
}

export const SaveMenu = ({ cookingItems, totalNutrition, buttonText = "Запази", sourceRecipe }: SaveMenuProps) => {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [selections, setSelections] = useState({
    recipe: false,
    meal: false,
    product: false
  });
  const [activeDialog, setActiveDialog] = useState<'recipe' | 'meal' | 'product' | 'both' | null>(null);
  const { toast } = useToast();

  const handleSelectionChange = (type: keyof typeof selections, checked: boolean) => {
    setSelections(prev => ({
      ...prev,
      [type]: checked
    }));
  };

  const handleSave = async () => {
    const selectedOptions = Object.entries(selections).filter(([_, selected]) => selected);
    
    if (selectedOptions.length === 0) {
      toast({
        title: "Не е избрана опция",
        description: "Моля изберете поне една опция за запазване.",
        variant: "destructive"
      });
      return;
    }

    setOpen(false);
    
    // If multiple options selected, show unified dialog
    if (selectedOptions.length > 1) {
      setActiveDialog('both');
    } else {
      // Single option - show specific dialog
      const [type] = selectedOptions;
      setActiveDialog(type[0] as any);
    }
  };

  const selectedCount = Object.values(selections).filter(Boolean).length;

  return (
    <>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button>
            <Save className="w-4 h-4 mr-2" />
            {buttonText}
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Запази готвенето като...</DialogTitle>
            <DialogDescription>
              Изберете как искате да запазите готвенето. Можете да изберете няколко опции наведнъж.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Checkbox 
                  id="recipe"
                  checked={selections.recipe}
                  onCheckedChange={(checked) => handleSelectionChange('recipe', !!checked)}
                />
                <Label htmlFor="recipe" className="flex items-center text-sm cursor-pointer">
                  <BookOpen className="w-4 h-4 mr-2 text-blue-600" />
                  Като рецепта
                </Label>
              </div>
              
              <div className="flex items-center space-x-3">
                <Checkbox 
                  id="meal"
                  checked={selections.meal}
                  onCheckedChange={(checked) => handleSelectionChange('meal', !!checked)}
                />
                <Label htmlFor="meal" className="flex items-center text-sm cursor-pointer">
                  <Utensils className="w-4 h-4 mr-2 text-green-600" />
                  Като ястие
                </Label>
              </div>
              
              <div className="flex items-center space-x-3">
                <Checkbox 
                  id="product"
                  checked={selections.product}
                  onCheckedChange={(checked) => handleSelectionChange('product', !!checked)}
                />
                <Label htmlFor="product" className="flex items-center text-sm cursor-pointer">
                  <Package className="w-4 h-4 mr-2 text-orange-600" />
                  Като продукт
                </Label>
              </div>
            </div>
            
            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button variant="outline" onClick={() => setOpen(false)}>
                Отказ
              </Button>
              <Button 
                onClick={handleSave}
                disabled={saving || selectedCount === 0}
              >
                {saving ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Запазва...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-2" />
                    Запази {selectedCount > 0 ? `(${selectedCount})` : ''}
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <SaveRecipeDialog
        open={activeDialog === 'recipe'}
        onOpenChange={(open) => !open && setActiveDialog(null)}
        cookingItems={cookingItems}
        totalNutrition={totalNutrition}
        sourceRecipe={sourceRecipe}
      />

      <SaveMealDialog
        open={activeDialog === 'meal'}
        onOpenChange={(open) => !open && setActiveDialog(null)}
        cookingItems={cookingItems}
        totalNutrition={totalNutrition}
      />

      <SaveProductDialog
        open={activeDialog === 'product'}
        onOpenChange={(open) => !open && setActiveDialog(null)}
        cookingItems={cookingItems}
        totalNutrition={totalNutrition}
      />

      <SaveBothDialog
        open={activeDialog === 'both'}
        onOpenChange={(open) => {
          if (!open) {
            setActiveDialog(null);
            // Reset selections
            setSelections({
              recipe: false,
              meal: false,
              product: false
            });
          }
        }}
        cookingItems={cookingItems}
        totalNutrition={totalNutrition}
        selections={selections}
        sourceRecipe={sourceRecipe}
      />
    </>
  );
};