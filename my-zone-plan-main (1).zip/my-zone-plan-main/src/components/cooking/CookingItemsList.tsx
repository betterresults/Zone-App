import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ChefHat, Trash2, ChevronLeft, ChevronRight } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  image_url?: string;
  protein_per_100g: number;
  carbs_per_100g: number;
  fat_per_100g: number;
  calories_per_100g: number;
}

interface Ingredient {
  id: string;
  product_id: string;
  grams: number;
  product?: Product;
}

interface CookingItemsListProps {
  ingredients: Ingredient[];
  products: Product[];
  onUpdateGrams: (id: string, grams: number) => void;
  onRemove: (id: string) => void;
  onClearAll?: () => void;
  title?: string;
}

export const CookingItemsList = ({
  ingredients,
  products,
  onUpdateGrams,
  onRemove,
  onClearAll,
  title = "Добавени продукти"
}: CookingItemsListProps) => {
  const gramOptions = [1, 2, 5, 10, 20, 25, 100, 200];

  return (
    <Card className="border-border">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle>{title} ({ingredients.length})</CardTitle>
          {ingredients.length > 0 && onClearAll && (
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                onClick={onClearAll}
                size="sm"
                className="hidden sm:flex"
              >
                Изчисти всичко
              </Button>
              <Button 
                variant="outline" 
                onClick={onClearAll}
                size="sm"
                className="sm:hidden"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent className="p-2 sm:p-3">
        {ingredients.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <ChefHat className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p className="text-lg">Все още няма добавени продукти</p>
            <p className="text-sm">Започнете с избирането на продукт отгоре</p>
          </div>
        ) : (
          <div className="space-y-2 sm:space-y-3">
            {ingredients.map(ingredient => {
              const product = products.find(p => p.id === ingredient.product_id);
              if (!product) return null;

              return (
                <div key={ingredient.id} className="bg-muted/30 rounded-lg p-2 sm:p-3 border border-border">
                  {/* First line: Image, Name, Editable grams, Delete */}
                  <div className="flex items-center gap-2 mb-2">
                      {/* Product image */}
                      <div className="w-10 h-8 sm:w-12 sm:h-10 bg-muted rounded-lg flex items-center justify-center overflow-hidden flex-shrink-0">
                        {product.image_url ? (
                          <img 
                            src={product.image_url} 
                            alt={product.name}
                            className="w-full h-full object-cover rounded-lg"
                          />
                        ) : (
                          <ChefHat className="w-3 h-3 sm:w-4 sm:h-4 text-muted-foreground" />
                        )}
                      </div>

                      {/* Product name */}
                      <div className="flex-1 min-w-0 pr-1">
                        <h4 className="font-medium text-xs sm:text-sm truncate">{product.name}</h4>
                      </div>

                      {/* Modern number control with arrows */}
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onUpdateGrams(ingredient.id, Math.max(0, ingredient.grams - 1))}
                          className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground"
                        >
                          <ChevronLeft className="w-3 h-3" />
                        </Button>
                        <div className="bg-muted/50 rounded-lg px-2 py-1 min-w-[45px] text-center">
                          <span className="font-bold text-sm">{ingredient.grams}</span>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onUpdateGrams(ingredient.id, ingredient.grams + 1)}
                          className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground"
                        >
                          <ChevronRight className="w-3 h-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onUpdateGrams(ingredient.id, 0)}
                          className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground hover:bg-muted/20"
                          title="Нулирай грамове"
                        >
                          <svg className="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/>
                            <path d="M21 3v5h-5"/>
                            <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/>
                            <path d="M3 21v-5h5"/>
                          </svg>
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onRemove(ingredient.id)}
                          className="h-6 w-6 p-0 text-muted-foreground hover:text-destructive"
                          title="Премахни"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                  </div>

                  {/* Second line: Quick gram selection with responsive layout */}
                  <div className="border-2 border-dashed border-primary/30 rounded-lg p-1.5 sm:p-2 bg-primary/5">
                    <div className="flex flex-col gap-1 sm:gap-2">
                      <div className="text-xs text-muted-foreground font-medium">
                        Добави грамове
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {gramOptions.map((grams) => (
                          <Button
                            key={grams}
                            variant="outline"
                            size="sm"
                            className="h-6 sm:h-8 text-xs px-1.5 sm:px-2 flex-shrink-0 min-w-[32px] sm:min-w-[40px]"
                            onClick={() => onUpdateGrams(ingredient.id, Math.max(0, ingredient.grams + grams))}
                          >
                            +{grams}
                          </Button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
};