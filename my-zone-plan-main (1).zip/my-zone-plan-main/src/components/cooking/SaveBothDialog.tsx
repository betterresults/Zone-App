import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { ServingsInput } from '@/components/ui/servings-input';
import { CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useUserLimits } from '@/hooks/useUserLimits';
import { useActivityTracker } from '@/hooks/useActivityTracker';

interface SaveBothDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  cookingItems: Array<{
    id: string;
    product: any;
    grams: number;
    portionName?: string;
  }>;
  totalNutrition: {
    protein: number;
    carbs: number;
    fat: number;
    fiber: number;
    calories: number;
  };
  selections: {
    recipe: boolean;
    meal: boolean;
    product: boolean;
  };
  sourceRecipe?: any; // Recipe being cooked from, if any
}

export const SaveBothDialog = ({ open, onOpenChange, cookingItems, totalNutrition, selections, sourceRecipe }: SaveBothDialogProps) => {
  const [recipeName, setRecipeName] = useState('');
  const [description, setDescription] = useState('');
  const [instructions, setInstructions] = useState('');
  const [servings, setServings] = useState(1);
  const [mealType, setMealType] = useState<'breakfast' | 'lunch' | 'dinner' | 'snack'>('lunch');
  const [isPublic, setIsPublic] = useState(false);
  const [addToCalendar, setAddToCalendar] = useState(false);
  const [calendarDate, setCalendarDate] = useState<Date>(new Date());
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { canAdd } = useUserLimits();
  const { trackActivity } = useActivityTracker();

  const saveBothMutation = useMutation({
    mutationFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      if (!recipeName.trim()) {
        throw new Error('Моля въведете име на рецептата');
      }

      const results: any = {};

      // Create recipe if selected
      if (selections.recipe) {
        const { data: recipe, error: recipeError } = await supabase
          .from('recipes')
          .insert({
            name: recipeName,
            description,
            instructions,
            servings,
            meal_type: mealType,
            is_public: isPublic,
            user_id: user.id
          })
          .select()
          .single();

        if (recipeError) throw recipeError;

        // Add ingredients to the recipe
        const recipeIngredients = cookingItems.map(item => ({
          recipe_id: recipe.id,
          product_id: item.product.id,
          grams: item.grams
        }));

        const { error: ingredientsError } = await supabase
          .from('recipe_ingredients')
          .insert(recipeIngredients);

        if (ingredientsError) throw ingredientsError;
        results.recipe = recipe;
      }

      // Create dish if selected
      if (selections.meal) {
        const { data: dish, error: dishError } = await supabase
          .from('dishes')
          .insert({
            name: recipeName,
            description: description,
            meal_type: mealType,
            is_public: false,
            user_id: user.id,
            image_url: null,
            source_recipe_id: results.recipe?.id
          })
          .select()
          .single();

        if (dishError) throw dishError;

        // Add ingredients to the dish (per-serving amounts)
        const dishIngredients = cookingItems.map(item => ({
          dish_id: dish.id,
          product_id: item.product.id,
          grams: item.grams / servings // Scale down to single serving
        }));

        const { error: dishIngredientsError } = await supabase
          .from('dish_ingredients')
          .insert(dishIngredients);

        if (dishIngredientsError) throw dishIngredientsError;
        results.dish = dish;

        // Add to calendar if requested
        if (addToCalendar) {
          const { error: calendarError } = await supabase
            .from('meals')
            .insert({
              user_id: user.id,
              dish_id: dish.id,
              date: format(calendarDate, 'yyyy-MM-dd'),
              meal_type: mealType,
              servings: 1
            });

          if (calendarError) throw calendarError;
        }
      }

      // Create product if selected
      if (selections.product) {
        const { data: product, error: productError } = await supabase
          .from('products')
          .insert({
            name: recipeName,
            user_id: user.id,
            calories_per_100g: (totalNutrition.calories / (cookingItems.reduce((sum, item) => sum + item.grams, 0) / 100)),
            protein_per_100g: (totalNutrition.protein / (cookingItems.reduce((sum, item) => sum + item.grams, 0) / 100)),
            carbs_per_100g: (totalNutrition.carbs / (cookingItems.reduce((sum, item) => sum + item.grams, 0) / 100)),
            fat_per_100g: (totalNutrition.fat / (cookingItems.reduce((sum, item) => sum + item.grams, 0) / 100)),
            fiber_per_100g: (totalNutrition.fiber / (cookingItems.reduce((sum, item) => sum + item.grams, 0) / 100)),
            category: 'other',
            is_public: false
          })
          .select()
          .single();

        if (productError) throw productError;
        results.product = product;
      }

      return results;
    },
    onSuccess: (data) => {
      const created = [];
      if (data.recipe) created.push('рецепта');
      if (data.dish) created.push('ястие');
      if (data.product) created.push('продукт');
      
      toast({
        title: "Запазено успешно!",
        description: `Създадени са: ${created.join(', ')}.`,
        variant: "success"
      });
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['recipes'] });
      queryClient.invalidateQueries({ queryKey: ['user-meals'] });
      queryClient.invalidateQueries({ queryKey: ['calendar-meals'] });
      queryClient.invalidateQueries({ queryKey: ['today-meals-with-dishes'] });
      queryClient.invalidateQueries({ queryKey: ['user-dishes'] });
      queryClient.invalidateQueries({ queryKey: ['my-products-for-cooking'] });
      queryClient.invalidateQueries({ queryKey: ['user-counts'] });
      
      trackActivity('cooking', 'save_cooking_result', `Запази готвене като: ${created.join(', ')}: ${recipeName}`, {
        recipe_id: data.recipe?.id,
        dish_id: data.dish?.id,
        product_id: data.product?.id,
        name: recipeName,
        meal_type: mealType,
        servings: servings,
        created_types: created,
        add_to_calendar: addToCalendar,
        products_count: cookingItems.length
      });
      onOpenChange(false);
      resetForm();
    },
    onError: (error) => {
      toast({
        title: "Грешка",
        description: error.message || "Неуспешно запазване.",
        variant: "destructive"
      });
      console.error('Save multiple error:', error);
    }
  });

  const resetForm = () => {
    setRecipeName('');
    setDescription('');
    setInstructions('');
    setServings(1);
    setMealType('lunch');
    setIsPublic(false);
    setAddToCalendar(false);
    setCalendarDate(new Date());
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!canAdd.recipes) {
      toast({
        title: "Достигнат лимит",
        description: "Достигнали сте лимита за рецепти. Моля, премахнете някои от съществуващите рецепти или преминете към Premium.",
        variant: "destructive"
      });
      return;
    }
    
    if (!canAdd.dishes) {
      toast({
        title: "Достигнат лимит", 
        description: "Достигнали сте лимита за ястия. Моля, премахнете някои от съществуващите ястия или преминете към Premium.",
        variant: "destructive"
      });
      return;
    }
    
    saveBothMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md h-[95vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle>Запази готвенето</DialogTitle>
          <DialogDescription>
            {(() => {
              const selected = [];
              if (selections.recipe) selected.push('рецепта');
              if (selections.meal) selected.push('ястие');
              if (selections.product) selected.push('продукт');
              return `Създаване на: ${selected.join(', ')}`;
            })()}
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto">
          <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="recipe-name">Име *</Label>
            <Input
              id="recipe-name"
              value={recipeName}
              onChange={(e) => setRecipeName(e.target.value)}
              placeholder="Например: Протеинова салата"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Описание (по желание)</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Кратко описание..."
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="instructions">Инструкции (по желание)</Label>
            <Textarea
              id="instructions"
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              placeholder="Стъпки за приготвяне..."
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="servings">Порции в рецептата *</Label>
              <ServingsInput
                id="servings"
                value={servings}
                onChange={setServings}
                min={1}
                max={50}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="meal-type">Категория *</Label>
              <Select value={mealType} onValueChange={(value: any) => setMealType(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="breakfast">Закуска</SelectItem>
                  <SelectItem value="lunch">Обяд</SelectItem>
                  <SelectItem value="dinner">Вечеря</SelectItem>
                  <SelectItem value="snack">Междинно</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="is-public"
              checked={isPublic}
              onCheckedChange={setIsPublic}
            />
            <Label htmlFor="is-public">Направи рецептата публична</Label>
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="add-to-calendar"
              checked={addToCalendar}
              onCheckedChange={setAddToCalendar}
            />
            <Label htmlFor="add-to-calendar">Добави ястието в календара</Label>
          </div>

          {addToCalendar && (
            <div className="space-y-2">
              <Label>Дата</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !calendarDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {calendarDate ? format(calendarDate, 'dd.MM.yyyy') : "Изберете дата"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={calendarDate}
                    onSelect={(date) => date && setCalendarDate(date)}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          )}

          <div className="bg-muted/50 p-3 rounded-lg space-y-3">
            <div>
              <h4 className="font-medium text-sm mb-2">Рецепта общо ({servings} {servings === 1 ? 'порция' : 'порции'}):</h4>
              <div className="text-sm space-y-1">
                <div>Калории: {Math.round(totalNutrition.calories)} kcal</div>
                <div>Протеини: {totalNutrition.protein.toFixed(1)}г</div>
                <div>Въглехидрати: {totalNutrition.carbs.toFixed(1)}г</div>
                <div>Мазнини: {totalNutrition.fat.toFixed(1)}г</div>
              </div>
            </div>
            
            <div className="pt-3 border-t">
              <h4 className="font-medium text-sm mb-2 text-primary">Ястие за 1 порция:</h4>
              <div className="text-sm space-y-1">
                <div>Калории: {Math.round(totalNutrition.calories / servings)} kcal</div>
                <div>Протеини: {(totalNutrition.protein / servings).toFixed(1)}г</div>
                <div>Въглехидрати: {(totalNutrition.carbs / servings).toFixed(1)}г</div>
                <div>Мазнини: {(totalNutrition.fat / servings).toFixed(1)}г</div>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Отказ
            </Button>
            <Button type="submit" disabled={saveBothMutation.isPending}>
              {saveBothMutation.isPending ? 'Запазва...' : 'Запази всичко'}
            </Button>
          </div>
        </form>
        </div>
      </DialogContent>
    </Dialog>
  );
};