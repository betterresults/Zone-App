import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ServingsInput } from '@/components/ui/servings-input';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useUserLimits } from '@/hooks/useUserLimits';
import { useActivityTracker } from '@/hooks/useActivityTracker';
import { useCamera } from '@/hooks/useCamera';
import { Camera, Image, X } from 'lucide-react';
import { compressImage, dataURLToFile } from '@/lib/imageCompression';

interface SaveMealDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  cookingItems: Array<{
    id: string;
    product: any;
    grams: number;
    portionName?: string;
  }>;
  totalNutrition: {
    protein: number;
    carbs: number;
    fat: number;
    fiber: number;
    calories: number;
  };
}

export const SaveMealDialog = ({ open, onOpenChange, cookingItems, totalNutrition }: SaveMealDialogProps) => {
  const [mealType, setMealType] = useState<'breakfast' | 'lunch' | 'dinner' | 'snack'>('lunch');
  const [mealName, setMealName] = useState('');
  const [description, setDescription] = useState('');
  const [servings, setServings] = useState(1);
  const [imageUrl, setImageUrl] = useState('');
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { canAdd } = useUserLimits();
  const { trackActivity } = useActivityTracker();
  const { takePicture, selectFromGallery } = useCamera();

  const saveMealMutation = useMutation({
    mutationFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      if (!mealName.trim()) {
        throw new Error('Моля въведете име на ястието');
      }

      // Upload image if exists
      let uploadedImageUrl: string | null = null;
      if (imageUrl && imageUrl.trim()) {
        try {
          // Compress the image
          const compressedDataUrl = await compressImage(imageUrl, {
            maxWidth: 800,
            maxHeight: 800,
            quality: 0.8,
            maxSizeKB: 500
          });
          
          // Convert to File
          const imageFile = dataURLToFile(compressedDataUrl, `dish_${Date.now()}.jpg`);
          
          // Upload to storage
          const fileName = `${user.id}_${Date.now()}.jpg`;
          const { error: uploadError } = await supabase.storage
            .from('recipe-images')
            .upload(fileName, imageFile, {
              cacheControl: '3600',
              upsert: false
            });

          if (uploadError) {
            console.error('Upload error:', uploadError);
            // Continue without image - uploadedImageUrl remains null
          } else {
            const { data: { publicUrl } } = supabase.storage
              .from('recipe-images')
              .getPublicUrl(fileName);

            uploadedImageUrl = publicUrl;
          }
        } catch (error) {
          console.error('Image processing error:', error);
          // Continue without image - uploadedImageUrl remains null
        }
      }

      // Create dish (always 1 serving for individual meals)
      const { data: dish, error: dishError } = await supabase
        .from('dishes')
        .insert({
          name: mealName,
          description,
          meal_type: mealType,
          is_public: false,
          user_id: user.id
        })
        .select()
        .single();

      if (dishError) throw dishError;

      // Add ingredients to the dish - DIVIDE by servings to get per-portion amounts
      const ingredients = cookingItems.map(item => ({
        dish_id: dish.id,
        product_id: item.product.id,
        grams: item.grams / servings // Divide by total servings to get 1 portion
      }));

      const { error: ingredientsError } = await supabase
        .from('dish_ingredients')
        .insert(ingredients);

      if (ingredientsError) throw ingredientsError;

      return dish;
    },
    onSuccess: (data) => {
      toast({
        title: "Ястието е запазено!",
        description: "Ястието е създадено и може да го намерите в страницата Ястия.",
        variant: "success"
      });
      queryClient.invalidateQueries({ queryKey: ['user-meals'] });
      queryClient.invalidateQueries({ queryKey: ['today-meals-with-dishes'] });
      queryClient.invalidateQueries({ queryKey: ['recipes'] });
      queryClient.invalidateQueries({ queryKey: ['user-dishes'] });
      queryClient.invalidateQueries({ queryKey: ['user-counts'] });
      trackActivity('cooking', 'save_cooking_result', `Запази готвене като ястие: ${data.name}`, {
        dish_id: data.id,
        dish_name: data.name,
        meal_type: data.meal_type,
        servings: servings,
        products_count: cookingItems.length
      });
      onOpenChange(false);
      resetForm();
    },
    onError: (error) => {
      toast({
        title: "Грешка",
        description: error.message || "Неуспешно създаване на ястието.",
        variant: "destructive"
      });
      console.error('Save meal error:', error);
    }
  });

  const resetForm = () => {
    setMealType('lunch');
    setMealName('');
    setDescription('');
    setServings(1);
    setImageUrl('');
  };

  const handleImageCapture = async () => {
    try {
      const imageDataUrl = await takePicture({
        quality: 80,
        allowEditing: false
      });
      setImageUrl(imageDataUrl);
    } catch (error) {
      toast({
        title: "Грешка",
        description: "Неуспешно заснемане на снимка",
        variant: "destructive"
      });
    }
  };

  const handleImageSelect = async () => {
    try {
      const imageDataUrl = await selectFromGallery();
      setImageUrl(imageDataUrl);
    } catch (error) {
      toast({
        title: "Грешка", 
        description: "Неуспешно избиране на снимка",
        variant: "destructive"
      });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canAdd.dishes) {
      toast({
        title: "Достигнат лимит",
        description: "Достигнали сте лимита за ястия. Моля, премахнете някои от съществуващите ястия или преминете към Premium.",
        variant: "destructive"
      });
      return;
    }
    saveMealMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md h-[95vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle>Запази като ястие</DialogTitle>
          <DialogDescription>
            Създайте ястие от текущите продукти
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto">
          <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="meal-name">Име на ястието *</Label>
            <Input
              id="meal-name"
              value={mealName}
              onChange={(e) => setMealName(e.target.value)}
              placeholder="Например: Протеинова салата"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Описание (по желание)</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Кратко описание на ястието..."
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label>Снимка (по желание)</Label>
            <div className="flex gap-2 items-start">
              {imageUrl && (
                <div className="relative">
                  <img 
                    src={imageUrl} 
                    alt="Снимка на ястието" 
                    className="w-20 h-20 object-cover rounded-lg border"
                  />
                  <Button
                    type="button"
                    variant="destructive"
                    size="sm"
                    className="absolute -top-2 -right-2 h-6 w-6 rounded-full p-0"
                    onClick={() => setImageUrl('')}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              )}
              <div className="flex gap-2">
                <Button type="button" variant="outline" size="sm" onClick={handleImageCapture}>
                  <Camera className="h-4 w-4 mr-1" />
                  Камера
                </Button>
                <Button type="button" variant="outline" size="sm" onClick={handleImageSelect}>
                  <Image className="h-4 w-4 mr-1" />
                  Галерия
                </Button>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="servings">Общо порции в рецептата *</Label>
            <ServingsInput
              id="servings"
              value={servings}
              onChange={setServings}
              min={1}
              max={50}
            />
            <p className="text-xs text-muted-foreground">
              Например: ако готвите за 5 порции, въведете 5. Ястието ще се запази като 1 порция.
            </p>
          </div>

            <div className="space-y-2">
              <Label htmlFor="meal-type">Категория *</Label>
              <Select value={mealType} onValueChange={(value: any) => setMealType(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="breakfast">Закуска</SelectItem>
                  <SelectItem value="lunch">Обяд</SelectItem>
                  <SelectItem value="dinner">Вечеря</SelectItem>
                  <SelectItem value="snack">Междинно</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="bg-muted/50 p-3 rounded-lg space-y-3">
            <div>
              <h4 className="font-medium text-sm mb-2">Общо в рецептата ({servings} {servings === 1 ? 'порция' : 'порции'}):</h4>
              <div className="text-sm space-y-1">
                <div>Калории: {Math.round(totalNutrition.calories)} kcal</div>
                <div>Протеини: {totalNutrition.protein.toFixed(1)}г</div>
                <div>Въглехидрати: {totalNutrition.carbs.toFixed(1)}г</div>
                <div>Мазнини: {totalNutrition.fat.toFixed(1)}г</div>
              </div>
            </div>
            
            <div className="pt-3 border-t">
              <h4 className="font-medium text-sm mb-2 text-primary">На 1 порция ще има:</h4>
              <div className="text-sm space-y-1">
                <div>Калории: {Math.round(totalNutrition.calories / servings)} kcal</div>
                <div>Протеини: {(totalNutrition.protein / servings).toFixed(1)}г</div>
                <div>Въглехидрати: {(totalNutrition.carbs / servings).toFixed(1)}г</div>
                <div>Мазнини: {(totalNutrition.fat / servings).toFixed(1)}г</div>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Отказ
            </Button>
            <Button type="submit" disabled={saveMealMutation.isPending}>
              {saveMealMutation.isPending ? 'Запазва...' : 'Запази ястието'}
            </Button>
          </div>
        </form>
        </div>
      </DialogContent>
    </Dialog>
  );
};