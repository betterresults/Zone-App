import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { StableInput as Input } from '@/components/ui/stable-input';
import { NumericInput } from '@/components/ui/numeric-input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useUserLimits } from '@/hooks/useUserLimits';
import { useActivityTracker } from '@/hooks/useActivityTracker';

interface SaveProductDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  cookingItems: Array<{
    id: string;
    product: any;
    grams: number;
    portionName?: string;
  }>;
  totalNutrition: {
    protein: number;
    carbs: number;
    fat: number;
    fiber: number;
    calories: number;
  };
}

export const SaveProductDialog = ({ open, onOpenChange, cookingItems, totalNutrition }: SaveProductDialogProps) => {
  const [productName, setProductName] = useState('');
  const [brand, setBrand] = useState('');
  const [category, setCategory] = useState<'protein' | 'carbs' | 'fats' | 'vegetables' | 'fruits' | 'dairy' | 'grains' | 'legumes' | 'nuts' | 'spices' | 'other'>('other');
  const [totalWeight, setTotalWeight] = useState(100);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { canAdd } = useUserLimits();
  const { trackActivity } = useActivityTracker();

  const saveProductMutation = useMutation({
    mutationFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      if (totalWeight <= 0) {
        throw new Error('Общото тегло трябва да е положително число');
      }

      // Calculate per 100g values
      const per100g = {
        protein_per_100g: (totalNutrition.protein / totalWeight) * 100,
        carbs_per_100g: (totalNutrition.carbs / totalWeight) * 100,
        fat_per_100g: (totalNutrition.fat / totalWeight) * 100,
        fiber_per_100g: (totalNutrition.fiber / totalWeight) * 100,
        calories_per_100g: (totalNutrition.calories / totalWeight) * 100
      };

      const { data: product, error } = await supabase
        .from('products')
        .insert({
          name: productName,
          brand: brand || null,
          category,
          protein_per_100g: per100g.protein_per_100g,
          carbs_per_100g: per100g.carbs_per_100g,
          fat_per_100g: per100g.fat_per_100g,
          fiber_per_100g: per100g.fiber_per_100g,
          calories_per_100g: per100g.calories_per_100g,
          default_serving_grams: totalWeight,
          user_id: user.id,
          is_public: false
        })
        .select()
        .single();

      if (error) throw error;
      return product;
    },
    onSuccess: (data) => {
      toast({
        title: "Продуктът е запазен!",
        description: "Новият продукт е добавен в списъка ви."
      });
      queryClient.invalidateQueries({ queryKey: ['my-products-for-cooking'] });
      queryClient.invalidateQueries({ queryKey: ['products'] });
      queryClient.invalidateQueries({ queryKey: ['user-counts'] });
      trackActivity('cooking', 'save_cooking_result', `Запази готвене като продукт: ${data.name}`, {
        product_id: data.id,
        product_name: data.name,
        category: data.category,
        total_weight: totalWeight,
        calories_per_100g: data.calories_per_100g,
        products_count: cookingItems.length
      });
      onOpenChange(false);
      resetForm();
    },
    onError: (error) => {
      toast({
        title: "Грешка",
        description: error.message || "Неуспешно запазване на продукта.",
        variant: "destructive"
      });
      console.error('Save product error:', error);
    }
  });

  const resetForm = () => {
    setProductName('');
    setBrand('');
    setCategory('other');
    setTotalWeight(100);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!productName.trim()) {
      toast({
        title: "Грешка",
        description: "Моля въведете име на продукта.",
        variant: "destructive"
      });
      return;
    }
    
    if (!canAdd.products) {
      toast({
        title: "Достигнат лимит",
        description: "Достигнали сте лимита за продукти. Моля, премахнете някои от съществуващите продукти или преминете към Premium.",
        variant: "destructive"
      });
      return;
    }
    
    saveProductMutation.mutate();
  };

  // Calculate per 100g preview
  const per100gPreview = totalWeight > 0 ? {
    protein: (totalNutrition.protein / totalWeight) * 100,
    carbs: (totalNutrition.carbs / totalWeight) * 100,
    fat: (totalNutrition.fat / totalWeight) * 100,
    fiber: (totalNutrition.fiber / totalWeight) * 100,
    calories: (totalNutrition.calories / totalWeight) * 100
  } : null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Запази като продукт</DialogTitle>
          <DialogDescription>
            Създайте нов продукт от текущите съставки
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="product-name">Име на продукта *</Label>
            <Input
              id="product-name"
              value={productName}
              onValueChange={(value) => setProductName(value)}
              placeholder="Например: Домашна протеинова смес"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="brand">Марка (по желание)</Label>
            <Input
              id="brand"
              value={brand}
              onValueChange={(value) => setBrand(value)}
              placeholder="Например: Домашно"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="category">Категория</Label>
              <Select value={category} onValueChange={(value: any) => setCategory(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="protein">Протеини</SelectItem>
                  <SelectItem value="carbs">Въглехидрати</SelectItem>
                  <SelectItem value="fats">Мазнини</SelectItem>
                  <SelectItem value="vegetables">Зеленчуци</SelectItem>
                  <SelectItem value="fruits">Плодове</SelectItem>
                  <SelectItem value="dairy">Млечни</SelectItem>
                  <SelectItem value="grains">Зърнени</SelectItem>
                  <SelectItem value="legumes">Бобови</SelectItem>
                  <SelectItem value="nuts">Ядки</SelectItem>
                  <SelectItem value="spices">Подправки</SelectItem>
                  <SelectItem value="other">Други</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="total-weight">Общо готово тегло (г) *</Label>
              <NumericInput
                id="total-weight"
                value={totalWeight}
                onValueChange={(n) => setTotalWeight(Math.max(1, Math.round(n)))}
                min={1}
                allowDecimal={false}
                required
              />
            </div>
          </div>

          <div className="bg-muted/50 p-3 rounded-lg">
            <h4 className="font-medium text-sm mb-2">Текущи стойности:</h4>
            <div className="text-sm space-y-1 mb-3">
              <div>Общо калории: {Math.round(totalNutrition.calories)} kcal</div>
              <div>Общо протеини: {totalNutrition.protein.toFixed(1)}g</div>
              <div>Общо въглехидрати: {totalNutrition.carbs.toFixed(1)}g</div>
              <div>Общо мазнини: {totalNutrition.fat.toFixed(1)}g</div>
            </div>
            
            {per100gPreview && (
              <>
                <h4 className="font-medium text-sm mb-2">На 100г ще бъде:</h4>
                <div className="text-sm space-y-1">
                  <div>Калории: {Math.round(per100gPreview.calories)} kcal</div>
                  <div>Протеини: {per100gPreview.protein.toFixed(1)}g</div>
                  <div>Въглехидрати: {per100gPreview.carbs.toFixed(1)}g</div>
                  <div>Мазнини: {per100gPreview.fat.toFixed(1)}g</div>
                </div>
              </>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Отказ
            </Button>
            <Button type="submit" disabled={saveProductMutation.isPending}>
              {saveProductMutation.isPending ? 'Запазва...' : 'Запази продукт'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};