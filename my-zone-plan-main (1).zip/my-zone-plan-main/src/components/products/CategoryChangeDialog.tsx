import { useEffect, useRef, useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Plus, Apple, Wheat, Beef, Milk, Carrot, Cherry, Nut, Droplets, Package, Check } from 'lucide-react';
import { IconPicker } from './IconPicker';

interface CategoryChangeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  product: any;
}

type CategoryValue = string;

const categories = [
  { value: 'fruits', label: 'Плодове', icon: Apple },
  { value: 'vegetables', label: 'Зеленчуци', icon: Carrot },
  { value: 'protein', label: 'Протеини', icon: Beef },
  { value: 'dairy', label: 'Млечни', icon: Milk },
  { value: 'grains', label: 'Зърнени', icon: Wheat },
  { value: 'legumes', label: 'Варива', icon: Cherry },
  { value: 'nuts', label: 'Ядки', icon: Nut },
  { value: 'fats', label: 'Мазнини', icon: Droplets },
  { value: 'other', label: 'Други', icon: Package }
];

export function CategoryChangeDialog({ open, onOpenChange, product }: CategoryChangeDialogProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>(product?.category || 'other');
  const [showAddNew, setShowAddNew] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [selectedIcon, setSelectedIcon] = useState('Package');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const wasCustomRef = useRef(false);
  const lastUpdateRef = useRef<any>(null);

  const updateInCache = (key: string, productId: string, patch: any) => {
    queryClient.setQueryData([key], (old: any) => {
      if (!old) return old;
      return old.map ? old.map((p: any) => (p.id === productId ? { ...p, ...patch } : p)) : old;
    });
  };

  const updateCategoryMutation = useMutation({
    mutationFn: async ({ productId, update }: { productId: string; update: any }) => {
      const { error } = await supabase
        .from('products')
        .update(update)
        .eq('id', productId);

      if (error) throw error;
    },
    onSuccess: () => {
      // Optimistically patch caches so UI updates without full refresh
      if (product?.id && lastUpdateRef.current) {
        updateInCache('my-products', product.id, lastUpdateRef.current);
        updateInCache('catalog-products', product.id, lastUpdateRef.current);
      }

      toast({
        title: "Категорията е променена",
        description: "Категорията на продукта е успешно обновена",
        duration: 2000,
      });

      onOpenChange(false);

      // Ensure background lists refetch in the background
      queryClient.invalidateQueries({ queryKey: ['my-products'] });
      queryClient.invalidateQueries({ queryKey: ['catalog-products'] });
    },
    onError: () => {
      toast({
        title: "Грешка",
        description: "Възникна грешка при промяната на категорията",
        variant: "destructive",
      });
    }
  });

  const handleSave = () => {
    if (!product?.id) return;

    if (showAddNew && newCategoryName.trim()) {
      const custom = newCategoryName.trim();
      wasCustomRef.current = true;
      lastUpdateRef.current = { 
        custom_category: custom, 
        custom_icon: selectedIcon 
      };
      setSelectedCategory('custom'); // Update to show the new custom category as selected
      updateCategoryMutation.mutate({ 
        productId: product.id, 
        update: lastUpdateRef.current
      });
    } else if (selectedCategory === 'custom') {
      // User selected existing custom category, no change needed
      onOpenChange(false);
    } else if (selectedCategory !== product?.category) {
      wasCustomRef.current = false;
      lastUpdateRef.current = { category: selectedCategory, custom_category: null };
      updateCategoryMutation.mutate({ 
        productId: product.id, 
        update: lastUpdateRef.current
      });
    } else {
      onOpenChange(false);
    }
  };
  useEffect(() => {
    if (open) {
      // Set the correct initial category - prioritize custom_category if it exists
      const initialCategory = product?.custom_category ? 'custom' : (product?.category || 'other');
      setSelectedCategory(initialCategory);
      setShowAddNew(false);
      setNewCategoryName('');
      setSelectedIcon(product?.custom_icon || 'Package'); // Set the icon from the product
      wasCustomRef.current = false;
      lastUpdateRef.current = null;
    }
  }, [open, product?.id]);
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Промени категория</DialogTitle>
          <DialogDescription className="sr-only">Промяна на категорията или добавяне на нова за избрания продукт</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Продукт: {product?.name}</label>
            
            {!showAddNew ? (
              <div className="space-y-3">
                <div className="grid grid-cols-3 gap-2">
                  {/* Show standard categories */}
                  {categories.map((category) => {
                    const Icon = category.icon;
                    const isSelected = selectedCategory === category.value;
                    return (
                      <Button
                        key={category.value}
                        variant={isSelected ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedCategory(category.value)}
                        className={`flex flex-col items-center gap-1 h-auto py-3 relative ${
                          isSelected ? 'ring-2 ring-primary' : ''
                        }`}
                      >
                        <Icon className="w-5 h-5" />
                        <span className="text-xs text-center leading-tight">{category.label}</span>
                        {isSelected && <Check className="w-3 h-3 absolute top-1 right-1" />}
                      </Button>
                    );
                  })}
                  
                  {/* Show custom category if exists */}
                  {product?.custom_category && (
                    <Button
                      variant={selectedCategory === 'custom' ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedCategory('custom')}
                      className={`flex flex-col items-center gap-1 h-auto py-3 relative ${
                        selectedCategory === 'custom' ? 'ring-2 ring-primary' : ''
                      }`}
                    >
                      {(() => {
                        // Get the custom icon from lucide-react
                        try {
                          const iconName = product.custom_icon || 'Package';
                          // Import the icon dynamically based on the name
                          const iconMap: Record<string, any> = {
                            Package, Apple, Wheat, Beef, Milk, Carrot, Cherry, Nut, Droplets
                          };
                          const IconComponent = iconMap[iconName] || Package;
                          return <IconComponent className="w-5 h-5" />;
                        } catch {
                          return <Package className="w-5 h-5" />;
                        }
                      })()}
                      <span className="text-xs text-center leading-tight">{product.custom_category}</span>
                      {selectedCategory === 'custom' && <Check className="w-3 h-3 absolute top-1 right-1" />}
                    </Button>
                  )}
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => setShowAddNew(true)}
                  className="w-full"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Добави нова категория
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                <Input
                  placeholder="Име на новата категория"
                  value={newCategoryName}
                  onChange={(e) => setNewCategoryName(e.target.value)}
                />
                <div className="space-y-2">
                  <label className="text-sm font-medium">Избери икона:</label>
                  <IconPicker
                    selectedIcon={selectedIcon}
                    onSelect={setSelectedIcon}
                  />
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => {
                    setShowAddNew(false);
                    setNewCategoryName('');
                    setSelectedIcon('Package');
                  }}
                  className="w-full"
                >
                  Отказ
                </Button>
              </div>
            )}
          </div>
          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Отказ
            </Button>
            <Button 
              onClick={handleSave}
              disabled={updateCategoryMutation.isPending || (showAddNew && !newCategoryName.trim())}
            >
              {updateCategoryMutation.isPending ? 'Запазва...' : 'Запази'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}