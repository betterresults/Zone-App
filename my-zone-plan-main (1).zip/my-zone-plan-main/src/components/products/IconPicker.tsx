import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Apple, Carrot, Beef, Milk, Wheat, Cherry, Nut, Droplets, Package, 
  Coffee, Fish, Egg, Pizza, Candy, Cookie, IceCream, 
  Zap, Heart, Star, Sun, Moon, Leaf, Flower, TreePine,
  ShoppingCart, Gift, Camera, Phone, Car, Home, Book, Music
} from 'lucide-react';

interface IconPickerProps {
  selectedIcon?: string;
  onSelect: (iconName: string) => void;
}

const availableIcons = [
  // Food icons
  { name: 'Apple', component: Apple, category: 'food' },
  { name: 'Carrot', component: Carrot, category: 'food' },
  { name: 'Beef', component: Beef, category: 'food' },
  { name: 'Milk', component: Milk, category: 'food' },
  { name: 'Wheat', component: Wheat, category: 'food' },
  { name: 'Cherry', component: Cherry, category: 'food' },
  { name: 'Nut', component: Nut, category: 'food' },
  { name: 'Coffee', component: Coffee, category: 'food' },
  { name: 'Fish', component: Fish, category: 'food' },
  { name: 'Egg', component: Egg, category: 'food' },
  { name: 'Pizza', component: Pizza, category: 'food' },
  { name: 'Candy', component: Candy, category: 'food' },
  { name: 'Cookie', component: Cookie, category: 'food' },
  { name: 'IceCream', component: IceCream, category: 'food' },
  
  // Nature icons
  { name: 'Leaf', component: Leaf, category: 'nature' },
  { name: 'Flower', component: Flower, category: 'nature' },
  { name: 'TreePine', component: TreePine, category: 'nature' },
  { name: 'Sun', component: Sun, category: 'nature' },
  { name: 'Moon', component: Moon, category: 'nature' },
  
  // General icons
  { name: 'Package', component: Package, category: 'general' },
  { name: 'Droplets', component: Droplets, category: 'general' },
  { name: 'Zap', component: Zap, category: 'general' },
  { name: 'Heart', component: Heart, category: 'general' },
  { name: 'Star', component: Star, category: 'general' },
  { name: 'ShoppingCart', component: ShoppingCart, category: 'general' },
  { name: 'Gift', component: Gift, category: 'general' },
  { name: 'Camera', component: Camera, category: 'general' },
  { name: 'Phone', component: Phone, category: 'general' },
  { name: 'Car', component: Car, category: 'general' },
  { name: 'Home', component: Home, category: 'general' },
  { name: 'Book', component: Book, category: 'general' },
  { name: 'Music', component: Music, category: 'general' },
];

export function IconPicker({ selectedIcon, onSelect }: IconPickerProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredIcons, setFilteredIcons] = useState(availableIcons);

  useEffect(() => {
    if (searchTerm) {
      const filtered = availableIcons.filter(icon => 
        icon.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        icon.category.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredIcons(filtered);
    } else {
      setFilteredIcons(availableIcons);
    }
  }, [searchTerm]);

  return (
    <div className="space-y-3">
      <Input
        placeholder="Търси икона..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />
      <div className="grid grid-cols-6 gap-2 max-h-48 overflow-y-auto">
        {filteredIcons.map((icon) => {
          const Icon = icon.component;
          const isSelected = selectedIcon === icon.name;
          return (
            <Button
              key={icon.name}
              variant={isSelected ? "default" : "outline"}
              size="sm"
              onClick={() => onSelect(icon.name)}
              className={`p-2 h-auto ${isSelected ? 'ring-2 ring-primary' : ''}`}
              title={icon.name}
            >
              <Icon className="w-4 h-4" />
            </Button>
          );
        })}
      </div>
    </div>
  );
}