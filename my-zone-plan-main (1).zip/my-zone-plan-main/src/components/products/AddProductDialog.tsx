import { useState, useRef, useCallback, useMemo, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { StableInput as Input } from '@/components/ui/stable-input';
import { NumericInput } from "@/components/ui/numeric-input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useSubscription } from '@/hooks/useSubscription';
import { useUserLimits } from '@/hooks/useUserLimits';
import { Loader2, Plus, X, Search, Package2, Camera, Upload, QrCode, Scan, Heart, PlusCircle, ArrowLeft, Scale, Milk, Droplets, Zap, Package, Apple, Carrot, Beef, Wheat, Coffee, Nut, Utensils, ChefHat } from "lucide-react";
import { useCamera } from "@/hooks/useCamera";
import { useBarcodeScanner } from "@/hooks/useBarcodeScanner";
import { ProFeatureGuard } from '@/components/subscription/ProFeatureGuard';
import { useOCR } from "@/hooks/useOCR";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useDebounce } from 'use-debounce';
import { useActivityTracker } from '@/hooks/useActivityTracker';

interface AddProductDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editProduct?: any; // Add edit product prop
}

interface ProductFormData {
  name: string;
  brand: string;
  category: 'fruits' | 'vegetables' | 'protein' | 'dairy' | 'grains' | 'legumes' | 'nuts' | 'fats' | 'other';
  calories_per_100g: number;
  protein_per_100g: number;
  carbs_per_100g: number;
  fat_per_100g: number;
  fiber_per_100g: number;
  default_serving_grams?: number;
  package_size_grams?: number;
  package_size_unit?: string;
  package_unit_type?: string;
  barcode: string;
}

const suggestedPortions = [
  'Стандартна порция',
  'Малка порция', 
  'Голяма порция',
  'Едно парче',
  'Една чаша',
  'Една супена лъжица',
  'Една чайна лъжичка',
  'Половин чаша',
  'Четвърт чаша'
];

const categories = [
  { value: 'fruits', label: 'Плодове', icon: Apple },
  { value: 'vegetables', label: 'Зеленчуци', icon: Carrot },
  { value: 'protein', label: 'Протеини', icon: Beef },
  { value: 'dairy', label: 'Млечни', icon: Milk },
  { value: 'grains', label: 'Зърнени', icon: Wheat },
  { value: 'legumes', label: 'Варива', icon: Coffee },
  { value: 'nuts', label: 'Ядки', icon: Nut },
  { value: 'fats', label: 'Мазнини', icon: Droplets },
  { value: 'other', label: 'Други', icon: ChefHat }
];

// Auto-categorization keywords
const categoryKeywords = {
  fruits: ['ябълка', 'банан', 'портокал', 'грозде', 'круша', 'праскова', 'кайсия', 'сливa', 'череша', 'вишна', 'мандарина', 'лимон', 'киви', 'ананас', 'манго', 'авокадо', 'ягода', 'малина', 'боровинка'],
  vegetables: ['домат', 'краставица', 'салата', 'спанак', 'моркови', 'лук', 'чесън', 'картоф', 'тиква', 'тиквичка', 'патладжан', 'чушка', 'броколи', 'карфиол', 'зеле', 'ряпа'],
  protein: ['пиле', 'свинско', 'говеждо', 'риба', 'яйца', 'бекон', 'шунка', 'наденица', 'кайма', 'пилешко', 'месо', 'файле', 'котлет'],
  dairy: ['мляко', 'кисело мляко', 'йогурт', 'сирене', 'кашкавал', 'масло', 'краве мляко', 'козе мляко', 'овче мляко', 'айран', 'сметана'],
  grains: ['хляб', 'ориз', 'макарони', 'спагети', 'овес', 'елда', 'киноа', 'просо', 'булгур', 'гриз', 'царевица', 'фузили'],
  legumes: ['боб', 'леща', 'нахут', 'грах', 'соя', 'фасул'],
  nuts: ['орехи', 'бадеми', 'лешници', 'фъстъци', 'кашу', 'семки', 'тахан'],
  fats: ['зехтин', 'олио', 'маргарин', 'смалец', 'кокосово масло']
};

export const AddProductDialog = ({ open, onOpenChange, editProduct }: AddProductDialogProps) => {
  const { isPro } = useSubscription();
  const { canAdd, remaining, limits, counts } = useUserLimits();
  const [activeTab, setActiveTab] = useState('create');
  const [createMode, setCreateMode] = useState<'select' | 'barcode' | 'label' | 'manual'>('select');
  const [searchQuery, setSearchQuery] = useState('');
  const [debouncedSearchQuery] = useDebounce(searchQuery, 300);
  const [showManualBarcodeInput, setShowManualBarcodeInput] = useState(false);
  const [manualBarcode, setManualBarcode] = useState('');
  const [isSearchingBarcode, setIsSearchingBarcode] = useState(false);
  const [formData, setFormData] = useState<ProductFormData>({
    name: '',
    brand: '',
    category: 'other' as const,
    calories_per_100g: 0,
    protein_per_100g: 0,
    carbs_per_100g: 0,
    fiber_per_100g: 0,
    fat_per_100g: 0,
    default_serving_grams: 100,
    package_size_grams: 1000,
    package_size_unit: 'г',
    package_unit_type: 'пакет',
    barcode: ''
  });
  const [customPortions, setCustomPortions] = useState<Array<{name: string, grams: number}>>([]);
  const [showUnitPopup, setShowUnitPopup] = useState(false);
  const [showCategoryPopup, setShowCategoryPopup] = useState(false);
  const [unitField, setUnitField] = useState<'size_unit' | 'unit_type' | null>(null);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [productImage, setProductImage] = useState<File | null>(null);
  const [productImagePreview, setProductImagePreview] = useState<string | null>(null);
  const [isProcessingImage, setIsProcessingImage] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const scrollPosRef = useRef(0);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { takePicture, selectFromGallery } = useCamera();
  const { scanBarcode, fetchProductFromBarcode } = useBarcodeScanner();
  const { extractNutritionFromImage } = useOCR();
  const { trackActivity } = useActivityTracker();

  // Fetch current user's products to exclude from public search
  const { data: myProducts = [] } = useQuery({
    queryKey: ['my-products'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];
      
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('user_id', user.id);
      
      if (error) throw error;
      return data || [];
    }
  });

  // Fetch public products (excluding ones the user already has)
  const { data: publicProducts = [], isLoading: isLoadingPublic } = useQuery({
    queryKey: ['public-products', debouncedSearchQuery, myProducts],
    queryFn: async () => {
      // Create more precise identifiers for user's products
      const myProductIdentifiers = myProducts.map(p => ({
        name: p.name.toLowerCase().trim(),
        brand: (p.brand || '').toLowerCase().trim(),
        barcode: p.barcode || null
      }));
      
      let query = supabase
        .from('products')
        .select('*')
        .eq('is_public', true)
        .limit(50);

      if (debouncedSearchQuery.trim()) {
        query = query.ilike('name', `%${debouncedSearchQuery.trim()}%`);
      }

      const { data, error } = await query;
      if (error) throw error;

      // Filter out products the user already has (more precise matching)
      return (data || []).filter(product => {
        const productName = product.name.toLowerCase().trim();
        const productBrand = (product.brand || '').toLowerCase().trim();
        const productBarcode = product.barcode || null;
        
        // Check if user already has this product
        return !myProductIdentifiers.some(userProduct => {
          // Match by barcode if both have it
          if (productBarcode && userProduct.barcode && productBarcode === userProduct.barcode) {
            return true;
          }
          
          // Match by name and brand
          if (productName === userProduct.name) {
            // If both have brands, they must match
            if (productBrand && userProduct.brand) {
              return productBrand === userProduct.brand;
            }
            // If one has brand and other doesn't, consider different products
            if (productBrand !== userProduct.brand) {
              return false;
            }
            // Both have no brand, match by name only
            return true;
          }
          
          return false;
        });
      });
    },
    enabled: !!myProducts
  });

  const copyProductMutation = useMutation({
    mutationFn: async (product: any) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Не сте влезли в системата');

      // Explicitly create the insert data without id to ensure UUID generation works
      const productInsertData = {
        name: product.name,
        brand: product.brand || null,
        category: product.category,
        calories_per_100g: product.calories_per_100g,
        protein_per_100g: product.protein_per_100g,
        carbs_per_100g: product.carbs_per_100g,
        fat_per_100g: product.fat_per_100g,
        fiber_per_100g: product.fiber_per_100g,
        default_serving_grams: product.default_serving_grams || 100,
        barcode: product.barcode || null,
        user_id: user.id,
        is_public: false,
        image_url: product.image_url || null
      };

      const { data, error } = await supabase
        .from('products')
        .insert([productInsertData])
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['products'] });
      queryClient.invalidateQueries({ queryKey: ['my-products'] });
      queryClient.invalidateQueries({ queryKey: ['my-products-for-cooking'] });
      queryClient.invalidateQueries({ queryKey: ['public-products'] });
      toast({
        title: "Продуктът е запазен!",
        description: "Продуктът беше добавен в списъка ви.",
      });
      trackActivity('products', 'add_product', `Копира публичен продукт: ${data.name}`, {
        product_id: data.id,
        product_name: data.name,
        category: data.category
      });
      onOpenChange(false);
    },
    onError: (error: any) => {
      toast({
        title: "Грешка",
        description: error.message || "Възникна грешка при запазването на продукта",
        variant: "destructive",
      });
    },
  });

  const handleProductImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setProductImage(file);
      const reader = new FileReader();
      reader.onload = (e) => setProductImagePreview(e.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const removeProductImage = () => {
    setProductImage(null);
    setProductImagePreview(null);
  };

  const uploadImage = async (file: File, productId: string): Promise<string | null> => {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${productId}.${fileExt}`;
      const filePath = `${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('product-images')
        .upload(filePath, file, {
          upsert: true
        });

      if (uploadError) {
        console.error('Upload error:', uploadError);
        return null;
      }

      const { data: { publicUrl } } = supabase.storage
        .from('product-images')
        .getPublicUrl(filePath);

      return publicUrl;
    } catch (error) {
      console.error('Error uploading image:', error);
      return null;
    }
  };

  const addProductMutation = useMutation({
    mutationFn: async (productData: ProductFormData & { image?: File | null, productImage?: File | null, portions?: Array<{name: string, grams: number}> }) => {
      // Check if user can add more products
      if (!canAdd.products) {
        throw new Error(`Достигнахте лимита от ${limits.products} продукта. ${!isPro ? 'Надстройте до Премиум за неограничен достъп или изтрийте някои от съществуващите продукти.' : ''}`);
      }

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Не сте влезли в системата');

      // Exclude image files and id from the product data since they will be handled separately
      const { image, productImage, portions, ...rest } = productData;
      
      // Explicitly create the insert data without id to ensure UUID generation works
      const productInsertData = {
        name: rest.name,
        brand: rest.brand || null,
        category: rest.category,
        calories_per_100g: rest.calories_per_100g,
        protein_per_100g: rest.protein_per_100g,
        carbs_per_100g: rest.carbs_per_100g,
        fat_per_100g: rest.fat_per_100g,
        fiber_per_100g: rest.fiber_per_100g,
        default_serving_grams: rest.default_serving_grams || 100,
        package_size_grams: rest.package_size_grams || null,
        package_size_unit: rest.package_size_unit || 'г',
        package_unit_type: rest.package_unit_type || 'пакет',
        barcode: rest.barcode || null,
        user_id: user.id,
        is_public: false
      };

      const { data: product, error } = await supabase
        .from('products')
        .insert([productInsertData])
        .select()
        .single();

      if (error) throw error;

      let imageUrl = null;
      // Use product image as main image if available, otherwise use scanned image
      const mainImage = productImage || image;
      if (mainImage) {
        imageUrl = await uploadImage(mainImage, product.id);
        if (imageUrl) {
          const { error: updateError } = await supabase
            .from('products')
            .update({ image_url: imageUrl })
            .eq('id', product.id);
          
          if (updateError) console.error('Error updating image URL:', updateError);
        }
      }

      // Save custom portions
      if (portions && portions.length > 0) {
        const portionData = portions.map(portion => ({
          product_id: product.id,
          user_id: user.id,
          portion_name: portion.name,
          grams: portion.grams
        }));

        const { error: portionsError } = await supabase
          .from('favorite_portions')
          .insert(portionData);

        if (portionsError) console.error('Error saving portions:', portionsError);
      }

      return { ...product, image_url: imageUrl };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['products'] });
      queryClient.invalidateQueries({ queryKey: ['my-products'] });
      queryClient.invalidateQueries({ queryKey: ['my-products-for-cooking'] });
      queryClient.invalidateQueries({ queryKey: ['public-products'] });
      queryClient.invalidateQueries({ queryKey: ['user-counts'] }); // Invalidate user counts
      toast({
        title: "Продуктът е създаден!",
        description: "Новият продукт беше добавен успешно.",
      });
      trackActivity('products', 'add_product', `Създаде нов продукт: ${data.name}`, {
        product_id: data.id,
        product_name: data.name,
        category: data.category,
        calories_per_100g: data.calories_per_100g,
        protein_per_100g: data.protein_per_100g
      });
      resetForm();
      onOpenChange(false);
    },
    onError: (error: any) => {
      toast({
        title: "Грешка",
        description: error.message || "Възникна грешка при създаването на продукта",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setFormData({
      name: '',
      brand: '',
      category: 'other' as const,
      calories_per_100g: 0,
      protein_per_100g: 0,
      carbs_per_100g: 0,
      fiber_per_100g: 0,
      fat_per_100g: 0,
      default_serving_grams: 100,
      package_size_grams: 1000,
      package_size_unit: 'г',
      package_unit_type: 'пакет',
      barcode: ''
    });
    setCustomPortions([]);
    setShowUnitPopup(false);
    setUnitField(null);
    setSelectedImage(null);
    setImagePreview(null);
    setProductImage(null);
    setProductImagePreview(null);
    setSearchQuery('');
    setActiveTab('create');
    setCreateMode('select');
    setManualBarcode('');
    setIsSearchingBarcode(false);
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setSelectedImage(null);
    setImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleTakePhoto = async () => {
    try {
      setIsProcessingImage(true);
      const imageDataUrl = await takePicture();
      if (imageDataUrl) {
        const response = await fetch(imageDataUrl);
        const blob = await response.blob();
        const file = new File([blob], 'photo.jpg', { type: 'image/jpeg' });
        setSelectedImage(file);
        setImagePreview(imageDataUrl);
        toast({ title: "Снимката е получена", description: "Можете да продължите.", duration: 2500 });
      }
    } catch (error: any) {
      console.error('Error taking photo:', error);
      const msg = String(error?.message || '');
      if (msg !== 'USER_CANCELLED') {
        toast({
          title: "Грешка", 
          description: "Грешка при снимане",
          variant: "destructive",
        });
      }
    } finally {
      setIsProcessingImage(false);
    }
  };

  const handleSelectFromGallery = async () => {
    try {
      const imageDataUrl = await selectFromGallery();
      if (imageDataUrl) {
        const response = await fetch(imageDataUrl);
        const blob = await response.blob();
        const file = new File([blob], 'gallery-image.jpg', { type: 'image/jpeg' });
        setSelectedImage(file);
        setImagePreview(imageDataUrl);
      }
    } catch (error) {
      console.error('Error selecting from gallery:', error);
      toast({
        title: "Грешка", 
        description: "Грешка при избор на снимка",
        variant: "destructive",
      });
    }
  };

  const handleScanBarcode = async () => {
    try {
      setIsProcessingImage(true);
      toast({ title: "Отварям камерата…", description: "Снимайте баркода отблизо и ясно." });
      const imageDataUrl = await takePicture();
      if (imageDataUrl) {
        console.log('[Barcode] Captured image length:', imageDataUrl.length);
        // Show what was captured so the user knows it worked
        setImagePreview(imageDataUrl);
        // Ensure we're in the barcode flow UI
        setCreateMode('barcode');

        const barcode = await scanBarcode(imageDataUrl);
        if (barcode) {
          toast({
            title: "Баркод намерен!",
            description: "Търся продукт...",
          });
          const productData = await fetchProductFromBarcode(barcode);
          if (productData) {
            setFormData(prev => ({
              ...prev,
              ...productData,
              barcode,
            }));
            
            if (productData.image_url) {
              try {
                const response = await fetch(productData.image_url);
                const blob = await response.blob();
                const file = new File([blob], 'product.jpg', { type: 'image/jpeg' });
                setSelectedImage(file);
                setImagePreview(productData.image_url);
              } catch (error) {
                console.error('Error downloading product image:', error);
              }
            }
            
            // Switch to manual mode to show the filled form
            setCreateMode('manual');
            
            toast({
              title: "Продуктът е намерен!",
              description: "Формата е попълнена с данни от баркода",
            });
          } else {
            // No product in public DB – still let the user proceed with the barcode
            setFormData(prev => ({ ...prev, barcode }));
            setCreateMode('manual');
            toast({
              title: "Продуктът не е открит в каталога",
              description: "Попълнете данните ръчно. Баркодът е добавен във формата.",
            });
          }
        } else {
          // No barcode detected in the photo – stay in barcode UI and allow manual entry
          setShowManualBarcodeInput(true);
          toast({
            title: "Баркод не е намерен",
            description: "Можете да въведете баркода ръчно отдолу или опитайте нова снимка.",
            duration: 4000,
            className: "border-orange-500 bg-orange-50 text-orange-900",
          });
        }
      } else {
        toast({ title: "Няма избрана снимка", description: "Моля, опитайте отново.", duration: 3000 });
      }
    } catch (error: any) {
      console.error('Error scanning barcode:', error);
      const msg = String(error?.message || '');
      if (msg !== 'USER_CANCELLED') {
        toast({
          title: "Грешка",
          description: "Грешка при сканиране на баркод",
          variant: "destructive",
        });
      }
    } finally {
      setIsProcessingImage(false);
      console.log('[Barcode] Finished flow');
    }
  };

  const handleManualBarcodeSearch = async () => {
    if (!manualBarcode.trim()) {
      toast({
        title: "Грешка",
        description: "Моля въведете баркод",
        variant: "destructive",
      });
      return;
      } else {
        toast({ title: "Няма избрана снимка", description: "Моля, опитайте отново.", duration: 3000 });
      }
    try {
      setIsSearchingBarcode(true);
      toast({
        title: "Търся продукт...",
        description: "Моля изчакайте",
      });
      
      const productData = await fetchProductFromBarcode(manualBarcode.trim());
      if (productData) {
        setFormData(prev => ({
          ...prev,
          ...productData,
          barcode: manualBarcode.trim(),
        }));
        
        if (productData.image_url) {
          try {
            const response = await fetch(productData.image_url);
            const blob = await response.blob();
            const file = new File([blob], 'product.jpg', { type: 'image/jpeg' });
            setSelectedImage(file);
            setImagePreview(productData.image_url);
          } catch (error) {
            console.error('Error downloading product image:', error);
          }
        }
        
        // Switch to manual mode to show the filled form
        setCreateMode('manual');
        setShowManualBarcodeInput(false);
        setManualBarcode('');
        
        toast({
          title: "Продукт намерен!",
          description: "Данните са попълнени автоматично",
        });
      } else {
        toast({
          title: "Продукт не е намерен",
          description: "Не е намерен продукт с този баркод. Можете да създадете продукта ръчно.",
          duration: 4000,
          className: "border-orange-500 bg-orange-50 text-orange-900",
        });
      }
    } catch (error) {
      console.error('Error searching manual barcode:', error);
      toast({
        title: "Грешка",
        description: "Грешка при търсене на продукт",
        variant: "destructive",
      });
    } finally {
      setIsSearchingBarcode(false);
    }
  };

  const handleScanNutrition = async () => {
    let toastId: any = null;
    
    try {
      setIsProcessingImage(true);
      
      toastId = toast({
        title: "Обработвам снимката...",
        description: "Моля изчакайте, докато извлека информацията от етикета.",
      });

      const imageDataUrl = await takePicture();
      if (imageDataUrl) {
        const nutritionData = await extractNutritionFromImage(imageDataUrl);
        
        if (nutritionData && (nutritionData.name || nutritionData.calories_per_100g > 0)) {
          setFormData(prev => ({
            ...prev,
            name: nutritionData.name || prev.name,
            calories_per_100g: nutritionData.calories_per_100g || prev.calories_per_100g,
            protein_per_100g: nutritionData.protein_per_100g || prev.protein_per_100g,
            carbs_per_100g: nutritionData.carbs_per_100g || prev.carbs_per_100g,
            fat_per_100g: nutritionData.fat_per_100g || prev.fat_per_100g,
            fiber_per_100g: nutritionData.fiber_per_100g || prev.fiber_per_100g,
          }));
          
          // Store the scanned image
          const response = await fetch(imageDataUrl);
          const blob = await response.blob();
          const file = new File([blob], 'scanned-label.jpg', { type: 'image/jpeg' });
          setSelectedImage(file);
          setImagePreview(imageDataUrl);
          
          toast({
            title: "Информацията е извлечена!",
            description: "Проверете и допълнете данните според нуждата.",
          });
        } else {
          toast({
            title: "Не успях да извлека информация",
            description: "Опитайте отново с по-ясна снимка на етикета.",
            variant: "destructive",
          });
        }
      }
    } catch (error: any) {
      console.error('Error scanning nutrition:', error);
      const msg = String(error?.message || '');
      if (msg !== 'USER_CANCELLED') {
        toast({
          title: "Грешка",
          description: "Грешка при сканиране на етикета",
          variant: "destructive",
        });
      }
    } finally {
      setIsProcessingImage(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      toast({
        title: "Грешка",
        description: "Името на продукта е задължително",
        variant: "destructive",
      });
      return;
    }
    
    addProductMutation.mutate({
      ...formData,
      image: selectedImage,
      productImage: productImage,
      portions: createMode !== 'manual' ? customPortions : undefined
    });
  };

  const addPortion = () => {
    setCustomPortions([...customPortions, { name: '', grams: 100 }]);
    // Keep scroll position by scrolling to the new portion after it's rendered
    setTimeout(() => {
      const portionElements = document.querySelectorAll('[data-portion-item]');
      const lastPortion = portionElements[portionElements.length - 1];
      if (lastPortion) {
        lastPortion.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 100);
  };

  // Auto-categorize product based on name
  const autoCategorize = useCallback((productName: string) => {
    const name = productName.toLowerCase();
    for (const [category, keywords] of Object.entries(categoryKeywords)) {
      if (keywords.some(keyword => name.includes(keyword))) {
        return category as typeof formData.category;
      }
    }
    return 'other' as const;
  }, []);

  const handleFormDataChange = useCallback((field: keyof ProductFormData, value: any) => {
    setFormData(prev => {
      const newData = { ...prev, [field]: value };
      // Auto-categorize when name changes
      if (field === 'name' && value && prev.category === 'other') {
        newData.category = autoCategorize(value);
      }
      return newData;
    });
  }, [autoCategorize]);

  const handlePortionChange = useCallback((index: number, field: 'name' | 'grams', value: string | number) => {
    setCustomPortions(prev => {
      const newPortions = [...prev];
      newPortions[index] = { ...newPortions[index], [field]: value };
      return newPortions;
    });
  }, []);

  const updatePortion = useCallback((index: number, field: 'name' | 'grams', value: string | number) => {
    handlePortionChange(index, field, value);
  }, [handlePortionChange]);

  const removePortion = (index: number) => {
    if (customPortions.length > 1) {
      setCustomPortions(customPortions.filter((_, i) => i !== index));
    }
  };

  // Initialize form data when editing
  useEffect(() => {
    if (editProduct && open) {
      setFormData({
        name: editProduct.name || '',
        brand: editProduct.brand || '',
        category: editProduct.category || 'other',
        calories_per_100g: editProduct.calories_per_100g || 0,
        protein_per_100g: editProduct.protein_per_100g || 0,
        carbs_per_100g: editProduct.carbs_per_100g || 0,
        fat_per_100g: editProduct.fat_per_100g || 0,
        fiber_per_100g: editProduct.fiber_per_100g || 0,
        default_serving_grams: editProduct.default_serving_grams || 100,
        package_size_grams: editProduct.package_size_grams || 1000,
        package_size_unit: editProduct.package_size_unit || 'г',
        package_unit_type: editProduct.package_unit_type || 'пакет',
        barcode: editProduct.barcode || ''
      });
      setProductImagePreview(editProduct.image_url || null);
      setProductImage(null);
      setActiveTab('create');
      setCreateMode('manual');
    }
  }, [editProduct, open]);

  const unitOptions = {
    size_unit: [
      { value: 'г', label: 'грама', icon: Scale },
      { value: 'кг', label: 'килограма', icon: Package },
      { value: 'мл', label: 'милилитра', icon: Droplets },
      { value: 'л', label: 'литра', icon: Milk },
      { value: 'бр', label: 'броя', icon: Package2 }
    ],
    unit_type: [
      { value: 'пакет', label: 'пакет', icon: Package },
      { value: 'брой', label: 'брой', icon: Package2 },
      { value: 'литър', label: 'литър', icon: Milk },
      { value: 'бутилка', label: 'бутилка', icon: Droplets },
      { value: 'кутия', label: 'кутия', icon: Package },
      { value: 'консерва', label: 'консерва', icon: Zap },
      { value: 'килограм', label: 'килограм', icon: Scale }
    ]
  };

  const handleUnitSelect = (value: string) => {
    if (unitField === 'size_unit') {
      handleFormDataChange('package_size_unit', value);
    } else if (unitField === 'unit_type') {
      handleFormDataChange('package_unit_type', value);
    }
    setShowUnitPopup(false);
    setUnitField(null);
  };

  const FormFields = () => (
    <>
      {/* Image Upload Section */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Package2 className="w-5 h-5 text-primary" />
          <Label className="text-base font-medium">Снимка на продукта</Label>
        </div>
        <div className="flex flex-col gap-3">
          {(imagePreview || productImagePreview) ? (
            <div className="flex items-center gap-3 justify-center">
              <Card className="relative w-24 h-24 rounded-2xl overflow-hidden shadow-lg bg-gradient-to-br from-primary/5 to-primary/10">
                <CardContent className="p-0">
                  <img
                    src={productImagePreview || imagePreview}
                    alt="Preview"
                    className="w-full h-full object-cover"
                  />
                </CardContent>
              </Card>
              
              <div className="flex flex-col gap-2">
                <Button
                  type="button"
                  variant="destructive"
                  size="sm"
                  className="w-8 h-8 rounded-full p-0 shadow-lg bg-red-500 hover:bg-red-600 text-white"
                  onClick={() => {
                    removeImage();
                    removeProductImage();
                  }}
                >
                  <X className="w-4 h-4" />
                </Button>
                
                <div className="relative">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="w-8 h-8 rounded-full p-0 shadow-lg"
                    onClick={() => {
                      const menu = document.getElementById('add-image-menu');
                      if (menu) menu.classList.toggle('hidden');
                    }}
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                  
                  <div id="add-image-menu" className="hidden absolute top-full right-0 mt-2 bg-background border rounded-xl shadow-lg z-10 w-48">
                    <div className="p-3 space-y-2">
                      <Button
                        type="button"
                        variant="ghost"
                        onClick={async () => {
                          document.getElementById('add-image-menu')?.classList.add('hidden');
                          try {
                            if (createMode === 'manual') {
                              await handleTakePhoto();
                            } else {
                              const imageDataUrl = await takePicture();
                              if (imageDataUrl) {
                                const response = await fetch(imageDataUrl);
                                const blob = await response.blob();
                                const file = new File([blob], 'product.jpg', { type: 'image/jpeg' });
                                setProductImage(file);
                                setProductImagePreview(imageDataUrl);
                              }
                            }
                          } catch (error) {
                            console.error('Error taking photo:', error);
                          }
                        }}
                        disabled={isProcessingImage}
                        className="w-full justify-start"
                      >
                        {isProcessingImage ? (
                          <Loader2 className="h-4 w-4 animate-spin mr-2" />
                        ) : (
                          <Camera className="h-4 w-4 mr-2" />
                        )}
                        Снимай с камерата
                      </Button>
                      <Button
                        type="button"
                        variant="ghost"
                        onClick={async () => {
                          document.getElementById('add-image-menu')?.classList.add('hidden');
                          try {
                            if (createMode === 'manual') {
                              await handleSelectFromGallery();
                            } else {
                              const input = document.createElement('input');
                              input.type = 'file';
                              input.accept = 'image/*';
                              input.onchange = (e) => {
                                const file = (e.target as HTMLInputElement)?.files?.[0];
                                if (file) {
                                  setProductImage(file);
                                  const reader = new FileReader();
                                  reader.onload = (e) => setProductImagePreview(e.target?.result as string);
                                  reader.readAsDataURL(file);
                                }
                              };
                              input.click();
                            }
                          } catch (error) {
                            console.error('Error selecting from gallery:', error);
                          }
                        }}
                        className="w-full justify-start"
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        Избери от галерията
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="relative">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  const menu = document.getElementById('image-menu');
                  if (menu) menu.classList.toggle('hidden');
                }}
                className="w-full h-24 border-2 border-dashed border-primary/20 hover:border-primary/40 rounded-xl bg-gradient-to-br from-background to-muted/30 transition-all duration-200"
              >
                <div className="text-center space-y-2">
                  <Camera className="mx-auto h-8 w-8 text-primary/60" />
                  <span className="text-sm font-medium text-muted-foreground">Добави снимка</span>
                </div>
              </Button>
              <div id="image-menu" className="hidden absolute top-full left-0 right-0 mt-2 bg-background border rounded-xl shadow-lg z-10">
                <div className="p-3 space-y-2">
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={async () => {
                      document.getElementById('image-menu')?.classList.add('hidden');
                      if (createMode === 'manual') {
                        await handleTakePhoto();
                      } else {
                        try {
                          const imageDataUrl = await takePicture();
                          if (imageDataUrl) {
                            const response = await fetch(imageDataUrl);
                            const blob = await response.blob();
                            const file = new File([blob], 'product.jpg', { type: 'image/jpeg' });
                            setProductImage(file);
                            setProductImagePreview(imageDataUrl);
                          }
                        } catch (error) {
                          console.error('Error taking product photo:', error);
                        }
                      }
                    }}
                    disabled={isProcessingImage}
                    className="w-full justify-start"
                  >
                    {isProcessingImage ? (
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    ) : (
                      <Camera className="h-4 w-4 mr-2" />
                    )}
                    Снимай с камерата
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={async () => {
                      document.getElementById('image-menu')?.classList.add('hidden');
                      if (createMode === 'manual') {
                        await handleSelectFromGallery();
                      } else {
                        const input = document.createElement('input');
                        input.type = 'file';
                        input.accept = 'image/*';
                        input.onchange = (e) => {
                          const file = (e.target as HTMLInputElement)?.files?.[0];
                          if (file) {
                            setProductImage(file);
                            const reader = new FileReader();
                            reader.onload = (e) => setProductImagePreview(e.target?.result as string);
                            reader.readAsDataURL(file);
                          }
                        };
                        input.click();
                      }
                    }}
                    className="w-full justify-start"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Избери от галерията
                  </Button>
                </div>
              </div>
            </div>
          )}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageSelect}
            className="hidden"
          />
        </div>
      </div>

      {/* Show scanned label preview for barcode/label modes */}
      {(createMode === 'barcode' || createMode === 'label') && imagePreview && (
        <div className="space-y-3">
          <Label className="text-sm text-muted-foreground">Сканиран етикет</Label>
          <Card className="relative w-20 h-20 mx-auto rounded-xl overflow-hidden shadow-md bg-gradient-to-br from-muted/50 to-muted">
            <CardContent className="p-0">
              <img
                src={imagePreview}
                alt="Scanned"
                className="w-full h-full object-cover opacity-80"
              />
            </CardContent>
          </Card>
        </div>
      )}

      {/* Basic Information */}
      <div className="space-y-4 p-4 bg-gradient-to-br from-background to-muted/20 rounded-2xl border-2">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-sm font-medium">Име на продукта *</Label>
            <Input
              id="name"
              key="product-name-input"
              value={formData.name}
              onValueChange={(value) => handleFormDataChange('name', value)}
              placeholder="напр. Ябълка Гренни Смит"
              required
              className="h-10 rounded-lg"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="brand" className="text-sm font-medium">Марка</Label>
            <Input
              id="brand"
              key="product-brand-input"
              value={formData.brand}
              onValueChange={(value) => handleFormDataChange('brand', value)}
              placeholder="напр. Danone"
              className="h-10 rounded-lg"
            />
          </div>
        </div>
      </div>

      {/* Категория и Баркод */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-3 p-4 bg-gradient-to-br from-background to-muted/20 rounded-2xl border-2">
          <Label className="text-sm font-medium">Категория *</Label>
          <Button
            type="button"
            variant="outline"
            onClick={() => { scrollPosRef.current = scrollContainerRef.current?.scrollTop || 0; setShowCategoryPopup(true); }}
            className="h-10 rounded-lg justify-between w-full"
          >
            <span>{categories.find(c => c.value === formData.category)?.label || 'Други'}</span>
            <Package2 className="w-4 h-4 ml-2" />
          </Button>
        </div>

        <div className="space-y-3 p-4 bg-gradient-to-br from-background to-muted/20 rounded-2xl border-2">
          <Label htmlFor="barcode" className="text-sm font-medium">Баркод</Label>
          <Input
            id="barcode"
            value={formData.barcode}
            onValueChange={(value) => handleFormDataChange('barcode', value)}
            placeholder="Въведете баркод"
            className="h-10 rounded-lg"
          />
        </div>
      </div>

      {/* Nutritional Information */}
      <div className="space-y-3 p-4 bg-gradient-to-br from-background to-muted/20 rounded-2xl border-2">
        <Label className="text-sm font-medium">Хранителни стойности (на 100г)</Label>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <div className="relative">
            <label className="absolute -top-2 left-2 bg-background px-1 text-xs font-medium text-muted-foreground z-10">
              Калории
            </label>
            <NumericInput
              id="calories"
              value={formData.calories_per_100g}
              onValueChange={(n) => handleFormDataChange('calories_per_100g', n)}
              min={0}
              allowDecimal
              placeholder="0"
              className="h-10 rounded-lg pr-12"
            />
            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">kcal</span>
          </div>
          <div className="relative">
            <label className="absolute -top-2 left-2 bg-background px-1 text-xs font-medium text-muted-foreground z-10">
              Протеин
            </label>
            <NumericInput
              id="protein"
              value={formData.protein_per_100g}
              onValueChange={(n) => handleFormDataChange('protein_per_100g', n)}
              min={0}
              allowDecimal
              placeholder="0"
              className="h-10 rounded-lg pr-8"
            />
            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">г</span>
          </div>
          <div className="relative">
            <label className="absolute -top-2 left-2 bg-background px-1 text-xs font-medium text-muted-foreground z-10">
              Въглехидрати
            </label>
            <NumericInput
              id="carbs"
              value={formData.carbs_per_100g}
              onValueChange={(n) => handleFormDataChange('carbs_per_100g', n)}
              min={0}
              allowDecimal
              placeholder="0"
              className="h-10 rounded-lg pr-8"
            />
            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">г</span>
          </div>
          <div className="relative">
            <label className="absolute -top-2 left-2 bg-background px-1 text-xs font-medium text-muted-foreground z-10">
              Мазнини
            </label>
            <NumericInput
              id="fat"
              value={formData.fat_per_100g}
              onValueChange={(n) => handleFormDataChange('fat_per_100g', n)}
              min={0}
              allowDecimal
              placeholder="0"
              className="h-10 rounded-lg pr-8"
            />
            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">г</span>
          </div>
          <div className="relative">
            <label className="absolute -top-2 left-2 bg-background px-1 text-xs font-medium text-muted-foreground z-10">
              Фибри
            </label>
            <NumericInput
              id="fiber"
              value={formData.fiber_per_100g}
              onValueChange={(n) => handleFormDataChange('fiber_per_100g', n)}
              min={0}
              allowDecimal
              placeholder="0"
              className="h-10 rounded-lg pr-8"
            />
            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">г</span>
          </div>
        </div>
      </div>

      {/* Package Size */}
      <div className="space-y-3 p-4 bg-gradient-to-br from-background to-muted/20 rounded-2xl border-2">
        <div className="flex items-center justify-between">
          <Label className="text-sm font-medium">Размер на пакета</Label>
          <span className="text-xs text-muted-foreground">За пазаруване</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <NumericInput
              id="package-size"
              value={formData.package_size_grams || 1000}
              onValueChange={(n) => handleFormDataChange('package_size_grams', n)}
              min={1}
              allowDecimal
              placeholder="1000"
              className="h-10 rounded-lg"
            />
          </div>
          <div>
            <Button
              type="button"
              variant="outline"
              onClick={() => { scrollPosRef.current = scrollContainerRef.current?.scrollTop || 0; setUnitField('size_unit'); setShowUnitPopup(true); }}
              className="h-10 rounded-lg justify-between w-full"
            >
              {unitOptions.size_unit.find(u => u.value === formData.package_size_unit)?.label || 'Единица'}
              <Package className="w-4 h-4 ml-2" />
            </Button>
          </div>
          <div>
            <Button
              type="button"
              variant="outline"
              onClick={() => { scrollPosRef.current = scrollContainerRef.current?.scrollTop || 0; setUnitField('unit_type'); setShowUnitPopup(true); }}
              className="h-10 rounded-lg justify-between w-full"
            >
              {unitOptions.unit_type.find(u => u.value === formData.package_unit_type)?.label || 'Тип'}
              <Package2 className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
      </div>

      {/* Custom Portions - Only show for non-manual creation */}
      {createMode !== 'manual' && (
        <div className="space-y-3 p-4 bg-gradient-to-br from-background to-muted/20 rounded-2xl border-2">
          <Label className="text-sm font-medium">Потребителски порции</Label>
          
          <div className="grid grid-cols-4 md:grid-cols-7 gap-2">
            {[10, 20, 50, 75, 100, 200, 250].map((grams) => {
              const isSelected = customPortions.some(p => p.grams === grams);
              return (
                <Button
                  key={grams}
                  type="button"
                  variant={isSelected ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    const portionName = `${grams}г порция`;
                    if (isSelected) {
                      setCustomPortions(prev => prev.filter(p => p.grams !== grams));
                    } else {
                      setCustomPortions(prev => [...prev, { name: portionName, grams }]);
                    }
                  }}
                  className={`text-xs font-medium transition-all duration-200 rounded-lg h-8 ${
                    isSelected 
                      ? 'bg-primary text-primary-foreground shadow-md scale-105' 
                      : 'hover:bg-primary/10 hover:border-primary/30'
                  }`}
                >
                  {grams}г
                </Button>
              );
            })}
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={addPortion}
              className="text-xs font-medium rounded-lg h-8 border-dashed hover:border-primary/30 transition-all duration-200"
            >
              <Plus className="w-3 h-3" />
            </Button>
          </div>

          {customPortions.length > 0 && (
            <div className="space-y-2">
              {customPortions.map((portion, index) => (
                <div key={`portion-${index}`} className="flex gap-2 items-center" data-portion-item>
                  <Input
                    key={`portion-name-${index}`}
                    placeholder="Име на порцията"
                    value={portion.name}
                    onValueChange={(value) => handlePortionChange(index, 'name', value)}
                    className="flex-1 h-9 rounded-lg"
                  />
                  <NumericInput
                    key={`portion-grams-${index}`}
                    placeholder="Грамове"
                    value={portion.grams}
                    onValueChange={(n) => handlePortionChange(index, 'grams', n)}
                    className="w-20 h-9 rounded-lg"
                    min={1}
                    allowDecimal={false}
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => removePortion(index)}
                    disabled={customPortions.length === 1}
                    className="rounded-lg h-9 w-9 p-0"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Unit Selection Popup */}
      {showUnitPopup && unitField && (
        <div 
          className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4"
          onClick={() => { setShowUnitPopup(false); setTimeout(() => { if (scrollContainerRef.current) scrollContainerRef.current.scrollTop = scrollPosRef.current; }, 0); }}
        >
          <div 
            className="bg-background border border-border rounded-2xl shadow-2xl w-full max-w-md"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 border-b border-border">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-lg">
                  {unitField === 'size_unit' ? 'Избери единица' : 'Избери тип'}
                </h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => { setShowUnitPopup(false); setTimeout(() => { if (scrollContainerRef.current) scrollContainerRef.current.scrollTop = scrollPosRef.current; }, 0); }}
                  className="h-8 w-8 p-0"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
            <div className="p-4">
              <div className="grid grid-cols-2 gap-2">
                {unitOptions[unitField].map((option) => {
                  const Icon = option.icon;
                  const isSelected = unitField === 'size_unit' 
                    ? formData.package_size_unit === option.value
                    : formData.package_unit_type === option.value;
                  
                  return (
                    <button
                      key={option.value}
                      onClick={() => { handleUnitSelect(option.value); setTimeout(() => { if (scrollContainerRef.current) scrollContainerRef.current.scrollTop = scrollPosRef.current; }, 0); }}
                      className={`flex items-center gap-3 p-3 rounded-xl border-2 transition-all duration-200 hover:bg-primary/5 ${
                        isSelected 
                          ? 'border-primary bg-primary/10 text-primary' 
                          : 'border-border hover:border-primary/30'
                      }`}
                    >
                      <div className={`p-2 rounded-lg ${
                        isSelected ? 'bg-primary/20' : 'bg-muted'
                      }`}>
                        <Icon className={`w-5 h-5 ${
                          isSelected ? 'text-primary' : 'text-muted-foreground'
                        }`} />
                      </div>
                      <span className="font-medium text-left flex-1">{option.label}</span>
                      {isSelected && (
                        <div className="w-2 h-2 rounded-full bg-primary" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Category Selection Popup */}
      {showCategoryPopup && (
        <div 
          className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4"
          onClick={() => { setShowCategoryPopup(false); setTimeout(() => { if (scrollContainerRef.current) scrollContainerRef.current.scrollTop = scrollPosRef.current; }, 0); }}
        >
          <div 
            className="bg-background border border-border rounded-2xl shadow-2xl w-full max-w-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 border-b border-border flex items-center justify-between">
              <h3 className="font-semibold text-lg">Избери категория</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => { setShowCategoryPopup(false); setTimeout(() => { if (scrollContainerRef.current) scrollContainerRef.current.scrollTop = scrollPosRef.current; }, 0); }}
                className="h-8 w-8 p-0"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
            <div className="p-4">
              <div className="grid grid-cols-3 gap-2">
                {categories.map((category) => {
                  const Icon = category.icon;
                  const isSelected = formData.category === category.value;
                  return (
                    <button
                      key={category.value}
                      type="button"
                      onClick={() => { handleFormDataChange('category', category.value as typeof formData.category); setShowCategoryPopup(false); setTimeout(() => { if (scrollContainerRef.current) scrollContainerRef.current.scrollTop = scrollPosRef.current; }, 0); }}
                      className={`p-3 rounded-xl border-2 transition-all duration-200 text-xs font-medium flex flex-col items-center gap-2 ${
                        isSelected 
                          ? 'border-primary bg-primary/10 text-primary' 
                          : 'border-border hover:border-primary/50 hover:bg-muted/50'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      {category.label}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="flex gap-3">
        <Button 
          type="button" 
          variant="outline" 
          onClick={() => onOpenChange(false)}
          className="flex-1"
        >
          Отказ
        </Button>
        <Button 
          type="submit" 
          disabled={addProductMutation.isPending || !formData.name.trim()}
          className="flex-1"
        >
          {addProductMutation.isPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              {editProduct ? 'Запазвам...' : 'Запазвам...'}
            </>
          ) : (
            editProduct ? 'Запази промени' : 'Запази продукт'
          )}
        </Button>
      </div>
    </>
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[95vh] md:h-[95vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Package2 className="w-5 h-5" />
            {editProduct ? 'Редактирай продукт' : 'Добави продукт'}
          </DialogTitle>
        </DialogHeader>

        <div ref={scrollContainerRef} className="flex-1 overflow-y-auto pb-safe">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="create">{editProduct ? 'Редактирай' : 'Създай нов'}</TabsTrigger>
            <TabsTrigger value="search" disabled={!!editProduct}>Търси в публичните</TabsTrigger>
          </TabsList>

          <TabsContent value="search">
            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Търсете продукти..."
                  value={searchQuery}
                  onValueChange={(value) => setSearchQuery(value)}
                  liveUpdate
                  className="pl-10"
                />
              </div>
              
              <div className="h-96 overflow-y-auto space-y-2">
                {isLoadingPublic ? (
                  <div className="text-center py-4">
                    <Loader2 className="h-6 w-6 animate-spin mx-auto" />
                    <p className="text-sm text-muted-foreground mt-2">Зареждам продукти...</p>
                  </div>
                ) : publicProducts.length === 0 ? (
                  <div className="text-center text-muted-foreground py-4">
                    {searchQuery ? 'Не са намерени продукти' : 'Няма налични публични продукти'}
                  </div>
                ) : (
                  publicProducts.map((product) => (
                    <Card key={product.id} className="p-4">
                      <div className="flex items-center gap-4">
                        {product.image_url && (
                          <img 
                            src={product.image_url} 
                            alt={product.name}
                            className="w-12 h-12 object-cover rounded"
                          />
                        )}
                        <div className="flex-1">
                          <h4 className="font-medium">{product.name}</h4>
                          {product.brand && (
                            <p className="text-sm text-muted-foreground">{product.brand}</p>
                          )}
                          <div className="text-xs text-muted-foreground mt-1">
                            {product.calories_per_100g} kcal • 
                            P: {product.protein_per_100g}g • 
                            C: {product.carbs_per_100g}g • 
                            F: {product.fat_per_100g}g
                          </div>
                        </div>
                        <Button
                          size="sm"
                          onClick={() => copyProductMutation.mutate(product)}
                          disabled={copyProductMutation.isPending}
                          className="flex items-center gap-2"
                        >
                          <Heart className="w-4 h-4" />
                          Запази
                        </Button>
                      </div>
                    </Card>
                  ))
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="create">
            {createMode === 'select' ? (
              <div className="space-y-6">
                <div className="text-center space-y-4">
                  <h3 className="text-lg font-medium">Изберете начин за създаване</h3>
                  <div className="grid grid-cols-1 gap-3">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => { setCreateMode('barcode'); handleScanBarcode(); }}
                      disabled={isProcessingImage}
                      className="w-full h-16 flex flex-col gap-2"
                    >
                      {isProcessingImage ? (
                        <Loader2 className="h-6 w-6 animate-spin" />
                      ) : (
                        <QrCode className="h-6 w-6" />
                      )}
                      <span>Сканирай баркод</span>
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setCreateMode('label')}
                      className="w-full h-16 flex flex-col gap-2"
                    >
                      <Scan className="h-6 w-6" />
                      <span>Сканирай етикет</span>
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setCreateMode('manual')}
                      className="w-full h-16 flex flex-col gap-2"
                    >
                      <PlusCircle className="h-6 w-6" />
                      <span>Ръчно създаване</span>
                    </Button>
                  </div>
                </div>
              </div>
            ) : createMode === 'barcode' ? (
              <div className="space-y-6">
                <div className="text-center space-y-4">
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={() => setCreateMode('select')}
                    className="mb-4 text-primary bg-primary/10 hover:bg-primary/20 hover:text-primary border border-primary/20"
                  >
                    <ArrowLeft className="h-5 w-5 mr-2" />
                    Назад
                  </Button>
                  <h3 className="text-lg font-medium">Сканирай баркод</h3>
                  <div className="border-2 border-dashed border-primary/50 rounded-lg p-8">
                    <QrCode className="mx-auto h-12 w-12 text-primary mb-4" />
                    <Button
                      type="button"
                      onClick={handleScanBarcode}
                      disabled={isProcessingImage}
                      className="w-full mb-4"
                    >
                      {isProcessingImage ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      ) : (
                        <Camera className="h-4 w-4 mr-2" />
                      )}
                      Сканирай баркод
                    </Button>
                    
                    <div className="space-y-3 pt-4 border-t">
                      <p className="text-sm text-muted-foreground text-center">
                        Или въведете баркода ръчно:
                      </p>
                      <div className="flex gap-2">
                        <Input
                          placeholder="Въведете баркод..."
                          value={manualBarcode}
                          onValueChange={(value) => setManualBarcode(value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              handleManualBarcodeSearch();
                            }
                          }}
                          inputMode="numeric"
                          pattern="[0-9]*"
                        />
                        <Button
                          type="button"
                          onClick={handleManualBarcodeSearch}
                          disabled={isSearchingBarcode || !manualBarcode.trim()}
                        >
                          {isSearchingBarcode ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <Search className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
                {(formData.name || imagePreview) && (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <FormFields />
                  </form>
                )}
              </div>
            ) : createMode === 'label' ? (
              <div className="space-y-6">
                <div className="text-center space-y-4">
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={() => setCreateMode('select')}
                    className="mb-4 text-primary bg-primary/10 hover:bg-primary/20 hover:text-primary border border-primary/20"
                  >
                    <ArrowLeft className="h-5 w-5 mr-2" />
                    Назад
                  </Button>
                  <h3 className="text-lg font-medium">Сканирай етикет</h3>
                  <div className="border-2 border-dashed border-primary/50 rounded-lg p-8">
                    <Scan className="mx-auto h-12 w-12 text-primary mb-4" />
                    <Button
                      type="button"
                      onClick={handleScanNutrition}
                      disabled={isProcessingImage}
                      className="w-full"
                    >
                      {isProcessingImage ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      ) : (
                        <Camera className="h-4 w-4 mr-2" />
                      )}
                      Сканирай етикет
                    </Button>
                  </div>
                </div>
                {(formData.name || imagePreview) && (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <FormFields />
                  </form>
                )}
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="flex items-center justify-between">
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={() => setCreateMode('select')}
                    className="text-primary bg-primary/10 hover:bg-primary/20 hover:text-primary border border-primary/20"
                  >
                    <ArrowLeft className="h-5 w-5 mr-2" />
                    Назад
                  </Button>
                </div>
                <FormFields />
              </form>
            )}
          </TabsContent>
        </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
};