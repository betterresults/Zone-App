import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { ServingsInput } from '@/components/ui/servings-input';
import { Separator } from '@/components/ui/separator';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trash2, Upload, X, ChefHat, Calculator, Camera, Plus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { ProductSelector } from './ProductSelector';
import { useSubscription } from '@/hooks/useSubscription';
import { useUserLimits } from '@/hooks/useUserLimits';
import { useActivityTracker } from '@/hooks/useActivityTracker';
import { useCamera } from '@/hooks/useCamera';

interface AddRecipeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface Ingredient {
  id: string;
  product_id: string;
  grams: number;
  product_name?: string;
}

export const AddRecipeDialog = ({ open, onOpenChange }: AddRecipeDialogProps) => {
  const { canAdd, remaining, limits } = useUserLimits();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [instructions, setInstructions] = useState('');
  const [servings, setServings] = useState(1);
  const [mealType, setMealType] = useState<'breakfast' | 'lunch' | 'dinner' | 'snack'>('lunch');
  const [isPublic, setIsPublic] = useState(false);
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [images, setImages] = useState<File[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showProductSelection, setShowProductSelection] = useState(true);
  const [selectedProductIds, setSelectedProductIds] = useState<Set<string>>(new Set());

  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { isPro } = useSubscription();
  const { trackActivity } = useActivityTracker();
  const { takePicture, selectFromGallery } = useCamera();

  // Fetch available products
  const { data: products = [] } = useQuery({
    queryKey: ['products-for-recipe-dialog'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data, error } = await supabase
        .from('products')
        .select('id, name, protein_per_100g, carbs_per_100g, fat_per_100g, calories_per_100g, image_url')
        .or(`user_id.eq.${user.id},is_public.eq.true`)
        .order('name');

      if (error) throw error;
      return data || [];
    }
  });

  const handleProductSelect = (productId: string, grams: number = 100) => {
    // Check if product is already added
    const existingIngredient = ingredients.find(ing => ing.product_id === productId);
    if (existingIngredient) {
      // Remove ingredient
      setIngredients(ingredients.filter(ing => ing.id !== existingIngredient.id));
      setSelectedProductIds(prev => {
        const newSet = new Set(prev);
        newSet.delete(productId);
        return newSet;
      });
    } else {
      // Add ingredient
      const newIngredient: Ingredient = {
        id: crypto.randomUUID(),
        product_id: productId,
        grams
      };
      setIngredients([...ingredients, newIngredient]);
      setSelectedProductIds(prev => new Set([...prev, productId]));
    }
  };

  const updateIngredientGrams = (id: string, newGrams: number) => {
    setIngredients(ingredients.map(ing => 
      ing.id === id ? { ...ing, grams: newGrams } : ing
    ));
  };

  const removeIngredient = (id: string) => {
    const ingredient = ingredients.find(ing => ing.id === id);
    if (ingredient) {
      setSelectedProductIds(prev => {
        const newSet = new Set(prev);
        newSet.delete(ingredient.product_id);
        return newSet;
      });
    }
    setIngredients(ingredients.filter(ing => ing.id !== id));
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setImages(prev => [...prev, ...files].slice(0, 5)); // Максимум 5 снимки
  };

  const handleTakePhoto = async () => {
    try {
      const imageDataUrl = await takePicture();
      if (imageDataUrl) {
        const response = await fetch(imageDataUrl);
        const blob = await response.blob();
        const file = new File([blob], 'recipe-photo.jpg', { type: 'image/jpeg' });
        setImages(prev => [...prev, file].slice(0, 5));
        toast({ title: "Снимката е добавена", description: "Можете да добавите още снимки.", duration: 2500 });
      }
    } catch (error: any) {
      console.error('Error taking photo:', error);
      const msg = String(error?.message || '');
      if (msg !== 'USER_CANCELLED') {
        toast({
          title: "Грешка", 
          description: "Грешка при снимане",
          variant: "destructive",
        });
      }
    }
  };

  const handleSelectFromGallery = async () => {
    try {
      const imageDataUrl = await selectFromGallery();
      if (imageDataUrl) {
        const response = await fetch(imageDataUrl);
        const blob = await response.blob();
        const file = new File([blob], 'recipe-gallery.jpg', { type: 'image/jpeg' });
        setImages(prev => [...prev, file].slice(0, 5));
      }
    } catch (error) {
      console.error('Error selecting from gallery:', error);
      toast({
        title: "Грешка", 
        description: "Грешка при избор на снимка",
        variant: "destructive",
      });
    }
  };

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const uploadImages = async (recipeId: string) => {
    const imageUrls = [];
    
    for (let i = 0; i < images.length; i++) {
      const file = images[i];
      const fileExt = file.name.split('.').pop() || 'jpg';
      const fileName = `${recipeId}_${i}_${Date.now()}.${fileExt}`;
      
      const { error: uploadError } = await supabase.storage
        .from('recipe-images')
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) {
        console.error('Upload error:', uploadError);
        toast({
          title: "Грешка при качване на снимка",
          description: uploadError.message,
          variant: "destructive",
        });
        continue;
      }

      const { data: { publicUrl } } = supabase.storage
        .from('recipe-images')
        .getPublicUrl(fileName);

      imageUrls.push(publicUrl);
    }
    
    return imageUrls;
  };

  const createRecipeMutation = useMutation({
    mutationFn: async () => {
      // Check if user can add more recipes
      if (!canAdd.recipes) {
        throw new Error(`Достигнахте лимита от ${limits.recipes} рецепти. ${!isPro ? 'Надстройте до Премиум за неограничен достъп или изтрийте някои от съществуващите рецепти.' : ''}`);
      }

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Create recipe
      const { data: recipe, error: recipeError } = await supabase
        .from('recipes')
        .insert({
          name,
          description: description || null,
          instructions: instructions || null,
          servings,
          meal_type: mealType,
          is_public: isPublic,
          user_id: user.id
        })
        .select()
        .single();

      if (recipeError) throw recipeError;

      // Upload images
      let imageUrls: string[] = [];
      if (images.length > 0) {
        imageUrls = await uploadImages(recipe.id);
        
        // Update recipe with image URLs
        const { error: updateError } = await supabase
          .from('recipes')
          .update({ image_urls: imageUrls })
          .eq('id', recipe.id);
          
        if (updateError) throw updateError;
      }

      // Add ingredients
      if (ingredients.length > 0) {
        const ingredientData = ingredients
          .filter(ing => ing.product_id)
          .map(ing => ({
            recipe_id: recipe.id,
            product_id: ing.product_id,
            grams: ing.grams
          }));

        const { error: ingredientsError } = await supabase
          .from('recipe_ingredients')
          .insert(ingredientData);

        if (ingredientsError) throw ingredientsError;
      }

      return recipe;
    },
    onSuccess: (data) => {
      toast({
        title: "Рецептата е създадена!",
        description: "Успешно създадохте нова рецепта."
      });
      queryClient.invalidateQueries({ queryKey: ['recipes'] });
      queryClient.invalidateQueries({ queryKey: ['user-counts'] }); // Invalidate user counts
      trackActivity('recipes', 'add_recipe', `Създаде нова рецепта: ${data.name}`, {
        recipe_id: data.id,
        recipe_name: data.name,
        meal_type: data.meal_type,
        servings: data.servings,
        is_public: data.is_public,
        ingredients_count: ingredients.length
      });
      onOpenChange(false);
      resetForm();
    },
    onError: (error) => {
      toast({
        title: "Грешка",
        description: "Неуспешно създаване на рецепта.",
        variant: "destructive"
      });
    }
  });

  const resetForm = () => {
    setName('');
    setDescription('');
    setInstructions('');
    setServings(1);
    setMealType('lunch');
    setIsPublic(false);
    setIngredients([]);
    setImages([]);
    setIsSubmitting(false);
    setShowProductSelection(true);
    setSelectedProductIds(new Set());
  };

  const handleSubmit = async () => {
    if (!name.trim()) {
      toast({
        title: "Грешка",
        description: "Моля въведете име на рецептата.",
        variant: "destructive"
      });
      return;
    }

    if (ingredients.length === 0) {
      toast({
        title: "Грешка", 
        description: "Моля добавете поне един продукт.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    createRecipeMutation.mutate();
  };

  // Calculate total nutrition
  const totalNutrition = ingredients.reduce((total, ingredient) => {
    const product = products.find(p => p.id === ingredient.product_id);
    if (!product) return total;

    const ratio = ingredient.grams / 100;
    return {
      protein: total.protein + (product.protein_per_100g * ratio),
      carbs: total.carbs + (product.carbs_per_100g * ratio),
      fat: total.fat + (product.fat_per_100g * ratio),
      calories: total.calories + (product.calories_per_100g * ratio)
    };
  }, { protein: 0, carbs: 0, fat: 0, calories: 0 });

  const perServing = {
    protein: totalNutrition.protein / servings,
    carbs: totalNutrition.carbs / servings,
    fat: totalNutrition.fat / servings,
    calories: totalNutrition.calories / servings
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ChefHat className="w-5 h-5" />
            Създай нова рецепта
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Основна информация */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Основна информация</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Име на рецептата *</Label>
                  <Input
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Напр. Гръцка салата"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Кратко описание</Label>
                  <Textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Опишете накратко рецептата..."
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="servings">Порции</Label>
                    <ServingsInput
                      id="servings"
                      value={servings}
                      onChange={setServings}
                      min={1}
                      max={20}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="meal-type">Тип хранене</Label>
                    <Select value={mealType} onValueChange={(value: any) => setMealType(value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="breakfast">Закуска</SelectItem>
                        <SelectItem value="lunch">Обяд</SelectItem>
                        <SelectItem value="dinner">Вечеря</SelectItem>
                        <SelectItem value="snack">Междинно</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {isPro && (
                  <div className="flex items-center justify-between">
                    <Label htmlFor="is-public">Публична рецепта</Label>
                    <Switch
                      id="is-public"
                      checked={isPublic}
                      onCheckedChange={setIsPublic}
                    />
                  </div>
                )}
                {!isPro && (
                  <div className="flex items-center justify-between opacity-50">
                    <div>
                      <Label>Публична рецепта</Label>
                      <div className="text-xs text-muted-foreground">Достъпно само за Премиум</div>
                    </div>
                    <Switch disabled checked={false} />
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Снимки */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Снимки</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleTakePhoto}
                    className="flex-1"
                  >
                    <Camera className="h-4 w-4 mr-2" />
                    Снимай с камерата
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleSelectFromGallery}
                    className="flex-1"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Избери от галерията
                  </Button>
                </div>
                
                <Input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleImageChange}
                  className="hidden"
                  id="image-upload"
                />

                {images.length > 0 && (
                  <div className="grid grid-cols-2 gap-2">
                    {images.map((image, index) => (
                      <div key={index} className="relative">
                        <img
                          src={URL.createObjectURL(image)}
                          alt={`Preview ${index + 1}`}
                          className="w-full h-24 object-cover rounded-lg"
                        />
                        <Button
                          variant="destructive"
                          size="sm"
                          className="absolute top-1 right-1 h-6 w-6 p-0"
                          onClick={() => removeImage(index)}
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Продукти */}
          <div className="space-y-6">
            <ProductSelector
              onProductSelect={handleProductSelect}
              selectedProductIds={selectedProductIds}
              showProductSelection={showProductSelection}
              onToggleProductSelection={setShowProductSelection}
              selectedCount={ingredients.length}
            />

            {/* Added Ingredients List */}
            {ingredients.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Добавени продукти ({ingredients.length})</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {ingredients.map((ingredient) => {
                    const product = products.find(p => p.id === ingredient.product_id);
                    if (!product) return null;
                    
                    const factor = ingredient.grams / 100;
                    const calories = Math.round(product.calories_per_100g * factor);
                    const protein = (product.protein_per_100g * factor).toFixed(1);
                    const carbs = (product.carbs_per_100g * factor).toFixed(1);
                    const fat = (product.fat_per_100g * factor).toFixed(1);

                    return (
                      <div key={ingredient.id} className="flex items-center gap-2 p-2 bg-muted/30 rounded-lg">
                        <div className="w-6 h-6 bg-muted rounded-full flex items-center justify-center overflow-hidden flex-shrink-0">
                          {product.image_url ? (
                            <img 
                              src={product.image_url} 
                              alt={product.name}
                              className="w-full h-full object-cover rounded-full"
                            />
                          ) : (
                            <ChefHat className="w-2 h-2 text-muted-foreground" />
                          )}
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-xs truncate leading-tight">{product.name}</h4>
                          <div className="text-xs text-muted-foreground leading-tight">
                            <div>{calories} kcal</div>
                            <div>P: {protein}g • C: {carbs}g • F: {fat}g</div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 flex-shrink-0">
                          <Input
                            type="number"
                            value={ingredient.grams}
                            onChange={(e) => updateIngredientGrams(ingredient.id, Number(e.target.value))}
                            className="w-12 text-center text-xs h-6 px-1"
                            min="1"
                          />
                          <span className="text-xs text-muted-foreground">g</span>
                        </div>

                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeIngredient(ingredient.id)}
                          className="text-destructive hover:text-destructive h-5 w-5 p-0 flex-shrink-0"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
            )}

            {/* Zone Резултат */}
            {ingredients.length > 0 && (
              <Card className="border-2 border-primary/20">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Calculator className="w-5 h-5" />
                    Zone Резултат (на порция)
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-3">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Total macros */}
                    <div className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900 p-4 rounded-lg">
                      <h3 className="font-bold text-sm text-blue-700 dark:text-blue-300 mb-3 text-center">МАКРОСИ/ПОРЦИЯ</h3>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center bg-white/50 dark:bg-black/20 p-2 rounded">
                          <span className="font-medium">Протеин</span>
                          <span className="font-bold text-blue-600">{perServing.protein.toFixed(1)}г</span>
                        </div>
                        <div className="flex justify-between items-center bg-white/50 dark:bg-black/20 p-2 rounded">
                          <span className="font-medium">Въглехидрати</span>
                          <span className="font-bold text-green-600">{perServing.carbs.toFixed(1)}г</span>
                        </div>
                        <div className="flex justify-between items-center bg-white/50 dark:bg-black/20 p-2 rounded">
                          <span className="font-medium">Мазнини</span>
                          <span className="font-bold text-orange-600">{perServing.fat.toFixed(1)}г</span>
                        </div>
                        <div className="flex justify-between items-center bg-primary/10 p-2 rounded border-2 border-primary/20">
                          <span className="font-bold">Калории</span>
                          <span className="font-bold text-primary text-lg">{Math.round(perServing.calories)}</span>
                        </div>
                      </div>
                    </div>

                    {/* Zone blocks */}
                    <div className="text-center space-y-4">
                      <h3 className="font-bold text-sm text-muted-foreground">ZONE БЛОКОВЕ</h3>
                      <div className="flex justify-center items-center gap-4">
                        {(() => {
                          const proteinBlocks = perServing.protein / 7;
                          const carbBlocks = perServing.carbs / 9;
                           const fatBlocks = perServing.fat / 1.5;
                          const minBlocks = Math.min(proteinBlocks, carbBlocks, fatBlocks); // Zone Diet правилна логика
                          const maxBlocks = Math.max(proteinBlocks, carbBlocks, fatBlocks);
                          const ratio = minBlocks / maxBlocks;
                          
                          const getBlockColor = (blockValue: number) => {
                            if (ratio >= 0.9) {
                              return 'bg-green-500';
                            } else if (ratio >= 0.7) {
                              const percentOfMax = blockValue / maxBlocks;
                              return percentOfMax >= 0.85 ? 'bg-green-500' : 'bg-yellow-500';
                            } else {
                              const percentOfMax = blockValue / maxBlocks;
                              if (percentOfMax >= 0.9) {
                                return 'bg-green-500';
                              } else if (percentOfMax >= 0.7) {
                                return 'bg-yellow-500';
                              } else {
                                return 'bg-red-500';
                              }
                            }
                          };

                          return (
                            <>
                              <div className="text-center">
                                <div className={`w-12 h-12 ${getBlockColor(proteinBlocks)} rounded-full flex items-center justify-center text-white font-bold text-sm border-2 border-white shadow-lg`}>
                                  {proteinBlocks.toFixed(1)}
                                </div>
                                <div className="text-xs mt-1 font-medium">Протеин</div>
                              </div>
                              <div className="text-center">
                                <div className={`w-12 h-12 ${getBlockColor(carbBlocks)} rounded-full flex items-center justify-center text-white font-bold text-sm border-2 border-white shadow-lg`}>
                                  {carbBlocks.toFixed(1)}
                                </div>
                                <div className="text-xs mt-1 font-medium">Въглехидр.</div>
                              </div>
                              <div className="text-center">
                                <div className={`w-12 h-12 ${getBlockColor(fatBlocks)} rounded-full flex items-center justify-center text-white font-bold text-sm border-2 border-white shadow-lg`}>
                                  {fatBlocks.toFixed(1)}
                                </div>
                                <div className="text-xs mt-1 font-medium">Мазнини</div>
                              </div>
                            </>
                          );
                        })()}
                      </div>
                      
                      {/* Zone status */}
                      <div className="mt-4">
                        {(() => {
                          const proteinBlocks = perServing.protein / 7;
                          const carbBlocks = perServing.carbs / 9;
                          const fatBlocks = perServing.fat / 1.5;
                          const minBlocks = Math.min(proteinBlocks, carbBlocks, fatBlocks); // Zone Diet правилна логика
                          const maxBlocks = Math.max(proteinBlocks, carbBlocks, fatBlocks);
                          const ratio = minBlocks / maxBlocks;
                          
                          if (ratio >= 0.9) {
                            return <Badge className="bg-green-500 text-white">В ЗОНАТА 🎯</Badge>;
                          } else if (ratio >= 0.7) {
                            return <Badge className="bg-yellow-500 text-white">БЛИЗО ДО ЗОНАТА ⚠️</Badge>;
                          } else {
                            return <Badge className="bg-red-500 text-white">ИЗВЪН ЗОНАТА ❌</Badge>;
                          }
                        })()}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Приготвяне */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Начин на приготвяне</CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={instructions}
                  onChange={(e) => setInstructions(e.target.value)}
                  placeholder="Опишете стъпките за приготвяне..."
                  rows={6}
                />
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-4 border-t">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Отказ
          </Button>
          <Button onClick={handleSubmit} disabled={isSubmitting}>
            {isSubmitting ? 'Създаване...' : 'Създай рецепта'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};