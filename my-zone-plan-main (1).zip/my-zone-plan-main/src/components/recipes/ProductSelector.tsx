import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Plus, Search, ChefHat } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { AddProductDialog } from '@/components/products/AddProductDialog';

interface Product {
  id: string;
  name: string;
  calories_per_100g: number;
  protein_per_100g: number;
  carbs_per_100g: number;
  fat_per_100g: number;
  image_url?: string;
}

interface ProductSelectorProps {
  onProductSelect: (productId: string, grams?: number) => void;
  selectedProductIds: Set<string>;
  showProductSelection: boolean;
  onToggleProductSelection: (show: boolean) => void;
  selectedCount: number;
}

export const ProductSelector = ({ 
  onProductSelect, 
  selectedProductIds, 
  showProductSelection, 
  onToggleProductSelection,
  selectedCount 
}: ProductSelectorProps) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddProduct, setShowAddProduct] = useState(false);

  // Fetch products
  const { data: products = [], refetch: refetchProducts } = useQuery({
    queryKey: ['products-for-recipes', searchQuery],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];
      
      let query = supabase
        .from('products')
        .select('id, name, protein_per_100g, carbs_per_100g, fat_per_100g, calories_per_100g, image_url')
        .eq('user_id', user.id) // Only user's products - no public products
        .order('name');
      
      if (searchQuery.trim()) {
        query = query.ilike('name', `%${searchQuery}%`);
      }
      
      const { data, error } = await query;
      if (error) throw error;
      return data || [];
    },
    staleTime: 1000 * 60 * 5,
    refetchOnWindowFocus: false
  });

  return (
    <>
      {/* Header with Add Products button */}
      {!showProductSelection && selectedCount > 0 && (
        <div className="flex justify-end mb-4">
          <Button 
            variant="default" 
            size="sm"
            onClick={() => onToggleProductSelection(true)}
            className="bg-gradient-to-r from-primary to-primary-light hover:from-primary-dark hover:to-primary shadow-lg hover:shadow-xl transition-all duration-300 text-sm px-3 py-2"
          >
            <Plus className="w-3 h-3 mr-1" />
            Добави продукти
          </Button>
        </div>
      )}

      {/* Product Selection - Collapsible */}
      {showProductSelection && (
        <div className="space-y-1 border border-border rounded-lg p-1 bg-card mb-6">
          {/* Search and Add Row */}
          <div className="flex gap-1">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Търси продукт..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button 
              variant="outline" 
              onClick={() => setShowAddProduct(true)}
              size="icon"
              className="flex-shrink-0"
            >
              <Plus className="w-4 h-4" />
            </Button>
          </div>

          {/* Products Grid - Better Layout */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {products.map(product => {
              const isSelected = selectedProductIds.has(product.id);
              return (
                <div 
                  key={product.id} 
                  className="relative cursor-pointer aspect-square rounded-lg border-2 border-border data-[selected=true]:border-primary data-[selected=true]:ring-2 data-[selected=true]:ring-primary/20 overflow-hidden group hover:scale-105 transition-transform duration-200"
                  data-selected={isSelected}
                  onClick={() => onProductSelect(product.id, 100)}
                >
                  {/* Background Image */}
                  {product.image_url ? (
                    <div 
                      className="absolute inset-0 bg-cover bg-center"
                      style={{ backgroundImage: `url(${product.image_url})` }}
                    />
                  ) : (
                    <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-primary/40 flex items-center justify-center">
                      <ChefHat className="w-8 h-8 text-primary" />
                    </div>
                  )}
                  
                  {/* Text Overlay */}
                  <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/95 via-black/70 to-transparent px-3 pt-6 pb-2">
                    <h4 className="font-bold text-sm leading-tight text-white line-clamp-2 text-center">
                      {product.name}
                    </h4>
                    <p className="text-xs text-white/80 text-center mt-1">
                      {product.calories_per_100g} kcal
                    </p>
                  </div>
                </div>
              );
            })}
            
            {products.length === 0 && (
              <div className="col-span-full text-center py-8 text-muted-foreground">
                <ChefHat className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>{searchQuery ? 'Няма намерени продукти' : 'Няма добавени продукти'}</p>
              </div>
            )}
          </div>

          {/* Hide Button */}
          {selectedCount > 0 && (
            <div className="flex justify-center pt-2 border-t">
              <Button 
                variant="ghost" 
                onClick={() => onToggleProductSelection(false)}
                size="sm"
              >
                Скрий продукти
              </Button>
            </div>
          )}
        </div>
      )}

      <AddProductDialog
        open={showAddProduct}
        onOpenChange={setShowAddProduct}
      />
    </>
  );
};