import { useState, useEffect, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { ServingsInput } from '@/components/ui/servings-input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Edit, Save, X, ChefHat, Trash2, Upload, Camera, Plus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { ProductSelector } from './ProductSelector';
import { useSubscription } from '@/hooks/useSubscription';
import { useActivityTracker } from '@/hooks/useActivityTracker';
import { useCamera } from '@/hooks/useCamera';

interface EditRecipeDialogProps {
  recipe: any;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface Ingredient {
  id: string;
  product_id: string;
  grams: number;
  product_name?: string;
}

export const EditRecipeDialog = ({ recipe, open, onOpenChange }: EditRecipeDialogProps) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [instructions, setInstructions] = useState('');
  const [servings, setServings] = useState(1);
  const [mealType, setMealType] = useState<'breakfast' | 'lunch' | 'dinner' | 'snack'>('lunch');
  const [isPublic, setIsPublic] = useState(false);
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [images, setImages] = useState<File[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showProductSelection, setShowProductSelection] = useState(false);
  const [selectedProductIds, setSelectedProductIds] = useState<Set<string>>(new Set());
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { isPro } = useSubscription();
  const { trackActivity } = useActivityTracker();
  const { takePicture, selectFromGallery } = useCamera();

  // Fetch available products
  const { data: products = [] } = useQuery({
    queryKey: ['products-for-recipe-dialog'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data, error } = await supabase
        .from('products')
        .select('id, name, protein_per_100g, carbs_per_100g, fat_per_100g, calories_per_100g, image_url')
        .or(`user_id.eq.${user.id},is_public.eq.true`)
        .order('name');

      if (error) throw error;
      return data || [];
    }
  });

  // Check for linked dishes function
  const checkLinkedDishes = async (): Promise<any[]> => {
    const recipeId = recipe?.id;
    if (!recipeId) return [];
    
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      // Use a simpler approach to avoid TypeScript issues
      const response = await fetch(`https://cmznrqtrtwohclokilkv.supabase.co/rest/v1/dishes?source_recipe_id=eq.${recipeId}&user_id=eq.${user.id}&select=id,name`, {
        headers: {
          'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNtem5ycXRydHdvaGNsb2tpbGt2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTcxNzY1MTMsImV4cCI6MjA3Mjc1MjUxM30.0KRvJiaVibJbhKLzWEtV3pdAXqPkv6bXoawuHFKLvwA',
          'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
          'Content-Type': 'application/json'
        }
      });
      const data = await response.json();
      return Array.isArray(data) ? data : [];
    } catch (error) {
      console.error('Error fetching linked dishes:', error);
      return [];
    }
  };

  useEffect(() => {
    if (recipe) {
      setName(recipe.name || '');
      setDescription(recipe.description || '');
      setInstructions(recipe.instructions || '');
      setServings(recipe.servings || 1);
      setMealType(recipe.meal_type || 'lunch');
      setIsPublic(recipe.is_public || false);
      
      // Load existing ingredients
      if (recipe.recipe_ingredients) {
        const recipeIngredients = recipe.recipe_ingredients.map((ing: any) => ({
          id: crypto.randomUUID(),
          product_id: ing.products.id,
          grams: ing.grams,
          product_name: ing.products.name
        }));
        setIngredients(recipeIngredients);
        setSelectedProductIds(new Set(recipeIngredients.map((ing: any) => ing.product_id)));
      }
    }
  }, [recipe]);

  const handleProductSelect = (productId: string, grams: number = 100) => {
    const existingIngredient = ingredients.find(ing => ing.product_id === productId);
    if (existingIngredient) {
      setIngredients(ingredients.filter(ing => ing.id !== existingIngredient.id));
      setSelectedProductIds(prev => {
        const newSet = new Set(prev);
        newSet.delete(productId);
        return newSet;
      });
    } else {
      const newIngredient: Ingredient = {
        id: crypto.randomUUID(),
        product_id: productId,
        grams
      };
      setIngredients([...ingredients, newIngredient]);
      setSelectedProductIds(prev => new Set([...prev, productId]));
    }
  };

  const updateIngredientGrams = (id: string, newGrams: number) => {
    setIngredients(ingredients.map(ing => 
      ing.id === id ? { ...ing, grams: newGrams } : ing
    ));
  };

  const removeIngredient = (id: string) => {
    const ingredient = ingredients.find(ing => ing.id === id);
    if (ingredient) {
      setSelectedProductIds(prev => {
        const newSet = new Set(prev);
        newSet.delete(ingredient.product_id);
        return newSet;
      });
    }
    setIngredients(ingredients.filter(ing => ing.id !== id));
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setImages(prev => [...prev, ...files].slice(0, 5));
  };

  const handleTakePhoto = async () => {
    try {
      const imageDataUrl = await takePicture();
      if (imageDataUrl) {
        const response = await fetch(imageDataUrl);
        const blob = await response.blob();
        const file = new File([blob], 'recipe-photo.jpg', { type: 'image/jpeg' });
        setImages(prev => [...prev, file].slice(0, 5));
        toast({ title: "Снимката е добавена", description: "Можете да добавите още снимки.", duration: 2500 });
      }
    } catch (error: any) {
      console.error('Error taking photo:', error);
      const msg = String(error?.message || '');
      if (msg !== 'USER_CANCELLED') {
        toast({
          title: "Грешка", 
          description: "Грешка при снимане",
          variant: "destructive",
        });
      }
    }
  };

  const handleSelectFromGallery = async () => {
    try {
      const imageDataUrl = await selectFromGallery();
      if (imageDataUrl) {
        const response = await fetch(imageDataUrl);
        const blob = await response.blob();
        const file = new File([blob], 'recipe-gallery.jpg', { type: 'image/jpeg' });
        setImages(prev => [...prev, file].slice(0, 5));
      }
    } catch (error) {
      console.error('Error selecting from gallery:', error);
      toast({
        title: "Грешка", 
        description: "Грешка при izbor на снимка",
        variant: "destructive",
      });
    }
  };

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const uploadImages = async (recipeId: string) => {
    const imageUrls = [];
    
    for (let i = 0; i < images.length; i++) {
      const file = images[i];
      const fileExt = file.name.split('.').pop() || 'jpg';
      const fileName = `${recipeId}_${i}_${Date.now()}.${fileExt}`;
      
      const { error: uploadError } = await supabase.storage
        .from('recipe-images')
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) {
        console.error('Upload error:', uploadError);
        continue;
      }

      const { data: { publicUrl } } = supabase.storage
        .from('recipe-images')
        .getPublicUrl(fileName);

      imageUrls.push(publicUrl);
    }
    
    return imageUrls;
  };

  const updateRecipeMutation = useMutation({
    mutationFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Update recipe basic info
      let imageUrls: string[] = recipe.image_urls || [];
      if (images.length > 0) {
        const newImageUrls = await uploadImages(recipe.id);
        imageUrls = [...imageUrls, ...newImageUrls];
      }

      const { error: recipeError } = await supabase
        .from('recipes')
        .update({
          name,
          description: description || null,
          instructions: instructions || null,
          servings,
          meal_type: mealType,
          is_public: isPublic,
          image_urls: imageUrls
        })
        .eq('id', recipe.id);

      if (recipeError) throw recipeError;

      // Delete existing ingredients
      const { error: deleteError } = await supabase
        .from('recipe_ingredients')
        .delete()
        .eq('recipe_id', recipe.id);

      if (deleteError) throw deleteError;

      // Add new ingredients
      if (ingredients.length > 0) {
        const ingredientData = ingredients
          .filter(ing => ing.product_id)
          .map(ing => ({
            recipe_id: recipe.id,
            product_id: ing.product_id,
            grams: ing.grams
          }));

        const { error: ingredientsError } = await supabase
          .from('recipe_ingredients')
          .insert(ingredientData);

        if (ingredientsError) throw ingredientsError;
      }

      // Update linked dishes automatically
      const linkedDishes = await checkLinkedDishes();
      if (linkedDishes.length > 0) {
        // Show notification about linked dishes update
        toast({
          title: "Свързани ястия обновени!",
          description: `Обновихме ${linkedDishes.length} ястия, свързани с тази рецепта.`,
          duration: 5000,
        });

        // Update dish basic info using fetch to avoid type issues
        await fetch(`https://cmznrqtrtwohclokilkv.supabase.co/rest/v1/dishes?source_recipe_id=eq.${recipe.id}&user_id=eq.${user.id}`, {
          method: 'PATCH',
          headers: {
            'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNtem5ycXRydHdvaGNsb2tpbGt2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTcxNzY1MTMsImV4cCI6MjA3Mjc1MjUxM30.0KRvJiaVibJbhKLzWEtV3pdAXqPkv6bXoawuHFKLvwA',
            'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            name,
            description: description || null,
            meal_type: mealType
          })
        });

        // Update dish ingredients for each linked dish
        for (const dish of linkedDishes) {
          // Delete existing dish ingredients using fetch to avoid type issues
          await fetch(`https://cmznrqtrtwohclokilkv.supabase.co/rest/v1/dish_ingredients?dish_id=eq.${dish.id}`, {
            method: 'DELETE',
            headers: {
              'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNtem5ycXRydHdvaGNsb2tpbGt2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTcxNzY1MTMsImV4cCI6MjA3Mjc1MjUxM30.0KRvJiaVibJbhKLzWEtV3pdAXqPkv6bXoawuHFKLvwA',
              'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
              'Content-Type': 'application/json'
            }
          });

          // Add new dish ingredients (adjusted for servings)
          if (ingredients.length > 0) {
            const dishIngredientData = ingredients
              .filter(ing => ing.product_id)
              .map(ing => ({
                dish_id: dish.id,
                product_id: ing.product_id,
                grams: ing.grams / servings // Adjust for single serving
              }));

            const { error: dishIngredientsError } = await supabase
              .from('dish_ingredients')
              .insert(dishIngredientData);

            if (dishIngredientsError) throw dishIngredientsError;
          }
        }
      }
    },
    onSuccess: () => {
      toast({
        title: "Рецептата е обновена!",
        description: "Успешно обновихте рецептата."
      });
      queryClient.invalidateQueries({ queryKey: ['recipes'] });
      queryClient.invalidateQueries({ queryKey: ['user-dishes'] });
      trackActivity('recipes', 'edit_recipe', `Редактира рецепта: ${name}`, {
        recipe_id: recipe.id,
        recipe_name: name,
        meal_type: mealType,
        servings: servings,
        is_public: isPublic,
        ingredients_count: ingredients.length
      });
      onOpenChange(false);
      setIsSubmitting(false);
    },
    onError: (error) => {
      toast({
        title: "Грешка",
        description: "Неуспешно обновяване на рецептата.",
        variant: "destructive"
      });
      setIsSubmitting(false);
    }
  });

  const handleSubmit = () => {
    if (!name.trim()) {
      toast({
        title: "Грешка",
        description: "Моля въведете име на рецептата.",
        variant: "destructive"
      });
      return;
    }

    if (ingredients.length === 0) {
      toast({
        title: "Грешка", 
        description: "Моля добавете поне един продукт.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    updateRecipeMutation.mutate();
  };

  // Calculate total nutrition - wrapped in useMemo for better performance
  const totalNutrition = useMemo(() => {
    return ingredients.reduce((total, ingredient) => {
      const product = products.find(p => p.id === ingredient.product_id);
      if (!product) return total;

      const ratio = ingredient.grams / 100;
      return {
        protein: total.protein + (product.protein_per_100g * ratio),
        carbs: total.carbs + (product.carbs_per_100g * ratio),
        fat: total.fat + (product.fat_per_100g * ratio),
        calories: total.calories + (product.calories_per_100g * ratio)
      };
    }, { protein: 0, carbs: 0, fat: 0, calories: 0 });
  }, [ingredients, products]);

  const perServing = useMemo(() => ({
    protein: totalNutrition.protein / servings,
    carbs: totalNutrition.carbs / servings,
    fat: totalNutrition.fat / servings,
    calories: totalNutrition.calories / servings
  }), [totalNutrition, servings]);

  if (!recipe) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Edit className="w-5 h-5" />
            Редактирай рецепта
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Left Column */}
          <div className="space-y-4">
            {/* Name and Image Upload */}
            <div className="flex gap-3">
              <div className="flex-1">
                <Input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Име на рецептата"
                  className="text-lg font-medium"
                />
              </div>
              <div className="flex gap-2 flex-shrink-0">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleTakePhoto}
                >
                  <Camera className="h-4 w-4" />
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleSelectFromGallery}
                >
                  <Upload className="h-4 w-4" />
                </Button>
                <Input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleImageChange}
                  className="hidden"
                  id="edit-image-upload"
                />
              </div>
            </div>

            {/* Description */}
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Кратко описание"
              rows={2}
              className="resize-none"
            />

            {/* Instructions */}
            <Textarea
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              placeholder="Инструкции за приготвяне"
              rows={3}
              className="resize-none"
            />

            {/* Servings, Meal Type, and Public Switch */}
            <div className="flex gap-3 items-center">
              <div className="flex-1">
                <ServingsInput
                  value={servings}
                  onChange={setServings}
                  min={1}
                  max={20}
                />
              </div>
              <div className="flex-1">
                <Select value={mealType} onValueChange={(value: any) => setMealType(value)}>
                  <SelectTrigger className="h-9">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="breakfast">Закуска</SelectItem>
                    <SelectItem value="lunch">Обяд</SelectItem>
                    <SelectItem value="dinner">Вечеря</SelectItem>
                    <SelectItem value="snack">Междинно</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {isPro && (
                <div className="flex items-center gap-2">
                  <span className="text-sm whitespace-nowrap">Публична</span>
                  <Switch
                    checked={isPublic}
                    onCheckedChange={setIsPublic}
                  />
                </div>
              )}
            </div>

            {/* Images Preview */}
            {((recipe?.image_urls && recipe.image_urls.length > 0) || images.length > 0) && (
              <div className="space-y-2">
                <div className="grid grid-cols-4 gap-2">
                  {/* Existing images */}
                  {recipe?.image_urls?.map((url: string, index: number) => (
                    <img
                      key={`existing-${index}`}
                      src={url}
                      alt={`Recipe ${index + 1}`}
                      className="w-full h-16 object-cover rounded-lg"
                    />
                  ))}
                  {/* New images */}
                  {images.map((image, index) => (
                    <div key={`new-${index}`} className="relative">
                      <img
                        src={URL.createObjectURL(image)}
                        alt={`New ${index + 1}`}
                        className="w-full h-16 object-cover rounded-lg"
                      />
                      <Button
                        variant="destructive"
                        size="sm"
                        className="absolute -top-1 -right-1 h-5 w-5 p-0"
                        onClick={() => removeImage(index)}
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Nutrition Summary */}
            {ingredients.length > 0 && (
              <div className="bg-muted/30 rounded-lg p-3">
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-xs text-muted-foreground">Общо</div>
                    <div className="text-lg font-bold text-primary">{Math.round(totalNutrition.calories)} kcal</div>
                    <div className="text-xs">
                      P: {totalNutrition.protein.toFixed(1)}г • C: {totalNutrition.carbs.toFixed(1)}г • F: {totalNutrition.fat.toFixed(1)}г
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground">На порция</div>
                    <div className="text-lg font-bold text-secondary">{Math.round(perServing.calories)} kcal</div>
                    <div className="text-xs">
                      P: {perServing.protein.toFixed(1)}г • C: {perServing.carbs.toFixed(1)}г • F: {perServing.fat.toFixed(1)}г
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-2">
              <Button 
                onClick={handleSubmit}
                disabled={updateRecipeMutation.isPending || isSubmitting}
                className="flex-1"
              >
                <Save className="w-4 h-4 mr-2" />
                {updateRecipeMutation.isPending || isSubmitting ? 'Запазване...' : 'Запази промените'}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => onOpenChange(false)}
                disabled={updateRecipeMutation.isPending || isSubmitting}
              >
                Отказ
              </Button>
            </div>
          </div>

          {/* Right Column - Products */}
          <div className="space-y-4">
            <ProductSelector
              onProductSelect={handleProductSelect}
              selectedProductIds={selectedProductIds}
              showProductSelection={showProductSelection}
              onToggleProductSelection={setShowProductSelection}
              selectedCount={ingredients.length}
            />

            {/* Added Ingredients List */}
            {ingredients.length > 0 && (
              <div className="space-y-2">
                <div className="text-sm font-medium">Продукти ({ingredients.length})</div>
                <div className="space-y-1 max-h-64 overflow-y-auto">
                  {ingredients.map((ingredient) => {
                    const product = products.find(p => p.id === ingredient.product_id);
                    if (!product) return null;
                    
                    const factor = ingredient.grams / 100;
                    const calories = Math.round(product.calories_per_100g * factor);
                    const protein = (product.protein_per_100g * factor).toFixed(1);
                    const carbs = (product.carbs_per_100g * factor).toFixed(1);
                    const fat = (product.fat_per_100g * factor).toFixed(1);

                    return (
                      <div key={ingredient.id} className="flex items-center gap-2 p-2 bg-muted/30 rounded-lg">
                        <div className="w-5 h-5 bg-muted rounded-full flex items-center justify-center overflow-hidden flex-shrink-0">
                          {product.image_url ? (
                            <img 
                              src={product.image_url} 
                              alt={product.name}
                              className="w-full h-full object-cover rounded-full"
                            />
                          ) : (
                            <ChefHat className="w-2 h-2 text-muted-foreground" />
                          )}
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-xs truncate leading-tight">{product.name}</h4>
                          <div className="text-xs text-muted-foreground leading-tight">
                            {calories} kcal • P: {protein}g • C: {carbs}g • F: {fat}g
                          </div>
                        </div>

                        <div className="flex items-center gap-1 flex-shrink-0">
                          <Input
                            type="number"
                            value={ingredient.grams}
                            onChange={(e) => updateIngredientGrams(ingredient.id, Number(e.target.value))}
                            className="w-10 text-center text-xs h-6 px-1"
                            min="1"
                          />
                          <span className="text-xs text-muted-foreground">g</span>
                        </div>

                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeIngredient(ingredient.id)}
                          className="h-6 w-6 p-0 hover:bg-destructive hover:text-destructive-foreground"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
