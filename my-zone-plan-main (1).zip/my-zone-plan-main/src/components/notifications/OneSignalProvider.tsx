import { useEffect } from 'react';
import { useOneSignal } from '@/hooks/useOneSignal';
import { useAuth } from '@/hooks/useAuth';
import { useProfile } from '@/hooks/useProfile';

const OneSignalProvider = () => {
  const { isInitialized, sendTags } = useOneSignal();
  const { user } = useAuth();
  const { profile } = useProfile();

  useEffect(() => {
    const syncOneSignal = async () => {
      if (isInitialized && user && profile && (window as any).OneSignal) {
        try {
          // External ID е вече зададен в useOneSignal - не трябва отново
          // Само проверяваме opt-in статуса за tags
          const optedIn = !!(window as any).OneSignal.User?.PushSubscription?.optedIn;
          
          // Set user tags for better targeting
          const tags: Record<string, string | number> = {
            user_id: user.id,
            email: user.email || '',
          };

          if (profile.display_name) {
            tags.display_name = profile.display_name;
          }

          if (profile.hydration_enabled) {
            tags.hydration_enabled = 'true';
          }

          if (profile.fitness_enabled) {
            tags.fitness_enabled = 'true';
          }

          if (profile.fasting_enabled) {
            tags.fasting_enabled = 'true';
          }

          if (profile.zone_enabled) {
            tags.zone_enabled = 'true';
          }

          // Only send tags AFTER user has opted-in (avoids 409 and missing device)
          if (optedIn) {
            await sendTags(tags);
            console.log('✅ OneSignal tags sent');
          } else {
            console.log('ℹ️ OneSignal: not opted-in yet, skipping tags');
          }
        } catch (e) {
          console.warn('⚠️ OneSignal sync failed:', e);
        }
      }
    };

    syncOneSignal();
  }, [isInitialized, user, profile, sendTags]);

  return null; // This is just a provider component
};

export default OneSignalProvider;