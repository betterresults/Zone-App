import { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useProfile } from "@/hooks/useProfile";
import { useOneSignal } from "@/hooks/useOneSignal";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

// Shows an immediate in-app prompt after login to request push permissions with a single tap
// (required by browser policies to be triggered by a user gesture)
const NotificationsOnboarding = () => {
  const { user } = useAuth();
  const { profile, updateProfile } = useProfile();
  const { isInitialized, isSubscribed, requestPermission, sendTags } = useOneSignal();

  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  const seenKey = useMemo(() => (user?.id ? `notif_prompt_seen_${user.id}` : null), [user?.id]);

  useEffect(() => {
    if (!user || !isInitialized) return;

    // If already subscribed or permission granted, don't show
    const perm = (typeof Notification !== 'undefined') ? Notification.permission : 'default';
    const hasSeen = seenKey ? localStorage.getItem(seenKey) : null;

    if (!isSubscribed && perm !== 'granted' && !hasSeen) {
      setOpen(true);
    }
  }, [user, isInitialized, isSubscribed, seenKey]);

  // Автоматично активиране в профила при дадено разрешение или открита абонамент
  useEffect(() => {
    if (!user || !isInitialized) return;
    const perm = (typeof Notification !== 'undefined') ? Notification.permission : 'default';
    if ((perm === 'granted' || isSubscribed) && profile && !profile.push_notifications_enabled) {
      updateProfile?.({ push_notifications_enabled: true }).catch(() => {});
    }
  }, [user, isInitialized, isSubscribed, profile?.push_notifications_enabled, updateProfile]);

  const handleEnable = async () => {
    if (!user) return;
    try {
      setLoading(true);
      const ok = await requestPermission();
      // If granted, link device to user and tag
      if (ok) {
        // Build tags (same as provider)
        const tags: Record<string, string | number> = {
          user_id: user.id,
          email: user.email || '',
        };
        if (profile?.display_name) tags.display_name = profile.display_name;
        if (profile?.hydration_enabled) tags.hydration_enabled = 'true';
        if (profile?.fitness_enabled) tags.fitness_enabled = 'true';
        if (profile?.fasting_enabled) tags.fasting_enabled = 'true';
        if (profile?.zone_enabled) tags.zone_enabled = 'true';

        await sendTags(tags);
        try { await updateProfile?.({ push_notifications_enabled: true }); } catch {}
      }
    } finally {
      if (seenKey) localStorage.setItem(seenKey, '1');
      setLoading(false);
      setOpen(false);
    }
  };

  const handleLater = () => {
    if (seenKey) localStorage.setItem(seenKey, '1');
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Разреши известия</DialogTitle>
          <DialogDescription>
            Получавай напомняния за хидратация, тренировки и менюта. Можеш да промениш това по-късно от Настройки.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter className="gap-2 sm:gap-0">
          <Button variant="secondary" onClick={handleLater} disabled={loading}>
            По-късно
          </Button>
          <Button onClick={handleEnable} disabled={loading}>
            {loading ? 'Молим за разрешение…' : 'Разреши'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default NotificationsOnboarding;
