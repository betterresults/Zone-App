import { ReactNode, useEffect } from 'react';
import { useTheme } from '@/hooks/useTheme';

interface ThemeProviderProps {
  children: ReactNode;
}

export const ThemeProvider = ({ children }: ThemeProviderProps) => {
  const { loadActiveTheme } = useTheme();

  useEffect(() => {
    // Load active theme immediately to prevent color flashing
    const loadTheme = async () => {
      await loadActiveTheme();
    };
    loadTheme();
  }, [loadActiveTheme]);

  return <>{children}</>;
};
