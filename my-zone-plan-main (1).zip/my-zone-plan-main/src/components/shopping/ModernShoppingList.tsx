import { useState } from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
  ShoppingCart, 
  Check, 
  Package, 
  ArrowLeft, 
  Archive,
  Bookmark,
  Apple,
  Beef,
  Milk,
  Coffee,
  Cookie,
  IceCream,
  MoreVertical,
  ChevronRight,
  Plus,
  Trash2
} from 'lucide-react';
import { ShoppingList, ShoppingListItem } from '@/hooks/useShoppingLists';
import { format } from 'date-fns';
import { bg } from 'date-fns/locale';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';

interface ModernShoppingListProps {
  list: ShoppingList;
  onBack: () => void;
  onToggleItem: (itemId: string, field: 'is_purchased' | 'is_available') => void;
  onArchive: (listId: string) => void;
  onSaveAsTemplate: (listId: string, templateName: string) => void;
  onDeleteItem: (itemId: string) => void;
}

const CATEGORY_ICONS = {
  'fruits-vegetables': Apple,
  'vegetables': Apple,
  'meat-fish': Beef,
  'protein': Beef,
  'dairy-eggs': Milk,
  'dairy': Milk,
  'beverages': Coffee,
  'snacks': Cookie,
  'frozen': IceCream,
  'bread-bakery': Cookie,
  'legumes': Package,
  'fats': Package,
  'other': Package,
};

const PRODUCT_ICONS = {
  'avocado': '🥑',
  'apple': '🍎',
  'banana': '🍌',
  'carrot': '🥕',
  'tomato': '🍅',
  'onion': '🧅',
  'potato': '🥔',
  'bread': '🍞',
  'milk': '🥛',
  'cheese': '🧀',
  'chicken': '🍗',
  'beef': '🥩',
  'fish': '🐟',
  'egg': '🥚',
  'rice': '🍚',
  'pasta': '🍝',
  'oil': '🫒',
  'water': '💧',
  'coffee': '☕',
  'tea': '🍵',
  'default': '📦'
};

const getProductIcon = (productName: string) => {
  const name = productName?.toLowerCase() || '';
  
  if (name.includes('авокадо') || name.includes('avocado')) return PRODUCT_ICONS.avocado;
  if (name.includes('ябълка') || name.includes('apple')) return PRODUCT_ICONS.apple;
  if (name.includes('банан') || name.includes('banana')) return PRODUCT_ICONS.banana;
  if (name.includes('морков') || name.includes('carrot')) return PRODUCT_ICONS.carrot;
  if (name.includes('домат') || name.includes('tomato')) return PRODUCT_ICONS.tomato;
  if (name.includes('лук') || name.includes('onion')) return PRODUCT_ICONS.onion;
  if (name.includes('картоф') || name.includes('potato')) return PRODUCT_ICONS.potato;
  if (name.includes('хляб') || name.includes('bread')) return PRODUCT_ICONS.bread;
  if (name.includes('мляко') || name.includes('milk')) return PRODUCT_ICONS.milk;
  if (name.includes('сирене') || name.includes('cheese')) return PRODUCT_ICONS.cheese;
  if (name.includes('пиле') || name.includes('chicken')) return PRODUCT_ICONS.chicken;
  if (name.includes('говеждо') || name.includes('beef')) return PRODUCT_ICONS.beef;
  if (name.includes('риба') || name.includes('fish')) return PRODUCT_ICONS.fish;
  if (name.includes('яйце') || name.includes('egg')) return PRODUCT_ICONS.egg;
  if (name.includes('ориз') || name.includes('rice')) return PRODUCT_ICONS.rice;
  if (name.includes('паста') || name.includes('pasta')) return PRODUCT_ICONS.pasta;
  if (name.includes('олио') || name.includes('oil')) return PRODUCT_ICONS.oil;
  if (name.includes('вода') || name.includes('water')) return PRODUCT_ICONS.water;
  if (name.includes('кафе') || name.includes('coffee')) return PRODUCT_ICONS.coffee;
  if (name.includes('чай') || name.includes('tea')) return PRODUCT_ICONS.tea;
  
  return PRODUCT_ICONS.default;
};

// Image resolver with robust fallbacks and local mapping
const LOCAL_PRODUCT_IMAGES: Record<string, string> = {
  carrot: '/products/carrots.jpg',
  eggplant: '/products/eggplants.jpg',
  onion: '/products/onions.jpg',
  zucchini: '/products/zucchini.jpg',
  beef: '/products/beef-lean.jpg',
  turkey: '/products/turkey-fillet.jpg',
};

const getProductImage = (product: any): string | null => {
  const p = product || {};
  const direct = p.image_url || p.imageUrl || p.image || p.photo_url || p.photoUrl;
  if (typeof direct === 'string' && direct.trim()) return direct;

  if (Array.isArray(p.image_urls) && p.image_urls[0]) return p.image_urls[0];
  if (Array.isArray(p.images) && p.images[0]) {
    const img = p.images[0];
    if (typeof img === 'string') return img;
    if (img?.url) return img.url;
  }

  const name: string = (p.name || '').toLowerCase();
  if (name.includes('морков') || name.includes('carrot')) return LOCAL_PRODUCT_IMAGES.carrot;
  if (name.includes('патладжан') || name.includes('eggplant')) return LOCAL_PRODUCT_IMAGES.eggplant;
  if (name.includes('лук') || name.includes('onion')) return LOCAL_PRODUCT_IMAGES.onion;
  if (name.includes('тиквич')) return LOCAL_PRODUCT_IMAGES.zucchini;
  if (name.includes('zucchini')) return LOCAL_PRODUCT_IMAGES.zucchini;
  if (name.includes('говеждо') || name.includes('beef')) return LOCAL_PRODUCT_IMAGES.beef;
  if (name.includes('пуеш') || name.includes('turkey')) return LOCAL_PRODUCT_IMAGES.turkey;

  return null;
};

// Category normalization helpers
const CATEGORY_MAP: Record<string, string> = {
  'fruits-vegetables': 'fruits-vegetables',
  'vegetables': 'vegetables',
  'fruits': 'fruits',
  'meat-fish': 'meat-fish',
  'meat': 'meat',
  'fish': 'fish',
  'protein': 'protein',
  'dairy-eggs': 'dairy-eggs',
  'dairy': 'dairy',
  'eggs': 'dairy-eggs',
  'bread-bakery': 'bread-bakery',
  'bakery': 'bread-bakery',
  'beverages': 'beverages',
  'drinks': 'beverages',
  'snacks': 'snacks',
  'frozen': 'frozen',
  'legumes': 'legumes',
  'beans': 'legumes',
  'nuts': 'nuts',
  'fats': 'fats',
  'oil': 'fats',
  'spices': 'spices',
  'sweets': 'sweets',
  'other': 'other',
  'others': 'other',
  'misc': 'other',
  'други': 'other'
};

const normalizeCategory = (raw?: string) => {
  if (!raw) return 'other';
  const key = raw.toString().trim().toLowerCase().replace(/[_\s]+/g, '-');
  return CATEGORY_MAP[key] || CATEGORY_MAP[key.replace(/s$/, '')] || 'other';
};

const getCategoryFromProduct = (product: any) => {
  const raw =
    (product?.custom_category && product.custom_category.trim()) ? product.custom_category :
    product?.category;

  return normalizeCategory(raw);
};

const CATEGORY_LABELS: Record<string, string> = {
  'fruits-vegetables': 'Плодове и зеленчуци',
  'vegetables': 'Зеленчуци',
  'fruits': 'Плодове',
  'meat-fish': 'Месо и риба',
  'meat': 'Месо',
  'fish': 'Риба',
  'protein': 'Протеини',
  'dairy-eggs': 'Млечни и яйца',
  'dairy': 'Млечни продукти',
  'bread-bakery': 'Хляб и тестени изделия',
  'beverages': 'Напитки',
  'snacks': 'Закуски',
  'frozen': 'Замразени продукти',
  'legumes': 'Бобови',
  'nuts': 'Ядки',
  'fats': 'Мазнини',
  'spices': 'Подправки',
  'sweets': 'Сладки',
  'other': 'Други',
};

const getCategoryLabel = (category: string) => {
  const key = normalizeCategory(category);
  return CATEGORY_LABELS[key] || 'Други';
};

export function ModernShoppingList({ 
  list, 
  onBack, 
  onToggleItem, 
  onArchive, 
  onSaveAsTemplate,
  onDeleteItem
}: ModernShoppingListProps) {
  const [showSaveTemplate, setShowSaveTemplate] = useState(false);
  const [templateName, setTemplateName] = useState('');


  const handleSaveTemplate = () => {
    if (templateName.trim()) {
      onSaveAsTemplate(list.id, templateName.trim());
      setTemplateName('');
      setShowSaveTemplate(false);
    }
  };

  // Group items by category using direct category from product
  const itemsByCategory = (list.items || []).reduce((acc, item) => {
    const category = getCategoryFromProduct(item.product);
    if (!acc[category]) acc[category] = [];
    acc[category].push(item);
    return acc;
  }, {} as Record<string, ShoppingListItem[]>);

  // Separate all items into active and completed
  const allActiveItems = (list.items || []).filter(item => !item.is_purchased && !item.is_available);
  const allCompletedItems = (list.items || []).filter(item => item.is_purchased || item.is_available);

  // Group active items by category
  const activeByCategory = allActiveItems.reduce((acc, item) => {
    const category = getCategoryFromProduct(item.product);
    if (!acc[category]) acc[category] = [];
    acc[category].push(item);
    return acc;
  }, {} as Record<string, ShoppingListItem[]>);

  // Sort categories to show non-empty ones first, with "Други" at the bottom
  const sortedActiveCategories = Object.entries(activeByCategory)
    .filter(([,items]) => items.length > 0)
    .sort(([categoryA,itemsA], [categoryB,itemsB]) => {
      // Put "other" category at the bottom
      if (categoryA === 'other') return 1;
      if (categoryB === 'other') return -1;
      // Sort by number of items descending
      return itemsB.length - itemsA.length;
    });

  const totalItems = list.total_items_count || 0;
  const completedItems = list.completed_items_count || 0;
  const progressPercent = totalItems > 0 ? Math.round((completedItems / totalItems) * 100) : 0;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="sm"
            onClick={onBack}
            className="p-2"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">{list.name}</h1>
            <p className="text-sm text-muted-foreground">
              {format(new Date(list.week_start_date), 'dd.MM', { locale: bg })} - {format(new Date(list.week_end_date), 'dd.MM', { locale: bg })}
            </p>
          </div>
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="p-2">
              <MoreVertical className="w-5 h-5" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => setShowSaveTemplate(true)}>
              <Bookmark className="w-4 h-4 mr-2" />
              Запази като шаблон
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onArchive(list.id)}>
              <Archive className="w-4 h-4 mr-2" />
              Архивирай
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Progress */}
      <Card className="bg-gradient-to-r from-primary/5 to-primary/10 border-primary/20">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <ShoppingCart className="w-5 h-5 text-primary" />
              <span className="font-medium">Прогрес</span>
            </div>
            <div className="text-2xl font-bold text-primary">
              {completedItems}/{totalItems}
            </div>
          </div>
          <div className="w-full bg-white/50 rounded-full h-3">
            <div 
              className="bg-primary h-3 rounded-full transition-all duration-500" 
              style={{ width: `${progressPercent}%` }}
            />
          </div>
          <p className="text-sm text-muted-foreground mt-2">
            {progressPercent}% завършено
          </p>
        </CardContent>
      </Card>

      {/* Categories */}
      {allActiveItems.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-full bg-primary/10">
                  <ShoppingCart className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">За купуване</h3>
                  <p className="text-sm text-muted-foreground">
                    {allActiveItems.length} продукта
                  </p>
                </div>
              </div>
            </div>
          </CardHeader>
            
          <CardContent className="pt-0 space-y-4">
            {sortedActiveCategories.map(([category, items]) => {
              const label = getCategoryLabel(category);
              
              return (
                <div key={category} className="space-y-2">
                  <div className="flex items-center gap-2 px-2">
                    <h4 className="font-medium text-sm">{label} ({items.length})</h4>
                  </div>
                  
                  <div className="space-y-2">
                    {items.map((item) => (
                      <div key={item.id} className="flex items-center gap-3 p-3 rounded-lg border bg-background">
                        <div className="w-10 h-10 rounded-lg bg-muted/50 flex items-center justify-center overflow-hidden">
                          {getProductImage(item.product) ? (
                            <img
                              src={getProductImage(item.product) as string}
                              alt={item.product?.name || 'Продукт'}
                              className="w-full h-full object-cover"
                              loading="lazy"
                            />
                          ) : (
                            <span className="text-lg">{getProductIcon(item.product?.name || '')}</span>
                          )}
                        </div>
                        
                        <div className="flex-1">
                          <div className="font-medium">{item.product?.name}</div>
                        </div>
                        
                        <div className="flex items-center gap-1">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => onToggleItem(item.id, 'is_available')}
                            className="h-8 w-8 p-0"
                            title="Имам го вкъщи"
                          >
                            <Package className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => onToggleItem(item.id, 'is_purchased')}
                            className="h-8 w-8 p-0"
                            title="Купено"
                          >
                            <Check className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => onDeleteItem(item.id)}
                            className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                            title="Премахни"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}

      {/* Completed Items - Always at the bottom */}
      {allCompletedItems.length > 0 && (
        <Card className="opacity-60">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-full bg-muted">
                <Check className="w-5 h-5 text-muted-foreground" />
              </div>
              <div>
                <h3 className="font-semibold text-muted-foreground">Завършени</h3>
                <p className="text-sm text-muted-foreground">
                  {allCompletedItems.length} продукта
                </p>
              </div>
            </div>
          </CardHeader>
            
          <CardContent className="pt-0 space-y-2">
            {allCompletedItems.map((item) => (
              <div key={item.id} className="flex items-center gap-3 p-3 rounded-lg border bg-muted/30">
                <div className="w-10 h-10 rounded-lg bg-muted/50 flex items-center justify-center overflow-hidden grayscale">
                  {getProductImage(item.product) ? (
                    <img 
                      src={getProductImage(item.product) as string} 
                      alt={item.product?.name || 'Продукт'}
                      className="w-full h-full object-cover"
                      loading="lazy"
                    />
                  ) : (
                    <span className="text-lg">{getProductIcon(item.product?.name || '')}</span>
                  )}
                </div>
                
                <div className="flex-1">
                  <div className="font-medium line-through">{item.product?.name}</div>
                </div>
                
                <div className="flex items-center gap-1">
                  {item.is_available && (
                    <div className="w-6 h-6 rounded-full bg-secondary flex items-center justify-center">
                      <Package className="w-3 h-3" />
                    </div>
                  )}
                  {item.is_purchased && (
                    <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center">
                      <Check className="w-3 h-3" />
                    </div>
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {totalItems === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <ShoppingCart className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
            <p className="text-muted-foreground">Няма продукти в списъка</p>
          </CardContent>
        </Card>
      )}

      {/* Save as Template Dialog */}
      <Dialog open={showSaveTemplate} onOpenChange={setShowSaveTemplate}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Запази като шаблон</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Име на шаблона</label>
              <Input
                placeholder="Например: Седмично пазаруване"
                value={templateName}
                onChange={(e) => setTemplateName(e.target.value)}
              />
            </div>
            <Button onClick={handleSaveTemplate} className="w-full">
              Запази шаблон
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}