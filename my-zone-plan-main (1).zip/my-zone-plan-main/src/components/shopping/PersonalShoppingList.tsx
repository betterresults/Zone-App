import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, ShoppingCart, Check, Package, Search, Trash2, MoreVertical } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface PersonalShoppingListItem {
  id: string;
  product_name: string;
  category: string;
  quantity_grams: number;
  is_purchased: boolean;
  is_available: boolean;
  notes?: string;
}

interface PersonalShoppingList {
  id: string;
  name: string;
  items: PersonalShoppingListItem[];
  created_at: string;
}

const PRODUCT_CATEGORIES = [
  { value: 'bread-bakery', label: 'Хляб и тестени изделия' },
  { value: 'dairy-eggs', label: 'Мляко и яйца' },
  { value: 'fruits-vegetables', label: 'Плодове и зеленчуци' },
  { value: 'meat-fish', label: 'Месо и риба' },
  { value: 'beverages', label: 'Напитки' },
  { value: 'snacks', label: 'Закуски' },
  { value: 'frozen', label: 'Замразени продукти' },
  { value: 'other', label: 'Други' }
];

export function PersonalShoppingList() {
  const [selectedList, setSelectedList] = useState<string | null>(null);
  const [showCreateList, setShowCreateList] = useState(false);
  const [showAddItem, setShowAddItem] = useState(false);
  const [newListName, setNewListName] = useState('');
  const [newItemName, setNewItemName] = useState('');
  const [newItemCategory, setNewItemCategory] = useState('');
  const [newItemQuantity, setNewItemQuantity] = useState<number>(100);
  const [searchTerm, setSearchTerm] = useState('');
  const queryClient = useQueryClient();

  // Fetch personal shopping lists
  const { data: personalLists = [], isLoading } = useQuery({
    queryKey: ['personal-shopping-lists'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      // For now, we'll simulate personal lists in localStorage
      // In a real app, you'd have a separate table for personal shopping lists
      const stored = localStorage.getItem(`personal-shopping-lists-${user.id}`);
      return stored ? JSON.parse(stored) : [];
    }
  });

  // Fetch products for suggestions
  const { data: products = [] } = useQuery({
    queryKey: ['products-for-suggestions', searchTerm],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      let query = supabase
        .from('products')
        .select('id, name, category')
        .or(`is_public.eq.true,user_id.eq.${user.id}`)
        .order('name');

      if (searchTerm) {
        query = query.ilike('name', `%${searchTerm}%`);
      }

      const { data, error } = await query.limit(10);
      if (error) throw error;
      return data || [];
    },
    enabled: showAddItem && searchTerm.length > 0
  });

  const selectedListData = selectedList ? personalLists.find((list: PersonalShoppingList) => list.id === selectedList) : null;

  const formatWeight = (grams: number) => {
    if (grams >= 1000) {
      return `${(grams / 1000).toFixed(1)} кг`;
    }
    return `${Math.round(grams)} г`;
  };

  const saveToStorage = async (lists: PersonalShoppingList[]) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      localStorage.setItem(`personal-shopping-lists-${user.id}`, JSON.stringify(lists));
      queryClient.invalidateQueries({ queryKey: ['personal-shopping-lists'] });
    }
  };

  const handleCreateList = async () => {
    if (!newListName.trim()) return;

    const newList: PersonalShoppingList = {
      id: Date.now().toString(),
      name: newListName,
      items: [],
      created_at: new Date().toISOString()
    };

    const updatedLists = [...personalLists, newList];
    await saveToStorage(updatedLists);
    setNewListName('');
    setShowCreateList(false);
    toast.success('Списъкът е създаден!');
  };

  const handleAddItem = async () => {
    if (!newItemName.trim() || !selectedList) return;

    const newItem: PersonalShoppingListItem = {
      id: Date.now().toString(),
      product_name: newItemName,
      category: newItemCategory || 'other',
      quantity_grams: newItemQuantity,
      is_purchased: false,
      is_available: false,
      notes: ''
    };

    const updatedLists = personalLists.map((list: PersonalShoppingList) =>
      list.id === selectedList
        ? { ...list, items: [...list.items, newItem] }
        : list
    );

    await saveToStorage(updatedLists);
    setNewItemName('');
    setNewItemCategory('');
    setNewItemQuantity(100);
    setShowAddItem(false);
    toast.success('Продуктът е добавен!');
  };

  const handleAddFromProduct = async (product: any) => {
    if (!selectedList) return;

    const newItem: PersonalShoppingListItem = {
      id: Date.now().toString(),
      product_name: product.name,
      category: product.category || 'other',
      quantity_grams: 100,
      is_purchased: false,
      is_available: false,
      notes: ''
    };

    const updatedLists = personalLists.map((list: PersonalShoppingList) =>
      list.id === selectedList
        ? { ...list, items: [...list.items, newItem] }
        : list
    );

    await saveToStorage(updatedLists);
    setSearchTerm('');
    toast.success('Продуктът е добавен!');
  };

  const handleToggleItem = async (itemId: string, field: 'is_purchased' | 'is_available') => {
    if (!selectedList) return;

    const updatedLists = personalLists.map((list: PersonalShoppingList) =>
      list.id === selectedList
        ? {
            ...list,
            items: list.items.map(item =>
              item.id === itemId
                ? { ...item, [field]: !item[field] }
                : item
            )
          }
        : list
    );

    await saveToStorage(updatedLists);
  };

  const handleDeleteList = async (listId: string) => {
    const updatedLists = personalLists.filter((list: PersonalShoppingList) => list.id !== listId);
    await saveToStorage(updatedLists);
    if (selectedList === listId) {
      setSelectedList(null);
    }
    toast.success('Списъкът е изтрит!');
  };

  const handleDeleteItem = async (itemId: string) => {
    if (!selectedList) return;

    const updatedLists = personalLists.map((list: PersonalShoppingList) =>
      list.id === selectedList
        ? { ...list, items: list.items.filter(item => item.id !== itemId) }
        : list
    );

    await saveToStorage(updatedLists);
    toast.success('Продуктът е премахнат!');
  };

  const getItemsByCategory = (items: PersonalShoppingListItem[]) => {
    const active = items.filter(item => !item.is_purchased && !item.is_available);
    const completed = items.filter(item => item.is_purchased || item.is_available);
    
    const groupByCategory = (items: PersonalShoppingListItem[]) => {
      return items.reduce((acc, item) => {
        const category = PRODUCT_CATEGORIES.find(cat => cat.value === item.category)?.label || 'Други';
        if (!acc[category]) acc[category] = [];
        acc[category].push(item);
        return acc;
      }, {} as Record<string, PersonalShoppingListItem[]>);
    };

    return {
      active: groupByCategory(active),
      completed: groupByCategory(completed)
    };
  };

  if (selectedListData) {
    const { active, completed } = getItemsByCategory(selectedListData.items);
    
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setSelectedList(null)}
            >
              ← Назад
            </Button>
            <div>
              <h1 className="text-3xl font-bold">{selectedListData.name}</h1>
              <p className="text-muted-foreground">Личен списък за пазаруване</p>
            </div>
          </div>
          
          <Dialog open={showAddItem} onOpenChange={setShowAddItem}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Добави продукт
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Добави продукт</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Търси продукт</label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                    <Input
                      placeholder="Търси в продуктите..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  {products.length > 0 && (
                    <div className="border rounded-lg max-h-40 overflow-y-auto">
                      {products.map((product) => (
                        <div
                          key={product.id}
                          className="p-2 hover:bg-accent cursor-pointer flex justify-between items-center"
                          onClick={() => handleAddFromProduct(product)}
                        >
                          <span>{product.name}</span>
                          <Plus className="w-4 h-4" />
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                
                <Separator />
                
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Или въведи ръчно</label>
                    <Input
                      placeholder="Име на продукт..."
                      value={newItemName}
                      onChange={(e) => setNewItemName(e.target.value)}
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium">Категория</label>
                    <Select value={newItemCategory} onValueChange={setNewItemCategory}>
                      <SelectTrigger>
                        <SelectValue placeholder="Избери категория" />
                      </SelectTrigger>
                      <SelectContent>
                        {PRODUCT_CATEGORIES.map((category) => (
                          <SelectItem key={category.value} value={category.value}>
                            {category.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium">Количество (грамове)</label>
                    <Input
                      type="number"
                      value={newItemQuantity}
                      onChange={(e) => setNewItemQuantity(parseFloat(e.target.value) || 100)}
                    />
                  </div>
                  
                  <Button onClick={handleAddItem} className="w-full">
                    Добави продукт
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Active Items by Category */}
        {Object.keys(active).map((category) => (
          <Card key={category}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShoppingCart className="w-5 h-5" />
                {category} ({active[category].length})
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {active[category].map((item) => (
                <div key={item.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <div className="font-medium">{item.product_name}</div>
                    <div className="text-sm text-muted-foreground">
                      {formatWeight(item.quantity_grams)}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleToggleItem(item.id, 'is_available')}
                      className="text-xs"
                    >
                      <Package className="w-3 h-3 mr-1" />
                      Имам
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleToggleItem(item.id, 'is_purchased')}
                      className="text-xs"
                    >
                      <Check className="w-3 h-3 mr-1" />
                      Купено
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDeleteItem(item.id)}
                      className="text-destructive"
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        ))}

        {/* Completed Items */}
        {Object.keys(completed).length > 0 && (
          <>
            <Separator />
            {Object.keys(completed).map((category) => (
              <Card key={category}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-muted-foreground">
                    <Check className="w-5 h-5" />
                    {category} - Завършени ({completed[category].length})
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {completed[category].map((item) => (
                    <div key={item.id} className="flex items-center justify-between p-3 border rounded-lg bg-muted/30 opacity-60">
                      <div className="flex-1">
                        <div className="font-medium line-through">{item.product_name}</div>
                        <div className="text-sm text-muted-foreground">
                          {formatWeight(item.quantity_grams)}
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        {item.is_available && <Badge variant="secondary">Имам</Badge>}
                        {item.is_purchased && <Badge variant="default">Купено</Badge>}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            handleToggleItem(item.id, 'is_available');
                            handleToggleItem(item.id, 'is_purchased');
                          }}
                        >
                          Върни
                        </Button>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            ))}
          </>
        )}

        {selectedListData.items.length === 0 && (
          <Card>
            <CardContent className="text-center py-8">
              <ShoppingCart className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground">Няма продукти в списъка</p>
            </CardContent>
          </Card>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Лични списъци</h1>
        </div>
        
        <Dialog open={showCreateList} onOpenChange={setShowCreateList}>
          <DialogTrigger asChild>
            <Button className="md:hidden h-10 w-10 p-0">
              <Plus className="w-5 h-5" />
            </Button>
          </DialogTrigger>
          <DialogTrigger asChild>
            <Button className="hidden md:flex">
              <Plus className="w-4 h-4 mr-2" />
              Нов списък
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Създай нов списък</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <Input
                placeholder="Име на списъка..."
                value={newListName}
                onChange={(e) => setNewListName(e.target.value)}
              />
              <Button onClick={handleCreateList} className="w-full">
                Създай списък
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {personalLists.length === 0 ? (
        <Card>
          <CardContent className="text-center py-8">
            <ShoppingCart className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <p className="text-muted-foreground">Няма създадени лични списъци</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {personalLists.map((list: PersonalShoppingList) => (
            <Card key={list.id} className="cursor-pointer hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex-1" onClick={() => setSelectedList(list.id)}>
                    <h3 className="text-lg font-medium">{list.name}</h3>
                    <div className="text-sm text-muted-foreground">
                      Личен списък • {list.items.length} продукта
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <div className="text-right" onClick={() => setSelectedList(list.id)}>
                      <div className="text-2xl font-bold">
                        {list.items.filter(item => item.is_purchased || item.is_available).length}/{list.items.length}
                      </div>
                      <div className="text-sm text-muted-foreground">завършени</div>
                    </div>
                    
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="p-2">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem 
                          onClick={() => handleDeleteList(list.id)}
                          className="text-destructive"
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Изтрий списък
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}