import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { format, startOfWeek, addDays, isSameDay, isToday } from 'date-fns';
import { bg } from 'date-fns/locale';
import { Plus } from 'lucide-react';
import { CalendarEventCard } from './CalendarEventCard';

interface WeekViewProps {
  selectedDate: Date;
  onDateSelect: (date: Date) => void;
  events: any[];
  habits: any[];
  getEventsForDate: (date: Date) => any[];
  isHabitActiveOnDay: (habit: any, date: Date) => boolean;
  onAddEvent: () => void;
  onEditEvent?: (event: any) => void;
  onDuplicateEvent?: (event: any) => void;
  deleteEvent: (id: string) => Promise<void>;
}

export function WeekView({ 
  selectedDate, 
  onDateSelect, 
  events, 
  habits,
  getEventsForDate, 
  isHabitActiveOnDay,
  onAddEvent,
  onEditEvent,
  onDuplicateEvent,
  deleteEvent
}: WeekViewProps) {
  const weekStart = startOfWeek(selectedDate, { weekStartsOn: 1 });
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));

  const selectedDateEvents = getEventsForDate(selectedDate);

  return (
    <div className="space-y-6">
      {/* Calendar Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-7 gap-2">
      {/* Mobile: Split into two rows */}
      <div className="sm:hidden grid grid-cols-4 gap-2">
        {weekDays.slice(0, 4).map((day, index) => {
          const dayEvents = getEventsForDate(day);
          const dayHabits = habits.filter(habit => isHabitActiveOnDay(habit, day));
          const isSelected = isSameDay(day, selectedDate);
          const isDayToday = isToday(day);
          
          return (
            <Card 
              key={index}
              className={`p-2 cursor-pointer transition-all border-2 min-h-[120px] ${
                isSelected 
                  ? 'border-primary bg-primary/5' 
                  : 'border-border hover:border-primary/50'
              } ${isDayToday ? 'ring-2 ring-primary/30' : ''}`}
              onClick={() => onDateSelect(day)}
            >
              <div className="flex flex-col h-full">
                {/* Day header */}
                <div className="text-center mb-2 pb-1 border-b">
                  <div className="text-xs text-muted-foreground uppercase">
                    {format(day, 'EEE', { locale: bg })}
                  </div>
                  <div className={`text-sm font-bold ${
                    isDayToday ? 'text-primary' : 'text-foreground'
                  }`}>
                    {format(day, 'd')}
                  </div>
                </div>

                {/* Events and habits */}
                <div className="flex-1 space-y-1">
                  {dayEvents.slice(0, 1).map((event) => (
                    <div key={event.id} className="text-xs p-1 bg-blue-100 text-blue-800 rounded truncate">
                      {event.title}
                    </div>
                  ))}
                  
                  {dayHabits.slice(0, 1).map((habit) => (
                    <div key={habit.id} className="text-xs p-1 bg-green-100 text-green-800 rounded truncate">
                      {habit.name}
                    </div>
                  ))}
                  
                  {(dayEvents.length > 1 || dayHabits.length > 1) && (
                    <div className="text-xs text-muted-foreground text-center">
                      +{Math.max(0, dayEvents.length - 1) + Math.max(0, dayHabits.length - 1)}
                    </div>
                  )}
                </div>

                {/* Add button */}
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full mt-1 h-5 text-xs"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDateSelect(day);
                    onAddEvent();
                  }}
                >
                  <Plus className="w-3 h-3" />
                </Button>
              </div>
            </Card>
          );
        })}
      </div>
      
      <div className="sm:hidden grid grid-cols-3 gap-2">
        {weekDays.slice(4).map((day, index) => {
          const dayEvents = getEventsForDate(day);
          const dayHabits = habits.filter(habit => isHabitActiveOnDay(habit, day));
          const isSelected = isSameDay(day, selectedDate);
          const isDayToday = isToday(day);
          
          return (
            <Card 
              key={index + 4}
              className={`p-2 cursor-pointer transition-all border-2 min-h-[120px] ${
                isSelected 
                  ? 'border-primary bg-primary/5' 
                  : 'border-border hover:border-primary/50'
              } ${isDayToday ? 'ring-2 ring-primary/30' : ''}`}
              onClick={() => onDateSelect(day)}
            >
              <div className="flex flex-col h-full">
                {/* Day header */}
                <div className="text-center mb-2 pb-1 border-b">
                  <div className="text-xs text-muted-foreground uppercase">
                    {format(day, 'EEE', { locale: bg })}
                  </div>
                  <div className={`text-sm font-bold ${
                    isDayToday ? 'text-primary' : 'text-foreground'
                  }`}>
                    {format(day, 'd')}
                  </div>
                </div>

                {/* Events and habits */}
                <div className="flex-1 space-y-1">
                  {dayEvents.slice(0, 1).map((event) => (
                    <div key={event.id} className="text-xs p-1 bg-blue-100 text-blue-800 rounded truncate">
                      {event.title}
                    </div>
                  ))}
                  
                  {dayHabits.slice(0, 1).map((habit) => (
                    <div key={habit.id} className="text-xs p-1 bg-green-100 text-green-800 rounded truncate">
                      {habit.name}
                    </div>
                  ))}
                  
                  {(dayEvents.length > 1 || dayHabits.length > 1) && (
                    <div className="text-xs text-muted-foreground text-center">
                      +{Math.max(0, dayEvents.length - 1) + Math.max(0, dayHabits.length - 1)}
                    </div>
                  )}
                </div>

                {/* Add button */}
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full mt-1 h-5 text-xs"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDateSelect(day);
                    onAddEvent();
                  }}
                >
                  <Plus className="w-3 h-3" />
                </Button>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Desktop: Normal 7-column grid */}
      {weekDays.map((day, index) => {
        const dayEvents = getEventsForDate(day);
        const dayHabits = habits.filter(habit => isHabitActiveOnDay(habit, day));
        const isSelected = isSameDay(day, selectedDate);
        const isDayToday = isToday(day);
        
        return (
          <Card 
            key={index}
            className={`hidden sm:block p-3 cursor-pointer transition-all border-2 min-h-[200px] ${
              isSelected 
                ? 'border-primary bg-primary/5' 
                : 'border-border hover:border-primary/50'
            } ${isDayToday ? 'ring-2 ring-primary/30' : ''}`}
            onClick={() => onDateSelect(day)}
          >
            <div className="flex flex-col h-full">
              {/* Day header */}
              <div className="text-center mb-3 pb-2 border-b">
                <div className="text-xs text-muted-foreground uppercase">
                  {format(day, 'EEE', { locale: bg })}
                </div>
                <div className={`text-lg font-bold ${
                  isDayToday ? 'text-primary' : 'text-foreground'
                }`}>
                  {format(day, 'd')}
                </div>
              </div>

              {/* Events and habits */}
              <div className="flex-1 space-y-1">
                {dayEvents.map((event) => (
                  <div key={event.id} className="text-xs p-1 bg-blue-100 text-blue-800 rounded truncate">
                    {event.start_time && (
                      <span className="font-medium">{event.start_time} </span>
                    )}
                    {event.title}
                  </div>
                ))}
                
                {dayHabits.map((habit) => (
                  <div key={habit.id} className="text-xs p-1 bg-green-100 text-green-800 rounded truncate">
                    {habit.time_of_day && (
                      <span className="font-medium">{habit.time_of_day} </span>
                    )}
                    {habit.name}
                  </div>
                ))}
              </div>

              {/* Add button */}
              <Button
                variant="ghost"
                size="sm"
                className="w-full mt-2 h-6 text-xs"
                onClick={(e) => {
                  e.stopPropagation();
                  onDateSelect(day);
                  onAddEvent();
                }}
              >
                <Plus className="w-3 h-3 mr-1" />
                Добави
              </Button>
            </div>
          </Card>
        );
      })}
      </div>

      {/* Selected Date Details */}
      {selectedDateEvents.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">
            Събития - {format(selectedDate, 'EEEE, dd MMMM', { locale: bg })}
          </h3>
          
          <div className="grid gap-3">
            {selectedDateEvents.map(event => (
              <CalendarEventCard
                key={event.id}
                event={event}
                onEdit={onEditEvent}
                onDuplicate={onDuplicateEvent}
                onDelete={() => deleteEvent(event.id)}
                compact={false}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}