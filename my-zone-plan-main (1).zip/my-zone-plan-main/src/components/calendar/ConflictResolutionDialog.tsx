import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Clock, AlertTriangle } from 'lucide-react';
import { format } from 'date-fns';
import { bg } from 'date-fns/locale';

interface Conflict {
  habit: any;
  event: any;
  time: string;
}

interface ConflictResolutionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  conflicts: Conflict[];
  eventData: any;
  selectedDate: Date;
  onResolve: (resolution: {
    type: 'change_event_time' | 'change_habit_time' | 'skip_habit' | 'ignore_conflict';
    newEventTime?: string;
    newHabitTime?: string;
    habitId?: string;
  }) => void;
}

export function ConflictResolutionDialog({
  open,
  onOpenChange,
  conflicts,
  eventData,
  selectedDate,
  onResolve
}: ConflictResolutionDialogProps) {
  const [resolution, setResolution] = useState<'change_event_time' | 'change_habit_time' | 'skip_habit' | 'ignore_conflict'>('change_event_time');
  const [newEventTime, setNewEventTime] = useState(eventData?.start_time || '');
  const [newHabitTime, setNewHabitTime] = useState('');
  const [selectedHabitId, setSelectedHabitId] = useState(conflicts[0]?.habit?.id || '');

  const handleResolve = () => {
    let resolutionData: any = { type: resolution };

    switch (resolution) {
      case 'change_event_time':
        resolutionData.newEventTime = newEventTime;
        break;
      case 'change_habit_time':
        resolutionData.newHabitTime = newHabitTime;
        resolutionData.habitId = selectedHabitId;
        break;
      case 'skip_habit':
        resolutionData.habitId = selectedHabitId;
        break;
      case 'ignore_conflict':
        // No additional data needed
        break;
    }

    onResolve(resolutionData);
    onOpenChange(false);
  };

  const conflict = conflicts[0]; // For now, handle first conflict
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-amber-600">
            <AlertTriangle className="w-5 h-5" />
            Конфликт във времето
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Conflict info */}
          <div className="p-4 bg-amber-50 dark:bg-amber-950/20 rounded-lg border border-amber-200 dark:border-amber-800">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-4 h-4 text-amber-600" />
              <span className="font-medium text-amber-800 dark:text-amber-200">
                {conflict?.time?.slice(0, 5)} - {format(selectedDate, 'dd MMMM', { locale: bg })}
              </span>
            </div>
            <div className="text-sm text-amber-700 dark:text-amber-300 space-y-1">
              <div><strong>Събитие:</strong> {eventData?.title}</div>
              <div><strong>Навик:</strong> {conflict?.habit?.name}</div>
            </div>
          </div>

          {/* Resolution options */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Как да разреша конфликта?</Label>

            {/* Change event time */}
            <div className="flex items-start gap-3">
              <input
                type="radio"
                id="change_event"
                name="resolution"
                value="change_event_time"
                checked={resolution === 'change_event_time'}
                onChange={(e) => setResolution(e.target.value as any)}
                className="mt-1"
              />
              <div className="flex-1">
                <label htmlFor="change_event" className="cursor-pointer font-medium">
                  Промени часа на събитието
                </label>
                {resolution === 'change_event_time' && (
                  <div className="mt-2">
                    <Input
                      type="time"
                      value={newEventTime}
                      onChange={(e) => setNewEventTime(e.target.value)}
                      className="w-32"
                    />
                  </div>
                )}
              </div>
            </div>

            {/* Change habit time for this day */}
            <div className="flex items-start gap-3">
              <input
                type="radio"
                id="change_habit"
                name="resolution"
                value="change_habit_time"
                checked={resolution === 'change_habit_time'}
                onChange={(e) => setResolution(e.target.value as any)}
                className="mt-1"
              />
              <div className="flex-1">
                <label htmlFor="change_habit" className="cursor-pointer font-medium">
                  Промени часа на навика само за този ден
                </label>
                {resolution === 'change_habit_time' && (
                  <div className="mt-2">
                    <Input
                      type="time"
                      value={newHabitTime}
                      onChange={(e) => setNewHabitTime(e.target.value)}
                      placeholder={conflict?.habit?.time_of_day}
                      className="w-32"
                    />
                  </div>
                )}
              </div>
            </div>

            {/* Skip habit for this day */}
            <div className="flex items-start gap-3">
              <input
                type="radio"
                id="skip_habit"
                name="resolution"
                value="skip_habit"
                checked={resolution === 'skip_habit'}
                onChange={(e) => setResolution(e.target.value as any)}
                className="mt-1"
              />
              <div className="flex-1">
                <label htmlFor="skip_habit" className="cursor-pointer font-medium">
                  Пропусни навика за този ден
                </label>
                <p className="text-sm text-muted-foreground mt-1">
                  Навикът няма да се показва за {format(selectedDate, 'dd MMMM', { locale: bg })}
                </p>
              </div>
            </div>

            {/* Ignore conflict */}
            <div className="flex items-start gap-3">
              <input
                type="radio"
                id="ignore"
                name="resolution"
                value="ignore_conflict"
                checked={resolution === 'ignore_conflict'}
                onChange={(e) => setResolution(e.target.value as any)}
                className="mt-1"
              />
              <div className="flex-1">
                <label htmlFor="ignore" className="cursor-pointer font-medium">
                  Създай въпреки конфликта
                </label>
                <p className="text-sm text-muted-foreground mt-1">
                  И двете активности ще са по същото време
                </p>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-2 pt-4">
            <Button variant="outline" onClick={() => onOpenChange(false)} className="flex-1">
              Отказ
            </Button>
            <Button 
              onClick={handleResolve} 
              className="flex-1"
              disabled={
                (resolution === 'change_event_time' && !newEventTime) ||
                (resolution === 'change_habit_time' && !newHabitTime)
              }
            >
              Приложи решението
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}