import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { format, startOfWeek, addDays, isSameDay, isToday } from 'date-fns';
import { bg } from 'date-fns/locale';
import { Plus, Clock, Calendar } from 'lucide-react';

interface MobileWeekListViewProps {
  selectedDate: Date;
  onDateSelect: (date: Date) => void;
  events: any[];
  habits: any[];
  getEventsForDate: (date: Date) => any[];
  isHabitActiveOnDay: (habit: any, date: Date) => boolean;
  onAddEvent: () => void;
  deleteEvent: (id: string) => Promise<void>;
}

export function MobileWeekListView({ 
  selectedDate, 
  onDateSelect, 
  events, 
  habits,
  getEventsForDate, 
  isHabitActiveOnDay,
  onAddEvent,
  deleteEvent
}: MobileWeekListViewProps) {
  const weekStart = startOfWeek(selectedDate, { weekStartsOn: 1 });
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));

  return (
    <div className="space-y-1">
      {weekDays.map((day, index) => {
        const dayEvents = getEventsForDate(day);
        const dayHabits = habits.filter(habit => isHabitActiveOnDay(habit, day));
        const isSelected = isSameDay(day, selectedDate);
        const isDayToday = isToday(day);
        
        // Combine and sort events and habits by time
        const allItems = [
          ...dayEvents.map(event => ({ 
            ...event, 
            type: 'event', 
            time: event.start_time || '00:00',
            title: event.title,
            color: 'bg-blue-50 text-blue-700'
          })),
          ...dayHabits.map(habit => ({ 
            ...habit, 
            type: 'habit', 
            time: habit.time_of_day || '00:00',
            title: habit.name,
            color: 'bg-green-50 text-green-700'
          }))
        ].sort((a, b) => a.time.localeCompare(b.time));
        
        const dayName = format(day, 'EEE', { locale: bg }).toUpperCase();
        
        return (
          <div 
            key={index}
            className={`flex items-center space-x-2 p-2 rounded-lg cursor-pointer transition-all border ${
              isSelected 
                ? 'border-primary bg-primary/5' 
                : 'border-border/50 hover:border-primary/50 hover:bg-muted/30'
            } ${isDayToday ? 'ring-1 ring-primary/50' : ''}`}
            onClick={() => onDateSelect(day)}
          >
            {/* Day indicator */}
            <div className="flex-shrink-0 w-10 text-center">
              <div className={`text-xs font-bold ${
                isDayToday ? 'text-primary' : 'text-muted-foreground'
              }`}>
                {dayName}
              </div>
              <div className="w-4 h-0.5 bg-border mx-auto mt-0.5" />
            </div>
            
            {/* Items list */}
            <div className="flex-1 min-w-0">
              {allItems.length > 0 ? (
                <div className="flex items-center gap-1">
                  {allItems.slice(0, 8).map((item, itemIndex) => (
                    <div 
                      key={`${item.type}-${item.id}-${itemIndex}`}
                      className={`w-3 h-3 rounded-sm ${
                        item.type === 'event' 
                          ? 'bg-blue-500' 
                          : 'bg-green-500'
                      }`}
                      title={`${item.time} - ${item.title}`}
                    />
                  ))}
                  {allItems.length > 8 && (
                    <div className="text-xs text-muted-foreground font-medium ml-1">
                      +{allItems.length - 8}
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex items-center">
                  <div className="w-3 h-0.5 bg-border/30" />
                </div>
              )}
            </div>
            
            {/* Add button */}
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0 flex-shrink-0"
              onClick={(e) => {
                e.stopPropagation();
                onDateSelect(day);
                onAddEvent();
              }}
            >
              <Plus className="w-3 h-3" />
            </Button>
          </div>
        );
      })}
    </div>
  );
}