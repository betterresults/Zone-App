import { Card } from '@/components/ui/card';
import { format, startOfYear, endOfYear, eachMonthOfInterval, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isToday, getMonth } from 'date-fns';
import { bg } from 'date-fns/locale';

interface YearViewProps {
  selectedDate: Date;
  onDateSelect: (date: Date) => void;
  events: any[];
  habits: any[];
  getEventsForDate: (date: Date) => any[];
  isHabitActiveOnDay: (habit: any, date: Date) => boolean;
}

export function YearView({ 
  selectedDate, 
  onDateSelect, 
  events, 
  habits,
  getEventsForDate, 
  isHabitActiveOnDay
}: YearViewProps) {
  const yearStart = startOfYear(selectedDate);
  const yearEnd = endOfYear(selectedDate);
  
  // Start from current month if we're in the current year
  const today = new Date();
  const isCurrentYear = selectedDate.getFullYear() === today.getFullYear();
  const startMonth = isCurrentYear ? today : yearStart;
  
  const months = eachMonthOfInterval({ start: startMonth, end: yearEnd });

  const getActivityCountForMonth = (month: Date) => {
    const monthStart = startOfMonth(month);
    const monthEnd = endOfMonth(month);
    const monthDays = eachDayOfInterval({ start: monthStart, end: monthEnd });
    
    let eventCount = 0;
    let habitCount = 0;
    
    monthDays.forEach(day => {
      eventCount += getEventsForDate(day).length;
      habitCount += habits.filter(habit => isHabitActiveOnDay(habit, day)).length;
    });
    
    return { eventCount, habitCount };
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      {months.map((month, index) => {
        const { eventCount, habitCount } = getActivityCountForMonth(month);
        const isCurrentMonth = getMonth(month) === getMonth(new Date()) && 
                              month.getFullYear() === new Date().getFullYear();
        const isSelectedMonth = getMonth(month) === getMonth(selectedDate);
        
        return (
          <Card 
            key={index}
            className={`p-4 cursor-pointer transition-all border-2 ${
              isSelectedMonth 
                ? 'border-primary bg-primary/5' 
                : 'border-border hover:border-primary/50'
            } ${isCurrentMonth ? 'ring-2 ring-primary/20' : ''}`}
            onClick={() => onDateSelect(month)}
          >
            <div className="text-center space-y-3">
              {/* Month name */}
              <h3 className={`font-bold text-lg ${
                isCurrentMonth ? 'text-primary' : 'text-foreground'
              }`}>
                {format(month, 'MMMM', { locale: bg })}
              </h3>
              
              {/* Activity summary */}
              <div className="space-y-2">
                {eventCount > 0 && (
                  <div className="flex items-center justify-center gap-2">
                    <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                    <span className="text-sm text-muted-foreground">
                      {eventCount} събитие{eventCount > 1 ? (eventCount > 4 ? 'я' : 'я') : ''}
                    </span>
                  </div>
                )}
                
                {habitCount > 0 && (
                  <div className="flex items-center justify-center gap-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span className="text-sm text-muted-foreground">
                      {habitCount} навик{habitCount > 1 ? (habitCount > 4 ? 'а' : 'а') : ''}
                    </span>
                  </div>
                )}
                
                {eventCount === 0 && habitCount === 0 && (
                  <span className="text-sm text-muted-foreground">
                    Няма активности
                  </span>
                )}
              </div>
              
              {/* Mini calendar preview */}
              <div className="grid grid-cols-7 gap-1 text-xs mt-2">
                {/* Week day headers */}
                {['П', 'В', 'С', 'Ч', 'П', 'С', 'Н'].map((day, idx) => (
                  <div key={idx} className="w-4 h-4 flex items-center justify-center text-muted-foreground font-medium">
                    {day}
                  </div>
                ))}
                
                {/* Empty cells for days before month start */}
                {Array.from({ length: (startOfMonth(month).getDay() + 6) % 7 }).map((_, idx) => (
                  <div key={`empty-${idx}`} className="w-4 h-4"></div>
                ))}
                
                {/* Month days */}
                {eachDayOfInterval({ 
                  start: startOfMonth(month), 
                  end: endOfMonth(month) 
                }).map((day, dayIndex) => {
                  const dayEvents = getEventsForDate(day).length;
                  const dayHabits = habits.filter(habit => isHabitActiveOnDay(habit, day)).length;
                  const hasActivity = dayEvents > 0 || dayHabits > 0;
                  const isDayToday = isToday(day);
                  
                  return (
                    <div 
                      key={dayIndex}
                      className={`w-4 h-4 flex items-center justify-center rounded-sm text-xs ${
                        isDayToday ? 'bg-primary text-white font-bold' :
                        hasActivity ? 'bg-accent text-accent-foreground' : 
                        'text-muted-foreground hover:bg-muted'
                      }`}
                    >
                      {format(day, 'd')}
                    </div>
                  );
                })}
              </div>
            </div>
          </Card>
        );
      })}
    </div>
  );
}