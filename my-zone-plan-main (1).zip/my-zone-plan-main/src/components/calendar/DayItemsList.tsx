import { format } from 'date-fns';
import { bg } from 'date-fns/locale';
import { CalendarEventCard } from './CalendarEventCard';
import { HabitCard } from './HabitCard';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface DayItemsListProps {
  selectedDate: Date;
  events: any[];
  habits: any[];
  tasks?: any[];
  onEditEvent: (event: any) => void;
  onDeleteEvent: (eventId: string) => void;
  onDuplicateEvent: (event: any) => void;
  onEditHabit: (habit: any) => void;
  onDeleteHabit: (habitId: string) => void;
  onDuplicateHabit: (habit: any) => void;
  onCompleteHabit: (habitId: string) => void;
  isHabitCompleted: (habitId: string, date: Date, completions: any[]) => boolean;
  habitCompletions: any[];
}

export const DayItemsList = ({
  selectedDate,
  events,
  habits,
  tasks = [],
  onEditEvent,
  onDeleteEvent,
  onDuplicateEvent,
  onEditHabit,
  onDeleteHabit,
  onDuplicateHabit,
  onCompleteHabit,
  isHabitCompleted,
  habitCompletions
}: DayItemsListProps) => {
  const dayName = format(selectedDate, 'EEEE, dd.MM.yyyy', { locale: bg });
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">
          События, навици и задачи за {dayName}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {events.length === 0 && habits.length === 0 && tasks.length === 0 ? (
          <p className="text-muted-foreground text-center py-6">
            Няма планирани дейности за този ден
          </p>
        ) : (
          <div className="space-y-3">
            {/* События */}
            {events.map((event) => (
              <CalendarEventCard
                key={event.id}
                event={event}
                onEdit={onEditEvent}
                onDelete={onDeleteEvent}
                onDuplicate={onDuplicateEvent}
              />
            ))}
            
            {/* Навици */}
            {habits.map((habit) => (
              <HabitCard
                key={habit.id}
                habit={habit}
                onEdit={onEditHabit}
                onDelete={onDeleteHabit}
                onDuplicate={onDuplicateHabit}
              />
            ))}
            
            {/* Задачи (ако има в бъдеще) */}
            {tasks.map((task) => (
              <div key={task.id} className="p-3 border rounded-lg">
                <div className="font-medium">{task.title}</div>
                {task.description && (
                  <div className="text-sm text-muted-foreground">{task.description}</div>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};