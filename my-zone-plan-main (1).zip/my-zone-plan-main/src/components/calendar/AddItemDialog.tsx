import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Calendar, Target, CheckSquare } from 'lucide-react';
import { useState } from 'react';
import { AddEventDialog } from './AddEventDialog';
import { AddHabitDialog } from '@/components/habits/AddHabitDialog';

interface AddItemDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedDate: Date;
  onEventCreate: (eventData: any) => void;
  onHabitCreate: (habitData: any) => void;
  isCreating: boolean;
}

export const AddItemDialog = ({
  open,
  onOpenChange,
  selectedDate,
  onEventCreate,
  onHabitCreate,
  isCreating
}: AddItemDialogProps) => {
  const [selectedType, setSelectedType] = useState<'event' | 'habit' | 'task' | null>(null);

  const handleClose = () => {
    setSelectedType(null);
    onOpenChange(false);
  };

  const handleEventCreate = async (eventData: any) => {
    await onEventCreate(eventData);
    handleClose();
  };

  const handleHabitCreate = async (habitData: any) => {
    await onHabitCreate(habitData);
    handleClose();
  };

  if (selectedType === 'event') {
    return (
      <AddEventDialog
        open={true}
        onOpenChange={handleClose}
        selectedDate={selectedDate}
        onSave={handleEventCreate}
        isLoading={isCreating}
      />
    );
  }

  if (selectedType === 'habit') {
    return (
      <AddHabitDialog
        open={true}
        onOpenChange={handleClose}
      />
    );
  }

  return (
        <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Какво искате да добавите?</DialogTitle>
        </DialogHeader>
        
        <div className="grid gap-3 py-4">
          <Button
            variant="outline"
            className="h-16 flex flex-col gap-2"
            onClick={() => setSelectedType('event')}
          >
            <Calendar className="h-6 w-6" />
            <span>Събитие</span>
          </Button>
          
          <Button
            variant="outline"
            className="h-16 flex flex-col gap-2"
            onClick={() => setSelectedType('habit')}
          >
            <Target className="h-6 w-6" />
            <span>Навик</span>
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};