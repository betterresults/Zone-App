import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CalendarIcon, Clock, Save, X, Bell } from 'lucide-react';
import { format } from 'date-fns';
import { NewCalendarEvent } from '@/hooks/useCalendarEvents';

interface AddEventDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedDate: Date;
  onSave: (eventData: NewCalendarEvent) => Promise<void>;
  isLoading?: boolean;
}

const eventTypeOptions = [
  { value: 'personal', label: 'Лично' },
  { value: 'meeting', label: 'Среща' },
  { value: 'appointment', label: 'Ангажимент' },
  { value: 'reminder', label: 'Напомняне' },
  { value: 'workout', label: 'Тренировка' },
  { value: 'health', label: 'Здраве' }
];

const colorOptions = [
  { value: '#8B5CF6', label: 'Лилав', color: '#8B5CF6' },
  { value: '#3B82F6', label: 'Син', color: '#3B82F6' },
  { value: '#10B981', label: 'Зелен', color: '#10B981' },
  { value: '#F59E0B', label: 'Жълт', color: '#F59E0B' },
  { value: '#EF4444', label: 'Червен', color: '#EF4444' },
  { value: '#8B5A2B', label: 'Кафяв', color: '#8B5A2B' }
];

export const AddEventDialog: React.FC<AddEventDialogProps> = ({
  open,
  onOpenChange,
  selectedDate,
  onSave,
  isLoading = false
}) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    start_time: '',
    end_time: '',
    event_type: 'personal',
    color: '#8B5CF6',
    all_day: false,
    reminder_enabled: false,
    reminder_minutes_before: 15
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title.trim()) return;

    const eventData: NewCalendarEvent = {
      title: formData.title.trim(),
      description: formData.description.trim() || undefined,
      event_date: selectedDate,
      start_time: formData.all_day ? undefined : formData.start_time || undefined,
      end_time: formData.all_day ? undefined : formData.end_time || undefined,
      event_type: formData.event_type,
      color: formData.color,
      all_day: formData.all_day,
      reminder_enabled: formData.reminder_enabled,
      reminder_minutes_before: formData.reminder_enabled ? formData.reminder_minutes_before : undefined
    };

    try {
      await onSave(eventData);
      // Reset form
      setFormData({
        title: '',
        description: '',
        start_time: '',
        end_time: '',
        event_type: 'personal',
        color: '#8B5CF6',
        all_day: false,
        reminder_enabled: false,
        reminder_minutes_before: 15
      });
      onOpenChange(false);
    } catch (error) {
      console.error('Error saving event:', error);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md mx-auto rounded-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CalendarIcon className="w-5 h-5" />
            Ново събитие
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="event-date" className="text-sm font-medium">
              Дата
            </Label>
            <div className="flex items-center gap-2 p-2 bg-muted rounded-lg">
              <CalendarIcon className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm">{format(selectedDate, 'dd.MM.yyyy')}</span>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="title" className="text-sm font-medium">
              Заглавие *
            </Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
              placeholder="Въведете заглавие..."
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-sm font-medium">
              Описание
            </Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Добавете описание..."
              rows={3}
            />
          </div>

          <div className="flex items-center justify-between">
            <Label htmlFor="all-day" className="text-sm font-medium">
              Целодневно събитие
            </Label>
            <Switch
              id="all-day"
              checked={formData.all_day}
              onCheckedChange={(checked) => setFormData(prev => ({ ...prev, all_day: checked }))}
            />
          </div>

          {!formData.all_day && (
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="start-time" className="text-sm font-medium">
                  Начален час
                </Label>
                <div className="relative">
                  <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="start-time"
                    type="time"
                    value={formData.start_time}
                    onChange={(e) => setFormData(prev => ({ ...prev, start_time: e.target.value }))}
                    className="pl-10"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="end-time" className="text-sm font-medium">
                  Краен час
                </Label>
                <div className="relative">
                  <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="end-time"
                    type="time"
                    value={formData.end_time}
                    onChange={(e) => setFormData(prev => ({ ...prev, end_time: e.target.value }))}
                    className="pl-10"
                  />
                </div>
              </div>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="event-type" className="text-sm font-medium">
              Тип събитие
            </Label>
            <Select value={formData.event_type} onValueChange={(value) => setFormData(prev => ({ ...prev, event_type: value }))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {eventTypeOptions.map(option => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-medium">Цвят</Label>
            <div className="flex gap-2">
              {colorOptions.map(option => (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => setFormData(prev => ({ ...prev, color: option.value }))}
                  className={`w-8 h-8 rounded-full border-2 transition-all ${
                    formData.color === option.value 
                      ? 'border-primary scale-110' 
                      : 'border-muted hover:scale-105'
                  }`}
                  style={{ backgroundColor: option.color }}
                  title={option.label}
                />
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="reminder-enabled" className="text-sm font-medium flex items-center gap-2">
                <Bell className="w-4 h-4" />
                Напомняне за събитието
              </Label>
              <Switch
                id="reminder-enabled"
                checked={formData.reminder_enabled}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, reminder_enabled: checked }))}
              />
            </div>

            {formData.reminder_enabled && (
              <div className="space-y-2">
                <Label htmlFor="reminder-time" className="text-sm font-medium">
                  Напомни преди
                </Label>
                <Select 
                  value={formData.reminder_minutes_before.toString()} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, reminder_minutes_before: parseInt(value) }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5">5 минути</SelectItem>
                    <SelectItem value="10">10 минути</SelectItem>
                    <SelectItem value="15">15 минути</SelectItem>
                    <SelectItem value="30">30 минути</SelectItem>
                    <SelectItem value="60">1 час</SelectItem>
                    <SelectItem value="120">2 часа</SelectItem>
                    <SelectItem value="1440">1 ден</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          <div className="flex gap-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1"
              disabled={isLoading}
            >
              <X className="w-4 h-4 mr-2" />
              Отказ
            </Button>
            <Button
              type="submit"
              className="flex-1"
              disabled={isLoading || !formData.title.trim()}
            >
              <Save className="w-4 h-4 mr-2" />
              {isLoading ? 'Запазване...' : 'Запази'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};