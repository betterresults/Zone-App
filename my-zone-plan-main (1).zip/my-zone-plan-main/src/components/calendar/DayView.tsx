import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { format, isToday, addDays, subDays } from 'date-fns';
import { bg } from 'date-fns/locale';
import { ChevronLeft, ChevronRight, Calendar, Clock } from 'lucide-react';
import { ActivitiesDisplay } from '@/components/activities/ActivitiesDisplay';

interface DayViewProps {
  selectedDate: Date;
  onDateSelect: (date: Date) => void;
  events: any[];
  habits: any[];
  getEventsForDate: (date: Date) => any[];
  isHabitActiveOnDay: (habit: any, date: Date) => boolean;
  onAddEvent: () => void;
  onEditEvent?: (event: any) => void;
  onDuplicateEvent?: (event: any) => void;
  deleteEvent: (id: string) => Promise<void>;
  onEditHabit?: (habit: any) => void;
  onDuplicateHabit?: (habit: any) => void;
  deleteHabit: (id: string) => Promise<void>;
  // Additional props needed for ActivitiesDisplay
  todayCompletions?: any[];
  todaySessions?: any[];
  isHabitCompleted?: (habitId: string, date: Date, completions: any[]) => boolean;
  handleToggleHabit?: (habitId: string) => void;
  parseDurationFromDescription?: (description?: string) => number | null;
  getActiveSession?: (habitId: string) => any;
  setFullscreenTimerHabit?: (habit: any) => void;
  startSessionMutation?: any;
  endSessionMutation?: any;
  expandedHabits?: Set<string>;
}

export function DayView({ 
  selectedDate, 
  onDateSelect,
  events, 
  habits,
  getEventsForDate, 
  isHabitActiveOnDay,
  onAddEvent,
  onEditEvent,
  onDuplicateEvent,
  deleteEvent,
  onEditHabit,
  onDuplicateHabit,
  deleteHabit,
  todayCompletions = [],
  todaySessions = [],
  isHabitCompleted = () => false,
  handleToggleHabit = () => {},
  parseDurationFromDescription = () => null,
  getActiveSession = () => null,
  setFullscreenTimerHabit = () => {},
  startSessionMutation = { isPending: false },
  endSessionMutation = { isPending: false },
  expandedHabits = new Set()
}: DayViewProps) {
  const dayEvents = getEventsForDate(selectedDate);
  const dayHabits = habits.filter(habit => isHabitActiveOnDay(habit, selectedDate));
  const isDayToday = isToday(selectedDate);

  // Prepare data for ActivitiesDisplay
  const allTasks = habits.filter(habit => habit.habit_type === 'task' || habit.habit_type === 'one_time_task');
  const sortedTasks = allTasks.filter(task => 
    isHabitActiveOnDay(task, selectedDate)
  );
  const importantIncompleteTasks = sortedTasks.filter(task => 
    task.is_important && !isHabitCompleted(task.id, selectedDate, todayCompletions)
  );
  const regularTasks = sortedTasks.filter(task => 
    !task.is_important && !isHabitCompleted(task.id, selectedDate, todayCompletions)
  );
  const completedTasks = sortedTasks.filter(task => 
    isHabitCompleted(task.id, selectedDate, todayCompletions)
  );

  const totalActivities = dayEvents.length + dayHabits.length + sortedTasks.length;
  const completedActivities = dayEvents.length + 
    dayHabits.filter(habit => isHabitCompleted(habit.id, selectedDate, todayCompletions)).length +
    sortedTasks.filter(task => isHabitCompleted(task.id, selectedDate, todayCompletions)).length;
  
  const habitProgress = totalActivities > 0 ? Math.round((completedActivities / totalActivities) * 100) : 0;

  return (
    <div className="space-y-4">
      {/* Day header with navigation */}
      <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
        <Button 
          variant="ghost" 
          size="sm"
          onClick={() => onDateSelect(subDays(selectedDate, 1))}
        >
          <ChevronLeft className="w-4 h-4" />
        </Button>
        
        <div className="text-center">
          <h3 className="text-xl font-bold">
            {format(selectedDate, 'EEEE', { locale: bg })}
          </h3>
          <p className="text-muted-foreground">
            {format(selectedDate, 'dd MMMM yyyy', { locale: bg })}
            {isDayToday && <span className="ml-2 text-primary font-medium">днес</span>}
          </p>
        </div>
        
        <Button 
          variant="ghost" 
          size="sm"
          onClick={() => onDateSelect(addDays(selectedDate, 1))}
        >
          <ChevronRight className="w-4 h-4" />
        </Button>
      </div>

      {/* Add Event button under day header */}
      <div className="px-4">
        <Button variant="outline" className="w-full" onClick={onAddEvent}>
          <Calendar className="w-4 h-4 mr-2" />
          Добави събитие
        </Button>
      </div>

      {/* Activities Display */}
      <ActivitiesDisplay
        selectedDate={selectedDate}
        todayEvents={dayEvents}
        sortedTasks={sortedTasks}
        todayHabits={dayHabits}
        importantIncompleteTasks={importantIncompleteTasks}
        regularTasks={regularTasks}
        completedTasks={completedTasks}
        todayCompletions={todayCompletions}
        todaySessions={todaySessions}
        completedActivities={completedActivities}
        totalActivities={totalActivities}
        habitProgress={habitProgress}
        isHabitCompleted={isHabitCompleted}
        handleToggleHabit={handleToggleHabit}
        parseDurationFromDescription={parseDurationFromDescription}
        getActiveSession={getActiveSession}
        setFullscreenTimerHabit={setFullscreenTimerHabit}
        startSessionMutation={startSessionMutation}
        endSessionMutation={endSessionMutation}
        expandedHabits={expandedHabits}
        showHeader={true}
      />
    </div>
  );
}