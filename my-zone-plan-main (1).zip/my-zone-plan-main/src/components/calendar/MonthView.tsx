import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isToday, isSameMonth } from 'date-fns';
import { bg } from 'date-fns/locale';
import { Plus } from 'lucide-react';
import { CalendarEventCard } from './CalendarEventCard';

interface MonthViewProps {
  selectedDate: Date;
  onDateSelect: (date: Date) => void;
  events: any[];
  habits: any[];
  getEventsForDate: (date: Date) => any[];
  isHabitActiveOnDay: (habit: any, date: Date) => boolean;
  onAddEvent: () => void;
  onEditEvent?: (event: any) => void;
  onDuplicateEvent?: (event: any) => void;
  deleteEvent?: (id: string) => Promise<void>;
}

export function MonthView({ 
  selectedDate, 
  onDateSelect, 
  events, 
  habits,
  getEventsForDate, 
  isHabitActiveOnDay,
  onAddEvent,
  onEditEvent,
  onDuplicateEvent,
  deleteEvent
}: MonthViewProps) {
  const monthStart = startOfMonth(selectedDate);
  const monthEnd = endOfMonth(selectedDate);
  
  // Start from Monday of the first week
  const calendarStart = new Date(monthStart);
  calendarStart.setDate(monthStart.getDate() - ((monthStart.getDay() + 6) % 7));
  
  // End on Sunday of the last week
  const calendarEnd = new Date(monthEnd);
  calendarEnd.setDate(monthEnd.getDate() + (6 - ((monthEnd.getDay() + 6) % 7)));
  
  const calendarDays = eachDayOfInterval({ start: calendarStart, end: calendarEnd });
  
  const weekDays = ['Пон', 'Вт', 'Ср', 'Чет', 'Пет', 'Съб', 'Нед'];

  const selectedDateEvents = getEventsForDate(selectedDate);

  return (
    <div className="space-y-4">
      {/* Week day headers */}
      <div className="grid grid-cols-7 gap-2">
        {weekDays.map((day) => (
          <div key={day} className="text-center text-sm font-medium text-muted-foreground p-2">
            {day}
          </div>
        ))}
      </div>

      {/* Calendar grid */}
      <div className="grid grid-cols-7 gap-2">
        {calendarDays.map((day, index) => {
          const dayEvents = getEventsForDate(day);
          const dayHabits = habits.filter(habit => isHabitActiveOnDay(habit, day));
          const isSelected = isSameDay(day, selectedDate);
          const isDayToday = isToday(day);
          const isCurrentMonth = isSameMonth(day, selectedDate);
          const isPast = day < new Date(new Date().setHours(0, 0, 0, 0));
          
          return (
            <Card 
              key={index}
              className={`p-2 cursor-pointer transition-all border min-h-[60px] sm:min-h-[80px] ${
                isSelected 
                  ? 'border-primary bg-primary/5' 
                  : 'border-border hover:border-primary/50'
              } ${isDayToday ? 'ring-2 ring-primary/30' : ''} ${
                !isCurrentMonth ? 'opacity-40' : ''
              } ${isPast ? 'bg-muted/20' : ''}`}
              onClick={() => !isPast && onDateSelect(day)}
            >
              <div className="flex flex-col h-full">
                {/* Day number */}
                <div className="text-center mb-1">
                  <span className={`text-sm font-medium ${
                    isDayToday ? 'text-primary font-bold' : 
                    !isCurrentMonth ? 'text-muted-foreground' : 'text-foreground'
                  }`}>
                    {format(day, 'd')}
                  </span>
                </div>

              {/* Events and habits indicators */}
              <div className="flex-1 space-y-1">
                {dayEvents.length > 0 && (
                  <div className="w-2 h-2 bg-blue-500 rounded-full mx-auto"></div>
                )}
                
                {dayHabits.length > 0 && (
                  <div className="w-2 h-2 bg-green-500 rounded-full mx-auto"></div>
                )}
                
                {(dayEvents.length > 1 || dayHabits.length > 1) && (
                  <div className="text-xs text-muted-foreground text-center">
                    +{Math.max(0, dayEvents.length - 1) + Math.max(0, dayHabits.length - 1)}
                  </div>
                )}
              </div>

                {/* Add button for current and future days */}
                {isCurrentMonth && !isPast && (dayEvents.length === 0 && dayHabits.length === 0) && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full h-6 text-xs opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDateSelect(day);
                      onAddEvent();
                    }}
                  >
                    <Plus className="w-3 h-3" />
                  </Button>
                )}
              </div>
            </Card>
          );
        })}
      </div>

      {/* Selected Date Details */}
      {selectedDateEvents.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">
            Събития - {format(selectedDate, 'EEEE, dd MMMM', { locale: bg })}
          </h3>
          
          <div className="grid gap-3">
            {selectedDateEvents.map(event => (
              <CalendarEventCard
                key={event.id}
                event={event}
                onEdit={onEditEvent}
                onDuplicate={onDuplicateEvent}
                onDelete={deleteEvent ? () => deleteEvent(event.id) : undefined}
                compact={false}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}