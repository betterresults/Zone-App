import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Clock, MoreVertical, Edit, Trash2, Copy } from 'lucide-react';
import { CalendarEvent } from '@/hooks/useCalendarEvents';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';

interface CalendarEventCardProps {
  event: CalendarEvent;
  onEdit?: (event: CalendarEvent) => void;
  onDelete?: (eventId: string) => void;
  onDuplicate?: (event: CalendarEvent) => void;
  compact?: boolean;
}

const eventTypeLabels = {
  personal: 'Лично',
  meeting: 'Среща',
  appointment: 'Ангажимент',
  reminder: 'Напомняне',
  workout: 'Тренировка',
  health: 'Здраве'
};

const statusLabels = {
  upcoming: 'Предстоящо',
  ongoing: 'В момента',
  completed: 'Завършено'
};

const getEventStyles = (event: CalendarEvent) => {
  const status = event.status || 'upcoming';
  
  switch (status) {
    case 'completed':
      return {
        cardClass: 'opacity-60 bg-muted/30',
        titleClass: 'line-through text-muted-foreground',
        statusBadge: {
          bg: '#64748b20',
          border: '#64748b40',
          color: '#64748b'
        }
      };
    case 'ongoing':
      return {
        cardClass: 'ring-2 ring-primary/50 bg-primary/5',
        titleClass: 'text-primary font-semibold',
        statusBadge: {
          bg: `${event.color}40`,
          border: `${event.color}60`,
          color: event.color
        }
      };
    default: // upcoming
      return {
        cardClass: '',
        titleClass: '',
        statusBadge: {
          bg: `${event.color}20`,
          border: `${event.color}40`,
          color: event.color
        }
      };
  }
};

export const CalendarEventCard: React.FC<CalendarEventCardProps> = ({
  event,
  onEdit,
  onDelete,
  onDuplicate,
  compact = false
}) => {
  const formatTime = (time: string) => {
    // Remove seconds and return HH:MM format
    return time.substring(0, 5);
  };

  const getTimeDisplay = () => {
    if (event.all_day) {
      return 'Цял ден';
    }
    
    if (event.start_time && event.end_time) {
      return `${formatTime(event.start_time)} - ${formatTime(event.end_time)}`;
    }
    
    if (event.start_time) {
      return formatTime(event.start_time);
    }
    
    return 'Без час';
  };

  const styles = getEventStyles(event);
  const status = event.status || 'upcoming';

  return (
    <Card 
      className={`group hover:shadow-md transition-all ${styles.cardClass}`}
      style={{ borderLeft: `4px solid ${event.color}` }}
    >
      <CardContent className="p-5">
        <div className="w-full">
          <div className="w-full">
            <div className="flex items-center justify-between w-full mb-3">
              <h3 className="font-bold text-xl text-foreground">
                {event.title}
              </h3>
              {(onEdit || onDelete || onDuplicate) && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <MoreVertical className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    {onEdit && (
                      <DropdownMenuItem onClick={() => onEdit(event)}>
                        <Edit className="w-4 h-4 mr-2" />
                        Редактирай
                      </DropdownMenuItem>
                    )}
                    {onDuplicate && (
                      <DropdownMenuItem onClick={() => onDuplicate(event)}>
                        <Copy className="w-4 h-4 mr-2" />
                        Дублирай
                      </DropdownMenuItem>
                    )}
                    {onDelete && (
                      <DropdownMenuItem 
                        onClick={() => onDelete(event.id)}
                        className="text-destructive focus:text-destructive"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Изтрий
                      </DropdownMenuItem>
                    )}
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>

            <div className="flex items-center gap-2 mb-3">
              <span 
                className="inline-block px-3 py-1 rounded-full text-sm border font-medium"
                style={{ 
                  backgroundColor: styles.statusBadge.bg,
                  borderColor: styles.statusBadge.border,
                  color: styles.statusBadge.color 
                }}
              >
                {eventTypeLabels[event.event_type as keyof typeof eventTypeLabels] || event.event_type}
              </span>
              {status !== 'upcoming' && (
                <span 
                  className="inline-block px-3 py-1 rounded-full text-sm font-medium"
                  style={{
                    backgroundColor: status === 'ongoing' ? '#10b98120' : '#64748b20',
                    color: status === 'ongoing' ? '#10b981' : '#64748b'
                  }}
                >
                  {statusLabels[status]}
                </span>
              )}
            </div>

            {event.description && (
              <p className={`text-base mb-4 ${status === 'completed' ? 'text-muted-foreground' : 'text-muted-foreground'}`}>
                {event.description}
              </p>
            )}

            <div className="flex items-center gap-3">
              <Clock className={`w-6 h-6 ${status === 'completed' ? 'text-muted-foreground' : 'text-primary'}`} />
              <span className={`text-2xl font-bold ${status === 'completed' ? 'text-muted-foreground' : 'text-foreground'}`}>
                {getTimeDisplay()}
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};