import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Clock, MoreVertical, Edit, Trash2, Copy, Play } from 'lucide-react';
import { Habit } from '@/hooks/useHabits';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';

interface HabitCardProps {
  habit: Habit;
  onEdit?: (habit: Habit) => void;
  onDelete?: (habitId: string) => void;
  onDuplicate?: (habit: Habit) => void;
  onStartWorkout?: (habit: Habit) => void;
}

const categoryLabels = {
  health: 'Здраве',
  fitness: 'Фитнес',
  productivity: 'Продуктивност',
  personal: 'Лично',
  learning: 'Учене',
  social: 'Социално'
};

export const HabitCard: React.FC<HabitCardProps> = ({
  habit,
  onEdit,
  onDelete,
  onDuplicate,
  onStartWorkout
}) => {
  const formatTime = (time: string) => {
    // Remove seconds and return HH:MM format
    return time.substring(0, 5);
  };

  const getTimeDisplay = () => {
    if (habit.time_of_day) {
      return formatTime(habit.time_of_day);
    }
    return 'Без час';
  };

  const getDisplayName = () => {
    // Remove day names from habit name (e.g. "Тренировка - Четвъртък" -> "Тренировка")
    return habit.name.replace(/\s*-\s*(Понедел|Втор|Сряд|Четвъртък|Петък|Събот|Неделя|Пон|Вт|Ср|Чет|Пет|Съб|Нед)ник?$/gi, '').trim();
  };

  return (
    <Card 
      className="group hover:shadow-md transition-all"
      style={{ borderLeft: `4px solid ${habit.color}` }}
    >
      <CardContent className="p-5">
        <div className="w-full">
          <div className="w-full">
            <div className="flex items-center justify-between w-full mb-3">
              <h3 className="font-bold text-xl text-foreground">
                {getDisplayName()}
              </h3>
              {(onEdit || onDelete || onDuplicate) && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <MoreVertical className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    {onEdit && (
                      <DropdownMenuItem onClick={() => onEdit(habit)}>
                        <Edit className="w-4 h-4 mr-2" />
                        Редактирай
                      </DropdownMenuItem>
                    )}
                    {onDuplicate && (
                      <DropdownMenuItem onClick={() => onDuplicate(habit)}>
                        <Copy className="w-4 h-4 mr-2" />
                        Дублирай
                      </DropdownMenuItem>
                    )}
                    {onDelete && (
                      <DropdownMenuItem 
                        onClick={() => onDelete(habit.id)}
                        className="text-destructive focus:text-destructive"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Изтрий
                      </DropdownMenuItem>
                    )}
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>

            <div className="flex items-center gap-2 mb-3">
              <span 
                className="inline-block px-3 py-1 rounded-full text-sm border font-medium"
                style={{ 
                  backgroundColor: `${habit.color}20`,
                  borderColor: `${habit.color}40`,
                  color: habit.color 
                }}
              >
                {categoryLabels[habit.category as keyof typeof categoryLabels] || habit.category}
              </span>
            </div>

            {habit.description && (
              <p className="text-base mb-4 text-muted-foreground">
                {habit.description}
              </p>
            )}

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Clock className="w-6 h-6 text-primary" />
                <span className="text-2xl font-bold text-foreground">
                  {getTimeDisplay()}
                </span>
              </div>
              {habit.category === 'fitness' && onStartWorkout && (
                <Button
                  size="lg"
                  onClick={() => onStartWorkout(habit)}
                  className="gap-2"
                >
                  <Play className="w-5 h-5" />
                  <span>Стартирай</span>
                </Button>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};