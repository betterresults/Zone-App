import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useProfile } from '@/hooks/useProfile';
import { useOneSignal } from '@/hooks/useOneSignal';
import { Bell, BellOff, Clock, Heart, Droplets, Dumbbell, TestTube2 } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export const NotificationSettings = () => {
  const { profile, updateProfile } = useProfile();
  const { isInitialized, isSubscribed, loading, requestPermission, repairSubscription } = useOneSignal();

  const handleToggleNotifications = async (enabled: boolean) => {
    if (enabled && !isSubscribed) {
      const granted = await requestPermission();
      if (!granted) {
        toast({
          title: "Нотификации не са разрешени",
          description: "Моля, разрешете нотификациите в браузъра.",
          variant: "destructive"
        });
        return;
      }
    }

    try {
      await updateProfile({ push_notifications_enabled: enabled });
      
      toast({
        description: enabled 
          ? "Нотификациите са активирани успешно с OneSignal." 
          : "Нотификациите са деактивирани."
      });
    } catch (error) {
      toast({
        title: "Грешка",
        description: "Неуспешно обновяване на настройките.",
        variant: "destructive"
      });
    }
  };

  const getNotificationStatus = () => {
    if (loading) return "Зареждане...";
    if (!isInitialized) return "Настройва се...";
    const perm = (typeof Notification !== 'undefined') ? Notification.permission : 'default';
    const activeByBrowser = perm === 'granted';
    if ((isSubscribed || activeByBrowser) && profile?.push_notifications_enabled) return "Активни";
    if (!isSubscribed && !activeByBrowser) return "Неактивни";
    return "Деактивирани";
  };

  const getStatusDescription = () => {
    if (loading) return "Зареждане на уведомленията...";
    if (!isInitialized) return "Настройване на уведомленията...";
    const perm = (typeof Notification !== 'undefined') ? Notification.permission : 'default';
    const activeByBrowser = perm === 'granted';
    if ((isSubscribed || activeByBrowser) && profile?.push_notifications_enabled) return "Уведомленията са активни и работят";
    if (!isSubscribed && !activeByBrowser) return "Моля, разрешете уведомленията";
    return "Уведомленията са изключени";
  };

  return (
    <div className="space-y-4">
      {/* OneSignal notification toggle */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="w-5 h-5" />
            Уведомления
          </CardTitle>
          <CardDescription>
            Получавайте напомняния за навици, тренировки и хидратация
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <p className="text-sm font-medium">
                {getNotificationStatus()}
              </p>
              <p className="text-xs text-muted-foreground">
                {getStatusDescription()}
              </p>
            </div>
            <Switch
              checked={profile?.push_notifications_enabled ?? false}
              onCheckedChange={handleToggleNotifications}
              disabled={loading || !isInitialized}
            />
          </div>
        </CardContent>
      </Card>

      {isInitialized && typeof Notification !== 'undefined' && Notification.permission === 'granted' && !isSubscribed && (
        <Card>
          <CardContent>
            <div className="flex items-center justify-between gap-3">
              <div className="text-sm">
                Разрешенията са дадени, но не сте абонирани към OneSignal.
              </div>
              <Button size="sm" onClick={repairSubscription}>
                Поправи абонамента
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Notification types */}
      {profile?.push_notifications_enabled && (isSubscribed || (typeof Notification !== 'undefined' && Notification.permission === 'granted')) && (
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-sm">
                <Clock className="w-4 h-4 text-primary" />
                Навици
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-xs text-muted-foreground">
                Напомняния за ежедневни навици според зададеното време
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-sm">
                <Dumbbell className="w-4 h-4 text-primary" />
                Фитнес
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-xs text-muted-foreground">
                Напомняния за тренировки 30 мин преди началото
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-sm">
                <Droplets className="w-4 h-4 text-primary" />
                Хидратация
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-xs text-muted-foreground">
                4 напомняния дневно за пиене на вода
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Status indicators */}
      <Card>
        <CardContent>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm">Системата е готова:</span>
              <Badge variant={isInitialized ? "default" : "secondary"}>
                {isInitialized ? "Да" : "Настройва се..."}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Разрешени уведомления:</span>
              <Badge variant={isSubscribed ? "default" : "secondary"}>
                {isSubscribed ? "Да" : "Не"}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};