import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Clock, Play, Square, Bell } from 'lucide-react';
import { useFasting } from '@/hooks/useFasting';
import { FastingStartDialog } from './FastingStartDialog';
import { useOneSignal } from '@/hooks/useOneSignal';
import { toast } from 'sonner';

export const FastingTimer = () => {
  const { 
    activeFast, 
    isLoading, 
    startFast, 
    endFast, 
    isStarting, 
    isEnding, 
    getCurrentFastingTime,
    formatFastingTime 
  } = useFasting();
  
  const { sendTags } = useOneSignal();
  const [showStartDialog, setShowStartDialog] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [hasNotified, setHasNotified] = useState(false);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (activeFast) {
      interval = setInterval(() => {
        const time = getCurrentFastingTime();
        setCurrentTime(time);
        
        // Check if target hours reached and haven't notified yet
        if (activeFast.target_hours && !hasNotified) {
          const targetMilliseconds = activeFast.target_hours * 60 * 60 * 1000;
          if (time >= targetMilliseconds) {
            setHasNotified(true);
            showCompletionNotification(activeFast.target_hours);
          }
        }
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [activeFast, hasNotified, getCurrentFastingTime]);

  // Reset notification flag when starting new fast
  useEffect(() => {
    if (activeFast) {
      setHasNotified(false);
    }
  }, [activeFast?.id]);

  const showCompletionNotification = (targetHours: number) => {
    // Show toast notification
    toast.success(`🎉 Честито! ${targetHours} часа фастинг завършен!`, {
      description: 'Не искаш ли да спреш фастинга сега?',
      duration: 10000,
      action: {
        label: 'Спри фастинга',
        onClick: () => activeFast && endFast(activeFast.id)
      }
    });

    // Update OneSignal tags for potential push notifications
    sendTags({
      fasting_goal_reached: 'true',
      fasting_target_hours: targetHours.toString(),
      fasting_completion_time: new Date().toISOString()
    });
  };

  const handleStartFasting = (params: { target_hours?: number; note?: string }) => {
    startFast(params);
  };

  const handleEndFasting = () => {
    if (activeFast) {
      endFast(activeFast.id);
      setHasNotified(false);
    }
  };

  const getProgress = () => {
    if (!activeFast?.target_hours) return 0;
    const targetMs = activeFast.target_hours * 60 * 60 * 1000;
    return Math.min((currentTime / targetMs) * 100, 100);
  };

  const getRemainingTime = () => {
    if (!activeFast?.target_hours) return null;
    const targetMs = activeFast.target_hours * 60 * 60 * 1000;
    const remaining = Math.max(0, targetMs - currentTime);
    return remaining;
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">Зареждане...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Интервален фастинг
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {activeFast ? (
            <>
              <div className="text-center space-y-2">
                <div className="text-2xl font-bold">
                  {formatFastingTime(currentTime)}
                </div>
                {activeFast.target_hours && (
                  <div className="space-y-2">
                    <Progress value={getProgress()} className="h-2" />
                    <div className="flex justify-between text-sm text-muted-foreground">
                      <span>Цел: {activeFast.target_hours}ч</span>
                      {getRemainingTime() !== null && (
                        <span>
                          {getRemainingTime()! > 0 
                            ? `Остават: ${formatFastingTime(getRemainingTime()!)}`
                            : '🎉 Цел постигната!'
                          }
                        </span>
                      )}
                    </div>
                  </div>
                )}
                {activeFast.note && (
                  <Badge variant="outline" className="mt-2">
                    {activeFast.note}
                  </Badge>
                )}
              </div>
              
              <Button 
                onClick={handleEndFasting} 
                disabled={isEnding}
                variant="destructive"
                className="w-full"
              >
                <Square className="w-4 h-4 mr-2" />
                {isEnding ? 'Спиране...' : 'Спри фастинга'}
              </Button>
              
              {getRemainingTime() !== null && getRemainingTime()! <= 0 && (
                <div className="text-center p-3 bg-green-100 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
                  <Bell className="w-5 h-5 mx-auto mb-1 text-green-600" />
                  <p className="text-sm text-green-700 dark:text-green-300 font-medium">
                    Честито! Постигнахте вашата цел от {activeFast.target_hours} часа!
                  </p>
                </div>
              )}
            </>
          ) : (
            <div className="text-center space-y-4">
              <p className="text-muted-foreground">
                Няма активна фастинг сесия
              </p>
              <Button 
                onClick={() => setShowStartDialog(true)} 
                className="w-full"
              >
                <Play className="w-4 h-4 mr-2" />
                Започни фастинг
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <FastingStartDialog
        open={showStartDialog}
        onOpenChange={setShowStartDialog}
        onStart={handleStartFasting}
        isStarting={isStarting}
      />
    </>
  );
};