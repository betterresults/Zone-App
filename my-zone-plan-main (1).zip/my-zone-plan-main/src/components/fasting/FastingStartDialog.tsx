import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

interface FastingStartDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onStart: (params: { target_hours?: number; note?: string }) => void;
  isStarting: boolean;
  defaultHours?: number;
}

export const FastingStartDialog = ({ 
  open, 
  onOpenChange, 
  onStart, 
  isStarting,
  defaultHours = 16 
}: FastingStartDialogProps) => {
  const [targetHours, setTargetHours] = useState(defaultHours);
  const [note, setNote] = useState('');

  const handleStart = () => {
    onStart({ target_hours: targetHours, note: note.trim() || undefined });
    setNote('');
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md rounded-2xl">
        <DialogHeader>
          <DialogTitle>Започни фастинг сесия</DialogTitle>
          <DialogDescription>
            Задай цел и започни новата си фастинг сесия
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="target-hours">Целеви часове</Label>
            <Input
              id="target-hours"
              type="number"
              min="1"
              max="48"
              value={targetHours}
              onChange={(e) => setTargetHours(Number(e.target.value))}
              placeholder="16"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="note">Забележка (по избор)</Label>
            <Textarea
              id="note"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Напр. 16:8 интервален фастинг"
              className="resize-none"
              rows={2}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Отказ
          </Button>
          <Button onClick={handleStart} disabled={isStarting}>
            Започни фастинг
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};