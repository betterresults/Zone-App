import { useState } from 'react';
import { Droplets, Coffee, Wine, Milk, Leaf, Apple, CheckCircle, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useHydration, BeverageType } from '@/hooks/useHydration';

interface HydrationCardProps {
  selectedDate?: Date;
  isRestrictedDate?: boolean;
  profile?: {
    daily_water_goal_ml?: number;
    hydration_enabled?: boolean;
  } | null;
}

export const HydrationCard = ({ selectedDate, isRestrictedDate = false, profile }: HydrationCardProps) => {
  const { totalVolume, addIntake, isAdding } = useHydration(selectedDate);
  
  const [selectedBeverage, setSelectedBeverage] = useState<BeverageType>('water');
  const [customNote, setCustomNote] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);
  const [animatedVolume, setAnimatedVolume] = useState(0);

  const waterGoal = profile?.daily_water_goal_ml || 2000;
  const waterProgress = Math.min((totalVolume / waterGoal) * 100, 100);

  const beverageOptions = [
    { type: 'water' as const, icon: Droplets, label: 'Вода', color: 'text-blue-500' },
    { type: 'coffee' as const, icon: Coffee, label: 'Кафе', color: 'text-amber-700' },
    { type: 'tea' as const, icon: Leaf, label: 'Чай', color: 'text-green-600' },
    { type: 'juice' as const, icon: Apple, label: 'Сок', color: 'text-orange-500' },
    { type: 'soup' as const, icon: Wine, label: 'Айран', color: 'text-purple-500' },
    { type: 'milk' as const, icon: Milk, label: 'Мляко', color: 'text-gray-500' },
    { type: 'other' as const, icon: Wine, label: 'Друго', color: 'text-indigo-500' }
  ];

  const getVolumeOptions = (type: BeverageType) => {
    const options = {
      water: [200, 250, 500],
      coffee: [100, 200, 250],
      tea: [100, 200, 250], 
      juice: [200, 250, 500],
      soup: [200, 250, 500],
      milk: [200, 250, 500],
      other: [200, 250, 500]
    };
    return options[type] || options.water;
  };

  const handleIntake = async (volume: number) => {
    const note = selectedBeverage === 'other' ? customNote : undefined;
    
    try {
      await addIntake({ 
        volume_ml: volume, 
        beverage_type: selectedBeverage,
        note
      });

      // Show success feedback and animated volume
      const newTotal = totalVolume + volume;
      setAnimatedVolume(newTotal);
      setShowSuccess(true);
      
      // Clear custom note after adding
      if (selectedBeverage === 'other') {
        setCustomNote('');
      }

      // Hide success animation after 1.5 seconds
      setTimeout(() => setShowSuccess(false), 1500);
    } catch (error) {
      // Handle error silently
    }
  };

  if (profile?.hydration_enabled === false) return null;

  return (
    <Card className={`relative transition-all duration-300 ${showSuccess ? 'bg-green-500/10 border-green-500/20 shadow-lg shadow-green-500/10' : ''}`}>
      {/* Large animated volume display */}
      {showSuccess && (
        <div className="absolute inset-0 flex items-center justify-center z-10 bg-green-500/5 rounded-lg backdrop-blur-sm">
          <div className="text-6xl lg:text-8xl font-bold text-green-600 animate-scale-in animate-fade-in">
            {animatedVolume}мл
          </div>
        </div>
      )}
      
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Droplets className="w-5 h-5 text-zone-protein" />
          Хидратация
        </CardTitle>
        <CardDescription className="text-sm">
          {totalVolume} от {waterGoal} мл
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Progress 
          value={waterProgress} 
          className={`w-full h-2 transition-all duration-500 ${showSuccess ? 'animate-pulse' : ''}`} 
        />
        <div className="text-center">
          <div className="text-xl lg:text-2xl font-bold text-zone-protein">
            {Math.round(waterProgress)}%
          </div>
          <div className="text-xs lg:text-sm text-muted-foreground">от дневната цел</div>
        </div>

        {/* Beverage Type Selector */}
        <div className="flex justify-center gap-1 lg:gap-2 p-2 bg-muted/30 rounded-lg flex-wrap">
          {beverageOptions.map(({ type, icon: Icon, label, color }) => (
            <button
              key={type}
              onClick={() => setSelectedBeverage(type)}
              className={`flex flex-col items-center gap-1 p-1 lg:p-2 rounded-lg transition-all duration-200 hover:scale-105 ${
                selectedBeverage === type 
                  ? 'bg-primary/10 border-2 border-primary' 
                  : 'hover:bg-muted/50 border-2 border-transparent'
              }`}
              title={label}
              disabled={isRestrictedDate}
            >
              <Icon className={`w-4 h-4 lg:w-5 lg:h-5 ${selectedBeverage === type ? 'text-primary' : color} transition-colors duration-200`} />
              <span className={`text-[9px] lg:text-[10px] font-medium ${selectedBeverage === type ? 'text-primary' : 'text-muted-foreground'}`}>
                {label}
              </span>
            </button>
          ))}
        </div>

        {/* Custom note input for 'other' beverage type */}
        {selectedBeverage === 'other' && (
          <div className="space-y-2">
            <Label htmlFor="custom-note">Какво пиеш?</Label>
            <Input
              id="custom-note"
              value={customNote}
              onChange={(e) => setCustomNote(e.target.value)}
              placeholder="напр. айран, газирана вода..."
              className="text-sm"
            />
          </div>
        )}

        {/* Volume Buttons */}
        <div className="grid grid-cols-3 gap-1 lg:gap-2">
          {getVolumeOptions(selectedBeverage).map((volume) => (
            <Button 
              key={volume}
              size="sm" 
              variant="outline" 
              onClick={() => handleIntake(volume)}
              disabled={isAdding || isRestrictedDate}
              className="text-[10px] lg:text-xs px-1 lg:px-2 py-1 h-8 hover:scale-105 transition-transform duration-200"
            >
              +{volume}мл
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};