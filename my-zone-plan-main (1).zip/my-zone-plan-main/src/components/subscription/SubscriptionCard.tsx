import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useSubscription } from '@/hooks/useSubscription';
import { useAuth } from '@/hooks/useAuth';
import { Check, Crown, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export const SubscriptionCard = () => {
  const { user } = useAuth();
  const { 
    subscribed, 
    subscription_tier, 
    subscription_end, 
    loading, 
    createCheckout, 
    openCustomerPortal,
    checkSubscription 
  } = useSubscription();
  const { toast } = useToast();
  const [selectedPlan, setSelectedPlan] = useState<'monthly' | '6monthly' | 'yearly' | null>(null);

  const handleSelectPlan = (planType: 'monthly' | '6monthly' | 'yearly') => {
    setSelectedPlan(planType);
  };

  const handleActivatePlan = async () => {
    if (!selectedPlan) return;
    
    try {
      await createCheckout(selectedPlan);
      toast({
        title: "Пренасочване към Stripe",
        description: "Ще бъдете пренасочени за завършване на абонамента.",
      });
    } catch (error) {
      toast({
        title: "Грешка",
        description: "Неуспешно създаване на сесия за плащане. Опитайте отново.",
        variant: "destructive",
      });
    }
  };

  const handleManageSubscription = async () => {
    try {
      await openCustomerPortal();
      toast({
        title: "Пренасочване към Клиентски портал",
        description: "Управлявайте абонамента си в Stripe портала.",
      });
    } catch (error) {
      toast({
        title: "Грешка",
        description: "Неуспешно отваряне на клиентския портал. Опитайте отново.",
        variant: "destructive",
      });
    }
  };

  const handleRefresh = async () => {
    try {
      await checkSubscription();
      toast({
        title: "Абонаментът е обновен",
        description: "Статусът на вашия абонамент е актуализиран.",
      });
    } catch (error) {
      toast({
        title: "Грешка",
        description: "Неуспешно обновяване на статуса на абонамента.",
        variant: "destructive",
      });
    }
  };

  if (!user) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Необходим е абонамент</CardTitle>
          <CardDescription>Моля, влезте в профила си, за да управлявате абонамента.</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Loader2 className="h-4 w-4 animate-spin" />
            Зареждане на статуса на абонамента...
          </CardTitle>
        </CardHeader>
      </Card>
    );
  }

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="text-center space-y-3">
        <h2 className="text-2xl sm:text-3xl font-bold leading-tight px-2">Изберете най-подходящия план за вас</h2>
        <p className="text-sm sm:text-base text-muted-foreground px-2">Започнете безплатно и надстройте, когато сте готови за повече функции</p>
      </div>

      {/* Current Plan Status */}
      {subscribed && (
        <Card className="border-primary bg-primary/5">
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
              <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                <CardTitle className="text-lg sm:text-xl">
                  {subscribed ? `${subscription_tier?.replace('Pro', 'Премиум')} План` : 'Безплатен План'}
                </CardTitle>
                <Badge variant="secondary" className="text-foreground border-foreground/20 bg-primary/10 w-fit">
                  Активен
                </Badge>
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleRefresh}
                disabled={loading}
                className="w-full sm:w-auto"
              >
                Обнови статуса
              </Button>
            </div>
            <CardDescription className="text-sm mt-2">
              {subscription_end 
                ? (
                  <div className="space-y-1">
                    <div>Вашият абонамент се подновява на:</div>
                    <div className="font-medium">{new Date(subscription_end).toLocaleDateString('bg-BG')}</div>
                  </div>
                )
                : 'Управлявайте вашия абонамент'
              }
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={handleManageSubscription} className="w-full">
              Управление на абонамента
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Pricing Plans */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8">
        {/* Free Plan */}
        <Card className={!subscribed ? "border-primary" : "border-muted/50 bg-muted/20"}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-xl text-muted-foreground">Безплатен План</CardTitle>
                <CardDescription className="text-base mt-2 text-muted-foreground">Започнете вашето Zone Diet пътешествие</CardDescription>
              </div>
              {!subscribed && <Badge variant="outline" className="text-foreground border-foreground/30 bg-secondary/50">Текущ</Badge>}
            </div>
            <div className="text-3xl font-bold text-muted-foreground mt-4">0 лв</div>
            <div className="text-muted-foreground text-sm">завинаги безплатно</div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <div className="space-y-2 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-muted-foreground" />
                  <span>Zone калкулации и блокове</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-muted-foreground" />
                  <span>Сканиране на баркодове</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-muted-foreground" />
                  <span>До 50 продукта</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-muted-foreground" />
                  <span>До 20 рецепти</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-muted-foreground" />
                  <span>До 20 ястия</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-muted-foreground" />
                  <span>Календар за текущия ден</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-muted-foreground" />
                  <span>Основно проследяване на теглото</span>
                </div>
              </div>
            </div>
            {!subscribed && (
              <div className="pt-4">
                <div className="text-primary font-medium mb-3">✓ Вече използвате този план</div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Premium Plan */}
        <Card className={subscribed ? "border-primary ring-2 ring-primary/20" : "border-2 border-primary shadow-lg bg-gradient-to-br from-primary/5 to-primary/10"}>
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
              <div>
                <CardTitle className="text-xl sm:text-2xl flex items-center gap-2">
                  <Crown className="h-5 w-5 sm:h-6 sm:w-6 text-yellow-500" />
                  Премиум План
                </CardTitle>
                <CardDescription className="text-base sm:text-lg mt-2 font-medium">
                  Пълен достъп до всички функции
                </CardDescription>
              </div>
              {subscribed && (
                <Badge variant="secondary" className="text-foreground border-foreground/20 bg-primary/10 w-fit">
                  Текущ
                </Badge>
              )}
            </div>
          </CardHeader>

          <CardContent className="space-y-6">
            {/* Premium Features */}
            <div className="space-y-3">
              <h4 className="font-semibold text-sm sm:text-base">Всички функции от безплатния план +</h4>
              <div className="grid gap-2 text-xs sm:text-sm">
                <div className="flex items-start gap-2">
                  <Check className="h-3 w-3 sm:h-4 sm:w-4 text-primary mt-0.5 flex-shrink-0" />
                  <span className="leading-tight"><strong>Неограничени</strong> продукти, рецепти и ястия</span>
                </div>
                <div className="flex items-start gap-2">
                  <Check className="h-3 w-3 sm:h-4 sm:w-4 text-primary mt-0.5 flex-shrink-0" />
                  <span className="leading-tight"><strong>Седмично планиране</strong> на храната</span>
                </div>
                <div className="flex items-start gap-2">
                  <Check className="h-3 w-3 sm:h-4 sm:w-4 text-primary mt-0.5 flex-shrink-0" />
                  <span className="leading-tight"><strong>Автоматичен списък</strong> за пазаруване</span>
                </div>
                <div className="flex items-start gap-2">
                  <Check className="h-3 w-3 sm:h-4 sm:w-4 text-primary mt-0.5 flex-shrink-0" />
                  <span className="leading-tight"><strong>Пълен достъп</strong> до календара</span>
                </div>
                <div className="flex items-start gap-2">
                  <Check className="h-3 w-3 sm:h-4 sm:w-4 text-primary mt-0.5 flex-shrink-0" />
                  <span className="leading-tight"><strong>OCR сканиране</strong> на етикети</span>
                </div>
                <div className="flex items-start gap-2">
                  <Check className="h-3 w-3 sm:h-4 sm:w-4 text-primary mt-0.5 flex-shrink-0" />
                  <span className="leading-tight"><strong>Интервален фастинг</strong> проследяване</span>
                </div>
                <div className="flex items-start gap-2">
                  <Check className="h-3 w-3 sm:h-4 sm:w-4 text-primary mt-0.5 flex-shrink-0" />
                  <span className="leading-tight"><strong>Фитнес интеграция</strong> и калории</span>
                </div>
                <div className="flex items-start gap-2">
                  <Check className="h-3 w-3 sm:h-4 sm:w-4 text-primary mt-0.5 flex-shrink-0" />
                  <span className="leading-tight"><strong>Споделяне на рецепти</strong> и общност</span>
                </div>
                <div className="flex items-start gap-2">
                  <Check className="h-3 w-3 sm:h-4 sm:w-4 text-primary mt-0.5 flex-shrink-0" />
                  <span className="leading-tight"><strong>Анализи и статистики</strong></span>
                </div>
                <div className="flex items-start gap-2">
                  <Check className="h-3 w-3 sm:h-4 sm:w-4 text-primary mt-0.5 flex-shrink-0" />
                  <span className="leading-tight"><strong>Приоритетна поддръжка</strong></span>
                </div>
              </div>
            </div>

            {/* Pricing Options - Always show */}
            <div className="space-y-4">
              <div className="border-t pt-4">
                <h4 className="font-semibold mb-3">
                  {subscribed ? 'Всички налични планове:' : 'Изберете план:'}
                </h4>
                <div className="grid gap-3">
                   {/* Monthly */}
                  <div 
                    className={`border rounded-lg p-3 transition-all ${
                      subscribed 
                        ? 'bg-muted/30 cursor-default' 
                        : `cursor-pointer ${
                            selectedPlan === 'monthly' 
                              ? 'border-primary bg-primary/10 ring-2 ring-primary/20' 
                              : 'hover:bg-muted/50'
                          }`
                    }`} 
                    onClick={() => !subscribed && handleSelectPlan('monthly')}
                  >
                    <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
                      <div>
                        <div className="font-semibold flex items-center gap-2">
                          Месечно
                          {subscribed && (
                            subscription_tier === 'месечен' || 
                            subscription_tier === 'Месечен' ||
                            subscription_tier === 'monthly' ||
                            (subscription_tier === 'pro' && subscription_end && new Date(subscription_end) > new Date() && 
                             new Date(subscription_end).getTime() - new Date().getTime() < 40 * 24 * 60 * 60 * 1000) // около месец
                          ) && (
                            <Badge variant="secondary" className="text-xs">Текущ план</Badge>
                          )}
                        </div>
                        <div className="text-sm text-muted-foreground">Гъвкавост за започващи</div>
                      </div>
                      <div className="text-left sm:text-right">
                        <div className="text-xl sm:text-2xl font-bold">4.99 €</div>
                        <div className="text-sm text-muted-foreground">на месец</div>
                      </div>
                    </div>
                  </div>

                  {/* 6-Monthly */}
                  <div 
                    className={`border rounded-lg p-3 relative overflow-hidden transition-all ${
                      subscribed 
                        ? 'bg-muted/30 cursor-default' 
                        : `cursor-pointer ${
                            selectedPlan === '6monthly' 
                              ? 'border-primary bg-primary/10 ring-2 ring-primary/20' 
                              : 'hover:bg-muted/50'
                          }`
                    }`} 
                    onClick={() => !subscribed && handleSelectPlan('6monthly')}
                  >
                    <div className="absolute top-0 right-0 transform translate-x-1 -translate-y-1">
                      <Badge className="bg-orange-500 text-white text-xs px-1.5 py-0.5">17% отстъпка</Badge>
                    </div>
                    <div className="flex flex-col gap-3 pr-20 sm:pr-0 sm:flex-row sm:justify-between sm:items-center">
                      <div className="space-y-1">
                        <div className="font-semibold text-base flex items-center gap-2">
                          6-месечно
                          {subscribed && (
                            subscription_tier === '6-месечен' || 
                            subscription_tier === '6-Месечен' || 
                            subscription_tier === '6monthly' ||
                            (subscription_tier === 'pro' && subscription_end && new Date(subscription_end) > new Date() && 
                             new Date(subscription_end).getTime() - new Date().getTime() >= 150 * 24 * 60 * 60 * 1000 && // повече от 5 месеца
                             new Date(subscription_end).getTime() - new Date().getTime() < 200 * 24 * 60 * 60 * 1000) // по-малко от 7 месеца
                          ) && (
                            <Badge variant="secondary" className="text-xs">Текущ план</Badge>
                          )}
                        </div>
                        <div className="text-sm text-muted-foreground">Най-добрата стойност</div>
                      </div>
                      <div className="space-y-1 sm:text-right">
                        <div className="text-xl sm:text-2xl font-bold">19.99 €</div>
                        <div className="text-sm text-muted-foreground space-y-1">
                          <div className="line-through">29.94 €</div>
                          <div>3.33 €/месец</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Yearly */}
                  <div 
                    className={`border rounded-lg p-3 relative overflow-hidden transition-all ${
                      subscribed 
                        ? 'bg-muted/30 cursor-default' 
                        : `cursor-pointer ${
                            selectedPlan === 'yearly' 
                              ? 'border-primary bg-primary/10 ring-2 ring-primary/20' 
                              : 'hover:bg-muted/50'
                          }`
                    }`} 
                    onClick={() => !subscribed && handleSelectPlan('yearly')}
                  >
                    <div className="absolute top-0 left-0 transform -translate-x-1 -translate-y-1">
                      <Badge className="bg-orange-500 text-white text-xs px-1.5 py-0.5">Препоръчано</Badge>
                    </div>
                    <div className="absolute top-0 right-0 transform translate-x-1 -translate-y-1">
                      <Badge className="bg-green-600 text-white text-xs px-1.5 py-0.5">50% отстъпка</Badge>
                    </div>
                    <div className="flex flex-col gap-3 px-16 sm:px-0 sm:flex-row sm:justify-between sm:items-center">
                      <div className="space-y-1">
                        <div className="font-semibold text-base flex items-center gap-2">
                          Годишно
                          {subscribed && (
                            subscription_tier === 'годишен' || 
                            subscription_tier === 'Годишен' || 
                            subscription_tier === 'yearly' ||
                            subscription_tier === 'Безсрочен' ||
                            (subscription_tier === 'pro' && subscription_end && new Date(subscription_end) > new Date() && 
                             new Date(subscription_end).getTime() - new Date().getTime() >= 300 * 24 * 60 * 60 * 1000) // повече от 10 месеца
                          ) && (
                            <Badge variant="secondary" className="text-xs">Текущ план</Badge>
                          )}
                        </div>
                        <div className="text-sm text-muted-foreground">Най-изгодната опция</div>
                      </div>
                      <div className="space-y-1 sm:text-right">
                        <div className="text-xl sm:text-2xl font-bold">29.99 €</div>
                        <div className="text-sm text-muted-foreground space-y-1">
                          <div className="line-through">59.88 €</div>
                          <div>2.50 €/месец</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Activate Button - Only for non-subscribers */}
                {!subscribed && selectedPlan && (
                  <div className="mt-6">
                    <Button 
                      onClick={handleActivatePlan} 
                      className="w-full h-12 text-base font-semibold"
                      size="lg"
                    >
                      Активирайте {
                        selectedPlan === 'monthly' ? 'месечния план' :
                        selectedPlan === '6monthly' ? '6-месечния план' :
                        'годишния план'
                      }
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Trust Indicators */}
      <div className="text-center space-y-4 py-6 border-t">
        <div className="flex flex-wrap justify-center items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span>Без договор</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span>Спрете по всяко време</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span>Мигновено активиране</span>
          </div>
        </div>
      </div>
    </div>
  );
};