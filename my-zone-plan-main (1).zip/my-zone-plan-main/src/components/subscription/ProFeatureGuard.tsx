import { ReactNode } from 'react';
import { useSubscription } from '@/hooks/useSubscription';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Crown, Lock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface ProFeatureGuardProps {
  children: ReactNode;
  feature: string;
  description?: string;
}

export const ProFeatureGuard = ({ children, feature, description }: ProFeatureGuardProps) => {
  const { isPro, loading } = useSubscription();
  const navigate = useNavigate();

  const handleUpgrade = () => {
    navigate('/settings#subscription');
  };

  if (loading) {
    return <>{children}</>;
  }

  if (isPro) {
    return <>{children}</>;
  }

  return (
    <Card className="border-primary/20">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2">
          <Lock className="h-5 w-5" />
          Премиум Функция
        </CardTitle>
        <CardDescription>
          {description || `${feature || 'Тази функция'} е достъпна само за Премиум потребители`}
        </CardDescription>
      </CardHeader>
      <CardContent className="text-center space-y-4">
        <div className="text-sm text-muted-foreground">
          Надстройте до Премиум за достъп до {feature?.toLowerCase() || 'тази функция'} и много други премиум функции.
        </div>
        <div className="flex justify-center">
          <Button onClick={handleUpgrade} className="flex items-center gap-2">
            <Crown className="h-4 w-4" />
            Надстройте до Премиум
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};