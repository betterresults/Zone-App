import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';

const TestNotification = () => {
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const testNotification = async () => {
    try {
      setLoading(true);
      setResult(null);
      
      console.log('Testing instant notification function...');
      
      const { data, error } = await supabase.functions.invoke('send-instant-notification', {
        body: {
          title: 'Тест нотификация',
          message: 'Това е моментална тест нотификация!'
          // Може да добавите userId за конкретен потребител
          // userId: '...'
        },
      });

      if (error) {
        console.error('Function error response:', error);
        setResult({ status: error.status ?? 400, error });
        return;
      }

      const os = (data as any)?.oneSignalResponse || {};
      const recipients = (typeof os.recipients === 'number') ? os.recipients : (typeof os.successful === 'number' ? os.successful : 0);

      setResult({ status: 200, data, recipients });
    } catch (error: any) {
      console.error('Instant notification error:', error);
      setResult({ error: error.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle>Test Notification</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Button 
          onClick={testNotification} 
          disabled={loading}
          className="w-full"
        >
          {loading ? 'Изпращам...' : 'Изпрати тест нотификация'}
        </Button>
        
        {result && (
          <div className="p-4 bg-muted rounded-md">
            <h4 className="font-medium mb-2">Резултат:</h4>
            <pre className="text-xs whitespace-pre-wrap">
              {JSON.stringify(result, null, 2)}
            </pre>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default TestNotification;