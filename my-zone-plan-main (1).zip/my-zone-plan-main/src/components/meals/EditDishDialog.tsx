import { useState, useEffect, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Edit, Save, X, ChefHat, Trash2, Camera, ImageIcon, Plus } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { ProductSelector } from '@/components/recipes/ProductSelector';
import { useActivityTracker } from '@/hooks/useActivityTracker';
import { useCamera } from '@/hooks/useCamera';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useZoneCalculation } from '@/hooks/useZoneCalculation';
import { useFeatureFlags } from '@/hooks/useFeatureFlags';
import { useProfile } from '@/hooks/useProfile';
import { ZoneResultCard } from '@/components/zone/ZoneResultCard';
import { CookingItemsList } from '@/components/cooking/CookingItemsList';

interface EditDishDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  dish: any;
}

interface Ingredient {
  id: string;
  product_id: string;
  grams: number;
  product_name?: string;
}

export const EditDishDialog = ({ open, onOpenChange, dish }: EditDishDialogProps) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [mealType, setMealType] = useState<'breakfast' | 'lunch' | 'dinner' | 'snack'>('lunch');
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [showProductSelection, setShowProductSelection] = useState(false);
  const [selectedProductIds, setSelectedProductIds] = useState<Set<string>>(new Set());
  const [imageUrl, setImageUrl] = useState<string>('');
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { trackActivity } = useActivityTracker();
  const { takePicture, selectFromGallery } = useCamera();
  const { calculateZoneBlocks, combineNutrition } = useZoneCalculation();
  const { isZoneEnabled } = useFeatureFlags();
  const { profile } = useProfile();

  // Fetch available products
  const { data: products = [] } = useQuery({
    queryKey: ['products-for-dish-dialog'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data, error } = await supabase
        .from('products')
        .select('id, name, protein_per_100g, carbs_per_100g, fat_per_100g, calories_per_100g, image_url')
        .or(`user_id.eq.${user.id},is_public.eq.true`)
        .order('name');

      if (error) throw error;
      return data || [];
    }
  });

  useEffect(() => {
    if (dish) {
      setName(dish.name || '');
      setDescription(dish.description || '');
      setMealType(dish.meal_type || 'lunch');
      setImageUrl(dish.image_url || '');
      
      // Load existing ingredients
      if (dish.dish_ingredients) {
        const dishIngredients = dish.dish_ingredients.map((ing: any) => ({
          id: crypto.randomUUID(),
          product_id: ing.products.id,
          grams: ing.grams,
          product_name: ing.products.name
        }));
        setIngredients(dishIngredients);
        setSelectedProductIds(new Set(dishIngredients.map((ing: any) => ing.product_id)));
      }
    }
  }, [dish]);

  const handleProductSelect = (productId: string, grams: number = 100) => {
    const existingIngredient = ingredients.find(ing => ing.product_id === productId);
    if (existingIngredient) {
      setIngredients(ingredients.filter(ing => ing.id !== existingIngredient.id));
      setSelectedProductIds(prev => {
        const newSet = new Set(prev);
        newSet.delete(productId);
        return newSet;
      });
    } else {
      const newIngredient: Ingredient = {
        id: crypto.randomUUID(),
        product_id: productId,
        grams
      };
      setIngredients([...ingredients, newIngredient]);
      setSelectedProductIds(prev => new Set([...prev, productId]));
    }
  };

  const updateIngredientGrams = (id: string, newGrams: number) => {
    setIngredients(ingredients.map(ing => 
      ing.id === id ? { ...ing, grams: newGrams } : ing
    ));
  };

  const removeIngredient = (id: string) => {
    const ingredient = ingredients.find(ing => ing.id === id);
    if (ingredient) {
      setSelectedProductIds(prev => {
        const newSet = new Set(prev);
        newSet.delete(ingredient.product_id);
        return newSet;
      });
    }
    setIngredients(ingredients.filter(ing => ing.id !== id));
  };

  const editDishMutation = useMutation({
    mutationFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const { error } = await supabase
        .from('dishes')
        .update({
          name: name.trim(),
          description: description.trim() || null,
          meal_type: mealType,
          image_url: imageUrl || null
        })
        .eq('id', dish.id);

      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "Ястието е обновено!",
        description: "Промените са запазени успешно."
      });
      queryClient.invalidateQueries({ queryKey: ['user-dishes'] });
      trackActivity('dishes', 'edit_dish', `Редактира ястие: ${name}`, {
        dish_id: dish.id,
        dish_name: name,
        meal_type: mealType,
        ingredients_count: ingredients.length
      });
      onOpenChange(false);
      resetForm();
    },
    onError: (error) => {
      toast({
        title: "Грешка",
        description: "Неуспешно обновяване на ястието.",
        variant: "destructive"
      });
    }
  });

  const resetForm = () => {
    setName('');
    setDescription('');
    setMealType('lunch');
    setIngredients([]);
    setSelectedProductIds(new Set());
    setImageUrl('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      toast({
        title: "Грешка",
        description: "Моля въведете име на ястието.",
        variant: "destructive"
      });
      return;
    }
    editDishMutation.mutate();
  };

  // Calculate total nutrition
  const totalNutrition = useMemo(() => {
    return ingredients.reduce((total, ingredient) => {
      const product = products.find(p => p.id === ingredient.product_id);
      if (!product) return total;

      const ratio = ingredient.grams / 100;
      return {
        protein: total.protein + (product.protein_per_100g * ratio),
        carbs: total.carbs + (product.carbs_per_100g * ratio),
        fat: total.fat + (product.fat_per_100g * ratio),
        fiber: total.fiber + ((product as any).fiber_per_100g || 0) * ratio,
        calories: total.calories + (product.calories_per_100g * ratio)
      };
    }, { protein: 0, carbs: 0, fat: 0, fiber: 0, calories: 0 });
  }, [ingredients, products]);

  // Zone calculation for ingredients
  const zoneData = useMemo(() => {
    if (!isZoneEnabled) return null;
    return calculateZoneBlocks(totalNutrition);
  }, [totalNutrition, calculateZoneBlocks, isZoneEnabled]);

  const handleTakePicture = async () => {
    try {
      const dataUrl = await takePicture();
      if (dataUrl) {
        setImageUrl(dataUrl);
      }
    } catch (error: any) {
      if (error.message !== 'USER_CANCELLED') {
        toast({
          title: 'Грешка',
          description: 'Неуспешно заснемане на снимка.',
          variant: 'destructive'
        });
      }
    }
  };

  const handleSelectFromGallery = async () => {
    try {
      const dataUrl = await selectFromGallery();
      if (dataUrl) {
        setImageUrl(dataUrl);
      }
    } catch (error: any) {
      if (error.message !== 'USER_CANCELLED') {
        toast({
          title: 'Грешка',
          description: 'Неуспешно избиране на снимка.',
          variant: 'destructive'
        });
      }
    }
  };

  const handleRemoveImage = () => {
    setImageUrl('');
  };

  if (!dish) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[95vw] sm:max-w-2xl lg:max-w-4xl h-[95vh] flex flex-col rounded-2xl">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Edit className="w-5 h-5" />
            Редактирай ястие
          </DialogTitle>
          <DialogDescription>
            Редактирайте информацията и продуктите за ястието
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto overflow-x-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6 px-1">
            {/* Основна информация */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Основна информация</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="dish-name">Име на ястието *</Label>
                    <Input
                      id="dish-name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Напр. Салата с пилешко"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="dish-description">Описание</Label>
                    <Textarea
                      id="dish-description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      placeholder="Кратко описание на ястието..."
                      rows={3}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="meal-type">Тип хранене *</Label>
                    <Select value={mealType} onValueChange={(value: any) => setMealType(value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="breakfast">Закуска</SelectItem>
                        <SelectItem value="lunch">Обяд</SelectItem>
                        <SelectItem value="dinner">Вечеря</SelectItem>
                        <SelectItem value="snack">Междинно</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Image upload section */}
                  <div className="space-y-2">
                    <Label className="text-sm">Снимка на ястието</Label>
                    <div className="flex items-start gap-2">
                      {imageUrl && (
                        <div className="relative">
                          <img
                            src={imageUrl}
                            alt="Снимка на ястието"
                            className="w-16 h-16 object-cover rounded-lg border"
                          />
                          <Button
                            variant="destructive"
                            size="sm"
                            className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0"
                            onClick={handleRemoveImage}
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </div>
                      )}
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="outline" size="sm" className="h-16 w-16 p-0">
                            <Plus className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent>
                          <DropdownMenuItem onClick={handleTakePicture}>
                            <Camera className="w-4 h-4 mr-2" />
                            Камера
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={handleSelectFromGallery}>
                            <ImageIcon className="w-4 h-4 mr-2" />
                            Галерия
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Nutrition Summary - only show when no Zone results */}
              {ingredients.length > 0 && !zoneData && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Хранителна стойност</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center space-y-2">
                      <div className="text-2xl font-bold text-primary">{Math.round(totalNutrition.calories)} kcal</div>
                      <div className="text-sm space-y-1">
                        <div>Протеин: {totalNutrition.protein.toFixed(1)}г</div>
                        <div>Въглехидр.: {totalNutrition.carbs.toFixed(1)}г</div>
                        <div>Мазнини: {totalNutrition.fat.toFixed(1)}г</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Продукти */}
            <div className="space-y-6">
              <ProductSelector
                onProductSelect={handleProductSelect}
                selectedProductIds={selectedProductIds}
                showProductSelection={showProductSelection}
                onToggleProductSelection={setShowProductSelection}
                selectedCount={ingredients.length}
              />

              {/* Added Ingredients List - Cook page style */}
              {ingredients.length > 0 && (
                <CookingItemsList 
                  ingredients={ingredients}
                  products={products}
                  onUpdateGrams={updateIngredientGrams}
                  onRemove={removeIngredient}
                  onClearAll={() => {
                    setIngredients([]);
                    setSelectedProductIds(new Set());
                  }}
                />
              )}

              {/* Zone Result - same as Cook page */}
              {zoneData && (
                <ZoneResultCard nutrition={totalNutrition} zoneCalc={zoneData} />
              )}

              {/* Action Button */}
              <div className="flex">
                <Button 
                  onClick={handleSubmit}
                  disabled={editDishMutation.isPending}
                  className="w-full"
                >
                  <Save className="w-4 h-4 mr-2" />
                  {editDishMutation.isPending ? 'Запазване...' : 'Запази промените'}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};