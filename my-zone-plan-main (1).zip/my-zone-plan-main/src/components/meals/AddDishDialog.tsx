import { useState, useMemo, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ChefHat, Save, X, Trash2, Camera, ImageIcon, Plus, Search, ChevronLeft, ChevronRight, Filter } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useUserLimits } from '@/hooks/useUserLimits';
import { useActivityTracker } from '@/hooks/useActivityTracker';
import { useCamera } from '@/hooks/useCamera';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useZoneCalculation } from '@/hooks/useZoneCalculation';
import { useFeatureFlags } from '@/hooks/useFeatureFlags';
import { ZoneResultCard } from '@/components/zone/ZoneResultCard';
import { CookingItemsList } from '@/components/cooking/CookingItemsList';
import { useDebounce } from 'use-debounce';
import { AddProductDialog } from '@/components/products/AddProductDialog';
import { Checkbox } from '@/components/ui/checkbox';

interface AddDishDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface Ingredient {
  id: string;
  product_id: string;
  grams: number;
}

// Product categories for filtering
const categories = [
  { value: 'all', label: 'Всички' },
  { value: 'vegetables', label: 'Зеленчуци' },
  { value: 'fruits', label: 'Плодове' },
  { value: 'protein', label: 'Протеини' },
  { value: 'dairy', label: 'Млечни' },
  { value: 'grains', label: 'Зърнени' },
  { value: 'legumes', label: 'Варива' },
  { value: 'nuts', label: 'Ядки' },
  { value: 'fats', label: 'Мазнини' },
  { value: 'other', label: 'Други' }
];

const PRODUCTS_PER_PAGE = 12;

export const AddDishDialog = ({ open, onOpenChange }: AddDishDialogProps) => {
  const { canAdd, limits } = useUserLimits();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [mealType, setMealType] = useState<'breakfast' | 'lunch' | 'dinner' | 'snack'>('lunch');
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [showProductSelection, setShowProductSelection] = useState(true);
  const [selectedProductIds, setSelectedProductIds] = useState<Set<string>>(new Set());
  const [imageUrl, setImageUrl] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');
  const [debouncedSearchQuery] = useDebounce(searchQuery, 300);
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [categoryDialogOpen, setCategoryDialogOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);

  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { trackActivity } = useActivityTracker();
  const { takePicture, selectFromGallery } = useCamera();
  const { calculateZoneBlocks, combineNutrition } = useZoneCalculation();
  const { isZoneEnabled } = useFeatureFlags();

  // Fetch available products with filtering and pagination
  const { data: productsData = { products: [], total: 0 }, isLoading } = useQuery({
    queryKey: ['products-for-add-dish-dialog', debouncedSearchQuery, selectedCategories, currentPage],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return { products: [], total: 0 };

      let query = supabase
        .from('products')
        .select('id, name, protein_per_100g, carbs_per_100g, fat_per_100g, fiber_per_100g, calories_per_100g, image_url, category', { count: 'exact' })
        .eq('user_id', user.id)
        .order('name');

      // Apply category filter
      if (selectedCategories.length > 0) {
        query = query.in('category', selectedCategories as any);
      }

      // Apply search filter
      if (debouncedSearchQuery.trim()) {
        query = query.ilike('name', `%${debouncedSearchQuery.trim()}%`);
      }

      // Apply pagination
      const from = (currentPage - 1) * PRODUCTS_PER_PAGE;
      const to = from + PRODUCTS_PER_PAGE - 1;
      query = query.range(from, to);

      const { data, error, count } = await query;
      
      if (error) throw error;
      return { 
        products: data || [], 
        total: count || 0 
      };
    },
    staleTime: 1000 * 60 * 5,
    refetchOnWindowFocus: false
  });

  const products = productsData.products;
  const totalProducts = productsData.total;
  const totalPages = Math.ceil(totalProducts / PRODUCTS_PER_PAGE);

  // Reset pagination when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [selectedCategories, debouncedSearchQuery]);

  const handleProductSelect = (productId: string, grams: number = 100) => {
    const existing = ingredients.find(i => i.product_id === productId);
    if (existing) {
      setIngredients(ingredients.filter(i => i.product_id !== productId));
      setSelectedProductIds(prev => {
        const ns = new Set(prev);
        ns.delete(productId);
        return ns;
      });
    } else {
      const ing: Ingredient = { id: crypto.randomUUID(), product_id: productId, grams };
      setIngredients(prev => [...prev, ing]);
      setSelectedProductIds(prev => new Set([...prev, productId]));
    }
  };

  const updateIngredientGrams = (id: string, newGrams: number) => {
    setIngredients(ingredients.map(ing => ing.id === id ? { ...ing, grams: newGrams } : ing));
  };

  const removeIngredient = (id: string) => {
    const ing = ingredients.find(i => i.id === id);
    if (ing) {
      setSelectedProductIds(prev => {
        const ns = new Set(prev);
        ns.delete(ing.product_id);
        return ns;
      });
    }
    setIngredients(ingredients.filter(i => i.id !== id));
  };

  const totalNutrition = useMemo(() => {
    return ingredients.reduce((total, ing) => {
      const product = products.find((p: any) => p.id === ing.product_id);
      if (!product) return total;
      const ratio = ing.grams / 100;
      return {
        protein: total.protein + product.protein_per_100g * ratio,
        carbs: total.carbs + product.carbs_per_100g * ratio,
        fat: total.fat + product.fat_per_100g * ratio,
        fiber: total.fiber + (product.fiber_per_100g || 0) * ratio,
        calories: total.calories + product.calories_per_100g * ratio,
      };
    }, { protein: 0, carbs: 0, fat: 0, fiber: 0, calories: 0 });
  }, [ingredients, products]);

  // Zone calculation for ingredients
  const zoneData = useMemo(() => {
    if (!isZoneEnabled) return null;
    return calculateZoneBlocks(totalNutrition);
  }, [totalNutrition, calculateZoneBlocks, isZoneEnabled]);

  const handleTakePicture = async () => {
    try {
      const dataUrl = await takePicture();
      if (dataUrl) {
        setImageUrl(dataUrl);
      }
    } catch (error: any) {
      if (error.message !== 'USER_CANCELLED') {
        toast({
          title: 'Грешка',
          description: 'Неуспешно заснемане на снимка.',
          variant: 'destructive'
        });
      }
    }
  };

  const handleSelectFromGallery = async () => {
    try {
      const dataUrl = await selectFromGallery();
      if (dataUrl) {
        setImageUrl(dataUrl);
      }
    } catch (error: any) {
      if (error.message !== 'USER_CANCELLED') {
        toast({
          title: 'Грешка',
          description: 'Неуспешно избиране на снимка.',
          variant: 'destructive'
        });
      }
    }
  };

  const handleRemoveImage = () => {
    setImageUrl('');
  };

  const resetForm = () => {
    setName('');
    setDescription('');
    setMealType('lunch');
    setIngredients([]);
    setSelectedProductIds(new Set());
    setShowProductSelection(true);
    setImageUrl('');
  };

  const createDishMutation = useMutation({
    mutationFn: async () => {
      if (!canAdd.dishes) {
        throw new Error(`Достигнахте лимита от ${limits.dishes} ястия. Надстройте до Премиум за неограничен достъп или изтрийте някои от съществуващите.`);
      }

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data: dish, error: dishError } = await supabase
        .from('dishes')
        .insert({
          name: name.trim(),
          description: description.trim() || null,
          meal_type: mealType,
          user_id: user.id,
          image_url: imageUrl || null,
        })
        .select()
        .single();

      if (dishError) throw dishError;

      if (ingredients.length > 0) {
        const rows = ingredients
          .filter(i => i.product_id)
          .map(i => ({ dish_id: dish.id, product_id: i.product_id, grams: i.grams }));

        const { error: ingError } = await supabase
          .from('dish_ingredients')
          .insert(rows);

        if (ingError) throw ingError;
      }

      return dish;
    },
    onSuccess: (dish) => {
      toast({ title: 'Ястието е създадено!', description: 'Успешно създадохте ново ястие.' });
      queryClient.invalidateQueries({ queryKey: ['dishes'] });
      queryClient.invalidateQueries({ queryKey: ['user-counts'] });
      trackActivity('dishes', 'add_dish', `Създаде ново ястие: ${dish.name}`, {
        dish_id: dish.id,
        dish_name: dish.name,
        meal_type: mealType,
        ingredients_count: ingredients.length,
      });
      onOpenChange(false);
      resetForm();
    },
    onError: (error: any) => {
      toast({ title: 'Грешка', description: error?.message || 'Неуспешно създаване на ястие.', variant: 'destructive' });
    }
  });

  const handleSubmit = () => {
    if (!name.trim()) {
      toast({ title: 'Грешка', description: 'Моля въведете име на ястието.', variant: 'destructive' });
      return;
    }
    if (ingredients.length === 0) {
      toast({ title: 'Грешка', description: 'Моля добавете поне един продукт.', variant: 'destructive' });
      return;
    }
    createDishMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[95vw] sm:max-w-2xl lg:max-w-4xl max-h-[95vh] overflow-y-auto overflow-x-hidden rounded-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-base sm:text-lg">
            <ChefHat className="w-4 h-4 sm:w-5 sm:h-5" />
            Създай ново ястие
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6 px-1">
          {/* Основна информация */}
          <div className="space-y-4 lg:space-y-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base lg:text-lg">Основна информация</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 lg:space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="dish-name" className="text-sm">Име на ястието *</Label>
                  <Input 
                    id="dish-name" 
                    value={name} 
                    onChange={(e) => setName(e.target.value)} 
                    placeholder="Напр. Пилешка салата"
                    className="text-sm" 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dish-description" className="text-sm">Кратко описание</Label>
                  <Textarea 
                    id="dish-description" 
                    value={description} 
                    onChange={(e) => setDescription(e.target.value)} 
                    placeholder="Опишете накратко ястието..." 
                    rows={2}
                    className="text-sm"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="meal-type" className="text-sm">Тип хранене</Label>
                  <Select value={mealType} onValueChange={(v: any) => setMealType(v)}>
                    <SelectTrigger className="text-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="breakfast">Закуска</SelectItem>
                      <SelectItem value="lunch">Обяд</SelectItem>
                      <SelectItem value="dinner">Вечеря</SelectItem>
                      <SelectItem value="snack">Междинно</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Image upload section */}
                <div className="space-y-2">
                  <Label className="text-sm">Снимка на ястието</Label>
                  <div className="flex items-start gap-2">
                    {imageUrl && (
                      <div className="relative">
                        <img
                          src={imageUrl}
                          alt="Снимка на ястието"
                          className="w-16 h-16 object-cover rounded-lg border"
                        />
                        <Button
                          variant="destructive"
                          size="sm"
                          className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0"
                          onClick={handleRemoveImage}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    )}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="outline" size="sm" className="h-16 w-16 p-0">
                          <Plus className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuItem onClick={handleTakePicture}>
                          <Camera className="w-4 h-4 mr-2" />
                          Камера
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={handleSelectFromGallery}>
                          <ImageIcon className="w-4 h-4 mr-2" />
                          Галерия
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Nutrition summary - only show when no Zone results */}
            {ingredients.length > 0 && !zoneData && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base lg:text-lg">Хранителна стойност (общо)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center space-y-2">
                    <div className="text-xl lg:text-2xl font-bold text-primary">{Math.round(totalNutrition.calories)} kcal</div>
                    <div className="text-xs lg:text-sm space-y-1">
                      <div>Протеин: {totalNutrition.protein.toFixed(1)}г</div>
                      <div>Въглехидр.: {totalNutrition.carbs.toFixed(1)}г</div>
                      <div>Мазнини: {totalNutrition.fat.toFixed(1)}г</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Продукти */}
          <div className="space-y-4 lg:space-y-6">
            {/* Add Products Button - when collapsed */}
            {!showProductSelection && ingredients.length > 0 && (
              <Button 
                variant="default" 
                size="sm"
                onClick={() => setShowProductSelection(true)}
                className="w-full bg-gradient-to-r from-primary to-primary-light hover:from-primary-dark hover:to-primary shadow-lg hover:shadow-xl transition-all duration-300"
              >
                <Plus className="w-4 h-4 mr-2" />
                Добави продукти
              </Button>
            )}

            {/* Product Selection - Collapsible */}
            {showProductSelection && (
              <div className="space-y-2 border border-border rounded-lg p-2 bg-card">
                {/* Search and Add Row */}
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder="Търси продукт..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <Button 
                    variant="outline" 
                    onClick={() => setShowAddProduct(true)}
                    size="icon"
                    className="flex-shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>

                {/* Category Filter */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="text-sm font-medium text-muted-foreground">Категории</div>
                    <Button variant="outline" size="sm" onClick={() => setCategoryDialogOpen(true)} className="flex items-center gap-2">
                      <Filter className="w-4 h-4" /> Филтрирай
                    </Button>
                  </div>
                  {selectedCategories.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {selectedCategories.map((cat) => (
                        <div key={cat} className="text-xs bg-secondary px-2 py-1 rounded">
                          {categories.find(c => c.value === cat)?.label || cat}
                        </div>
                      ))}
                      <Button variant="ghost" size="sm" className="h-7" onClick={() => setSelectedCategories([])}>Изчисти</Button>
                    </div>
                  )}
                </div>

                {/* Categories Dialog */}
                <Dialog open={categoryDialogOpen} onOpenChange={setCategoryDialogOpen}>
                  <DialogContent className="max-w-sm">
                    <DialogHeader>
                      <DialogTitle>Избери категории</DialogTitle>
                    </DialogHeader>
                    <div className="grid grid-cols-2 gap-2 py-2">
                      {categories.filter(c => c.value !== 'all').map((category) => {
                        const checked = selectedCategories.includes(category.value);
                        return (
                          <label key={category.value} className="flex items-center gap-2 rounded-lg border p-2 cursor-pointer">
                            <Checkbox
                              checked={checked}
                              onCheckedChange={(val) => {
                                const v = !!val;
                                setSelectedCategories((prev) =>
                                  v ? [...prev, category.value] : prev.filter((x) => x !== category.value)
                                );
                              }}
                            />
                            <span className="text-sm">{category.label}</span>
                          </label>
                        );
                      })}
                    </div>
                    <div className="flex justify-end gap-2 pt-2 border-t">
                      <Button variant="outline" onClick={() => setCategoryDialogOpen(false)}>Затвори</Button>
                      <Button onClick={() => setCategoryDialogOpen(false)}>Приложи</Button>
                    </div>
                  </DialogContent>
                </Dialog>

                {/* Loading indicator */}
                {isLoading ? (
                  <div className="text-center py-4 text-muted-foreground">
                    Зареждане...
                  </div>
                ) : (
                  <>
                    {/* Products Grid - Same as Cook page */}
                    <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-2">
                      {products.map(product => {
                        const isAdded = selectedProductIds.has(product.id);
                        return (
                          <div 
                            key={product.id} 
                            className={`relative cursor-pointer aspect-square rounded-lg border-2 overflow-hidden transition-colors duration-200 ${
                              isAdded 
                                ? 'border-primary bg-primary/10' 
                                : 'border-border hover:border-primary/50'
                            }`}
                            onClick={() => handleProductSelect(product.id, 100)}
                          >
                            {/* Background Image */}
                            {product.image_url ? (
                              <div 
                                className={`absolute inset-0 bg-cover bg-center transition-all duration-200 ${isAdded ? 'opacity-70' : ''}`}
                                style={{ backgroundImage: `url(${product.image_url})` }}
                              />
                            ) : (
                              <div className={`absolute inset-0 bg-gradient-to-br from-primary/20 to-primary/40 flex items-center justify-center transition-all duration-200 ${isAdded ? 'from-primary/40 to-primary/60' : ''}`}>
                                <ChefHat className="w-6 h-6 text-primary" />
                              </div>
                            )}
                            
                            {/* Text Overlay */}
                            <div className="absolute inset-0 flex items-end justify-center pb-4">
                              <div className="backdrop-blur-sm px-2 py-1.5 rounded-md border bg-background/90 border-border/50">
                                <h4 className="font-semibold text-xs leading-tight uppercase tracking-wide text-center line-clamp-2 text-foreground">
                                  {product.name}
                                </h4>
                              </div>
                            </div>

                            {/* Selected indicator */}
                            {isAdded && (
                              <div className="absolute top-2 right-2 w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                                <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                                </svg>
                              </div>
                            )}
                          </div>
                        );
                      })}
                      
                      {products.length === 0 && (
                        <div className="col-span-full text-center py-8 text-muted-foreground">
                          <ChefHat className="w-12 h-12 mx-auto mb-2 opacity-50" />
                          <p>{searchQuery || selectedCategories.length > 0 ? 'Няма намерени продукти' : 'Няма добавени продукти'}</p>
                        </div>
                      )}
                    </div>

                    {/* Pagination */}
                    {totalPages > 1 && (
                      <div className="flex items-center justify-center gap-2 pt-1">
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                          disabled={currentPage === 1}
                          className="w-8 h-8"
                        >
                          <ChevronLeft className="w-4 h-4" />
                        </Button>
                        <span className="text-xs text-muted-foreground min-w-[36px] text-center">
                          {currentPage} / {totalPages}
                        </span>
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                          disabled={currentPage === totalPages}
                          className="w-8 h-8"
                        >
                          <ChevronRight className="w-4 h-4" />
                        </Button>
                      </div>
                    )}
                  </>
                )}

                {/* Hide Button */}
                {ingredients.length > 0 && (
                  <div className="flex justify-center pt-2 border-t">
                    <Button 
                      variant="ghost" 
                      onClick={() => setShowProductSelection(false)}
                      size="sm"
                    >
                      Скрий продукти
                    </Button>
                  </div>
                )}
              </div>
            )}

            {/* Added Ingredients List - Cook page style */}
            {ingredients.length > 0 && (
              <CookingItemsList 
                ingredients={ingredients}
                products={products}
                onUpdateGrams={updateIngredientGrams}
                onRemove={removeIngredient}
                onClearAll={() => {
                  setIngredients([]);
                  setSelectedProductIds(new Set());
                }}
              />
            )}

            {/* Zone Result - same as Cook page */}
            {zoneData && (
              <ZoneResultCard nutrition={totalNutrition} zoneCalc={zoneData} />
            )}

            {/* Action */}
            <div className="flex">
              <Button onClick={handleSubmit} className="w-full text-sm">
                <Save className="w-4 h-4 mr-2" />
                Създай ястие
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>

      <AddProductDialog
        open={showAddProduct}
        onOpenChange={setShowAddProduct}
      />
    </Dialog>
  );
}
