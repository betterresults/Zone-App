import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQueryClient } from '@tanstack/react-query';

interface AddDishToCalendarDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  dish: any;
  isPro: boolean;
}

export const AddDishToCalendarDialog = ({ open, onOpenChange, dish, isPro }: AddDishToCalendarDialogProps) => {
  const [servings, setServings] = useState(1);
  const [mealType, setMealType] = useState<'breakfast' | 'lunch' | 'dinner' | 'snack'>(
    dish?.meal_type || 'lunch'
  );
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedDays, setSelectedDays] = useState<number[]>([new Date().getDay()]);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const servingOptions = [
    { value: 0.5, label: '1/2 порция' },
    { value: 1, label: '1 порция' },
    { value: 1.5, label: '1 1/2 порции' },
    { value: 2, label: '2 порции' }
  ];

  const mealTypeLabels = {
    breakfast: 'Закуска',
    lunch: 'Обяд',
    dinner: 'Вечеря',
    snack: 'Междинно'
  };

  const dayLabels = [
    'Неделя', 'Понеделник', 'Вторник', 'Сряда', 'Четвъртък', 'Петък', 'Събота'
  ];

  const addDishMutation = useMutation({
    mutationFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      if (isPro && selectedDays.length > 1) {
        // Premium users can add for multiple days
        const meals = selectedDays.map(day => {
          const date = new Date(selectedDate);
          const diff = day - date.getDay();
          date.setDate(date.getDate() + diff);
          
          return {
            user_id: user.id,
            dish_id: dish.id,
            date: format(date, 'yyyy-MM-dd'),
            meal_type: mealType,
            servings: servings
          };
        });

        const { error } = await supabase
          .from('meals')
          .insert(meals);

        if (error) throw error;

        // Sync with weekly meal plans for each day
        for (const meal of meals) {
          const mealDate = new Date(meal.date);
          const dayOfWeek = (mealDate.getDay() === 0) ? 6 : mealDate.getDay() - 1;
          const weekStart = new Date(mealDate);
          weekStart.setDate(mealDate.getDate() - dayOfWeek);
          const weekStartString = format(weekStart, 'yyyy-MM-dd');

          // Check if exists in weekly plans
          const { data: existingWeekly } = await supabase
            .from('weekly_meal_plans')
            .select('*')
            .eq('user_id', user.id)
            .eq('week_start_date', weekStartString)
            .eq('day_of_week', dayOfWeek)
            .eq('meal_type', mealType)
            .eq('dish_id', dish.id)
            .maybeSingle();

          if (existingWeekly) {
            await supabase
              .from('weekly_meal_plans')
              .update({ 
                is_completed: true,
                completed_at: new Date().toISOString(),
                servings: servings
              })
              .eq('id', existingWeekly.id);
          } else {
            await supabase
              .from('weekly_meal_plans')
              .insert({
                user_id: user.id,
                week_start_date: weekStartString,
                day_of_week: dayOfWeek,
                meal_type: mealType,
                dish_id: dish.id,
                servings: servings,
                is_completed: true,
                completed_at: new Date().toISOString()
              });
          }
        }

        return { count: meals.length };
      } else {
        // Single day (free users or premium users with single day)
        const { error } = await supabase
          .from('meals')
          .insert({
            user_id: user.id,
            dish_id: dish.id,
            date: format(selectedDate, 'yyyy-MM-dd'),
            meal_type: mealType,
            servings: servings
          });

        if (error) throw error;

        // Sync with weekly meal plans
        const mealDate = selectedDate;
        const dayOfWeek = (mealDate.getDay() === 0) ? 6 : mealDate.getDay() - 1;
        const weekStart = new Date(mealDate);
        weekStart.setDate(mealDate.getDate() - dayOfWeek);
        const weekStartString = format(weekStart, 'yyyy-MM-dd');

        const { data: existingWeekly } = await supabase
          .from('weekly_meal_plans')
          .select('*')
          .eq('user_id', user.id)
          .eq('week_start_date', weekStartString)
          .eq('day_of_week', dayOfWeek)
          .eq('meal_type', mealType)
          .eq('dish_id', dish.id)
          .maybeSingle();

        if (existingWeekly) {
          await supabase
            .from('weekly_meal_plans')
            .update({ 
              is_completed: true,
              completed_at: new Date().toISOString(),
              servings: servings
            })
            .eq('id', existingWeekly.id);
        } else {
          await supabase
            .from('weekly_meal_plans')
            .insert({
              user_id: user.id,
              week_start_date: weekStartString,
              day_of_week: dayOfWeek,
              meal_type: mealType,
              dish_id: dish.id,
              servings: servings,
              is_completed: true,
              completed_at: new Date().toISOString()
            });
        }

        return { count: 1 };
      }
    },
    onSuccess: (data) => {
      toast({
        title: "Добавено в календара!",
        description: data.count > 1 
          ? `"${dish.name}" е добавено за ${data.count} дни.`
          : `"${dish.name}" е добавено за ${mealTypeLabels[mealType]} на ${format(selectedDate, 'dd.MM.yyyy')}.`,
        variant: "success"
      });
      
      queryClient.invalidateQueries({ queryKey: ['calendar-meals'] });
      queryClient.invalidateQueries({ queryKey: ['today-meals-with-dishes'] });
      queryClient.invalidateQueries({ queryKey: ['meals'] });
      queryClient.invalidateQueries({ queryKey: ['weeklyMealPlans'] });
      
      onOpenChange(false);
      resetForm();
    },
    onError: (error) => {
      toast({
        title: "Грешка",
        description: "Неуспешно добавяне в календара.",
        variant: "destructive"
      });
      console.error('Add to calendar error:', error);
    }
  });

  const resetForm = () => {
    setServings(1);
    setMealType(dish?.meal_type || 'lunch');
    setSelectedDate(new Date());
    setSelectedDays([new Date().getDay()]);
  };

  const handleDayToggle = (dayIndex: number) => {
    setSelectedDays(prev => {
      if (prev.includes(dayIndex)) {
        return prev.filter(day => day !== dayIndex);
      } else {
        return [...prev, dayIndex];
      }
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isPro && selectedDays.length === 0) return;
    addDishMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Добави в календара</DialogTitle>
          <DialogDescription>
            Добавете "{dish?.name}" в календара си
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="meal-type">Тип хранене</Label>
              <Select value={mealType} onValueChange={(value: any) => setMealType(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="breakfast">Закуска</SelectItem>
                  <SelectItem value="lunch">Обяд</SelectItem>
                  <SelectItem value="dinner">Вечеря</SelectItem>
                  <SelectItem value="snack">Междинно</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="servings">Порции</Label>
              <Select value={servings.toString()} onValueChange={(value) => setServings(parseFloat(value))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {servingOptions.map(option => (
                    <SelectItem key={option.value} value={option.value.toString()}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {isPro ? (
            <>
              <div className="space-y-2">
                <Label>Дата</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !selectedDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {selectedDate ? format(selectedDate, 'dd.MM.yyyy') : "Изберете дата"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={(date) => date && setSelectedDate(date)}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <Label>Дни от седмицата (може да изберете няколко)</Label>
                <div className="grid grid-cols-2 gap-2">
                  {dayLabels.map((day, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Checkbox
                        id={`day-${index}`}
                        checked={selectedDays.includes(index)}
                        onCheckedChange={() => handleDayToggle(index)}
                      />
                      <Label htmlFor={`day-${index}`} className="text-sm">
                        {day}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <div className="bg-muted/50 p-3 rounded-lg">
              <p className="text-sm text-muted-foreground">
                Ще бъде добавено за <strong>{mealTypeLabels[mealType]}</strong> днес ({format(new Date(), 'dd.MM.yyyy')})
              </p>
            </div>
          )}

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Отказ
            </Button>
            <Button 
              type="submit" 
              disabled={addDishMutation.isPending || (isPro && selectedDays.length === 0)}
            >
              {addDishMutation.isPending ? 'Добавя...' : 'Добави'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};