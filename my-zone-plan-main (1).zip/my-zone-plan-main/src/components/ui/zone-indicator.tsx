import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { type ZoneCalculation } from '@/hooks/useZoneCalculation';

interface ZoneIndicatorProps {
  zoneData: ZoneCalculation;
  className?: string;
  showDetails?: boolean;
  compact?: boolean;
}

export const ZoneIndicator = ({ 
  zoneData, 
  className,
  showDetails = false,
  compact = false
}: ZoneIndicatorProps) => {
  const { isInZone, ratio, protein, carbs, fat } = zoneData;

  // Calculate zone status with correct Zone Diet logic
  const minBlocks = Math.min(protein, carbs, fat); // Zone Diet правилна логика
  const maxBlocks = Math.max(protein, carbs, fat);
  const zoneRatio = minBlocks > 0 ? minBlocks / maxBlocks : 0;
  
  // Function to determine color based on Cook page logic
  const getBlockColor = (blockValue: number) => {
    if (zoneRatio >= 0.9) {
      // В ЗОНАТА - всички зелени
      return 'bg-green-500';
    } else if (zoneRatio >= 0.7) {
      // БЛИЗО ДО ЗОНАТА - само зелени и жълти, БЕЗ червени
      const percentOfMax = blockValue / maxBlocks;
      return percentOfMax >= 0.85 ? 'bg-green-500' : 'bg-yellow-500';
    } else {
      // ИЗВЪН ЗОНАТА - може да има червени
      const percentOfMax = blockValue / maxBlocks;
      if (percentOfMax >= 0.9) {
        return 'bg-green-500';
      } else if (percentOfMax >= 0.7) {
        return 'bg-yellow-500';
      } else {
        return 'bg-red-500';
      }
    }
  };

  const getZoneStatus = () => {
    if (zoneRatio >= 0.9) {
      return { text: "В зоната", color: "text-green-600" };
    } else if (zoneRatio >= 0.7) {
      return { text: "Близо до зоната", color: "text-yellow-600" };
    } else {
      return { text: "Извън зоната", color: "text-red-600" };
    }
  };

  const zoneStatus = getZoneStatus();

  if (compact) {
    return (
      <div className={cn("flex flex-col items-center gap-2", className)}>
        <div className="flex items-center justify-center gap-3">
          <div className="flex flex-col items-center gap-1">
            <div className={cn("w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm", getBlockColor(protein))}>
              {protein.toFixed(1)}
            </div>
            <span className="text-xs font-medium text-muted-foreground">П</span>
          </div>
          <div className="flex flex-col items-center gap-1">
            <div className={cn("w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm", getBlockColor(carbs))}>
              {carbs.toFixed(1)}
            </div>
            <span className="text-xs font-medium text-muted-foreground">В</span>
          </div>
          <div className="flex flex-col items-center gap-1">
            <div className={cn("w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm", getBlockColor(fat))}>
              {fat.toFixed(1)}
            </div>
            <span className="text-xs font-medium text-muted-foreground">М</span>
          </div>
        </div>
        <div className={cn("text-xs font-medium", zoneStatus.color)}>
          {zoneStatus.text}
        </div>
      </div>
    );
  }

  return (
    <div className={cn("space-y-2", className)}>
      <div className="flex items-center gap-2">
        <Badge 
          variant={isInZone ? "default" : "secondary"}
          className={cn(
            "text-xs font-medium",
            isInZone 
              ? "bg-zone-balanced text-white" 
              : "bg-zone-warning text-white"
          )}
        >
          {isInZone ? "В Зоната ✓" : "Извън Зоната"}
        </Badge>
        <span className="text-sm text-muted-foreground">
          {ratio}
        </span>
      </div>
      
      {showDetails && (
        <div className="grid grid-cols-3 gap-2 text-xs">
          <div className="flex items-center gap-1">
            <div className={cn("w-2 h-2 rounded-full", getBlockColor(protein))}></div>
            <span>П: {protein.toFixed(1)}</span>
          </div>
          <div className="flex items-center gap-1">
            <div className={cn("w-2 h-2 rounded-full", getBlockColor(carbs))}></div>
            <span>В: {carbs.toFixed(1)}</span>
          </div>
          <div className="flex items-center gap-1">
            <div className={cn("w-2 h-2 rounded-full", getBlockColor(fat))}></div>
            <span>М: {fat.toFixed(1)}</span>
          </div>
        </div>
      )}
    </div>
  );
};