import React from "react";
import { cn } from "@/lib/utils";

interface StableInputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "value" | "onChange"> {
  value: string;
  onValueChange: (value: string) => void;
  liveUpdate?: boolean; // if true, call onValueChange on each keystroke
}

export const StableInput = React.forwardRef<HTMLInputElement, StableInputProps>(
  ({ value, onValueChange, className, onBlur, onKeyDown, placeholder, id, type = "text", liveUpdate = false, ...rest }, ref) => {
    const [displayValue, setDisplayValue] = React.useState<string>(value || "");

    // Sync when external value changes (e.g., when form initializes or is reset)
    React.useEffect(() => {
      setDisplayValue(value || "");
    }, [value]);

    const commit = (newValue: string) => {
      onValueChange(newValue);
      setDisplayValue(newValue);
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const newValue = e.target.value;
      setDisplayValue(newValue);
      // Only update immediately if liveUpdate is true (for search fields)
      if (liveUpdate) {
        onValueChange(newValue);
      }
    };

    const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
      // Always commit the final value on blur
      onValueChange(displayValue);
      onBlur?.(e);
    };

    return (
      <input
        id={id}
        ref={ref}
        type={type}
        autoComplete="off"
        className={cn(
          "flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
          className
        )}
        value={displayValue}
        onChange={handleChange}
        onBlur={handleBlur}
        onKeyDown={onKeyDown}
        placeholder={placeholder}
        {...rest}
      />
    );
  }
);

StableInput.displayName = "StableInput";

export default StableInput;