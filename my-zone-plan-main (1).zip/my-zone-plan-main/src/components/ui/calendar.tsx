import * as React from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { DayPicker } from "react-day-picker";

import { cn } from "@/lib/utils";
import { buttonVariants } from "@/components/ui/button";

export type CalendarProps = React.ComponentProps<typeof DayPicker> & {
  hasEventsOnDate?: (date: Date) => boolean;
  hasHabitsOnDate?: (date: Date) => boolean;
  hasConflictsOnDate?: (date: Date) => boolean;
};

function Calendar({ 
  className, 
  classNames, 
  showOutsideDays = true, 
  hasEventsOnDate,
  hasHabitsOnDate, 
  hasConflictsOnDate,
  ...props 
}: CalendarProps) {
  // Create modifiers to identify days with events, habits, or conflicts
  const modifiers = React.useMemo(() => {
    const result: any = {};
    
    if (hasEventsOnDate) {
      result.hasEvents = hasEventsOnDate;
    }
    
    if (hasHabitsOnDate) {
      result.hasHabits = hasHabitsOnDate;
    }
    
    if (hasConflictsOnDate) {
      result.hasConflicts = hasConflictsOnDate;
    }
    
    return result;
  }, [hasEventsOnDate, hasHabitsOnDate, hasConflictsOnDate]);

  // Custom Day component to show indicators
  const DayComponent = (props: any) => {
    const { date, displayMonth, ...dayProps } = props;
    const hasEvents = hasEventsOnDate?.(date);
    const hasHabits = hasHabitsOnDate?.(date);
    const hasConflicts = hasConflictsOnDate?.(date);
    
    return (
      <button
        {...dayProps}
        className={cn(
          dayProps.className,
          "relative h-16 w-16 p-1 font-normal rounded-lg border hover:bg-accent/50 transition-colors flex flex-col items-center justify-start",
          hasEvents && "border-blue-500/30 bg-blue-50/30",
          hasHabits && !hasEvents && "border-green-500/30 bg-green-50/30", 
          hasConflicts && "border-red-500/50 bg-red-50/50"
        )}
      >
        <span className="text-sm font-medium mb-1">{date.getDate()}</span>
        
        {/* Show preview of events/habits */}
        <div className="flex-1 w-full text-[10px] leading-none space-y-0.5 overflow-hidden">
          {hasEvents && (
            <div className="bg-blue-500 text-white px-1 rounded text-center truncate">
              Събитие
            </div>
          )}
          {hasHabits && (
            <div className="bg-green-500 text-white px-1 rounded text-center truncate">
              Навик
            </div>
          )}
          {hasConflicts && (
            <div className="bg-red-500 text-white px-1 rounded text-center truncate">
              Конфликт
            </div>
          )}
        </div>
      </button>
    );
  };

  return (
    <DayPicker
      showOutsideDays={showOutsideDays}
      className={cn("p-3", className)}
      modifiers={modifiers}
      classNames={{
        months: "flex flex-col sm:flex-row space-y-4 sm:space-x-4 sm:space-y-0",
        month: "space-y-4",
        caption: "flex justify-center pt-1 relative items-center",
        caption_label: "text-sm font-medium",
        nav: "space-x-1 flex items-center",
        nav_button: cn(
          buttonVariants({ variant: "ghost" }),
          "h-7 w-7 p-0 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/50",
        ),
        nav_button_previous: "absolute left-1",
        nav_button_next: "absolute right-1",
        table: "w-full border-collapse space-y-1",
        head_row: "flex",
        head_cell: "text-muted-foreground rounded-md w-16 font-normal text-[0.8rem]",
        row: "flex w-full mt-2",
        cell: "h-16 w-16 p-0 text-center text-sm align-middle relative focus-within:z-20",
        day: cn(buttonVariants({ variant: "ghost" }), "h-16 w-16 p-0 font-normal aria-selected:opacity-100 rounded-lg relative"),
        day_range_end: "day-range-end",
        day_selected: "bg-primary text-primary-foreground hover:bg-primary rounded-lg shadow-sm",
        day_today: "bg-accent/30 text-foreground font-medium rounded-lg",
        day_outside: "day-outside text-muted-foreground opacity-40 aria-selected:bg-accent/20 aria-selected:text-muted-foreground aria-selected:opacity-30",
        day_disabled: "text-muted-foreground opacity-50",
        day_range_middle: "aria-selected:bg-accent aria-selected:text-accent-foreground",
        day_hidden: "invisible",
        ...classNames,
      }}
      components={{
        IconLeft: ({ ..._props }) => <ChevronLeft className="h-4 w-4" />,
        IconRight: ({ ..._props }) => <ChevronRight className="h-4 w-4" />,
        Day: DayComponent,
      }}
      {...props}
    />
  );
}
Calendar.displayName = "Calendar";

export { Calendar };
