import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Minus, Plus } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

interface ServingsInputProps {
  value: number;
  onChange: (value: number) => void;
  min?: number;
  max?: number;
  id?: string;
}

export function ServingsInput({ 
  value, 
  onChange, 
  min = 1, 
  max = 100,
  id 
}: ServingsInputProps) {
  const isMobile = useIsMobile();
  const [displayValue, setDisplayValue] = React.useState(value.toString());

  // Update display value when prop value changes
  React.useEffect(() => {
    setDisplayValue(value.toString());
  }, [value]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setDisplayValue(newValue);

    if (newValue === '') {
      // Allow empty input temporarily
      return;
    }

    const num = parseInt(newValue);
    if (!isNaN(num) && num >= min && num <= max) {
      onChange(num);
    }
  };

  const handleBlur = () => {
    // On blur, ensure we have a valid value
    if (displayValue === '' || isNaN(parseInt(displayValue))) {
      setDisplayValue(value.toString());
    } else {
      const num = parseInt(displayValue);
      if (num < min) {
        const newValue = min;
        setDisplayValue(newValue.toString());
        onChange(newValue);
      } else if (num > max) {
        const newValue = max;
        setDisplayValue(newValue.toString());
        onChange(newValue);
      }
    }
  };

  const increment = () => {
    const newValue = Math.min(value + 1, max);
    onChange(newValue);
  };

  const decrement = () => {
    const newValue = Math.max(value - 1, min);
    onChange(newValue);
  };

  if (isMobile) {
    return (
      <div className="flex items-center space-x-2">
        <Button
          type="button"
          variant="outline"
          size="icon"
          onClick={decrement}
          disabled={value <= min}
          className="h-10 w-10 shrink-0"
        >
          <Minus className="h-4 w-4" />
        </Button>
        <div className="flex-1 min-w-0 bg-background border border-input rounded-md px-3 py-2 text-center">
          <span className="text-base font-semibold text-foreground">{displayValue}</span>
        </div>
        <Button
          type="button"
          variant="outline"
          size="icon"
          onClick={increment}
          disabled={value >= max}
          className="h-10 w-10 shrink-0"
        >
          <Plus className="h-4 w-4" />
        </Button>
      </div>
    );
  }

  return (
    <Input
      id={id}
      type="number"
      value={displayValue}
      onChange={handleInputChange}
      onBlur={handleBlur}
      min={min}
      max={max}
    />
  );
}