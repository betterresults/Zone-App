import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { AlertDialog, AlertDialogAction, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { RefreshCw } from 'lucide-react';

export const UpdatePrompt = () => {
  const [showUpdatePrompt, setShowUpdatePrompt] = useState(false);
  const [newServiceWorker, setNewServiceWorker] = useState<ServiceWorker | null>(null);
  const [isUpdating, setIsUpdating] = useState(false);

  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        // Service worker has been updated
        window.location.reload();
      });

      navigator.serviceWorker.getRegistration().then((registration) => {
        if (!registration) return;

        // If there's already an updated worker waiting, prompt immediately
        if (registration.waiting) {
          setNewServiceWorker(registration.waiting);
          setShowUpdatePrompt(true);
        }

        registration.addEventListener('updatefound', () => {
          const newWorker = registration.installing;
          if (newWorker) {
            setNewServiceWorker(newWorker);
            newWorker.addEventListener('statechange', () => {
              if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                // New service worker is available
                setShowUpdatePrompt(true);
              }
            });
          }
        });
      }).catch(() => {/* no-op */});
    }
  }, []);

  const handleUpdate = () => {
    if (isUpdating || !newServiceWorker) return;
    
    setIsUpdating(true);
    newServiceWorker.postMessage({ type: 'SKIP_WAITING' });
    // Don't close the dialog immediately - let the page reload handle it
  };

  const clearCacheAndReload = () => {
    if ('caches' in window) {
      caches.keys().then(cacheNames => {
        Promise.all(
          cacheNames.map(cacheName => caches.delete(cacheName))
        ).then(() => {
          (window as any).location.reload();
        });
      });
    } else {
      (window as any).location.reload();
    }
  };

  return (
    <>
      <AlertDialog open={showUpdatePrompt} onOpenChange={isUpdating ? undefined : setShowUpdatePrompt}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <RefreshCw className="w-5 h-5" />
              Налично е обновление
            </AlertDialogTitle>
            <AlertDialogDescription>
              Има нова версия на приложението. Желаете ли да се обнови сега?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <Button variant="outline" disabled={isUpdating} onClick={() => setShowUpdatePrompt(false)}>
              По-късно
            </Button>
            <AlertDialogAction disabled={isUpdating} onClick={handleUpdate}>
              {isUpdating ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Обновява се...
                </>
              ) : (
                'Обнови сега'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Debug button removed - only available in settings */}
    </>
  );
};