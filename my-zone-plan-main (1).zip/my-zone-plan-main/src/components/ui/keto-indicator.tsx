import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import type { KetoCalculation } from "@/hooks/useKetoCalculation";

interface KetoIndicatorProps {
  ketoData: KetoCalculation;
  className?: string;
  showDetails?: boolean;
  compact?: boolean;
}

export const KetoIndicator = ({ 
  ketoData, 
  className, 
  showDetails = true, 
  compact = false 
}: KetoIndicatorProps) => {
  const getKetoStatus = () => {
    if (ketoData.isKetoCompliant) {
      return { text: ketoData.status, color: "bg-success text-success-foreground" };
    } else {
      return { text: ketoData.status, color: "bg-muted text-muted-foreground" };
    }
  };

  const getMacroColor = (percentage: number, type: 'fat' | 'protein' | 'carb') => {
    switch (type) {
      case 'fat':
        // Кето изисква високи мазнини (>=70% отлично, >=60% добро, <60% недостатъчно)
        return percentage >= 70 ? "bg-success/20" : percentage >= 60 ? "bg-warning/20" : "bg-destructive/20";
      case 'protein':
        // Кето изисква умерени протеини (15-25% добро, извън този диапазон - внимание)
        return percentage <= 25 && percentage >= 15 ? "bg-success/20" : "bg-warning/20";
      case 'carb':
        // Кето изисква ниски въглехидрати (<=10% отлично, <=15% добро, >15% лошо)
        return percentage <= 10 ? "bg-success/20" : percentage <= 15 ? "bg-warning/20" : "bg-destructive/20";
      default:
        return "bg-muted/20";
    }
  };

  if (compact) {
    const { text, color } = getKetoStatus();
    return (
      <Badge variant="secondary" className={cn(color, className)}>
        {text}
      </Badge>
    );
  }

  const { text, color } = getKetoStatus();
  
  return (
    <div className={cn("space-y-2", className)}>
      <Badge variant="secondary" className={color}>
        {text}
      </Badge>
      
      {showDetails && (
        <div className="space-y-1 text-sm">
          <div className="flex justify-between items-center">
            <span>Нето въглехидрати:</span>
            <span className="font-medium">
              {ketoData.netCarbs.toFixed(1)}г / {ketoData.dailyLimit}г
            </span>
          </div>
          
          <div className="grid grid-cols-3 gap-2 mt-2">
            <div className={cn("p-2 rounded text-center", getMacroColor(ketoData.fatPercentage, 'fat'))}>
              <div className="text-xs text-muted-foreground">Мазнини</div>
              <div className="font-medium">{ketoData.fatPercentage.toFixed(0)}%</div>
            </div>
            
            <div className={cn("p-2 rounded text-center", getMacroColor(ketoData.proteinPercentage, 'protein'))}>
              <div className="text-xs text-muted-foreground">Протеини</div>
              <div className="font-medium">{ketoData.proteinPercentage.toFixed(0)}%</div>
            </div>
            
            <div className={cn("p-2 rounded text-center", getMacroColor(ketoData.carbPercentage, 'carb'))}>
              <div className="text-xs text-muted-foreground">Въглехидрати</div>
              <div className="font-medium">{ketoData.carbPercentage.toFixed(0)}%</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};