import React from "react";
import { cn } from "@/lib/utils";

interface NumericInputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "value" | "onChange" | "type"> {
  value: number | null | undefined;
  onValueChange: (value: number) => void;
  allowDecimal?: boolean;
  min?: number;
  max?: number;
}

export const NumericInput = React.forwardRef<HTMLInputElement, NumericInputProps>(
  ({ value, onValueChange, allowDecimal = true, min, max, className, onBlur, placeholder, id, ...rest }, ref) => {
    const [displayValue, setDisplayValue] = React.useState<string>(
      value !== null && value !== undefined ? String(value) : ""
    );

    // Sync when external value changes (e.g., when form initializes or is reset)
    React.useEffect(() => {
      const next = value !== null && value !== undefined ? String(value) : "";
      setDisplayValue(next);
    }, [value]);

    const sanitize = (input: string) => {
      // Allow digits and a single decimal separator (dot or comma)
      const regex = allowDecimal ? /[^0-9.,]/g : /[^0-9]/g;
      let s = input.replace(regex, "");
      if (allowDecimal) {
        // Keep only the first decimal separator
        const firstSepIndex = Math.max(s.indexOf("."), s.indexOf(","));
        if (firstSepIndex !== -1) {
          const before = s.slice(0, firstSepIndex + 1);
          const after = s
            .slice(firstSepIndex + 1)
            .replace(/[.,]/g, "");
          s = before + after;
        }
      }
      return s;
    };

    const commit = (raw: string) => {
      const normalized = raw.replace(",", ".");
      const parsed = normalized === "" ? NaN : Number(normalized);
      let next = parsed;
      if (!isNaN(next)) {
        if (typeof min === "number" && next < min) next = min;
        if (typeof max === "number" && next > max) next = max;
        onValueChange(next);
        setDisplayValue(String(next));
      } else {
        // If invalid, reset to last valid value
        const fallback = value !== null && value !== undefined ? String(value) : "";
        setDisplayValue(fallback);
      }
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const raw = e.target.value;
      const cleaned = sanitize(raw);
      setDisplayValue(cleaned);
      // Do not call onValueChange on each keystroke to avoid focus glitches on mobile
    };

    const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
      commit(displayValue);
      onBlur?.(e);
    };

    return (
      <input
        id={id}
        ref={ref}
        type="text"
        inputMode={allowDecimal ? "decimal" : "numeric"}
        pattern={allowDecimal ? "[0-9]*[.,]?[0-9]*" : "[0-9]*"}
        autoComplete="off"
        className={cn(
          "flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
          className
        )}
        value={displayValue}
        onChange={handleChange}
        onBlur={handleBlur}
        placeholder={placeholder}
        {...rest}
      />
    );
  }
);

NumericInput.displayName = "NumericInput";

export default NumericInput;
