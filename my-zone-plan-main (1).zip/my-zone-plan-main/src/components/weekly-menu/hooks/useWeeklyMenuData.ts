import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { startOfWeek, format, addDays } from 'date-fns';

export const useWeeklyMenuData = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [currentWeek, setCurrentWeek] = useState(() => startOfWeek(new Date(), { weekStartsOn: 1 }));
  const [weekPlan, setWeekPlan] = useState({
    meals: ['breakfast', 'lunch', 'dinner'],
    withTimes: false,
    times: {}
  });

  // Fetch weekly meal plans and filter out consumed meals for today
  const { data: weeklyPlans = [], isLoading } = useQuery({
    queryKey: ['weeklyMealPlans', user?.id, format(currentWeek, 'yyyy-MM-dd')],
    queryFn: async () => {
      if (!user) return [];

      const weekStartStr = format(currentWeek, 'yyyy-MM-dd');
      const weekEndStr = format(addDays(currentWeek, 6), 'yyyy-MM-dd');

      // 1) Fetch all planned weekly meals for this week
      const { data: planned, error: plannedError } = await supabase
        .from('weekly_meal_plans')
        .select(`
          *,
          products(*),
          recipes(*, recipe_ingredients(grams, products(*))),
          dishes(*, dish_ingredients(grams, products(*)))
        `)
        .eq('user_id', user.id)
        .eq('week_start_date', weekStartStr);

      if (plannedError) throw plannedError;

      // 2) Fetch ALL meals (consumed or planned) logged in the meals table for the current week
      const { data: mealsOfWeek, error: mealsError } = await supabase
        .from('meals')
        .select(`
          *,
          products(*),
          recipes(*, recipe_ingredients(grams, products(*))),
          dishes(*, dish_ingredients(grams, products(*)))
        `)
        .eq('user_id', user.id)
        .gte('date', weekStartStr)
        .lte('date', weekEndStr);

      if (mealsError) {
        console.error('Error fetching meals for week:', mealsError);
      }

      // Map planned entries and mark their source
      const plannedMarked = (planned || []).map((p: any) => ({ ...p, _source: 'planned' }));

      // Map meals into plan-like entries so UI can render them by day/type
      const mealsAsPlans = (mealsOfWeek || []).map((m: any) => {
        const d = new Date(m.date);
        const dayIndex = (d.getDay() === 0) ? 6 : d.getDay() - 1;
        return {
          id: `meal-${m.id}`,
          user_id: m.user_id,
          week_start_date: weekStartStr,
          day_of_week: dayIndex,
          meal_type: m.meal_type,
          grams: m.grams,
          servings: m.servings,
          product_id: m.product_id,
          recipe_id: m.recipe_id,
          dish_id: m.dish_id,
          products: m.products,
          recipes: m.recipes,
          dishes: m.dishes,
          is_consumed: m.is_consumed,
          _source: 'meals'
        } as any;
      });

      // IMPORTANT: Do not hide or de-duplicate; show everything as requested
      return [...plannedMarked, ...mealsAsPlans];
    },
    enabled: !!user,
  });

  // Realtime updates for weekly meal plans
  useEffect(() => {
    if (!user?.id) return;
    const weekStartStr = format(currentWeek, 'yyyy-MM-dd');

    const channel = supabase
      .channel('weekly-menu-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'weekly_meal_plans',
          filter: `user_id=eq.${user.id}`
        },
        () => {
          queryClient.invalidateQueries({ queryKey: ['weeklyMealPlans', user?.id, weekStartStr] });
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'meals',
          filter: `user_id=eq.${user.id}`
        },
        () => {
          queryClient.invalidateQueries({ queryKey: ['weeklyMealPlans', user?.id, weekStartStr] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, currentWeek, queryClient]);

  // Fetch products for meal selection - only user's products
  const { data: products = [] } = useQuery({
    queryKey: ['products', user?.id],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('user_id', user.id) // Only user's products
        .order('name');

      if (error) throw error;
      return data || [];
    },
    enabled: !!user,
  });

  // Fetch recipes for meal selection
  const { data: recipes = [] } = useQuery({
    queryKey: ['recipes', user?.id],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from('recipes')
        .select('*')
        .or(`user_id.eq.${user.id},is_public.eq.true`)
        .order('name');

      if (error) throw error;
      return data || [];
    },
    enabled: !!user,
  });

  // Add meal to week mutation - replace existing meal if any
  const addMealToWeekMutation = useMutation({
    mutationFn: async ({ dayIndex, mealType, item, type, grams }: any) => {
      if (!user) throw new Error('User not authenticated');

      const dbMealType = (typeof mealType === 'string' && mealType.startsWith('snack')) ? 'snack' : mealType;

      // First, delete any existing meal for this slot
      let existingMeal = null;
      if (mealType.startsWith('snack')) {
        const snackIndex = mealType === 'snack1' ? 0 : mealType === 'snack2' ? 1 : 2;
        const snacks = await supabase
          .from('weekly_meal_plans')
          .select('*')
          .eq('user_id', user.id)
          .eq('week_start_date', format(currentWeek, 'yyyy-MM-dd'))
          .eq('day_of_week', dayIndex)
          .eq('meal_type', 'snack')
          .order('created_at');
        
        if (snacks.data && snacks.data[snackIndex]) {
          existingMeal = snacks.data[snackIndex];
        }
      } else {
        const existing = await supabase
          .from('weekly_meal_plans')
          .select('*')
          .eq('user_id', user.id)
          .eq('week_start_date', format(currentWeek, 'yyyy-MM-dd'))
          .eq('day_of_week', dayIndex)
          .eq('meal_type', dbMealType)
          .maybeSingle();
        
        existingMeal = existing.data;
      }

      if (existingMeal) {
        await supabase
          .from('weekly_meal_plans')
          .delete()
          .eq('id', existingMeal.id);
      }

      // Then insert the new meal
      const mealData: any = {
        user_id: user.id,
        week_start_date: format(currentWeek, 'yyyy-MM-dd'),
        day_of_week: dayIndex,
        meal_type: dbMealType,
        grams: grams || null,
        servings: type === 'recipe' ? 1 : null,
      };

      if (type === 'product') {
        mealData.product_id = item.id;
      } else if (type === 'recipe') {
        mealData.recipe_id = item.id;
      } else if (type === 'dish') {
        mealData.dish_id = item.id;
      }

      const { error } = await supabase
        .from('weekly_meal_plans')
        .insert(mealData);

      if (error) throw error;

      // If adding meal for today, also add to meals table
      const today = new Date();
      const todayDayOfWeek = (today.getDay() === 0) ? 6 : today.getDay() - 1;
      const weekStart = new Date(currentWeek);
      const isThisWeek = format(weekStart, 'yyyy-MM-dd') === format(new Date(today.getFullYear(), today.getMonth(), today.getDate() - todayDayOfWeek), 'yyyy-MM-dd');
      
      if (isThisWeek && dayIndex === todayDayOfWeek) {
        const todayMealData: any = {
          user_id: user.id,
          date: format(today, 'yyyy-MM-dd'),
          meal_type: dbMealType,
          grams: grams || null,
          servings: type === 'recipe' ? 1 : (type === 'dish' ? 1 : null),
          is_consumed: false // Mark as not consumed since it's planned
        };

        if (type === 'product') {
          todayMealData.product_id = item.id;
        } else if (type === 'recipe') {
          todayMealData.recipe_id = item.id;
        } else if (type === 'dish') {
          todayMealData.dish_id = item.id;
        }

        // Check if already exists in meals table for today (as consumed or planned)
        const { data: existingMeal } = await supabase
          .from('meals')
          .select('*')
          .eq('user_id', user.id)
          .eq('date', format(today, 'yyyy-MM-dd'))
          .eq('meal_type', dbMealType)
          .eq(type === 'product' ? 'product_id' : type === 'recipe' ? 'recipe_id' : 'dish_id', item.id)
          .maybeSingle();

        // Only add if doesn't exist or if it exists but is not consumed
        if (!existingMeal) {
          await supabase
            .from('meals')
            .insert(todayMealData);
        } else if (existingMeal && existingMeal.is_consumed) {
          // If meal exists and is consumed, don't add the planned version
          // This prevents consumed meals from appearing as planned in weekly menu
          console.log('Meal already consumed, not adding planned version');
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ predicate: (q) => Array.isArray(q.queryKey) && (q.queryKey[0] === 'weeklyMealPlans' || q.queryKey[0] === 'weekly-plans' || q.queryKey[0] === 'weekly-menu-ingredients' || q.queryKey[0] === 'habits' || q.queryKey[0] === 'habit-completions' || q.queryKey[0] === 'today-meals-with-dishes' || q.queryKey[0] === 'meals') });
      // Also invalidate weekly menu for immediate UI update
      queryClient.refetchQueries({ predicate: (q) => Array.isArray(q.queryKey) && q.queryKey[0] === 'weeklyMealPlans' });
      
      toast({
        title: "Успех",
        description: "Храненето е добавено към седмичното меню",
      });
    },
    onError: (error) => {
      console.error('Error adding meal to week:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно добавяне на храненето",
        variant: "destructive",
      });
    },
  });

  // Load user preferences for meal plan
  useEffect(() => {
    const loadPreferences = async () => {
      if (!user) return;

      try {
        const { data } = await supabase
          .from('user_preferences')
          .select('preference_value')
          .eq('user_id', user.id)
          .eq('preference_key', 'weekly_meal_plan')
          .maybeSingle();

        if (data?.preference_value) {
          setWeekPlan(data.preference_value as any);
        }
      } catch (error) {
        console.error('Error loading preferences:', error);
      }
    };

    loadPreferences();
  }, [user]);

  // Save preferences when weekPlan changes
  useEffect(() => {
    if (!user) return;

    const timeoutId = setTimeout(async () => {
      try {
        await supabase
          .from('user_preferences')
          .upsert({
            user_id: user.id,
            preference_key: 'weekly_meal_plan',
            preference_value: weekPlan
          }, {
            onConflict: 'user_id,preference_key'
          });
        
        console.log('Preferences saved successfully');
      } catch (error) {
        console.error('Error saving preferences:', error);
      }
    }, 500); // Increased debounce time

    return () => {
      clearTimeout(timeoutId);
    };
  }, [weekPlan, user]);

  // Delete meal from week mutation - can delete by ID or group ID
  const deleteMealFromWeekMutation = useMutation({
    mutationFn: async (mealIdOrGroupId: string) => {
      if (!user) throw new Error('User not authenticated');

      console.log('Starting deletion for:', mealIdOrGroupId);

      // Get meal info before deletion for sync
      let mealsToDelete: any[] = [];
      
      // Try deleting by concrete meal ID first, then fall back to group ID
      // 1) Try by ID
      console.log('Attempting lookup by meal ID:', mealIdOrGroupId);
      const { data: byIdData, error: byIdErr } = await supabase
        .from('weekly_meal_plans')
        .select('*')
        .eq('id', mealIdOrGroupId)
        .eq('user_id', user.id);
      if (byIdErr) {
        console.error('Error selecting by ID:', byIdErr);
        throw byIdErr;
      }

      if (byIdData && byIdData.length > 0) {
        mealsToDelete = byIdData;
        console.log('Found meal(s) by ID:', mealsToDelete.map(m => m.id));

        console.log('Executing delete by meal ID...');
        const deleteResult = await supabase
          .from('weekly_meal_plans')
          .delete()
          .eq('id', mealIdOrGroupId)
          .eq('user_id', user.id);

        console.log('Delete result (by ID):', deleteResult);
        if (deleteResult.error) {
          console.error('Delete error (by ID):', deleteResult.error);
          throw deleteResult.error;
        }
      } else {
        // 2) Try by group ID if nothing found by ID
        console.log('No meal found by ID, attempting lookup by group ID:', mealIdOrGroupId);
        const { data: byGroupData, error: byGroupErr } = await supabase
          .from('weekly_meal_plans')
          .select('*')
          .eq('meal_group_id', mealIdOrGroupId)
          .eq('user_id', user.id);
        if (byGroupErr) {
          console.error('Error selecting by group ID:', byGroupErr);
          throw byGroupErr;
        }

        mealsToDelete = byGroupData || [];
        console.log('Found meals to delete by group:', mealsToDelete.map(m => m.id));

        if (mealsToDelete.length === 0) {
          console.warn('No meals found to delete for ID/Group:', mealIdOrGroupId);
          throw new Error('Няма намерени хранения за изтриване');
        }

        console.log('Executing delete by group ID...');
        const deleteResult = await supabase
          .from('weekly_meal_plans')
          .delete()
          .eq('meal_group_id', mealIdOrGroupId)
          .eq('user_id', user.id);

        console.log('Delete result (by group):', deleteResult);
        if (deleteResult.error) {
          console.error('Delete error (by group):', deleteResult.error);
          throw deleteResult.error;
        }
      }

      console.log('Successfully deleted from weekly_meal_plans');

      // Sync deletion with meals table for today's meals
      const today = new Date();
      const todayDayOfWeek = (today.getDay() === 0) ? 6 : today.getDay() - 1;
      const weekStart = new Date(currentWeek);
      const isThisWeek = format(weekStart, 'yyyy-MM-dd') === format(new Date(today.getFullYear(), today.getMonth(), today.getDate() - todayDayOfWeek), 'yyyy-MM-dd');

      if (isThisWeek) {
        console.log('Syncing deletion with meals table for today...');
        for (const meal of mealsToDelete) {
          if (meal.day_of_week === todayDayOfWeek) {
            const deleteConditions: any = {
              user_id: user.id,
              date: format(today, 'yyyy-MM-dd'),
              meal_type: meal.meal_type
            };

            if (meal.product_id) {
              deleteConditions.product_id = meal.product_id;
            } else if (meal.recipe_id) {
              deleteConditions.recipe_id = meal.recipe_id;
            } else if (meal.dish_id) {
              deleteConditions.dish_id = meal.dish_id;
            }

            console.log('Deleting from meals table with conditions:', deleteConditions);
            const mealDeleteResult = await supabase
              .from('meals')
              .delete()
              .match(deleteConditions);
              
            console.log('Meals table delete result:', mealDeleteResult);
          }
        }
      }
    },
    onSuccess: async (_data, variables) => {
      // Optimistically update cache so the UI updates immediately
      const idOrGroup = String(variables);
      const key = ['weeklyMealPlans', user?.id, format(currentWeek, 'yyyy-MM-dd')];
      queryClient.setQueryData(key, (oldData: any) => {
        if (!Array.isArray(oldData)) return oldData;
        return oldData.filter((m) => m.id !== idOrGroup && m.meal_group_id !== idOrGroup);
      });

      // Force immediate refetch to ensure data consistency
      await queryClient.refetchQueries({ 
        predicate: (q) => Array.isArray(q.queryKey) && q.queryKey[0] === 'weeklyMealPlans',
        exact: false 
      });

      // Invalidate related queries  
      queryClient.invalidateQueries({ predicate: (q) => Array.isArray(q.queryKey) && (q.queryKey[0] === 'weekly-plans' || q.queryKey[0] === 'weekly-menu-ingredients' || q.queryKey[0] === 'today-meals-with-dishes' || q.queryKey[0] === 'meals') });

      toast({
        title: "Успех",
        description: "Храненето е изтрито успешно",
      });
    },
    onError: (error) => {
      console.error('Error deleting meal from week:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно изтриване на храненето",
        variant: "destructive",
      });
    },
  });

  const saveWeekPlanNow = async () => {
    if (!user) return;
    try {
      await supabase
        .from('user_preferences')
        .upsert(
          {
            user_id: user.id,
            preference_key: 'weekly_meal_plan',
            preference_value: weekPlan,
          },
          { onConflict: 'user_id,preference_key' }
        );

      toast({ title: 'Успех', description: 'Настройките са запазени' });
    } catch (error) {
      console.error('Error saving preferences:', error);
      toast({
        title: 'Грешка',
        description: 'Неуспешно запазване на настройките',
        variant: 'destructive',
      });
    }
  };

  return {
    currentWeek,
    setCurrentWeek,
    weekPlan,
    setWeekPlan: (newPlan: any) => {
      setWeekPlan(newPlan);
      // When meal plan settings change, refresh planned meals cache
      queryClient.invalidateQueries({ 
        predicate: (q) => Array.isArray(q.queryKey) && 
          (q.queryKey[0] === 'weekly-plans' || q.queryKey[0] === 'weeklyMealPlans')
      });
    },
    weeklyPlans,
    products,
    recipes,
    isLoading,
    addMealToWeekMutation,
    deleteMealFromWeekMutation,
    saveWeekPlanNow,
  };
};