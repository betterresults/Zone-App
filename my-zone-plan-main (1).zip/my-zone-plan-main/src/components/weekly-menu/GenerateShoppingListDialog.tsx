import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ShoppingCart, Loader2 } from 'lucide-react';
import { useWeeklyMenuIngredients, useShoppingLists } from '@/hooks/useShoppingLists';
import { format, addDays, startOfWeek, getWeek } from 'date-fns';
import { bg } from 'date-fns/locale';

interface GenerateShoppingListDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  weekStartDate: Date;
}

export function GenerateShoppingListDialog({ 
  open, 
  onOpenChange, 
  weekStartDate 
}: GenerateShoppingListDialogProps) {
  const [listName, setListName] = useState('');
  const { data: ingredients, isLoading } = useWeeklyMenuIngredients(weekStartDate);
  const { createShoppingListMutation } = useShoppingLists();

  const weekStart = startOfWeek(weekStartDate, { weekStartsOn: 1 }); // Monday
  const weekEnd = addDays(weekStart, 6); // Sunday

  useEffect(() => {
    if (open) {
      const weekNumber = getWeek(weekStart);
      const defaultName = `Седмица ${weekNumber}`;
      setListName(defaultName);
    }
  }, [open, weekStartDate]);

  const formatWeight = (grams: number) => {
    if (grams >= 1000) {
      return `${(grams / 1000).toFixed(1)} кг`;
    }
    return `${Math.round(grams)} г`;
  };

  const handleGenerate = () => {
    if (!ingredients || ingredients.length === 0) return;

    const weekNumber = getWeek(weekStart);
    const name = listName.trim() || `Седмица ${weekNumber} (${format(weekStart, 'dd.MM', { locale: bg })} - ${format(weekEnd, 'dd.MM')})`;

    createShoppingListMutation.mutate({
      name,
      week_start_date: format(weekStart, 'yyyy-MM-dd'),
      week_end_date: format(weekEnd, 'yyyy-MM-dd'),
      items: ingredients.map(ingredient => ({
        product_id: ingredient.product_id,
        quantity_grams: ingredient.quantity_grams,
        estimated_packages: ingredient.estimated_packages,
      })),
    });

    onOpenChange(false);
    setListName('');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShoppingCart className="w-5 h-5" />
            Направи списък за пазаруване
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium">Име на списъка</label>
            <Input
              value={listName}
              onChange={(e) => setListName(e.target.value)}
              placeholder={`Седмица ${getWeek(weekStart)} (${format(weekStart, 'dd.MM', { locale: bg })} - ${format(weekEnd, 'dd.MM')})`}
              className="mt-1"
            />
          </div>

          <div>
            <div className="text-sm font-medium mb-2">
              Необходими продукти ({format(weekStart, 'dd.MM', { locale: bg })} - {format(weekEnd, 'dd.MM', { locale: bg })})
            </div>
            
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin" />
                <span className="ml-2">Изчисляване на продуктите...</span>
              </div>
            ) : !ingredients || ingredients.length === 0 ? (
              <Card>
                <CardContent className="text-center py-8">
                  <p className="text-muted-foreground">
                    Няма планирани ястия за тази седмица
                  </p>
                </CardContent>
              </Card>
            ) : (
              <ScrollArea className="h-64 border rounded-md">
                <div className="p-2 space-y-2">
                  {ingredients.map((ingredient) => (
                    <Card key={ingredient.product_id} className="bg-muted/30">
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="font-medium">{ingredient.product.name}</div>
                            <div className="text-sm text-muted-foreground">
                              {ingredient.product.category}
                            </div>
                          </div>
                            <div className="text-right">
                              <div className="font-medium">
                                {formatWeight(ingredient.quantity_grams)}
                              </div>
                               <div className="text-sm text-muted-foreground">
                                 ~{ingredient.estimated_packages} {ingredient.product.package_unit_type || 'пакет'}
                               </div>
                            </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            )}
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Отказ
            </Button>
            <Button 
              onClick={handleGenerate}
              disabled={!ingredients || ingredients.length === 0 || createShoppingListMutation.isPending}
            >
              {createShoppingListMutation.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : (
                <ShoppingCart className="w-4 h-4 mr-2" />
              )}
              Направи списък
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}