import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ChevronLeft, ChevronRight, Settings, Star, ShoppingCart } from 'lucide-react';
import { format, addDays, subWeeks, addWeeks, getWeek } from 'date-fns';
import { GenerateShoppingListDialog } from './GenerateShoppingListDialog';
import { useState } from 'react';

interface WeeklyMenuHeaderProps {
  currentWeek: Date;
  onWeekChange: (date: Date) => void;
  showPlanDialog: boolean;
  onShowPlanDialogChange: (show: boolean) => void;
  showTemplateDialog: boolean;
  onShowTemplateDialogChange: (show: boolean) => void;
  weekPlan: any;
  onWeekPlanChange: (plan: any) => void;
  availableMeals: any[];
  templateName: string;
  onTemplateNameChange: (name: string) => void;
  onSaveTemplate: () => void;
  saveTemplateMutation: any;
  onSaveWeekPlan: () => void;
}

export const WeeklyMenuHeader = ({
  currentWeek,
  onWeekChange,
  showPlanDialog,
  onShowPlanDialogChange,
  showTemplateDialog,
  onShowTemplateDialogChange,
  weekPlan,
  onWeekPlanChange,
  availableMeals,
  templateName,
  onTemplateNameChange,
  onSaveTemplate,
  saveTemplateMutation,
  onSaveWeekPlan,
}: WeeklyMenuHeaderProps) => {
  const [showShoppingListDialog, setShowShoppingListDialog] = useState(false);

  return (
    <>
      {/* Mobile Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-foreground">
            <span className="sm:hidden">Сед. меню</span>
            <span className="hidden sm:inline">Седмично меню</span>
          </h1>
        </div>
        
        <div className="flex gap-2 flex-wrap justify-center sm:justify-end">
          <Button 
            size="sm" 
            variant="outline" 
            className="gap-1 text-xs h-8"
            onClick={() => setShowShoppingListDialog(true)}
          >
            <ShoppingCart className="w-3 h-3" />
            <span className="hidden sm:inline">Направи списък</span>
          </Button>
          
          <Dialog open={showPlanDialog} onOpenChange={onShowPlanDialogChange}>
            <DialogTrigger asChild>
              <Button size="sm" className="gap-1 text-xs h-8">
                <Settings className="w-3 h-3" />
                <span className="hidden sm:inline">Настройки</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Настройки за седмичен план</DialogTitle>
              </DialogHeader>
              <div className="space-y-6">
                <div className="space-y-3">
                  <Label className="text-base font-medium">Изберете хранения:</Label>
                  <div className="space-y-2">
                    {availableMeals.map((meal) => (
                      <div key={meal.value} className="flex items-center space-x-2">
                        <Checkbox
                          id={meal.value}
                          checked={weekPlan.meals.includes(meal.value)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              onWeekPlanChange(prev => ({
                                ...prev,
                                meals: [...prev.meals, meal.value]
                              }));
                            } else {
                              onWeekPlanChange(prev => ({
                                ...prev,
                                meals: prev.meals.filter(m => m !== meal.value)
                              }));
                            }
                          }}
                        />
                        <Label htmlFor={meal.value}>{meal.label}</Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="withTimes"
                      checked={weekPlan.withTimes}
                      onCheckedChange={(checked) => {
                        onWeekPlanChange(prev => ({
                          ...prev,
                          withTimes: !!checked
                        }));
                      }}
                    />
                    <Label htmlFor="withTimes">Добави часове за хранене</Label>
                  </div>

                  {weekPlan.withTimes && (
                    <div className="space-y-2 pl-6">
                      {weekPlan.meals.map((mealType) => (
                        <div key={mealType} className="flex items-center space-x-2">
                          <Label className="w-20 text-sm">{availableMeals.find(m => m.value === mealType)?.label}:</Label>
                          <Input
                            type="time"
                            value={weekPlan.times[mealType] || ''}
                            onChange={(e) => {
                              onWeekPlanChange(prev => ({
                                ...prev,
                                times: {
                                  ...prev.times,
                                  [mealType]: e.target.value
                                }
                              }));
                            }}
                            className="w-24 h-8"
                          />
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              <div className="pt-2">
                <Button className="w-full" onClick={() => { onSaveWeekPlan(); }}>
                  Запази
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Week Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <h3 className="text-base sm:text-lg font-semibold">План за седмица {getWeek(currentWeek)}</h3>
        <div className="flex gap-1 sm:gap-2">
          <Dialog open={showTemplateDialog} onOpenChange={onShowTemplateDialogChange}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1 text-xs h-7">
                <Star className="w-3 h-3" />
                <span className="hidden sm:inline">Шаблон</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Запази като шаблон</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="template-name">Име на шаблона</Label>
                  <Input
                    id="template-name"
                    placeholder="Например: Моя любим план"
                    value={templateName}
                    onChange={(e) => onTemplateNameChange(e.target.value)}
                  />
                </div>
                <Button 
                  onClick={onSaveTemplate} 
                  disabled={!templateName.trim() || saveTemplateMutation.isPending}
                  className="w-full"
                >
                  {saveTemplateMutation.isPending ? 'Запазва...' : 'Запази шаблон'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => onWeekChange(subWeeks(currentWeek, 1))}
            className="h-7 w-7 p-0"
          >
            <ChevronLeft className="w-3 h-3" />
          </Button>
          
          <div className="text-xs font-medium px-2 py-1 bg-muted rounded flex items-center">
            {format(currentWeek, 'dd.MM')} - {format(addDays(currentWeek, 6), 'dd.MM.yy')}
          </div>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => onWeekChange(addWeeks(currentWeek, 1))}
            className="h-7 w-7 p-0"
          >
            <ChevronRight className="w-3 h-3" />
          </Button>
        </div>
      </div>

      <GenerateShoppingListDialog 
        open={showShoppingListDialog}
        onOpenChange={setShowShoppingListDialog}
        weekStartDate={currentWeek}
      />
    </>
  );
};