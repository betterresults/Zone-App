import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface MealSelectionDialog {
  open: boolean;
  dayIndex: number;
  mealType: string;
  dayName: string;
}

interface WeeklyMenuDialogsProps {
  mealDialog: MealSelectionDialog;
  onMealDialogChange: (dialog: MealSelectionDialog) => void;
  mealTypeLabels: Record<string, string>;
  products: any[];
  recipes: any[];
  dishes: any[];
  addMealToWeekMutation: any;
}

export const WeeklyMenuDialogs = ({
  mealDialog,
  onMealDialogChange,
  mealTypeLabels,
  products = [],
  recipes = [],
  dishes = [],
  addMealToWeekMutation
}: WeeklyMenuDialogsProps) => {
  return (
    <Dialog 
      open={mealDialog.open} 
      onOpenChange={(open) => onMealDialogChange({ ...mealDialog, open })}
    >
      <DialogContent className="max-w-[95vw] sm:max-w-2xl lg:max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            Избери {mealTypeLabels[mealDialog.mealType]} за {mealDialog.dayName}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <Tabs defaultValue="dishes" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="dishes">Ястия</TabsTrigger>
              <TabsTrigger value="products">Продукти</TabsTrigger>
            </TabsList>

            <TabsContent value="dishes" className="space-y-4">
              <div className="grid gap-3 max-h-96 overflow-y-auto">
                {dishes.slice(0, 30).map((dish) => (
                  <Card 
                    key={dish.id} 
                    className="cursor-pointer transition-colors hover:bg-accent hover:text-accent-foreground"
                    onClick={() => {
                      addMealToWeekMutation.mutate({
                        dayIndex: mealDialog.dayIndex,
                        mealType: mealDialog.mealType,
                        item: dish,
                        type: 'dish',
                        servings: 1
                      });
                      onMealDialogChange({ ...mealDialog, open: false });
                    }}
                  >
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">{dish.name}</CardTitle>
                      {dish.description && (
                        <p className="text-xs text-muted-foreground">{dish.description}</p>
                      )}
                      <div className="flex items-center gap-2">
                        <p className="text-xs text-muted-foreground">
                          1 порция
                        </p>
                      </div>
                    </CardHeader>
                  </Card>
                ))}
              </div>
            </TabsContent>


            <TabsContent value="products" className="space-y-4">
              <div className="grid gap-3 max-h-96 overflow-y-auto">
                {products.slice(0, 30).map((product) => (
                  <Card 
                    key={product.id} 
                    className="cursor-pointer transition-colors hover:bg-accent hover:text-accent-foreground"
                    onClick={() => {
                      addMealToWeekMutation.mutate({
                        dayIndex: mealDialog.dayIndex,
                        mealType: mealDialog.mealType,
                        item: product,
                        type: 'product',
                        grams: 100
                      });
                      onMealDialogChange({ ...mealDialog, open: false });
                    }}
                  >
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">{product.name}</CardTitle>
                      {product.brand && (
                        <p className="text-xs text-muted-foreground">{product.brand}</p>
                      )}
                      <p className="text-xs text-muted-foreground">
                        {product.calories_per_100g} kcal / 100g
                      </p>
                    </CardHeader>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
};