import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { X, Plus, Save, Minus, PlusCircle, Utensils, Search } from 'lucide-react';
import { useZoneCalculation, NutritionData } from '@/hooks/useZoneCalculation';
import { ZoneIndicator } from '@/components/ui/zone-indicator';
import { ChefHat } from 'lucide-react';
import { useProfile } from '@/hooks/useProfile';
import { NumericInput } from '@/components/ui/numeric-input';
import { useToast } from '@/hooks/use-toast';
import { ScrollArea } from '@/components/ui/scroll-area';

interface MealItem {
  id: string;
  type: 'dish' | 'recipe' | 'product';
  item: any;
  servings?: number;
  grams?: number;
  tempId: string; // For managing state before saving
}

interface MealSelectionDialog {
  open: boolean;
  dayIndex: number;
  mealType: string;
  dayName: string;
  existingMeals?: any[]; // For editing existing meal combinations
}

interface AdvancedMealDialogProps {
  mealDialog: MealSelectionDialog;
  onMealDialogChange: (dialog: MealSelectionDialog) => void;
  mealTypeLabels: Record<string, string>;
  products: any[];
  recipes: any[];
  dishes: any[];
  onSaveMeals: (meals: MealItem[]) => Promise<void>;
  onSaveAsCombination?: (meals: MealItem[], name: string) => Promise<void>;
  // New props for daily meal mode
  isDailyMode?: boolean;
  mealTypeOptions?: { value: string; label: string }[];
  selectedMealType?: string;
  onMealTypeChange?: (mealType: string) => void;
}

export const AdvancedMealDialog = ({
  mealDialog,
  onMealDialogChange,
  mealTypeLabels,
  products = [],
  recipes = [],
  dishes = [],
  onSaveMeals,
  onSaveAsCombination,
  isDailyMode = false,
  mealTypeOptions = [],
  selectedMealType,
  onMealTypeChange
}: AdvancedMealDialogProps) => {
  const [selectedMeals, setSelectedMeals] = useState<MealItem[]>([]);
  const [combinationName, setCombinationName] = useState('');
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [activeTab, setActiveTab] = useState('dishes');
  const [dishesSearch, setDishesSearch] = useState('');
  const [productsSearch, setProductsSearch] = useState('');
  const { calculateZoneBlocks } = useZoneCalculation();
  const { profile } = useProfile();
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);

  // Initialize with existing meals if editing
  useEffect(() => {
    if (mealDialog.open && mealDialog.existingMeals?.length) {
      const mappedMeals: MealItem[] = mealDialog.existingMeals.map((meal, index) => {
        let type: 'dish' | 'recipe' | 'product' = 'product';
        let item = null;
        
        if (meal.dishes) {
          type = 'dish';
          item = meal.dishes;
        } else if (meal.recipes) {
          type = 'recipe';
          item = meal.recipes;
        } else if (meal.products) {
          type = 'product';
          item = meal.products;
        }

        return {
          id: meal.id,
          type,
          item,
          servings: meal.servings || 1,
          grams: meal.grams,
          tempId: `existing_${index}`
        };
      });
      setSelectedMeals(mappedMeals);
    } else if (mealDialog.open) {
      setSelectedMeals([]);
    }
  }, [mealDialog.open, mealDialog.existingMeals]);

  // Reset state when dialog closes
  useEffect(() => {
    if (!mealDialog.open) {
      setSelectedMeals([]);
      setCombinationName('');
      setShowSaveDialog(false);
      setDishesSearch('');
      setProductsSearch('');
    }
  }, [mealDialog.open]);

  const addMealItem = (item: any, type: 'dish' | 'recipe' | 'product') => {
    const newMeal: MealItem = {
      id: `temp_${Date.now()}`,
      type,
      item,
      servings: type === 'product' ? undefined : 1,
      grams: type === 'product' ? 100 : undefined,
      tempId: `temp_${Date.now()}_${Math.random()}`
    };
    setSelectedMeals(prev => [...prev, newMeal]);
  };

  const removeMealItem = (tempId: string) => {
    setSelectedMeals(prev => prev.filter(meal => meal.tempId !== tempId));
  };

  const updateMealServings = (tempId: string, servings: number) => {
    setSelectedMeals(prev =>
      prev.map(meal =>
        meal.tempId === tempId ? { ...meal, servings } : meal
      )
    );
  };

  const updateMealGrams = (tempId: string, grams: number) => {
    setSelectedMeals(prev =>
      prev.map(meal =>
        meal.tempId === tempId ? { ...meal, grams } : meal
      )
    );
  };

  const calculateMealNutrition = (meal: MealItem): NutritionData => {
    let nutrition: NutritionData = {
      protein: 0,
      carbs: 0,
      fiber: 0,
      fat: 0,
      calories: 0
    };

    if (meal.type === 'product' && meal.item) {
      const grams = meal.grams || 100;
      const multiplier = grams / 100;
      
      nutrition = {
        protein: (meal.item.protein_per_100g || 0) * multiplier,
        carbs: (meal.item.carbs_per_100g || 0) * multiplier,
        fiber: (meal.item.fiber_per_100g || 0) * multiplier,
        fat: (meal.item.fat_per_100g || 0) * multiplier,
        calories: (meal.item.calories_per_100g || 0) * multiplier
      };
    } else if ((meal.type === 'recipe' || meal.type === 'dish') && meal.item) {
      // For recipes and dishes, we need to calculate from ingredients
      const ingredients = meal.type === 'recipe' 
        ? meal.item.recipe_ingredients 
        : meal.item.dish_ingredients;
      
      if (ingredients) {
        const servings = meal.servings || 1;
        ingredients.forEach((ingredient: any) => {
          const product = ingredient.products;
          if (!product) return;
          const ratio = ingredient.grams / 100;
          nutrition.protein += (product.protein_per_100g || 0) * ratio * servings;
          nutrition.carbs += (product.carbs_per_100g || 0) * ratio * servings;
          nutrition.fat += (product.fat_per_100g || 0) * ratio * servings;
          nutrition.fiber += (product.fiber_per_100g || 0) * ratio * servings;
          nutrition.calories += (product.calories_per_100g || 0) * ratio * servings;
        });
      } else {
        // Fallback estimates if no ingredients data
        const servings = meal.servings || 1;
        nutrition = {
          protein: 15 * servings,
          carbs: 20 * servings,
          fiber: 3 * servings,
          fat: 8 * servings,
          calories: 200 * servings
        };
      }
    }

    return nutrition;
  };

  const getTotalNutrition = (): NutritionData => {
    return selectedMeals.reduce((total, meal) => {
      const mealNutrition = calculateMealNutrition(meal);
      return {
        protein: total.protein + mealNutrition.protein,
        carbs: total.carbs + mealNutrition.carbs,
        fiber: total.fiber + mealNutrition.fiber,
        fat: total.fat + mealNutrition.fat,
        calories: total.calories + mealNutrition.calories
      };
    }, { protein: 0, carbs: 0, fiber: 0, fat: 0, calories: 0 });
  };

  const handleSaveMeals = async () => {
    if (selectedMeals.length === 0 || saving) return;
    
    if (isDailyMode) {
      // For daily mode, show confirmation and keep dialog open
      toast({
        title: "Запазване...",
        description: `Добавяне на ${selectedMeals.length} хранения`,
      });
    }
    
    setSaving(true);
    try {
      await onSaveMeals(selectedMeals);
      
      if (isDailyMode) {
        // For daily mode, clear selection but keep dialog open
        setSelectedMeals([]);
        toast({
          title: "Успех",
          description: `Добавени ${selectedMeals.length} хранения`,
        });
      } else {
        // For weekly mode, close dialog
        onMealDialogChange({ ...mealDialog, open: false });
      }
    } catch (error) {
      console.error('Error saving meals:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно запазване на хранения",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const handleSaveAsCombination = async () => {
    if (!combinationName.trim() || selectedMeals.length === 0) {
      toast({
        title: "Грешка",
        description: "Моля въведете име за комбинацията",
        variant: "destructive"
      });
      return;
    }

    try {
      if (onSaveAsCombination) {
        await onSaveAsCombination(selectedMeals, combinationName);
        setShowSaveDialog(false);
        setCombinationName('');
        toast({
          title: "Успех",
          description: "Комбинацията е запазена успешно"
        });
      }
    } catch (error) {
      console.error('Error saving combination:', error);
      toast({
        title: "Грешка", 
        description: "Неуспешно запазване на комбинацията",
        variant: "destructive"
      });
    }
  };

  // Filter dishes and products based on search
  const filteredDishes = dishes.filter(dish => 
    dish.name.toLowerCase().includes(dishesSearch.toLowerCase())
  );
  
  const filteredProducts = products.filter(product => 
    product.name.toLowerCase().includes(productsSearch.toLowerCase())
  );

  const totalNutrition = getTotalNutrition();
  const zoneCalculation = calculateZoneBlocks(totalNutrition);

  return (
    <>
      <Dialog 
        open={mealDialog.open} 
        onOpenChange={(open) => onMealDialogChange({ ...mealDialog, open })}
      >
        <DialogContent className="max-w-[95vw] sm:max-w-4xl lg:max-w-6xl max-h-[95vh] overflow-hidden flex flex-col pointer-events-auto">
          <DialogHeader>
            <DialogTitle className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <span className="text-sm sm:text-base">
                {isDailyMode 
                  ? 'Добави хранене за днес' 
                  : `Избери ${mealTypeLabels[mealDialog.mealType]} за ${mealDialog.dayName}`
                }
              </span>
              <div className="flex items-center gap-2">
                {isDailyMode && (
                  <Select value={selectedMealType} onValueChange={onMealTypeChange}>
                    <SelectTrigger className="h-8 w-[180px] bg-muted/40 border border-muted/40">
                      <SelectValue placeholder="Вид хранене" />
                    </SelectTrigger>
                    <SelectContent>
                      {mealTypeOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}

                {selectedMeals.length > 0 && onSaveAsCombination && !isDailyMode && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowSaveDialog(true)}
                    className="gap-2 shrink-0"
                  >
                    <Save className="w-4 h-4" />
                    <span className="hidden sm:inline">Запази комбинация</span>
                    <span className="sm:hidden">Запази</span>
                  </Button>
                )}
              </div>
            </DialogTitle>
          </DialogHeader>

          <div className="flex-1 overflow-hidden flex flex-col lg:flex-row gap-4">
            {/* Food selection - full width on mobile, left side on desktop */}
            <div className="flex-1 overflow-hidden">

              <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col min-w-0">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="dishes">Ястия</TabsTrigger>
                  <TabsTrigger value="products">Продукти</TabsTrigger>
                </TabsList>

                <div className="flex-1 overflow-hidden mt-4 min-w-0">
                  <TabsContent value="dishes" className="h-full overflow-hidden">
                    <div className="relative mb-4">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                      <Input
                        placeholder="Търси ястия..."
                        value={dishesSearch}
                        onChange={(e) => setDishesSearch(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                    <ScrollArea className="h-[60vh]">
                      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2 sm:gap-3 pr-2 auto-rows-[120px] sm:auto-rows-[130px]">
                      {filteredDishes.map((dish) => {
                        const dishNutrition = calculateMealNutrition({
                          id: dish.id,
                          type: 'dish',
                          item: dish,
                          servings: 1,
                          tempId: 'temp'
                        });
                        const dishZone = calculateZoneBlocks(dishNutrition);
                        
                        return (
                          <div 
                            key={`dish-${dish.id}`} 
                            className="relative cursor-pointer h-[120px] sm:h-[130px] rounded-lg border-2 overflow-hidden group transition-all duration-200 border-border hover:border-primary/50 hover:shadow-sm"
                            onClick={() => addMealItem(dish, 'dish')}
                          >
                            {dish.image_url ? (
                              <img
                                src={dish.image_url}
                                alt={dish.name}
                                className="w-full h-[70px] sm:h-[80px] object-cover"
                              />
                            ) : (
                              <div className="w-full h-[70px] sm:h-[80px] bg-gradient-to-br from-primary/20 to-primary/40 flex items-center justify-center">
                                <ChefHat className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
                              </div>
                            )}
                            <div className="px-1 sm:px-2 py-1">
                              <h4 className="font-medium text-xs sm:text-sm leading-tight line-clamp-2 mb-1">{dish.name}</h4>
                              <div className="text-[10px] sm:text-xs text-muted-foreground">
                                <span className="text-orange-600 font-medium">{Math.round(dishNutrition.calories)} kcal</span>
                                {profile?.zone_enabled && (
                                  <span className="ml-1 text-blue-600 font-medium">{Math.round(dishZone.blocks * 10) / 10} Б</span>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </ScrollArea>
                  </TabsContent>

                  <TabsContent value="products" className="h-full overflow-hidden">
                    <div className="relative mb-4">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                      <Input
                        placeholder="Търси продукти..."
                        value={productsSearch}
                        onChange={(e) => setProductsSearch(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                    <ScrollArea className="h-[60vh]">
                      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2 sm:gap-3 pr-2 auto-rows-[120px] sm:auto-rows-[130px]">
                      {filteredProducts.map((product) => {
                        const productNutrition = {
                          protein: product.protein_per_100g || 0,
                          carbs: product.carbs_per_100g || 0,
                          fat: product.fat_per_100g || 0,
                          fiber: product.fiber_per_100g || 0,
                          calories: product.calories_per_100g || 0
                        };
                        const productZone = calculateZoneBlocks(productNutrition);
                        
                        return (
                          <div 
                            key={`product-${product.id}`} 
                            className="relative cursor-pointer h-[120px] sm:h-[130px] rounded-lg border-2 overflow-hidden group transition-all duration-200 border-border hover:border-primary/50 hover:shadow-sm"
                            onClick={() => addMealItem(product, 'product')}
                          >
                            {product.image_url ? (
                              <img
                                src={product.image_url}
                                alt={product.name}
                                className="w-full h-[70px] sm:h-[80px] object-cover"
                              />
                            ) : (
                              <div className="w-full h-[70px] sm:h-[80px] bg-gradient-to-br from-green-100 to-green-200 dark:from-green-900/30 dark:to-green-800/30 flex items-center justify-center">
                                <Utensils className="w-4 h-4 sm:w-5 sm:h-5 text-green-600" />
                              </div>
                            )}
                            <div className="px-1 sm:px-2 py-1">
                              <h4 className="font-medium text-xs sm:text-sm leading-tight line-clamp-2 mb-1">{product.name}</h4>
                              <div className="text-[10px] sm:text-xs text-muted-foreground">
                                <span className="text-orange-600 font-medium">{Math.round(productNutrition.calories)} kcal/100г</span>
                                {profile?.zone_enabled && (
                                  <span className="ml-1 text-blue-600 font-medium">{Math.round(productZone.blocks * 10) / 10} Б</span>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                   </ScrollArea>
                  </TabsContent>
                </div>
              </Tabs>
            </div>

            {/* Selected meals and calculations - bottom on mobile, right side on desktop */}
            <div className="shrink-0 w-full lg:w-64 xl:w-72 max-w-full lg:border-l lg:pl-4 border-t lg:border-t-0 pt-4 lg:pt-0 flex flex-col overflow-x-hidden">
              <h3 className="font-medium mb-4 text-sm sm:text-base">Избрани храни ({selectedMeals.length})</h3>
              
              <div className="flex-1 overflow-y-auto space-y-1 mb-4 max-h-48 lg:max-h-none">
                {selectedMeals.map((meal) => {
                  const nutrition = calculateMealNutrition(meal);
                  const zoneCalc = calculateZoneBlocks(nutrition);
                  
                  return (
                    <div key={meal.tempId} className="border rounded-lg p-2 bg-card relative">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeMealItem(meal.tempId)}
                        className="absolute top-1 right-1 h-4 w-4 rounded-full bg-destructive hover:bg-destructive/80 text-destructive-foreground p-0 z-10"
                      >
                        <X className="w-2 h-2" />
                      </Button>
                      
                      <h4 className="font-medium text-xs mb-1 pr-4">{meal.item.name}</h4>
                      
                      {meal.type === 'product' ? (
                        <div className="flex items-center gap-1">
                          <NumericInput
                            value={meal.grams || 100}
                            onValueChange={(value) => updateMealGrams(meal.tempId, value)}
                            min={1}
                            max={2000}
                            className="h-5 text-xs w-12"
                          />
                          <span className="text-xs text-muted-foreground">г</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => updateMealServings(meal.tempId, Math.max(0.5, (meal.servings || 1) - 0.5))}
                            className="h-4 w-4 p-0"
                          >
                            <Minus className="w-2 h-2" />
                          </Button>
                          <span className="text-xs font-medium min-w-[1rem] text-center">
                            {meal.servings || 1}
                          </span>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => updateMealServings(meal.tempId, (meal.servings || 1) + 0.5)}
                            className="h-4 w-4 p-0"
                          >
                            <Plus className="w-2 h-2" />
                          </Button>
                        </div>
                      )}
                      
                      <div className="mt-1 text-xs">
                        <span className="text-orange-600 font-medium">{Math.round(nutrition.calories)} kcal</span>
                        {profile?.zone_enabled && (
                          <span className="ml-2 text-blue-600 font-medium">{Math.round(zoneCalc.blocks * 10) / 10} Б</span>
                        )}
                      </div>
                    </div>
                  );
                })}
                
                {selectedMeals.length === 0 && (
                  <div className="text-center py-4 lg:py-8 text-muted-foreground">
                    <PlusCircle className="w-6 h-6 lg:w-8 lg:h-8 mx-auto mb-2 opacity-40" />
                    <p className="text-xs lg:text-sm">
                      <span className="lg:hidden">Изберете храни отгоре</span>
                      <span className="hidden lg:inline">Изберете храни от лявата страна</span>
                    </p>
                  </div>
                )}
              </div>

              {/* Total calculations with zone visualization */}
              {selectedMeals.length > 0 && (
                <div className="border-t pt-3 space-y-2">
                  <h4 className="font-medium text-sm">Общо</h4>
                  <div className="bg-muted rounded-lg p-2 space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Калории:</span>
                      <span className="font-medium text-orange-600">
                        {Math.round(totalNutrition.calories)} kcal
                      </span>
                    </div>
                    {profile?.zone_enabled && (
                      <div className="flex justify-between text-sm">
                        <span>Блокове:</span>
                        <span className="font-medium text-blue-600">
                          {Math.round(zoneCalculation.blocks * 10) / 10}
                        </span>
                      </div>
                    )}
                  </div>
                  
                  {/* Zone circles visualization */}
                  {profile?.zone_enabled && (
                    <ZoneIndicator 
                      zoneData={zoneCalculation}
                      compact={true}
                      className="justify-center"
                    />
                  )}
                  
                  <Button 
                    onClick={handleSaveMeals}
                    className="w-full"
                    disabled={selectedMeals.length === 0 || saving}
                  >
                    {saving 
                      ? 'Запазва...'
                      : (isDailyMode 
                        ? `Добави ${selectedMeals.length} хранения`
                        : 'Запази храненията')
                    }
                  </Button>
                </div>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Save combination dialog */}
      <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
        <DialogContent className="max-w-[95vw] sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-base">Запази като комбинация</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-sm">Име на комбинацията</Label>
              <Input
                value={combinationName}
                onChange={(e) => setCombinationName(e.target.value)}
                placeholder="напр. Балансиран обяд"
                className="text-sm"
              />
            </div>
            <div className="flex flex-col-reverse sm:flex-row gap-2 justify-end">
              <Button variant="outline" onClick={() => setShowSaveDialog(false)} className="text-sm">
                Отказ
              </Button>
              <Button onClick={handleSaveAsCombination} className="text-sm">
                Запази
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};