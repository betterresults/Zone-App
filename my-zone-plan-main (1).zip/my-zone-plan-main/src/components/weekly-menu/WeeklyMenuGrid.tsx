import { WeeklyMenuMealCell } from './WeeklyMenuMealCell';
import { format, addDays } from 'date-fns';

interface WeeklyMenuGridProps {
  weekPlan: any;
  weeklyPlans: any[];
  mealTypeLabels: Record<string, string>;
  onMealClick: (dayIndex: number, mealType: string, dayName: string, existingMeals?: any[]) => void;
  onMealDelete: (mealId: string) => void;
  onSaveCombination?: (dayIndex: number, mealType: string, dayName: string) => void;
  weekDayNames: string[];
  weekDays: string[];
  currentWeek: Date;
}

export const WeeklyMenuGrid = ({
  weekPlan,
  weeklyPlans,
  mealTypeLabels,
  onMealClick,
  onMealDelete,
  onSaveCombination,
  weekDayNames,
  weekDays,
  currentWeek
}: WeeklyMenuGridProps) => {
  const renderMealSlot = (dayIndex: number, mealType: string) => {
    let meals: any[] = [];
    
    if (mealType.startsWith('snack')) {
      const snackIndex = mealType === 'snack1' ? 0 : mealType === 'snack2' ? 1 : 2;
      const snacks = weeklyPlans
        .filter(p => p.day_of_week === dayIndex && p.meal_type === 'snack')
        .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
      meals = snacks[snackIndex] ? [snacks[snackIndex]] : [];
    } else {
      // Get all meals for this day and meal type
      meals = weeklyPlans.filter(p => p.day_of_week === dayIndex && p.meal_type === mealType);
    }
    
    return (
          <WeeklyMenuMealCell
            key={`${dayIndex}-${mealType}`}
            dayIndex={dayIndex}
            mealType={mealType}
            meals={meals}
            mealTypeLabels={mealTypeLabels}
            onMealClick={onMealClick}
            onMealDelete={onMealDelete}
            onSaveCombination={onSaveCombination}
            weekDayNames={weekDayNames}
          />
    );
  };

  return (
    <div className="bg-card rounded-xl border shadow-sm overflow-hidden">
      <div className="grid grid-cols-8 gap-0">
        {/* Header Row */}
        <div className="bg-muted/30 p-2 text-center border-b border-r">
          <div className="text-xs font-medium text-muted-foreground">Ден</div>
        </div>
        {weekDays.map((day, index) => (
          <div key={index} className="bg-muted/30 p-2 text-center border-b border-r last:border-r-0">
            <div className="text-xs font-medium">{day}</div>
            <div className="text-xs text-muted-foreground">
              {format(addDays(currentWeek, index), 'dd.MM')}
            </div>
          </div>
        ))}

        {/* Meal Rows - show meals in proper order based on settings */}
        {[
          'breakfast',
          'snack1', 
          'lunch',
          'snack2',
          'dinner', 
          'snack3'
        ].filter(mealType => weekPlan.meals.includes(mealType)).map((mealType: string) => (
          <div key={mealType} className="contents">
            {/* Meal Type Header */}
            <div className="p-3 border-b border-r bg-muted/20 flex flex-col justify-center">
              <div className="text-xs font-medium text-center">
                {mealTypeLabels[mealType]}
              </div>
              {weekPlan.withTimes && weekPlan.times[mealType] && (
                <div className="text-xs text-muted-foreground text-center mt-1">
                  {weekPlan.times[mealType]}
                </div>
              )}
            </div>
            
            {/* Meal Slots */}
            {Array.from({ length: 7 }, (_, dayIndex) => (
              <div key={dayIndex} className="border-b border-r last:border-r-0 p-2">
                {renderMealSlot(dayIndex, mealType)}
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};