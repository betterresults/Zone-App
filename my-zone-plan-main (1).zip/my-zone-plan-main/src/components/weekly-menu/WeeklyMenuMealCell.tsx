import { Plus, X } from 'lucide-react';
import { useZoneCalculation, NutritionData } from '@/hooks/useZoneCalculation';

interface WeeklyMenuMealCellProps {
  dayIndex: number;
  mealType: string;
  meals: any[]; // Changed from single meal to array of meals
  mealTypeLabels: Record<string, string>;
  onMealClick: (dayIndex: number, mealType: string, dayName: string, existingMeals?: any[]) => void;
  onMealDelete?: (mealId: string) => void;
  onSaveCombination?: (dayIndex: number, mealType: string, dayName: string) => void;
  weekDayNames: string[];
}

export const WeeklyMenuMealCell = ({ 
  dayIndex, 
  mealType, 
  meals, 
  mealTypeLabels, 
  onMealClick,
  onMealDelete,
  onSaveCombination,
  weekDayNames 
}: WeeklyMenuMealCellProps) => {
  const { calculateZoneBlocks } = useZoneCalculation();
  
  // Calculate combined nutrition from all meals with proper net carbs calculation
  let totalNutrition: NutritionData & { netCarbs: number } = {
    protein: 0,
    carbs: 0,
    fiber: 0,
    fat: 0,
    calories: 0,
    netCarbs: 0
  };

  meals.forEach((meal) => {
    let mealNutrition: NutritionData & { netCarbs: number } = {
      protein: 0,
      carbs: 0,
      fiber: 0,
      fat: 0,
      calories: 0,
      netCarbs: 0
    };

    if (meal.recipes) {
      // Calculate from recipe ingredients with servings
      meal.recipes.recipe_ingredients?.forEach((ingredient: any) => {
        const product = ingredient.products;
        if (!product) return;
        const ratio = ingredient.grams / 100;
        const servings = meal.servings || 1;
        
        const proteinAmount = (product.protein_per_100g || 0) * ratio * servings;
        const carbAmount = (product.carbs_per_100g || 0) * ratio * servings;
        const fatAmount = (product.fat_per_100g || 0) * ratio * servings;
        const fiberAmount = (product.fiber_per_100g || 0) * ratio * servings;
        const caloriesAmount = (product.calories_per_100g || 0) * ratio * servings;
        const netCarbsAmount = Math.max(0, carbAmount - fiberAmount);
        
        mealNutrition.protein += proteinAmount;
        mealNutrition.carbs += carbAmount;
        mealNutrition.fat += fatAmount;
        mealNutrition.fiber += fiberAmount;
        mealNutrition.calories += caloriesAmount;
        mealNutrition.netCarbs += netCarbsAmount;
      });
    } else if (meal.dishes) {
      // Calculate from dish ingredients
      meal.dishes.dish_ingredients?.forEach((ingredient: any) => {
        const product = ingredient.products;
        if (!product) return;
        const ratio = ingredient.grams / 100;
        const servings = meal.servings || 1;
        
        const proteinAmount = (product.protein_per_100g || 0) * ratio * servings;
        const carbAmount = (product.carbs_per_100g || 0) * ratio * servings;
        const fatAmount = (product.fat_per_100g || 0) * ratio * servings;
        const fiberAmount = (product.fiber_per_100g || 0) * ratio * servings;
        const caloriesAmount = (product.calories_per_100g || 0) * ratio * servings;
        const netCarbsAmount = Math.max(0, carbAmount - fiberAmount);
        
        mealNutrition.protein += proteinAmount;
        mealNutrition.carbs += carbAmount;
        mealNutrition.fat += fatAmount;
        mealNutrition.fiber += fiberAmount;
        mealNutrition.calories += caloriesAmount;
        mealNutrition.netCarbs += netCarbsAmount;
      });
    } else if (meal.products) {
      // Calculate nutrition for products
      const grams = meal.grams || 100;
      const multiplier = grams / 100;
      
      const proteinAmount = (meal.products.protein_per_100g || 0) * multiplier;
      const carbAmount = (meal.products.carbs_per_100g || 0) * multiplier;
      const fatAmount = (meal.products.fat_per_100g || 0) * multiplier;
      const fiberAmount = (meal.products.fiber_per_100g || 0) * multiplier;
      const caloriesAmount = (meal.products.calories_per_100g || 0) * multiplier;
      const netCarbsAmount = Math.max(0, carbAmount - fiberAmount);
      
      mealNutrition = {
        protein: proteinAmount,
        carbs: carbAmount,
        fiber: fiberAmount,
        fat: fatAmount,
        calories: caloriesAmount,
        netCarbs: netCarbsAmount
      };
    }

    // Add to total
    totalNutrition.protein += mealNutrition.protein;
    totalNutrition.carbs += mealNutrition.carbs;
    totalNutrition.fat += mealNutrition.fat;
    totalNutrition.fiber += mealNutrition.fiber;
    totalNutrition.calories += mealNutrition.calories;
    totalNutrition.netCarbs += mealNutrition.netCarbs;
  });

  const zoneCalc = calculateZoneBlocks(totalNutrition);
  const calories = Math.round(totalNutrition.calories);
  const blocks = Math.round(zoneCalc.blocks * 10) / 10;

  const hasMeals = meals.length > 0;

  return (
    <div
      key={`${dayIndex}-${mealType}`}
      className={`border rounded-xl bg-card cursor-pointer transition-all duration-200 min-h-[120px] flex flex-col relative group ${
        hasMeals ? 'hover:shadow-md hover:scale-[1.02] border-primary/20 hover:bg-accent hover:text-accent-foreground' : 'hover:bg-accent/30 border-dashed'
      }`}
      onClick={() => {
        onMealClick(dayIndex, mealType, weekDayNames[dayIndex], meals);
      }}
    >
      {hasMeals ? (
        <div className="p-3 flex-1 flex flex-col relative">
          {/* Meal count indicator for multiple meals */}
          {meals.length > 1 && (
            <div className="absolute -top-1 -left-1 w-5 h-5 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-xs font-bold z-20">
              {meals.length}
            </div>
          )}

          {/* Delete button for all meals */}
          {onMealDelete && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                console.log('Delete button clicked for meals:', meals);
                
                // Always delete by individual meal ID for now
                if (meals.length >= 1) {
                  console.log('Deleting by meal ID:', meals[0].id);
                  onMealDelete(meals[0].id);
                } else {
                  console.log('No meals to delete');
                }
              }}
              className="absolute -top-2 -right-2 w-6 h-6 bg-destructive hover:bg-destructive/80 text-destructive-foreground rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-10 flex items-center justify-center"
            >
              <X className="w-3 h-3" />
            </button>
          )}

          {/* Save combination button for multiple meals */}
          {onSaveCombination && meals.length > 1 && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onSaveCombination(dayIndex, mealType, weekDayNames[dayIndex]);
              }}
              className="absolute -top-2 -left-2 w-6 h-6 bg-primary hover:bg-primary/80 text-primary-foreground rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-10 flex items-center justify-center"
            >
              <Plus className="w-3 h-3" />
            </button>
          )}
          
          <div className="flex-1">
            {meals.length === 1 ? (
              // Single meal display
              <>
                <div className="font-medium text-sm mb-1">
                  {meals[0].products?.name || meals[0].recipes?.name || meals[0].dishes?.name || 'Unknown Item'}
                </div>
                
                <div className="text-xs text-muted-foreground space-y-1">
                  {meals[0].grams && (
                    <div>{meals[0].grams}g</div>
                  )}
                  {meals[0].servings && meals[0].servings !== 1 && (
                    <div>{meals[0].servings} порции</div>
                  )}
                  {meals[0].notes && (
                    <div className="text-xs opacity-75 italic">{meals[0].notes}</div>
                  )}
                </div>
              </>
            ) : (
              // Multiple meals display - show meal names directly
              <>
                <div className="text-sm space-y-1">
                  {meals.map((meal, index) => (
                    <div key={index} className="font-medium truncate">
                      {meal.products?.name || meal.recipes?.name || meal.dishes?.name}
                      {meal.servings && meal.servings !== 1 && ` (${meal.servings})`}
                      {meal.grams && ` (${meal.grams}g)`}
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
          
          <div className="mt-2 pt-2 border-t border-border/40">
            <div className="flex justify-between text-xs">
              <span className="text-orange-600 font-medium">{calories} kcal</span>
              <span className="text-blue-600 font-medium">{blocks} блока</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground p-3">
          <Plus className="w-8 h-8 mb-2 opacity-40" />
          <div className="text-xs text-center opacity-60 font-medium">
            Добави {mealTypeLabels[mealType]?.toLowerCase()}
          </div>
        </div>
      )}
    </div>
  );
};