import { useEffect, useState } from 'react';
import { useAuth } from './useAuth';
import { useProfile } from './useProfile';

// OneSignal v16 API types
// Global singleton guards to prevent double initialization across multiple hook instances
let oneSignalInitPromise: Promise<void> | null = null;
let oneSignalInitialized = false;
let oneSignalInitializing = false;
declare global {
  interface Window {
    OneSignal?: {
      init: (config: any) => Promise<void>;
      User: {
        addTag: (key: string, value: string | number) => Promise<void>;
        addTags: (tags: Record<string, string | number>) => Promise<void>;
        getTags: () => Promise<Record<string, string | number>>;
        removeTag: (key: string) => Promise<void>;
        PushSubscription: {
          optedIn: boolean;
          optIn: () => Promise<void>;
          optOut: () => Promise<void>;
        };
      };
      Notifications: {
        permission: string;
        requestPermission: () => Promise<string>;
      };
      login: (externalId: string) => Promise<void>;
    };
    OneSignalDeferred?: Array<(OneSignal: any) => void>;
  }
}

export const useOneSignal = () => {
  const [isInitialized, setIsInitialized] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const { profile } = useProfile();

  useEffect(() => {
    // Only initialize OneSignal if user is logged in
    if (!user?.id) {
      setLoading(false);
      return;
    }

const loadAndInitOneSignal = async () => {
      // Global guards to prevent double init across multiple hook instances
      if (oneSignalInitialized) {
        setIsInitialized(true);
        setLoading(false);
        return;
      }
      if (oneSignalInitializing) {
        setLoading(true);
        // Wait until the first initializer finishes
        let attempts = 0;
        while (!oneSignalInitialized && attempts < 100) {
          await new Promise((r) => setTimeout(r, 100));
          attempts++;
        }
        setIsInitialized(oneSignalInitialized);
        setLoading(false);
        return;
      }
      oneSignalInitializing = true;

      setLoading(true);

      try {
        // Load OneSignal SDK dynamically
        if (!window.OneSignal) {
          console.log('🔔 Loading OneSignal SDK...');
          
          // Load the script
          const script = document.createElement('script');
          script.src = 'https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.page.js';
          script.defer = true;
          document.head.appendChild(script);

          // Wait for script to load and OneSignal to be available
          await new Promise<void>((resolve, reject) => {
            let attempts = 0;
            const maxAttempts = 50; // 5 seconds total
            
            const checkInterval = setInterval(() => {
              attempts++;
              if (window.OneSignal) {
                clearInterval(checkInterval);
                resolve();
              } else if (attempts >= maxAttempts) {
                clearInterval(checkInterval);
                reject(new Error('OneSignal SDK failed to load after 5 seconds'));
              }
            }, 100);
          });
        }

        console.log('🔔 Initializing OneSignal v16...');
        
        // КРИТИЧНО: Получаваме service worker регистрацията от PWA
        let swRegistration = null;
        try {
          if ('serviceWorker' in navigator) {
            // Чакаме за PWA service worker да се зареди
            const registration = await navigator.serviceWorker.getRegistration('/sw.js');
            if (registration) {
              swRegistration = registration;
              console.log('✅ PWA Service Worker found, linking to OneSignal:', registration.scope);
            } else {
              console.log('⚠️ PWA Service Worker not found, will register it...');
              swRegistration = await navigator.serviceWorker.register('/sw.js');
              console.log('✅ PWA Service Worker registered:', swRegistration.scope);
            }
          }
        } catch (e) {
          console.warn('⚠️ Service Worker setup failed:', e);
        }
        
        // Initialize OneSignal with PWA service worker
        const initConfig: any = {
          appId: "ac619bb3-6b72-4efc-84fd-0e4abb4a7c35",
          // КРИТИЧНО: Връзваме със service worker-а на PWA
          serviceWorkerRegistration: swRegistration,
          // Prevent any automatic prompts from OneSignal dashboard
          promptOptions: {
            slidedown: {
              prompts: [
                {
                  // Disable auto prompt for push slidedown; we'll call requestPermission() manually
                  type: "category",
                  autoPrompt: false,
                  delay: { pageViews: 999, timeDelay: 9999 }
                }
              ]
            }
          },
          // Disable the default welcome notification completely
          welcomeNotification: { disable: true }
        };
        
        await window.OneSignal.init(initConfig);

        // Ensure language is Bulgarian for any OS prompts shown by OneSignal UI
        try { (window as any).OneSignal?.User?.setLanguage?.('bg'); } catch {}


        // КРИТИЧНО: Задаваме external_id ВЕДНАГА след инициализация
        // преди opt-in, за да може OneSignal да го разпознае
        if (user?.id) {
          try {
            await window.OneSignal.login(user.id);
            console.log('✅ OneSignal external ID set BEFORE opt-in:', user.id);
          } catch (e) {
            console.warn('⚠️ OneSignal login failed (но ще работи):', e);
          }
        }

        // Determine initial subscription status
        const checkSubscriptionStatus = () => {
          const optedIn = !!window.OneSignal.User?.PushSubscription?.optedIn;
          const browserPermission = (typeof Notification !== 'undefined') ? Notification.permission : 'default';
          const subscribed = optedIn && browserPermission === 'granted';
          setIsSubscribed(subscribed);
          return subscribed;
        };
        
        const subscribed = checkSubscriptionStatus();

        oneSignalInitialized = true;
        oneSignalInitializing = false;
        setIsInitialized(true);
        setLoading(false);
        console.log('✅ OneSignal initialized successfully, subscribed:', subscribed);
      } catch (error) {
        console.error('❌ OneSignal initialization failed:', error);
        // Ensure we release the initializing lock
        oneSignalInitializing = false;
        // Set as initialized even if failed, so UI doesn't show "configuring" forever
        setIsInitialized(true);
        setLoading(false);
      }
    };

    loadAndInitOneSignal();
  }, [user?.id, isInitialized]);

  const requestPermission = async () => {
    if (!window.OneSignal || !isInitialized) {
      console.warn('OneSignal not initialized');
      return false;
    }

    try {
      // If already granted, just ensure opt-in and login
      const currentPerm = (typeof Notification !== 'undefined') ? Notification.permission : 'default';
      if (currentPerm === 'granted') {
        try { if (user?.id) await window.OneSignal.login(user.id); } catch {}
        if (!(window as any).OneSignal?.User?.PushSubscription?.optedIn) {
          await window.OneSignal.User.PushSubscription.optIn();
        }
        setIsSubscribed(true);
        console.log('✅ Already granted, ensured login and opt-in');
        return true;
      }

      console.log('🔔 Requesting OneSignal permission...');
      const permission = await window.OneSignal.Notifications.requestPermission();
      
      if (permission === 'granted') {
        try { if (user?.id) await window.OneSignal.login(user.id); } catch {}
        await window.OneSignal.User.PushSubscription.optIn();
        setIsSubscribed(true);
        console.log('✅ OneSignal permission granted and subscribed');
        return true;
      }
      
      console.log('❌ OneSignal permission denied:', permission);
      return false;
    } catch (error) {
      console.error('❌ OneSignal permission request failed:', error);
      return false;
    }
  };

  // Auto-detect new subscriptions (e.g., when browser prompts outside our UI)
  useEffect(() => {
    if (!isInitialized) return;

    let interval: number | undefined;
    const check = async () => {
      const nowOptedIn = !!(window as any).OneSignal?.User?.PushSubscription?.optedIn;
      const browserPermission = (typeof Notification !== 'undefined') ? Notification.permission : 'default';
      const nowSubscribed = nowOptedIn && browserPermission === 'granted';
      
      if (nowSubscribed && !isSubscribed) {
        setIsSubscribed(true);
        console.log('✅ OneSignal subscription detected, external ID already set:', user?.id);
      } else if (!nowSubscribed && isSubscribed) {
        // User might have revoked permissions
        setIsSubscribed(false);
        console.log('⚠️ OneSignal subscription lost');
      }
    };

    interval = window.setInterval(check, 2000);
    return () => {
      if (interval) window.clearInterval(interval);
    };
  }, [isInitialized, isSubscribed, user?.id]);

  // If permission is already granted but OneSignal is not opted-in, opt-in automatically
  useEffect(() => {
    if (!isInitialized) return;
    const perm = (typeof Notification !== 'undefined') ? Notification.permission : 'default';
    const tryOptIn = async () => {
      const opted = !!(window as any).OneSignal?.User?.PushSubscription?.optedIn;
      if (perm === 'granted' && !opted && (window as any).OneSignal?.User?.PushSubscription?.optIn) {
        try {
          await (window as any).OneSignal.User.PushSubscription.optIn();
          // Check subscription status after opt-in
          const nowOptedIn = !!(window as any).OneSignal?.User?.PushSubscription?.optedIn;
          const nowSubscribed = nowOptedIn && perm === 'granted';
          setIsSubscribed(nowSubscribed);
          console.log('✅ Auto opt-in performed after granted permission, subscribed:', nowSubscribed);
        } catch (e) {
          console.warn('⚠️ Auto opt-in failed:', e);
        }
      }
    };
    // Defer a bit to allow SDK to finalize
    const t = setTimeout(tryOptIn, 500);
    return () => clearTimeout(t);
  }, [isInitialized, user?.id]);

  const sendNotification = async (title: string, message: string, data?: any) => {
    if (!window.OneSignal || !isInitialized) {
      console.warn('OneSignal not initialized');
      return false;
    }

    try {
      // Should be sent via backend (Edge Function)
      console.log('📤 Sending OneSignal notification (backend required):', { title, message, data });
      return true;
    } catch (error) {
      console.error('❌ Failed to send OneSignal notification:', error);
      return false;
    }
  };

  const getTags = async () => {
    if (!window.OneSignal || !isInitialized) return {};

    try {
      return await window.OneSignal.User.getTags();
    } catch (error) {
      console.error('❌ Failed to get OneSignal tags:', error);
      return {};
    }
  };

  const sendTags = async (tags: Record<string, string | number>) => {
    if (!window.OneSignal || !isInitialized) return false;

    try {
      await window.OneSignal.User.addTags(tags);
      console.log('✅ OneSignal tags sent:', tags);
      return true;
    } catch (error) {
      console.error('❌ Failed to send OneSignal tags:', error);
      return false;
    }
  };

  const repairSubscription = async () => {
    if (!window.OneSignal || !isInitialized) return false;
    try {
      console.log('🛠️ Repairing OneSignal subscription...');
      
      // Step 1: Ensure external ID is set first
      if (user?.id) {
        try { 
          await window.OneSignal.login(user.id); 
          console.log('✅ External ID re-set:', user.id);
        } catch (e) {
          console.warn('⚠️ Login during repair failed:', e);
        }
      }
      
      // Step 2: Check current browser permission
      const browserPermission = (typeof Notification !== 'undefined') ? Notification.permission : 'default';
      if (browserPermission !== 'granted') {
        console.warn('❌ Browser permission not granted, can\'t repair');
        return false;
      }
      
      // Step 3: Force opt-out then opt-in to re-establish subscription
      try {
        const wasOptedIn = !!(window as any).OneSignal?.User?.PushSubscription?.optedIn;
        console.log('Current opt-in status:', wasOptedIn);
        
        if (wasOptedIn) {
          await (window as any).OneSignal.User.PushSubscription.optOut();
          console.log('✅ Opted out');
          // Wait a bit for the opt-out to process
          await new Promise(r => setTimeout(r, 500));
        }
        
        await (window as any).OneSignal.User.PushSubscription.optIn();
        console.log('✅ Opted in');
        
        // Wait for the opt-in to process
        await new Promise(r => setTimeout(r, 1000));
        
      } catch (e) {
        console.error('❌ Opt-out/opt-in cycle failed:', e);
      }

      // Step 4: Verify final state
      const finalOptedIn = !!(window as any).OneSignal?.User?.PushSubscription?.optedIn;
      const finalSubscribed = finalOptedIn && browserPermission === 'granted';
      setIsSubscribed(finalSubscribed);
      
      console.log('🧩 Repair complete - optedIn:', finalOptedIn, 'permission:', browserPermission, 'subscribed:', finalSubscribed);
      return finalSubscribed;
    } catch (e) {
      console.error('❌ Repair subscription failed:', e);
      return false;
    }
  };

  return {
    isInitialized,
    isSubscribed,
    loading,
    requestPermission,
    sendNotification,
    getTags,
    sendTags,
    repairSubscription,
  };
};