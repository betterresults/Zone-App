import { useState, useCallback, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';
import { useScheduledNotifications } from './useScheduledNotifications';

export interface CalendarEvent {
  id: string;
  user_id: string;
  title: string;
  description?: string;
  event_date: string;
  start_time?: string;
  end_time?: string;
  event_type: string;
  color: string;
  all_day: boolean;
  status?: 'upcoming' | 'ongoing' | 'completed';
  reminder_enabled: boolean;
  reminder_minutes_before: number;
  created_at: string;
  updated_at: string;
}

export interface NewCalendarEvent {
  title: string;
  description?: string;
  event_date: Date;
  start_time?: string;
  end_time?: string;
  event_type?: string;
  color?: string;
  all_day?: boolean;
  reminder_enabled?: boolean;
  reminder_minutes_before?: number;
}

export const useCalendarEvents = (startDate?: Date, endDate?: Date) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { scheduleEventNotification, cancelNotifications } = useScheduledNotifications();

  // Real-time subscription for calendar events
  useEffect(() => {
    if (!user?.id) return;

    const channel = supabase
      .channel('calendar-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'calendar_events',
          filter: `user_id=eq.${user.id}`
        },
        async (payload) => {
          console.log('Calendar change detected:', payload);
          // Invalidate and refetch all calendar queries instantly
          await queryClient.invalidateQueries({ queryKey: ['calendar-events'] });
          await queryClient.refetchQueries({ queryKey: ['calendar-events'] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, queryClient]);

  // Fetch calendar events for a date range
  const { data: events = [], isLoading, refetch } = useQuery({
    queryKey: ['calendar-events', user?.id, startDate, endDate],
    queryFn: async () => {
      if (!user) return [];

      let query = supabase
        .from('calendar_events')
        .select('*')
        .eq('user_id', user.id)
        .order('event_date', { ascending: true })
        .order('start_time', { ascending: true });

      if (startDate) {
        query = query.gte('event_date', format(startDate, 'yyyy-MM-dd'));
      }
      if (endDate) {
        query = query.lte('event_date', format(endDate, 'yyyy-MM-dd'));
      }

      const { data, error } = await query;

      if (error) throw error;
      return data as CalendarEvent[];
    },
    enabled: !!user
  });

  // Get events for a specific date
  const getEventsForDate = useCallback((date: Date) => {
    const dateString = format(date, 'yyyy-MM-dd');
    return events.filter(event => event.event_date === dateString);
  }, [events]);

  // Create new event
  const createEventMutation = useMutation({
    mutationFn: async (eventData: NewCalendarEvent) => {
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('calendar_events')
        .insert({
          user_id: user.id,
          title: eventData.title,
          description: eventData.description,
          event_date: format(eventData.event_date, 'yyyy-MM-dd'),
          start_time: eventData.start_time,
          end_time: eventData.end_time,
          event_type: eventData.event_type || 'personal',
          color: eventData.color || '#8B5CF6',
          all_day: eventData.all_day || false,
          reminder_enabled: eventData.reminder_enabled || false,
          reminder_minutes_before: eventData.reminder_minutes_before || 15
        })
        .select()
        .single();

      if (error) throw error;

      // Schedule notification if reminder is enabled
      if (eventData.reminder_enabled && eventData.start_time && !eventData.all_day) {
        const eventDateTime = new Date(`${format(eventData.event_date, 'yyyy-MM-dd')}T${eventData.start_time}`);
        await scheduleEventNotification(
          data.id,
          eventData.title,
          eventDateTime,
          eventData.reminder_minutes_before || 15
        );
      }

      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['calendar-events'] });
      toast({
        title: "Събитието е създадено!",
        description: "Успешно добавихте ново събитие в календара."
      });
    },
    onError: (error) => {
      console.error('Error creating event:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно създаване на събитието.",
        variant: "destructive"
      });
    }
  });

  // Update event
  const updateEventMutation = useMutation({
    mutationFn: async ({ id, ...eventData }: Partial<CalendarEvent> & { id: string }) => {
      const updateData: any = {};
      
      if (eventData.title !== undefined) updateData.title = eventData.title;
      if (eventData.description !== undefined) updateData.description = eventData.description;
      if (eventData.event_date !== undefined) {
        updateData.event_date = typeof eventData.event_date === 'string' 
          ? eventData.event_date 
          : format(new Date(eventData.event_date), 'yyyy-MM-dd');
      }
      if (eventData.start_time !== undefined) updateData.start_time = eventData.start_time;
      if (eventData.end_time !== undefined) updateData.end_time = eventData.end_time;
      if (eventData.event_type !== undefined) updateData.event_type = eventData.event_type;
      if (eventData.color !== undefined) updateData.color = eventData.color;
      if (eventData.all_day !== undefined) updateData.all_day = eventData.all_day;

      const { error } = await supabase
        .from('calendar_events')
        .update(updateData)
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['calendar-events'] });
      toast({
        title: "Събитието е обновено!",
        description: "Успешно актуализирахте събитието."
      });
    },
    onError: (error) => {
      console.error('Error updating event:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно обновяване на събитието.",
        variant: "destructive"
      });
    }
  });

  // Delete event
  const deleteEventMutation = useMutation({
    mutationFn: async (eventId: string) => {
      // Cancel any scheduled notifications for this event
      await cancelNotifications(eventId);
      
      const { error } = await supabase
        .from('calendar_events')
        .delete()
        .eq('id', eventId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['calendar-events'] });
      toast({
        title: "Събитието е изтрито!",
        description: "Успешно премахнахте събитието от календара."
      });
    },
    onError: (error) => {
      console.error('Error deleting event:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно изтриване на събитието.",
        variant: "destructive"
      });
    }
  });

  return {
    events,
    isLoading,
    refetch,
    getEventsForDate,
    createEvent: createEventMutation.mutateAsync,
    updateEvent: updateEventMutation.mutateAsync,
    deleteEvent: deleteEventMutation.mutateAsync,
    isCreating: createEventMutation.isPending,
    isUpdating: updateEventMutation.isPending,
    isDeleting: deleteEventMutation.isPending
  };
};