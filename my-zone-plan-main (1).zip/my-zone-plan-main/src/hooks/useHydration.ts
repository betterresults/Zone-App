import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { useProfile } from './useProfile';
import { toast } from '@/hooks/use-toast';
import { format, startOfDay, endOfDay } from 'date-fns';
import { useEffect } from 'react';

export type BeverageType = 'water' | 'tea' | 'coffee' | 'juice' | 'soup' | 'milk' | 'other';

export interface HydrationIntake {
  id: string;
  user_id: string;
  beverage_type: BeverageType;
  volume_ml: number;
  intake_at: string;
  note?: string;
  product_id?: string;
  created_at: string;
  updated_at: string;
}

// Standard product IDs for caloric beverages
const STANDARD_PRODUCTS = {
  milk: 'f47ac10b-58cc-4372-a567-0e02b2c3d479',
  ayran: 'f47ac10b-58cc-4372-a567-0e02b2c3d480',
  juice: 'f47ac10b-58cc-4372-a567-0e02b2c3d481',
} as const;

export const useHydration = (date: Date = new Date()) => {
  const { user } = useAuth();
  const { profile } = useProfile();
  const queryClient = useQueryClient();

  const { data: intakes = [], isLoading } = useQuery({
    queryKey: ['hydration', user?.id, format(date, 'yyyy-MM-dd')],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const start = startOfDay(date).toISOString();
      const end = endOfDay(date).toISOString();
      
      const { data, error } = await supabase
        .from('hydration_intakes')
        .select('*')
        .eq('user_id', user.id)
        .gte('intake_at', start)
        .lte('intake_at', end)
        .order('intake_at', { ascending: false });

      if (error) throw error;
      return data as HydrationIntake[];
    },
    enabled: !!user?.id,
  });

  // Real-time subscription for hydration updates
  useEffect(() => {
    if (!user?.id) return;

    const channel = supabase
      .channel('hydration-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'hydration_intakes',
          filter: `user_id=eq.${user.id}`
        },
        async (payload) => {
          console.log('Hydration change detected:', payload);
          // Invalidate and refetch all hydration queries instantly
          await queryClient.invalidateQueries({ queryKey: ['hydration'] });
          await queryClient.refetchQueries({ queryKey: ['hydration'] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, queryClient]);

  const addIntakeMutation = useMutation({
    mutationFn: async ({ volume_ml, beverage_type = 'water', note }: {
      volume_ml: number;
      beverage_type?: BeverageType;
      note?: string;
    }) => {
      if (!user?.id) throw new Error('User not authenticated');
      
      // Determine if this is a caloric beverage and get the standard product ID
      let product_id: string | undefined;
      if (beverage_type === 'milk') {
        product_id = STANDARD_PRODUCTS.milk;
      } else if (beverage_type === 'soup') { // soup = ayran
        product_id = STANDARD_PRODUCTS.ayran;
      } else if (beverage_type === 'juice') {
        product_id = STANDARD_PRODUCTS.juice;
      }
      
      const { data, error } = await supabase
        .from('hydration_intakes')
        .insert({
          user_id: user.id,
          volume_ml,
          beverage_type,
          note,
          product_id,
          intake_at: new Date().toISOString(),
        })
        .select()
        .single();

      if (error) throw error;
      
      // If this is a caloric beverage, add it to meals for calorie tracking
      if (product_id) {
        const { error: mealError } = await supabase
          .from('meals')
          .insert({
            user_id: user.id,
            product_id,
            grams: volume_ml, // Use volume as grams for liquid products
            meal_type: 'snack',
            date: new Date().toISOString().split('T')[0],
            notes: `Напитка от хидратация: ${beverage_type === 'other' ? note : beverage_type}`.trim(),
          });
        
        if (mealError) {
          console.warn('Failed to add caloric beverage to meals:', mealError);
        }
      }
      
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['hydration'] });
      // Removed success toast - only show error toasts
    },
    onError: () => {
      toast({
        title: "Грешка",
        description: "Неуспешно записване на приема на течности.",
        variant: "destructive",
      });
    },
  });

  const deleteIntakeMutation = useMutation({
    mutationFn: async (intakeId: string) => {
      const { error } = await supabase
        .from('hydration_intakes')
        .delete()
        .eq('id', intakeId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['hydration'] });
      // Removed success toast - only show error toasts  
    },
    onError: () => {
      toast({
        title: "Грешка",
        description: "Неуспешно изтриване.",
        variant: "destructive",
      });
    },
  });

  const totalVolume = intakes.reduce((sum, intake) => sum + intake.volume_ml, 0);

  return {
    intakes,
    isLoading,
    totalVolume,
    addIntake: addIntakeMutation.mutate,
    deleteIntake: deleteIntakeMutation.mutate,
    isAdding: addIntakeMutation.isPending,
  };
};