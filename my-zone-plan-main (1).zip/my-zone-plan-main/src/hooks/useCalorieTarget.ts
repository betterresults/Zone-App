import { useMemo } from 'react';
import { useProfile } from './useProfile';

interface CalorieCalculationParams {
  height_cm?: number | string;
  weight_kg?: number | string;
  age?: number | string;
  gender?: string;
  activity_level?: string;
  weight_goal?: string;
}

export const calculateCalories = (params: CalorieCalculationParams): number | null => {
  const height = typeof params.height_cm === 'string' ? parseFloat(params.height_cm) : params.height_cm;
  const weight = typeof params.weight_kg === 'string' ? parseFloat(params.weight_kg) : params.weight_kg;
  const age = typeof params.age === 'string' ? parseFloat(params.age) : params.age;

  if (!height || !weight || !age || !params.gender) {
    return null;
  }

  // Mifflin-St Jeor Formula
  let bmr: number;
  if (params.gender === 'male') {
    bmr = 10 * weight + 6.25 * height - 5 * age + 5;
  } else {
    bmr = 10 * weight + 6.25 * height - 5 * age - 161;
  }

  // Activity level multipliers
  const activityMultipliers = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    very_active: 1.725,
    extra_active: 1.9
  };

  const activityLevel = params.activity_level || 'moderate';
  const multiplier = activityMultipliers[activityLevel as keyof typeof activityMultipliers] || 1.55;
  
  let calories = bmr * multiplier;

  // Adjust calories based on weight goal
  if (params.weight_goal) {
    switch (params.weight_goal) {
      case 'lose':
        // Caloric deficit for weight loss
        calories -= 400;
        break;
      case 'gain':
        // Caloric surplus for muscle gain
        calories += 400;
        break;
      case 'maintain':
        // No adjustment for maintenance
        break;
    }
  }
  
  return Math.round(calories);
};

export const useCalorieTarget = (formData?: CalorieCalculationParams) => {
  const { profile } = useProfile();

  const recommendedCalories = useMemo(() => {
    // If formData is provided, use it for real-time calculation
    if (formData) {
      return calculateCalories(formData);
    }

    // Otherwise use saved profile data
    if (!profile?.height_cm || !profile?.weight_kg || !profile?.age || !profile?.gender) {
      return null;
    }

    return calculateCalories({
      height_cm: profile.height_cm,
      weight_kg: profile.weight_kg,
      age: profile.age,
      gender: profile.gender,
      activity_level: profile.activity_level,
      weight_goal: profile.weight_goal
    });
  }, [profile, formData]);

  const dailyCalorieTarget = profile?.daily_calorie_target || recommendedCalories;

  return {
    recommendedCalories,
    dailyCalorieTarget,
    hasCustomTarget: !!profile?.daily_calorie_target,
  };
};