import { useState, useEffect } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';

export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    
    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        if (!mounted) return;
        
        console.log('🔐 Auth state changed:', event, session?.user?.email);
        setSession(session);
        setUser(session?.user ?? null);
        setLoading(false);
      }
    );

    // THEN check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!mounted) return;
      
      console.log('🔐 Initial session:', session?.user?.email);
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);
    }).catch(error => {
      console.error('🔐 Error getting session:', error);
      if (mounted) {
        setLoading(false);
      }
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const signUp = async (email: string, password: string, displayName?: string, extraData?: Record<string, any>) => {
    try {
      const redirectUrl = `${window.location.origin}/beta-welcome`;
      
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: redirectUrl,
          data: {
            display_name: displayName || '',
            ...extraData
          }
        }
      });

      if (error) {
        return { error };
      }

      // Track sign-up with Partnero Universal
      if (data.user && (window as any).po) {
        try {
          (window as any).po('integration', 'universal', {
            email: email,
            first_name: displayName?.split(' ')[0] || '',
            last_name: displayName?.split(' ').slice(1).join(' ') || ''
          });
        } catch (err) {
          console.error('Error tracking signup with Partnero Universal:', err);
        }
      }

      // Create partner in Partnero
      if (data.user) {
        try {
          await supabase.functions.invoke('partnero-referral/create-partner', {
            body: { 
              userId: data.user.id, 
              email: email 
            }
          });
        } catch (err) {
          console.error('Error creating Partnero partner:', err);
        }
      }

      // Track sign-up with Partnero API
      if (data.user) {
        try {
          await supabase.functions.invoke('partnero-track-signup', {
            body: {
              email: email,
              first_name: displayName?.split(' ')[0] || '',
              last_name: displayName?.split(' ').slice(1).join(' ') || ''
            }
          });
        } catch (err) {
          console.error('Error tracking signup with Partnero API:', err);
        }
      }

      return { error: null, user: data.user };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Възникна неочаквана грешка';
      return { error: { message: errorMessage } };
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        let errorMessage = "Възникна грешка при влизането";
        if (error.message.includes("Invalid login credentials")) {
          errorMessage = "Неправилни данни за вход";
        } else if (error.message.includes("Email not confirmed")) {
          errorMessage = "Моля потвърдете имейла си първо";
        }
        
        return { error: { ...error, message: errorMessage } };
      }

      return { error: null };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Възникна неочаквана грешка';
      return { error: { message: errorMessage } };
    }
  };

  const signOut = async () => {
    try {
      // Clear all cached data first
      const profileKey = user?.id ? `profile_${user.id}` : null;
      if (profileKey) {
        localStorage.removeItem(profileKey);
      }
      
      // Clear subscription cache
      Object.keys(localStorage).forEach(key => {
        if (key.startsWith('subscription_') || key.startsWith('profile_')) {
          localStorage.removeItem(key);
        }
      });

      // Sign out from Supabase
      const { error } = await supabase.auth.signOut();
      
      if (error) {
        return { error };
      }

      // Clear local state
      setUser(null);
      setSession(null);

      return { error: null };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Възникна неочаквана грешка';
      return { error: { message: errorMessage } };
    }
  };

  return {
    user,
    session,
    loading,
    signUp,
    signIn,
    signOut,
    isAuthenticated: !!user,
  };
};