import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';

interface FeedbackData {
  feedback_type: string;
  category: string;
  title: string;
  description: string;
}

interface FeedbackRecord {
  id: string;
  user_id: string;
  feedback_type: string;
  category: string | null;
  title: string;
  description: string;
  status: string;
  priority: string;
  admin_notes: string | null;
  created_at: string;
  updated_at: string;
}

export const useFeedback = () => {
  const [userFeedback, setUserFeedback] = useState<FeedbackRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();

  const fetchUserFeedback = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('beta_feedback')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching feedback:', error);
        return;
      }

      setUserFeedback(data || []);
    } catch (error) {
      console.error('Error fetching feedback:', error);
    } finally {
      setLoading(false);
    }
  };

  const submitFeedback = async (feedbackData: FeedbackData) => {
    if (!user) throw new Error('User not authenticated');

    const { error } = await supabase
      .from('beta_feedback')
      .insert({
        user_id: user.id,
        feedback_type: feedbackData.feedback_type as any,
        category: feedbackData.category || null,
        title: feedbackData.title,
        description: feedbackData.description
      });

    if (error) {
      console.error('Error submitting feedback:', error);
      throw error;
    }

    // Refresh the feedback list
    await fetchUserFeedback();
  };

  useEffect(() => {
    if (user) {
      fetchUserFeedback();
    }
  }, [user]);

  return {
    userFeedback,
    loading,
    submitFeedback,
    refetch: fetchUserFeedback
  };
};