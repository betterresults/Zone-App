import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';

export type ActivityCategory = 
  | 'cooking' 
  | 'products' 
  | 'recipes' 
  | 'dishes' 
  | 'calendar' 
  | 'referral' 
  | 'settings' 
  | 'subscription' 
  | 'fitness' 
  | 'zone' 
  | 'weight' 
  | 'hydration' 
  | 'fasting' 
  | 'weekly_menu' 
  | 'information'
  | 'notifications';

export type ActivityType = 
  // Cooking
  | 'start_cooking' | 'finish_cooking' | 'save_cooking_result'
  // Products
  | 'add_product' | 'edit_product' | 'delete_product' | 'scan_barcode'
  // Recipes
  | 'add_recipe' | 'edit_recipe' | 'delete_recipe' | 'make_public' | 'make_private' | 'view_public_recipe'
  // Dishes
  | 'add_dish' | 'edit_dish' | 'delete_dish' | 'create_from_recipe'
  // Calendar
  | 'add_meal' | 'edit_meal' | 'delete_meal' | 'plan_meal'
  // Referral
  | 'copy_referral_link' | 'generate_referral_link'
  // Settings
  | 'update_profile' | 'update_targets' | 'update_preferences' | 'change_theme'
  // Subscription
  | 'subscribe' | 'unsubscribe' | 'update_subscription'
  // Fitness
  | 'add_training_day' | 'remove_training_day' | 'complete_workout' | 'log_calories' | 'enable_fitness' | 'disable_fitness'
  // Zone
  | 'enable_zone' | 'disable_zone' | 'calculate_zone'
  // Weight
  | 'log_weight' | 'update_weight_goal'
  // Hydration
  | 'enable_hydration' | 'disable_hydration' | 'log_hydration' | 'update_hydration_goal'
  // Fasting
  | 'enable_fasting' | 'disable_fasting' | 'start_fast' | 'end_fast' | 'update_fast_goal'
  // Weekly Menu
  | 'add_weekly_meal' | 'create_template' | 'delete_template' | 'edit_template' | 'apply_template'
  // Information
  | 'view_information'
  // Notifications
  | 'sw_registration_check' | 'sw_registration_start' | 'sw_registration_success' | 'sw_registration_error' | 'sw_registration_skipped'
  | 'permission_request_start' | 'permission_result' | 'permission_native_result' | 'permission_granted_subscribe' | 'permission_error' | 'permission_not_supported' | 'permission_change'
  | 'subscription_start' | 'subscription_no_user' | 'sw_ready' | 'subscription_existing_found' | 'subscription_creating_new' | 'subscription_created' | 'subscription_complete' | 'subscription_error'
  | 'store_subscription_start' | 'store_subscription_no_user' | 'store_subscription_db_error' | 'store_subscription_success' | 'store_subscription_error';

interface ActivityData {
  [key: string]: any;
}

export const useActivityTracker = () => {
  const { user } = useAuth();

  const trackActivity = async (
    category: ActivityCategory,
    type: ActivityType,
    description: string,
    data?: ActivityData
  ) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('user_activities')
        .insert({
          user_id: user.id,
          activity_category: category,
          activity_type: type,
          activity_description: description,
          activity_data: data || {},
          ip_address: null, // Will be populated by trigger if needed
          user_agent: navigator.userAgent
        });

      if (error) {
        console.error('Failed to track activity:', error);
      }
    } catch (error) {
      console.error('Activity tracking error:', error);
    }
  };

  return { trackActivity };
};