import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';


interface SubscriptionState {
  subscribed: boolean;
  subscription_tier: string | null;
  subscription_end: string | null;
  loading: boolean;
  error: string | null;
}

export const useSubscription = () => {
  const { user, session, loading: authLoading } = useAuth();
  
  const [subscriptionState, setSubscriptionState] = useState<SubscriptionState>(() => {
    // Try to load from cache on mount
    const cached = user?.id ? localStorage.getItem(`subscription_${user.id}`) : null;
    if (cached) {
      return { ...JSON.parse(cached), loading: true };
    }
    return {
      subscribed: false,
      subscription_tier: null,
      subscription_end: null,
      loading: true,
      error: null,
    };
  });

  const checkSubscription = useCallback(async () => {
    if (!session || !user) {
      setSubscriptionState(prev => ({ ...prev, loading: authLoading }));
      return;
    }

    try {
      setSubscriptionState(prev => ({ ...prev, loading: true, error: null }));
      
      // Skip edge function and go directly to database query to avoid Stripe rate limits
      const { data: subscriptionData, error: dbError } = await supabase
        .from('subscribers')
        .select('id, user_id, email, subscribed, subscription_tier, subscription_end, subscription_source')
        .eq('user_id', user.id)
        .maybeSingle();

      if (dbError) {
        throw dbError;
      }

      let subscription = subscriptionData || {
        id: undefined as unknown as string,
        user_id: user.id,
        email: user.email,
        subscribed: false,
        subscription_tier: null as string | null,
        subscription_end: null as string | null,
        subscription_source: null as string | null
      } as any;

      // If no subscription by user_id, try to find by email and attach user_id
      if (!subscriptionData) {
        const { data: emailSubscription, error: emailError } = await supabase
          .from('subscribers')
          .select('id, user_id, email, subscribed, subscription_tier, subscription_end, subscription_source')
          .eq('email', user.email)
          .maybeSingle();

        if (!emailError && emailSubscription) {
          // Update the subscription with user_id if missing
          if (!emailSubscription.user_id) {
            await supabase
              .from('subscribers')
              .update({ user_id: user.id })
              .eq('id', emailSubscription.id);
            
            subscription = { ...emailSubscription, user_id: user.id } as any;
          } else {
            subscription = emailSubscription as any;
          }
        }
      }

      // Auto-grant PRO for 6 months if this is a beta signup and no active subscription exists
      if ((!subscription.subscribed || subscription.subscribed === false) && user.user_metadata?.beta_signup === true) {
        try {
          const endIso = new Date(Date.now() + 6 * 30 * 24 * 60 * 60 * 1000).toISOString();
          const updatePayload = {
            user_id: user.id,
            email: user.email,
            subscribed: true,
            subscription_tier: 'pro',
            subscription_end: endIso,
            subscription_source: 'beta'
          };

          const { data: upserted } = await supabase
            .from('subscribers')
            .upsert(updatePayload, { onConflict: 'email' })
            .select('id, user_id, email, subscribed, subscription_tier, subscription_end, subscription_source')
            .single();

          if (upserted) {
            subscription = upserted as any;
          }
        } catch (e) {
          console.error('Auto-grant beta subscription failed:', e);
        }
      }

      const newState = {
        subscribed: subscription.subscribed || false,
        subscription_tier: subscription.subscription_tier || null,
        subscription_end: subscription.subscription_end || null,
        loading: false,
        error: null,
      };
      
      setSubscriptionState(newState);
      
      // Cache subscription data
      if (user?.id) {
        localStorage.setItem(`subscription_${user.id}`, JSON.stringify(newState));
      }
    } catch (error: any) {
      console.error('Error checking subscription:', error);
      // Only show error if it's not a network issue
      const errorMessage = error?.message?.includes('Failed to fetch') 
        ? null 
        : (error instanceof Error ? error.message : 'Failed to check subscription');
      
      setSubscriptionState(prev => ({
        ...prev,
        loading: false,
        error: errorMessage
      }));
    }
  }, [session, user]);

  const createCheckout = async (planType: 'monthly' | '6monthly' | 'yearly' = 'monthly') => {
    if (!session) {
      throw new Error('Must be logged in to subscribe');
    }

    try {
      const { data, error } = await supabase.functions.invoke('create-checkout', {
        headers: { Authorization: `Bearer ${session.access_token}` },
        body: { planType }
      });

      if (error) throw error;
      
      // Redirect to Stripe checkout
      if (data.url) {
        window.location.href = data.url;
      }
    } catch (error) {
      console.error('Error creating checkout:', error);
      throw error;
    }
  };

  const openCustomerPortal = async () => {
    if (!session) {
      throw new Error('Must be logged in to manage subscription');
    }

    try {
      const { data, error } = await supabase.functions.invoke('customer-portal', {
        headers: { Authorization: `Bearer ${session.access_token}` }
      });

      if (error) throw error;
      
      // Open Stripe customer portal in a new tab
      if (data.url) {
        window.open(data.url, '_blank');
      }
    } catch (error) {
      console.error('Error opening customer portal:', error);
      throw error;
    }
  };

  // Check subscription status when user changes
  useEffect(() => {
    if (user) {
      checkSubscription();
    } else {
      setSubscriptionState({
        subscribed: false,
        subscription_tier: null,
        subscription_end: null,
        loading: authLoading,
        error: null,
      });
    }
  }, [user, checkSubscription]);

  // Auto-refresh subscription status every 5 minutes for authenticated users (reduced to avoid rate limiting)
  useEffect(() => {
    if (!user) return;

    const interval = setInterval(() => {
      checkSubscription();
    }, 300000); // 5 minutes to avoid Stripe rate limiting

    return () => clearInterval(interval);
  }, [user, checkSubscription]);

  // Check subscription when window regains focus
  useEffect(() => {
    if (!user) return;

    const handleFocus = () => {
      checkSubscription();
    };

    window.addEventListener('focus', handleFocus);
    return () => window.removeEventListener('focus', handleFocus);
  }, [user, checkSubscription]);

  // Listen for storage events to refresh subscription when admin makes changes
  useEffect(() => {
    if (!user) return;

    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'subscription-update-trigger') {
        checkSubscription();
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [user, checkSubscription]);

  // Listen for realtime changes to subscribers table
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel('subscription-changes')
      .on(
        'postgres_changes',
        {
          event: '*', // Listen to all events (INSERT, UPDATE, DELETE)
          schema: 'public',
          table: 'subscribers'
        },
        (payload) => {
          console.log('Subscription change detected:', payload);
          // Check if the change affects current user
          const newRecord = payload.new as any;
          const oldRecord = payload.old as any;
          
          if ((newRecord?.user_id === user.id || newRecord?.email === user.email) ||
              (oldRecord?.user_id === user.id || oldRecord?.email === user.email)) {
            console.log('Subscription change affects current user, refreshing...');
            checkSubscription();
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, checkSubscription]);

  return {
    ...subscriptionState,
    checkSubscription,
    createCheckout,
    openCustomerPortal,
    isPro: subscriptionState.subscribed && subscriptionState.subscription_tier !== null,
    isSubscribed: subscriptionState.subscribed,
    isBetaTester: subscriptionState.subscription_tier === 'pro' && subscriptionState.subscription_end !== null,
    planDisplayName: subscriptionState.subscription_tier === 'pro' && subscriptionState.subscription_end !== null 
      ? 'Beta Tester (PRO)' 
      : subscriptionState.subscription_tier === 'pro' 
        ? 'PRO Plan' 
        : subscriptionState.subscribed 
          ? 'Active Plan' 
          : 'Безплатен план'
  };
};