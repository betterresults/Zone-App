import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { useSubscription } from './useSubscription';

interface UserLimits {
  products: number;
  recipes: number;
  dishes: number;
}

interface UserCounts {
  products: number;
  recipes: number;
  dishes: number;
}

const FREE_LIMITS: UserLimits = {
  products: 100,  // Increased from 50 to 100 as user requested
  recipes: 50,
  dishes: 50
};

// Premium users have no limits (or very high limits)
const PREMIUM_LIMITS: UserLimits = {
  products: 10000,
  recipes: 10000,
  dishes: 10000
};

export const useUserLimits = () => {
  const { user } = useAuth();
  const { isPro } = useSubscription();

  // Get current limits based on subscription status
  const limits = isPro ? PREMIUM_LIMITS : FREE_LIMITS;

  // Query to get user's current counts
  const { data: counts, isLoading } = useQuery({
    queryKey: ['user-counts', user?.id],
    queryFn: async () => {
      if (!user) return { products: 0, recipes: 0, dishes: 0 };

      // Get counts for all three types in parallel
      const [productsResult, recipesResult, dishesResult] = await Promise.all([
        supabase
          .from('products')
          .select('id', { count: 'exact', head: true })
          .eq('user_id', user.id),
        supabase
          .from('recipes')
          .select('id', { count: 'exact', head: true })
          .eq('user_id', user.id),
        supabase
          .from('dishes')
          .select('id', { count: 'exact', head: true })
          .eq('user_id', user.id)
      ]);

      const counts: UserCounts = {
        products: productsResult.count || 0,
        recipes: recipesResult.count || 0,
        dishes: dishesResult.count || 0
      };

      return counts;
    },
    enabled: !!user
  });

  // Check if user can add more of each type
  const canAdd = {
    products: !counts || counts.products < limits.products,
    recipes: !counts || counts.recipes < limits.recipes,
    dishes: !counts || counts.dishes < limits.dishes
  };

  // Calculate remaining items
  const remaining = {
    products: Math.max(0, limits.products - (counts?.products || 0)),
    recipes: Math.max(0, limits.recipes - (counts?.recipes || 0)),
    dishes: Math.max(0, limits.dishes - (counts?.dishes || 0))
  };

  // Calculate usage percentage
  const usage = {
    products: counts ? Math.round((counts.products / limits.products) * 100) : 0,
    recipes: counts ? Math.round((counts.recipes / limits.recipes) * 100) : 0,
    dishes: counts ? Math.round((counts.dishes / limits.dishes) * 100) : 0
  };

  return {
    limits,
    counts: counts || { products: 0, recipes: 0, dishes: 0 },
    canAdd,
    remaining,
    usage,
    isLoading,
    isPro
  };
};