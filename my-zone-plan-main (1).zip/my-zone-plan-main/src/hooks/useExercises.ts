import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { toast } from 'sonner';
import { format, startOfWeek, addDays, getDay } from 'date-fns';

export interface Exercise {
  id: string;
  name: string;
  description?: string;
  category: string;
  muscle_groups: string[];
  equipment?: string;
  difficulty_level: string;
  instructions?: string;
  tips?: string;
  image_url?: string;
  video_url?: string;
  is_public: boolean;
  created_by?: string;
}

export interface WorkoutExercise {
  id: string;
  user_id: string;
  fitness_session_id?: string;
  exercise_id: string;
  sets: number;
  reps?: number;
  weight_kg?: number;
  duration_seconds?: number;
  distance_meters?: number;
  rest_seconds: number;
  notes?: string;
  exercise_order: number;
  created_at: string;
  updated_at: string;
  exercise?: Exercise;
}

export const useExercises = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const {
    data: exercises,
    isLoading,
    error,
  } = useQuery({
    queryKey: ['exercises'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('exercises')
        .select('*')
        .order('name');

      if (error) throw error;
      return data as Exercise[];
    },
  });

  const createExerciseMutation = useMutation({
    mutationFn: async (exerciseData: Omit<Exercise, 'id' | 'created_by'>) => {
      if (!user?.id) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('exercises')
        .insert({
          ...exerciseData,
          created_by: user.id,
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['exercises'] });
      toast.success('Упражнението е добавено успешно!');
    },
    onError: (error) => {
      console.error('Error creating exercise:', error);
      toast.error('Грешка при добавяне на упражнението');
    },
  });

  return {
    exercises: exercises || [],
    isLoading,
    error,
    createExerciseMutation,
  };
};

export const useWorkoutExercises = (sessionDate?: string) => {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const {
    data: workoutExercises,
    isLoading,
    error,
  } = useQuery({
    queryKey: ['workout-exercises', user?.id, sessionDate],
    queryFn: async () => {
      if (!user?.id) throw new Error('User not authenticated');

      let query = supabase
        .from('workout_exercises')
        .select(`
          *,
          exercise:exercises(*),
          fitness_session:fitness_sessions(*)
        `)
        .eq('user_id', user.id);

      if (sessionDate) {
        // Get workout exercises for specific session
        const { data: session } = await supabase
          .from('fitness_sessions')
          .select('id')
          .eq('user_id', user.id)
          .eq('session_date', sessionDate)
          .maybeSingle();

        if (session) {
          query = query.eq('fitness_session_id', session.id);
        } else {
          return [];
        }
      }

      const { data, error } = await query.order('exercise_order', { ascending: true });

      if (error) throw error;
      return data as WorkoutExercise[];
    },
    enabled: !!user?.id,
  });

  const addWorkoutExerciseMutation = useMutation({
    mutationFn: async (exerciseData: {
      exercise_id: string;
      session_date: string;
      sets?: number;
      reps?: number;
      weight_kg?: number;
      duration_seconds?: number;
      distance_meters?: number;
      rest_seconds?: number;
      notes?: string;
    }) => {
      if (!user?.id) throw new Error('User not authenticated');

      // Check if this is the first exercise for this session
      const isFirstExerciseForSession = (workoutExercises || []).length === 0;

      // Get or create fitness session for the date
      let { data: session, error: sessionError } = await supabase
        .from('fitness_sessions')
        .select('id')
        .eq('user_id', user.id)
        .eq('session_date', exerciseData.session_date)
        .maybeSingle();

      if (sessionError && sessionError.code !== 'PGRST116') throw sessionError;

      if (!session) {
        const { data: newSession, error: newSessionError } = await supabase
          .from('fitness_sessions')
          .insert({
            user_id: user.id,
            session_date: exerciseData.session_date,
            completed: true, // Mark as completed when adding exercises
          })
          .select('id')
          .single();

        if (newSessionError) throw newSessionError;
        session = newSession;
      }

      // Calculate the next exercise_order
      const maxOrder = (workoutExercises || []).reduce((max, ex) => Math.max(max, ex.exercise_order || 0), -1);
      const nextOrder = maxOrder + 1;

      const { data, error } = await supabase
        .from('workout_exercises')
        .insert({
          user_id: user.id,
          fitness_session_id: session.id,
          exercise_id: exerciseData.exercise_id,
          sets: exerciseData.sets || 1,
          reps: exerciseData.reps,
          weight_kg: exerciseData.weight_kg,
          duration_seconds: exerciseData.duration_seconds,
          distance_meters: exerciseData.distance_meters,
          rest_seconds: exerciseData.rest_seconds || 60,
          notes: exerciseData.notes,
          exercise_order: nextOrder,
        })
        .select()
        .single();

      if (error) throw error;

      // Ensure a generic fitness habit exists for this day
      try {
        const { data: fitnessSettings } = await supabase
          .from('fitness_settings')
          .select('*')
          .eq('user_id', user.id)
          .maybeSingle();

        const sessionDateObj = new Date(exerciseData.session_date);
        const dayOfWeek = getDay(sessionDateObj); // 0 Sun ... 6 Sat
        const mondayBasedIndex = (dayOfWeek + 6) % 7; // convert to Mon=0..Sun=6 to match training_times keys
        const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
        const bgDayNames = ['Неделя', 'Понеделник', 'Вторник', 'Сряда', 'Четвъртък', 'Петък', 'Събота'];

        const trainingTime = (fitnessSettings as any)?.training_times?.[mondayBasedIndex] || '09:00';
        const notificationsEnabled = (fitnessSettings as any)?.notifications_enabled || false;
        const notificationMinutes = (fitnessSettings as any)?.notification_minutes || 30;

        let reminderTime: string | null = null;
        if (notificationsEnabled) {
          const [hours, minutes] = trainingTime.split(':').map(Number);
          const reminderMinutes = minutes - notificationMinutes;
          const reminderHours = reminderMinutes < 0 ? hours - 1 : hours;
          const finalMinutes = reminderMinutes < 0 ? 60 + reminderMinutes : reminderMinutes;
          reminderTime = `${reminderHours.toString().padStart(2, '0')}:${Math.max(0, finalMinutes).toString().padStart(2, '0')}`;
        }

        const { data: existingHabit } = await supabase
          .from('habits')
          .select('id')
          .eq('user_id', user.id)
          .eq('category', 'fitness')
          .contains('repeat_days', [dayNames[dayOfWeek]])
          .maybeSingle();

        if (!existingHabit) {
          await supabase
            .from('habits')
            .insert({
              user_id: user.id,
              name: `Тренировка - ${bgDayNames[dayOfWeek]}`,
              description: null, // Remove the template description
              category: 'fitness',
              color: '#8B5CF6',
              repeat_days: [dayNames[dayOfWeek]],
              time_of_day: trainingTime,
              reminder_enabled: notificationsEnabled,
              reminder_time: notificationsEnabled ? reminderTime : null,
              is_active: true,
            });
        }
      } catch (habitError) {
        console.warn('Failed to ensure habit exists:', habitError);
      }

      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workout-exercises'] });
      queryClient.invalidateQueries({ queryKey: ['fitness-sessions'] });
      queryClient.invalidateQueries({ queryKey: ['habits'] });
      toast.success('Упражнението е добавено към тренировката!');
    },
    onError: (error) => {
      console.error('Error adding workout exercise:', error);
      toast.error('Грешка при добавяне на упражнението');
    },
  });

  const updateWorkoutExerciseMutation = useMutation({
    mutationFn: async ({ id, updates }: { 
      id: string; 
      updates: Partial<Omit<WorkoutExercise, 'id' | 'user_id' | 'created_at' | 'updated_at'>>
    }) => {
      const { data, error } = await supabase
        .from('workout_exercises')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workout-exercises'] });
    },
    onError: (error) => {
      console.error('Error updating workout exercise:', error);
      toast.error('Грешка при обновяване на упражнението');
    },
  });

  const deleteWorkoutExerciseMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('workout_exercises')
        .delete()
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workout-exercises'] });
      toast.success('Упражнението е премахнато');
    },
    onError: (error) => {
      console.error('Error deleting workout exercise:', error);
      toast.error('Грешка при премахване на упражнението');
    },
  });

  const reorderWorkoutExercisesMutation = useMutation({
    mutationFn: async (exercises: { id: string; exercise_order: number }[]) => {
      if (!user?.id) throw new Error('User not authenticated');

      // Update each exercise order
      const updates = exercises.map(ex =>
        supabase
          .from('workout_exercises')
          .update({ exercise_order: ex.exercise_order })
          .eq('id', ex.id)
          .eq('user_id', user.id)
      );

      await Promise.all(updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workout-exercises'] });
    },
    onError: (error) => {
      console.error('Error reordering exercises:', error);
      toast.error('Грешка при пренареждане на упражненията');
    },
  });

  const copyWorkoutToOtherDays = useMutation({
    mutationFn: async ({ 
      sourceDate, 
      targetDays, 
      exercises 
    }: { 
      sourceDate: string; 
      targetDays: number[]; 
      exercises: WorkoutExercise[] 
    }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const currentWeek = startOfWeek(new Date(sourceDate), { weekStartsOn: 1 });

      // За всеки target ден
      for (const dayOfWeek of targetDays) {
        const targetDate = format(addDays(currentWeek, dayOfWeek), 'yyyy-MM-dd');
        
        // Създаваме или намираме фитнес сесия за target датата
        let { data: session } = await supabase
          .from('fitness_sessions')
          .select('id')
          .eq('user_id', user.id)
          .eq('session_date', targetDate)
          .maybeSingle();

        if (!session) {
          const { data: newSession, error: sessionError } = await supabase
            .from('fitness_sessions')
            .insert({
              user_id: user.id,
              session_date: targetDate,
              completed: false
            })
            .select()
            .single();

          if (sessionError) throw sessionError;
          session = newSession;
        }

        // Изтриваме съществуващи упражнения за този ден
        await supabase
          .from('workout_exercises')
          .delete()
          .eq('fitness_session_id', session.id);

        // Копираме всички упражнения
        const exercisesToCopy = exercises.map(ex => ({
          user_id: user.id,
          fitness_session_id: session!.id,
          exercise_id: ex.exercise_id,
          sets: ex.sets,
          reps: ex.reps,
          weight_kg: ex.weight_kg,
          duration_seconds: ex.duration_seconds,
          distance_meters: ex.distance_meters,
          rest_seconds: ex.rest_seconds,
          notes: ex.notes
        }));

        const { error: insertError } = await supabase
          .from('workout_exercises')
          .insert(exercisesToCopy);

        if (insertError) throw insertError;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workout-exercises'] });
      queryClient.invalidateQueries({ queryKey: ['fitness-sessions'] });
    },
    onError: (error) => {
      console.error('Error copying workout:', error);
      toast.error('Грешка при копиране на тренировката');
    },
  });

  return {
    workoutExercises: workoutExercises || [],
    isLoading,
    error,
    addWorkoutExerciseMutation,
    updateWorkoutExerciseMutation,
    deleteWorkoutExerciseMutation,
    reorderWorkoutExercisesMutation,
    copyWorkoutToOtherDays,
  };
};
