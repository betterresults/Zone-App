import { useState, useEffect, useCallback } from 'react';
import { useAuth } from './useAuth';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from './use-toast';

export interface AdminStats {
  total_users: number;
  users_last_30_days: number;
  users_last_7_days: number;
  blocked_users: number;
  total_products: number;
  total_recipes: number;
  total_meals: number;
  meals_last_30_days: number;
}

export interface UserProfile {
  id: string;
  user_id: string;
  email: string;
  display_name: string | null;
  blocked: boolean;
  blocked_at: string | null;
  blocked_reason: string | null;
  created_at: string;
  user_roles?: { role: string }[];
  subscription?: {
    subscribed: boolean;
    subscription_tier: string | null;
    subscription_end: string | null;
    subscription_source?: string | null;
  };
}

export const useAdmin = () => {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [users, setUsers] = useState<UserProfile[]>([]);

  useEffect(() => {
    if (!isAuthenticated) {
      setIsAdmin(false);
      setLoading(false);
      return;
    }
    if (isAuthenticated && !user) {
      // Wait for the user object before checking admin status
      setLoading(true);
      return;
    }
    // user is available here
    checkAdminStatus();
  }, [isAuthenticated, user]);

  const checkAdminStatus = async () => {
    setLoading(true);
    try {
      const { error, count } = await supabase
        .from('user_roles')
        .select('role', { count: 'exact', head: true })
        .eq('user_id', user?.id)
        .eq('role', 'admin');

      setIsAdmin(!error && (count ?? 0) > 0);
    } catch (error) {
      console.error('Error checking admin status:', error);
      setIsAdmin(false);
    } finally {
      setLoading(false);
    }
  };

  const loadStats = useCallback(async () => {
    if (!isAdmin) return;

    try {
      const { data, error } = await supabase.rpc('get_admin_stats');
      if (error) throw error;
      if (data) {
        setStats(data as unknown as AdminStats);
      }
    } catch (error) {
      console.error('Error loading stats:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно зареждане на статистиките",
        variant: "destructive"
      });
    }
  }, [isAdmin, toast]);

  const loadUsers = useCallback(async () => {
    if (!isAdmin) return;

    try {
      // First get all profiles
      const { data: profilesData, error: profilesError } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (profilesError) throw profilesError;

      // Then get all user roles
      const { data: rolesData, error: rolesError } = await supabase
        .from('user_roles')
        .select('user_id, role');

      if (rolesError) throw rolesError;

      // Get subscription data
      const { data: subscriptionData, error: subscriptionError } = await supabase
        .from('subscribers')
        .select('user_id, subscribed, subscription_tier, subscription_end, subscription_source');

      if (subscriptionError) throw subscriptionError;

      // Combine the data
      const usersWithRoles = (profilesData || []).map(profile => ({
        ...profile,
        user_roles: (rolesData || []).filter(role => role.user_id === profile.user_id),
        subscription: (subscriptionData || []).find(sub => sub.user_id === profile.user_id) || {
          subscribed: false,
          subscription_tier: null,
          subscription_end: null,
          subscription_source: null
        }
      }));

      setUsers(usersWithRoles);
    } catch (error) {
      console.error('Error loading users:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно зареждане на потребителите",
        variant: "destructive"
      });
    }
  }, [isAdmin, toast]);

  const blockUser = async (userId: string, reason: string) => {
    if (!isAdmin) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          blocked: true,
          blocked_at: new Date().toISOString(),
          blocked_by: user?.id,
          blocked_reason: reason
        })
        .eq('user_id', userId);

      if (error) throw error;

      toast({
        title: "Успех",
        description: "Потребителят е блокиран успешно"
      });
      
      loadUsers(); // Reload users list
    } catch (error) {
      console.error('Error blocking user:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно блокиране на потребителя",
        variant: "destructive"
      });
    }
  };

  const unblockUser = async (userId: string) => {
    if (!isAdmin) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          blocked: false,
          blocked_at: null,
          blocked_by: null,
          blocked_reason: null
        })
        .eq('user_id', userId);

      if (error) throw error;

      toast({
        title: "Успех",
        description: "Потребителят е разблокиран успешно"
      });
      
      loadUsers(); // Reload users list
    } catch (error) {
      console.error('Error unblocking user:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно разблокиране на потребителя",
        variant: "destructive"
      });
    }
  };

  const makeAdmin = async (userId: string) => {
    if (!isAdmin) return;

    try {
      const { error } = await supabase
        .from('user_roles')
        .upsert({
          user_id: userId,
          role: 'admin',
          created_by: user?.id
        });

      if (error) throw error;

      toast({
        title: "Успех",
        description: "Потребителят е направен админ успешно"
      });
      
      loadUsers(); // Reload users list
    } catch (error) {
      console.error('Error making user admin:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно назначаване на админ",
        variant: "destructive"
      });
    }
  };

  const removeAdmin = async (userId: string) => {
    if (!isAdmin) return;

    try {
      const { error } = await supabase
        .from('user_roles')
        .delete()
        .eq('user_id', userId)
        .eq('role', 'admin');

      if (error) throw error;

      toast({
        title: "Успех",
        description: "Админ правата са премахнати успешно"
      });
      
      loadUsers(); // Reload users list
    } catch (error) {
      console.error('Error removing admin:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно премахване на админ правата",
        variant: "destructive"
      });
    }
  };

  const deleteUser = async (userId: string) => {
    if (!isAdmin) return;

    try {
      const { error } = await supabase.functions.invoke('admin-delete-user', {
        body: { userId }
      });
      
      if (error) throw error;

      toast({
        title: "Успех",
        description: "Потребителят е изтрит успешно"
      });
      
      loadUsers(); // Reload users list
    } catch (error) {
      console.error('Error deleting user:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно изтриване на потребителя",
        variant: "destructive"
      });
    }
  };

  const updateUserProfile = async (userId: string, updates: Partial<UserProfile>) => {
    if (!isAdmin) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('user_id', userId);

      if (error) throw error;

      toast({
        title: "Успех",
        description: "Профилът е обновен успешно"
      });
      
      loadUsers(); // Reload users list
    } catch (error) {
      console.error('Error updating user profile:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно обновяване на профила",
        variant: "destructive"
      });
    }
  };

  const updateSubscription = async (userId: string, tier: string, months: number = 1, userEmail?: string) => {
    if (!isAdmin) return;

    try {
      // Find user email if not provided
      if (!userEmail) {
        const user = users.find(u => u.user_id === userId);
        userEmail = user?.email;
      }
      
      if (!userEmail) {
        throw new Error('User email not found');
      }

      const endDate = new Date();
      endDate.setMonth(endDate.getMonth() + months);

      // First check if record exists
      const { data: existing } = await supabase
        .from('subscribers')
        .select('id')
        .eq('email', userEmail)
        .single();

      if (existing) {
        // Update existing record
        const { error } = await supabase
          .from('subscribers')
          .update({
            user_id: userId,
            subscribed: true,
            subscription_tier: tier,
            subscription_end: endDate.toISOString(),
            updated_at: new Date().toISOString(),
          })
          .eq('email', userEmail);

        if (error) throw error;
      } else {
        // Insert new record
        const { error } = await supabase
          .from('subscribers')
          .insert({
            user_id: userId,
            email: userEmail,
            subscribed: true,
            subscription_tier: tier,
            subscription_end: endDate.toISOString(),
            updated_at: new Date().toISOString(),
          });

        if (error) throw error;
      }

      toast({
        title: "Успех",
        description: `Планът е обновен на ${tier} за ${months} месеца`
      });
      
      // Trigger subscription refresh for all clients
      localStorage.setItem('subscription-update-trigger', Date.now().toString());
      
      loadUsers(); // Reload users list
    } catch (error) {
      console.error('Error updating subscription:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно обновяване на плана",
        variant: "destructive"
      });
    }
  };

  const cancelSubscription = async (userId: string, userEmail?: string) => {
    if (!isAdmin) return;

    try {
      // Find user email if not provided
      if (!userEmail) {
        const user = users.find(u => u.user_id === userId);
        userEmail = user?.email;
      }
      
      if (!userEmail) {
        throw new Error('User email not found');
      }

      // Update existing record to cancel subscription
      const { error } = await supabase
        .from('subscribers')
        .update({
          subscribed: false,
          subscription_tier: null,
          subscription_end: null,
          updated_at: new Date().toISOString(),
        })
        .eq('email', userEmail);

      if (error) throw error;

      toast({
        title: "Успех",
        description: "Планът е премахнат успешно"
      });
      
      // Trigger subscription refresh for all clients
      localStorage.setItem('subscription-update-trigger', Date.now().toString());
      
      loadUsers(); // Reload users list
    } catch (error) {
      console.error('Error canceling subscription:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно премахване на плана",
        variant: "destructive"
      });
     }
   };

   return {
    isAdmin,
    loading,
    stats,
    users,
    loadStats,
    loadUsers,
    blockUser,
    unblockUser,
    makeAdmin,
    removeAdmin,
    deleteUser,
    updateUserProfile,
    updateSubscription,
    cancelSubscription
  };
};