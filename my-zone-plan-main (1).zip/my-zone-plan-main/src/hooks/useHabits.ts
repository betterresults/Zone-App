import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { format, startOfWeek, addDays } from 'date-fns';
import { useEffect } from 'react';

export interface Habit {
  id: string;
  name: string;
  description?: string;
  color: string;
  category: string;
  time_of_day?: string;
  repeat_days: string[];
  reminder_enabled: boolean;
  reminder_time?: string;
  reminder_minutes_before?: number;
  is_active: boolean;
  streak_count: number;
  fitness_template_id?: string;
  one_time_date?: string;
  habit_type?: 'habit' | 'task';
  duration_minutes?: number;
  is_important: boolean;
  created_at: string;
  updated_at: string;
}

export interface HabitCompletion {
  id: string;
  habit_id: string;
  completion_date: string;
  completed_at: string;
  notes?: string;
}

export const useHabits = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Real-time subscription for habits
  useEffect(() => {
    const channel = supabase
      .channel('habits-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'habits'
        },
        async (payload) => {
          console.log('Habits change detected:', payload);
          // Invalidate all habits queries to refresh data instantly
          await queryClient.invalidateQueries({ queryKey: ['habits'] });
          await queryClient.refetchQueries({ queryKey: ['habits'] });
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'habit_completions'
        },
        async (payload) => {
          console.log('Habit completions change detected:', payload);
          // Invalidate ALL habit-completions queries (regardless of date range)
          await queryClient.invalidateQueries({ queryKey: ['habit-completions'] });
          await queryClient.refetchQueries({ queryKey: ['habit-completions'] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [queryClient]);

  // Fetch all active habits for the user
  const {
    data: habits = [],
    isLoading: isLoadingHabits,
    error: habitsError
  } = useQuery({
    queryKey: ['habits'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('habits')
        .select('*')
        .eq('user_id', user.id)
        .eq('is_active', true)
        .order('created_at', { ascending: true });

      if (error) throw error;
      return data as Habit[];
    }
  });

  // Fetch habit completions for a specific date range
  const useHabitCompletions = (startDate: Date, endDate: Date) => {
    return useQuery({
      queryKey: ['habit-completions', format(startDate, 'yyyy-MM-dd'), format(endDate, 'yyyy-MM-dd')],
      queryFn: async () => {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) throw new Error('Not authenticated');

        const { data, error } = await supabase
          .from('habit_completions')
          .select('*')
          .eq('user_id', user.id)
          .gte('completion_date', format(startDate, 'yyyy-MM-dd'))
          .lte('completion_date', format(endDate, 'yyyy-MM-dd'));

        if (error) throw error;
        return data as HabitCompletion[];
      },
      enabled: habits.length > 0
    });
  };

  // Create a new habit
  const createHabitMutation = useMutation({
    mutationFn: async (habitData: Omit<Habit, 'id' | 'created_at' | 'updated_at' | 'streak_count'>) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('habits')
        .insert({
          ...habitData,
          user_id: user.id
        })
        .select()
        .single();

      if (error) throw error;

      // Schedule notification via Edge Function (server-side, handles RLS/admin)
      if (habitData.reminder_enabled) {
        console.log('🔔 Attempting to schedule notifications for habit:', data.id, habitData);
        try {
          const { data: fnData, error: fnError } = await supabase.functions.invoke('schedule-habit-notifications', {
            body: { habitId: data.id }
          });
          if (fnError) {
            console.error('❌ Failed to schedule habit notifications:', fnError);
          } else {
            console.log('✅ Successfully scheduled habit notification:', fnData);
          }
        } catch (e) {
          console.error('❌ Error invoking schedule-habit-notifications:', e);
        }
      } else {
        console.log('🔕 Notifications disabled for habit:', data.id);
      }
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['habits'] });
      // Also invalidate weekly menu to show habits immediately
      queryClient.invalidateQueries({ predicate: (q) => Array.isArray(q.queryKey) && (q.queryKey[0] === 'weeklyMealPlans' || q.queryKey[0] === 'weekly-plans') });
    },
    onError: (error) => {
      toast({
        title: "Грешка",
        description: "Неуспешно създаване на навик.",
        variant: "destructive"
      });
    }
  });

  // Update an existing habit
  const updateHabitMutation = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<Habit> & { id: string }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Update the habit
      const { error } = await supabase
        .from('habits')
        .update(updates)
        .eq('id', id);

      if (error) throw error;

      // If reminder settings changed, re-schedule via Edge Function
      if ('reminder_enabled' in updates || 'reminder_time' in updates || 
          'time_of_day' in updates || 'reminder_minutes_before' in updates ||
          'repeat_days' in updates || 'one_time_date' in updates) {
        console.log('🔄 Attempting to reschedule notifications for habit:', id, updates);
        try {
          const { data: fnData, error: fnError } = await supabase.functions.invoke('schedule-habit-notifications', {
            body: { habitId: id }
          });
          if (fnError) {
            console.error('❌ Failed to reschedule habit notifications:', fnError);
          } else {
            console.log('✅ Successfully rescheduled habit notification:', fnData);
          }
        } catch (e) {
          console.error('❌ Error invoking schedule-habit-notifications:', e);
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['habits'] });
    },
    onError: (error) => {
      toast({
        title: "Грешка",
        description: "Неуспешно обновяване на навик.",
        variant: "destructive"
      });
    }
  });

  // Delete a habit
  const deleteHabitMutation = useMutation({
    mutationFn: async (habitId: string) => {
      // Delete the habit
      const { error: habitError } = await supabase
        .from('habits')
        .delete()
        .eq('id', habitId);

      if (habitError) throw habitError;

      // Also delete any scheduled notifications for this habit
      await supabase
        .from('scheduled_notifications')
        .delete()
        .eq('reference_id', habitId)
        .eq('notification_type', 'habit');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['habits'] });
      queryClient.invalidateQueries({ queryKey: ['habit-completions'] });
    },
    onError: (error) => {
      toast({
        title: "Грешка",
        description: "Неуспешно изтриване на навик.",
        variant: "destructive"
      });
    }
  });

  // Mark habit as complete for a specific date
  const completeHabitMutation = useMutation({
    mutationFn: async ({ habitId, date }: { habitId: string; date: Date }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('habit_completions')
        .upsert({
          habit_id: habitId,
          user_id: user.id,
          completion_date: format(date, 'yyyy-MM-dd')
        })
        .select()
        .single();

      if (error) throw error;
      
      // Delete any scheduled notifications for this habit for today
      await supabase
        .from('scheduled_notifications')
        .delete()
        .eq('user_id', user.id)
        .eq('reference_id', habitId)
        .eq('notification_type', 'habit_reminder')
        .gte('scheduled_for', format(date, 'yyyy-MM-dd'))
        .lt('scheduled_for', format(new Date(date.getTime() + 24 * 60 * 60 * 1000), 'yyyy-MM-dd'));

      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['habit-completions'] });
      queryClient.invalidateQueries({ queryKey: ['scheduled-notifications'] });
      // Also invalidate weekly menu to show habit completion immediately
      queryClient.invalidateQueries({ predicate: (q) => Array.isArray(q.queryKey) && (q.queryKey[0] === 'weeklyMealPlans' || q.queryKey[0] === 'weekly-plans') });
      // Update streak count logic here if needed
    },
    onError: (error) => {
      toast({
        title: "Грешка",
        description: "Неуспешно отбелязване на навика като завършен.",
        variant: "destructive"
      });
    }
  });

  // Remove habit completion for a specific date
  const uncompleteHabitMutation = useMutation({
    mutationFn: async ({ habitId, date }: { habitId: string; date: Date }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error } = await supabase
        .from('habit_completions')
        .delete()
        .eq('habit_id', habitId)
        .eq('user_id', user.id)
        .eq('completion_date', format(date, 'yyyy-MM-dd'));

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['habit-completions'] });
      // Also invalidate weekly menu to show habit uncompletion immediately
      queryClient.invalidateQueries({ predicate: (q) => Array.isArray(q.queryKey) && (q.queryKey[0] === 'weeklyMealPlans' || q.queryKey[0] === 'weekly-plans') });
    },
    onError: (error) => {
      toast({
        title: "Грешка",
        description: "Неуспешно премахване на завършването на навик.",
        variant: "destructive"
      });
    }
  });

  // Helper function to check if habit is completed on a specific date
  const isHabitCompleted = (habitId: string, date: Date, completions: HabitCompletion[]): boolean => {
    const dateStr = format(date, 'yyyy-MM-dd');
    return completions.some(completion => 
      completion.habit_id === habitId && completion.completion_date === dateStr
    );
  };

  // Helper function to check if habit should be shown on a specific day
  const isHabitActiveOnDay = (habit: Habit, date: Date): boolean => {
    // If it's a one-time habit, check if it matches the specific date
    if (habit.one_time_date) {
      const dateStr = format(date, 'yyyy-MM-dd');
      return dateStr === habit.one_time_date;
    }
    
    // Otherwise check repeat days
    const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const dayName = dayNames[date.getDay()];
    return habit.repeat_days.includes(dayName);
  };

  return {
    habits,
    isLoadingHabits,
    habitsError,
    useHabitCompletions,
    createHabitMutation,
    updateHabitMutation,
    deleteHabitMutation,
    completeHabitMutation,
    uncompleteHabitMutation,
    isHabitCompleted,
    isHabitActiveOnDay
  };
};