import { useProfile } from './useProfile';

export type DietMode = 'calories' | 'zone' | 'keto';

export const useFeatureFlags = () => {
  const { profile } = useProfile();

  const getDietMode = (): DietMode => {
    if (profile?.zone_enabled) return 'zone';
    if (profile?.keto_enabled) return 'keto';
    return 'calories';
  };

  return {
    isZoneEnabled: profile?.zone_enabled ?? false,
    isKetoEnabled: profile?.keto_enabled ?? false,
    isFitnessEnabled: profile?.fitness_enabled ?? true,
    isHydrationEnabled: profile?.hydration_enabled ?? true,
    isFastingEnabled: profile?.fasting_enabled ?? true,
    dietMode: getDietMode(),
    dailyCarbsLimit: profile?.daily_carbs_limit ?? 30,
  };
};