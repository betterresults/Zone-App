import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { useProfile } from './useProfile';
import { toast } from '@/hooks/use-toast';

interface ScheduledNotification {
  id: string;
  user_id: string;
  notification_type: 'event' | 'habit';
  reference_id: string;
  scheduled_for: string;
  title: string;
  message: string;
  is_sent: boolean;
  sent_at?: string;
  created_at: string;
  updated_at: string;
}

interface NotificationTemplate {
  id: string;
  template_type: 'event' | 'habit';
  template_name: string;
  title_template: string;
  message_template: string;
  time_of_day: 'morning' | 'afternoon' | 'evening' | 'any';
  is_active: boolean;
}

export const useScheduledNotifications = () => {
  const { user } = useAuth();
  const { profile } = useProfile();
  const queryClient = useQueryClient();

  // Fetch notification templates
  const { data: templates = [] } = useQuery({
    queryKey: ['notification-templates'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('notification_templates')
        .select('*')
        .eq('is_active', true);
      
      if (error) throw error;
      return data as NotificationTemplate[];
    },
  });

  // Fetch user's scheduled notifications
  const { data: notifications = [], isLoading } = useQuery({
    queryKey: ['scheduled-notifications', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const { data, error } = await supabase
        .from('scheduled_notifications')
        .select('*')
        .eq('user_id', user.id)
        .eq('is_sent', false)
        .order('scheduled_for', { ascending: true });
      
      if (error) throw error;
      return data as ScheduledNotification[];
    },
    enabled: !!user?.id,
  });

  // Create notification mutation
  const createNotificationMutation = useMutation({
    mutationFn: async (notification: Omit<ScheduledNotification, 'id' | 'created_at' | 'updated_at' | 'is_sent' | 'sent_at'>) => {
      const { data, error } = await supabase
        .from('scheduled_notifications')
        .insert([notification])
        .select()
        .single();
        
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scheduled-notifications'] });
    },
    onError: (error) => {
      console.error('Failed to create scheduled notification:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно планиране на известие.",
        variant: "destructive",
      });
    },
  });

  // Delete notification mutation
  const deleteNotificationMutation = useMutation({
    mutationFn: async (notificationId: string) => {
      const { error } = await supabase
        .from('scheduled_notifications')
        .delete()
        .eq('id', notificationId);
        
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scheduled-notifications'] });
    },
    onError: (error) => {
      console.error('Failed to delete scheduled notification:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно изтриване на известие.",
        variant: "destructive",
      });
    },
  });

  // Generate personalized message
  const generatePersonalizedMessage = (
    template: NotificationTemplate,
    eventData: {
      event_title?: string;
      habit_name?: string;
      minutes?: number;
      streak_count?: number;
    }
  ) => {
    if (!profile) return { title: template.title_template, message: template.message_template };

    const name = profile.display_name || profile.first_name || 'там';
    let title = template.title_template;
    let message = template.message_template;

    // Replace placeholders
    title = title.replace('{name}', name);
    message = message
      .replace('{name}', name)
      .replace('{event_title}', eventData.event_title || '')
      .replace('{habit_name}', eventData.habit_name || '')
      .replace('{minutes}', eventData.minutes?.toString() || '')
      .replace('{streak_count}', eventData.streak_count?.toString() || '');

    return { title, message };
  };

  // Get appropriate template based on time of day
  const getTemplateForTime = (templateType: 'event' | 'habit', scheduledTime: Date) => {
    const hour = scheduledTime.getHours();
    let timeOfDay: 'morning' | 'afternoon' | 'evening' = 'morning';
    
    if (hour >= 12 && hour < 18) {
      timeOfDay = 'afternoon';
    } else if (hour >= 18) {
      timeOfDay = 'evening';
    }

    // Find template for specific time of day
    let template = templates.find(t => 
      t.template_type === templateType && 
      t.time_of_day === timeOfDay
    );

    // Fallback to 'any' time template
    if (!template) {
      template = templates.find(t => 
        t.template_type === templateType && 
        t.time_of_day === 'any'
      );
    }

    return template;
  };

  // Schedule event notification
  const scheduleEventNotification = async (
    eventId: string,
    eventTitle: string,
    eventDateTime: Date,
    reminderMinutes: number
  ) => {
    if (!user?.id) return;

    const scheduledFor = new Date(eventDateTime.getTime() - reminderMinutes * 60 * 1000);
    const template = getTemplateForTime('event', scheduledFor);
    
    if (!template) {
      console.error('No template found for event notification');
      return;
    }

    const { title, message } = generatePersonalizedMessage(template, {
      event_title: eventTitle,
      minutes: reminderMinutes,
    });

    return createNotificationMutation.mutateAsync({
      user_id: user.id,
      notification_type: 'event',
      reference_id: eventId,
      scheduled_for: scheduledFor.toISOString(),
      title,
      message,
    });
  };

  // Schedule habit notification
  const scheduleHabitNotification = async (
    habitId: string,
    habitName: string,
    reminderDateTime: Date,
    streakCount = 0
  ) => {
    if (!user?.id) return;

    const template = getTemplateForTime('habit', reminderDateTime);
    
    if (!template) {
      console.error('No template found for habit notification');
      return;
    }

    const { title, message } = generatePersonalizedMessage(template, {
      habit_name: habitName.toLowerCase(),
      streak_count: streakCount,
    });

    return createNotificationMutation.mutateAsync({
      user_id: user.id,
      notification_type: 'habit',
      reference_id: habitId,
      scheduled_for: reminderDateTime.toISOString(),
      title,
      message,
    });
  };

  // Cancel notifications for a reference
  const cancelNotifications = async (referenceId: string) => {
    if (!user?.id) return;

    const { error } = await supabase
      .from('scheduled_notifications')
      .delete()
      .eq('user_id', user.id)
      .eq('reference_id', referenceId)
      .eq('is_sent', false);

    if (error) {
      console.error('Failed to cancel notifications:', error);
    } else {
      queryClient.invalidateQueries({ queryKey: ['scheduled-notifications'] });
    }
  };

  return {
    notifications,
    templates,
    isLoading,
    scheduleEventNotification,
    scheduleHabitNotification,
    cancelNotifications,
    createNotification: createNotificationMutation.mutateAsync,
    deleteNotification: deleteNotificationMutation.mutateAsync,
    isCreating: createNotificationMutation.isPending,
    isDeleting: deleteNotificationMutation.isPending,
  };
};