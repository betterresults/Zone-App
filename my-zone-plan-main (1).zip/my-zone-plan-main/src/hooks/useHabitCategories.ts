import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface HabitCategory {
  id: string;
  user_id: string;
  name: string;
  color: string;
  icon: string;
  is_default: boolean;
  created_at: string;
  updated_at: string;
}

export const useHabitCategories = () => {
  return useQuery({
    queryKey: ['habit-categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('user_habit_categories')
        .select('*')
        .order('name');
      
      if (error) throw error;
      return data as HabitCategory[];
    },
  });
};

export const useCreateHabitCategory = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (category: Omit<HabitCategory, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('user_habit_categories')
        .insert({
          ...category,
          user_id: user.id,
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['habit-categories'] });
      toast({
        title: "Успех!",
        description: "Категорията е създадена успешно",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Грешка",
        description: error.message || "Грешка при създаване на категория",
        variant: "destructive",
      });
    },
  });
};

export const useUpdateHabitCategory = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<HabitCategory> & { id: string }) => {
      const { data, error } = await supabase
        .from('user_habit_categories')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['habit-categories'] });
      toast({
        title: "Успех!",
        description: "Категорията е обновена успешно",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Грешка",
        description: error.message || "Грешка при обновяване на категория",
        variant: "destructive",
      });
    },
  });
};

export const useDeleteHabitCategory = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('user_habit_categories')
        .delete()
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['habit-categories'] });
      toast({
        title: "Успех!",
        description: "Категорията е изтрита успешно",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Грешка",
        description: error.message || "Грешка при изтриване на категория",
        variant: "destructive",
      });
    },
  });
};