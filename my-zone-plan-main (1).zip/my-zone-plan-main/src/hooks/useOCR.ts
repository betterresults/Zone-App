import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

// Image compression utility
const compressImage = (imageDataUrl: string, maxSizeKB: number = 800): Promise<string> => {
  return new Promise((resolve) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();
    
    img.onload = () => {
      // Calculate new dimensions to reduce file size
      let { width, height } = img;
      const maxDimension = 1200; // Reduce max dimension
      
      if (width > maxDimension || height > maxDimension) {
        if (width > height) {
          height = (height * maxDimension) / width;
          width = maxDimension;
        } else {
          width = (width * maxDimension) / height;
          height = maxDimension;
        }
      }
      
      canvas.width = width;
      canvas.height = height;
      ctx?.drawImage(img, 0, 0, width, height);
      
      // Start with high quality and reduce if needed
      let quality = 0.8;
      let compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
      
      // Reduce quality until we're under the size limit
      while (compressedDataUrl.length > maxSizeKB * 1024 * 4/3 && quality > 0.1) { // Base64 is ~4/3 larger
        quality -= 0.1;
        compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
      }
      
      console.log(`Image compressed: ${imageDataUrl.length} -> ${compressedDataUrl.length} bytes, quality: ${quality}`);
      resolve(compressedDataUrl);
    };
    
    img.src = imageDataUrl;
  });
};

export const useOCR = () => {
  const extractNutritionFromImage = async (imageDataUrl: string) => {
    try {
      console.log('=== OCR Process Starting ===');
      console.log('Original image data URL length:', imageDataUrl.length);
      
      // Compress image before sending to OCR.space to avoid 1MB limit
      const compressedImage = await compressImage(imageDataUrl, 800); // 800KB limit
      console.log('Compressed image data URL length:', compressedImage.length);
      
      // Call our OCR Edge Function first (primary method)
      console.log('Calling OCR Edge Function...');
      
      const { data, error } = await supabase.functions.invoke('ocr-proxy', {
        body: { imageDataUrl: compressedImage }
      });
      
      if (error) {
        console.error('OCR Edge Function error:', error);
        throw new Error(`OCR service error: ${error.message}`);
      }
      
      console.log('OCR Edge Function response:', data);
      
      // Handle different response formats from OCR.space
      let ocrText = '';
      if (data.success && data.text) {
        ocrText = data.text;
      } else if (data.ParsedResults && data.ParsedResults[0] && data.ParsedResults[0].ParsedText) {
        ocrText = data.ParsedResults[0].ParsedText;
      } else if (typeof data === 'object' && data.ParsedResults) {
        // Handle direct OCR.space JSON response
        ocrText = data.ParsedResults[0]?.ParsedText || '';
      }
      
      if (ocrText) {
        console.log('=== OCR TEXT RESULT (OCR.space) ===');
        console.log('Raw OCR text:', ocrText);
        console.log('Text length:', ocrText.length);
        console.log('=====================================');
        
        // Extract both nutritional information and product name
        const extractedData = extractNutritionalDataFromTable(ocrText);
        const productName = extractProductName(ocrText);
        
        console.log('=== EXTRACTION RESULTS ===');
        console.log('Extracted nutrition data:', extractedData);
        console.log('Extracted product name:', productName);
        console.log('==========================');
        
        // Check if we found anything useful
        const hasNutrition = extractedData.calories_per_100g > 0 || 
                            extractedData.protein_per_100g > 0 || 
                            extractedData.carbs_per_100g > 0 || 
                            extractedData.fat_per_100g > 0;
        
        if (hasNutrition || (productName && productName.length > 2)) {
          return {
            ...extractedData,
            name: productName
          };
        }
      }
      
      // Fallback to local Tesseract if OCR.space fails or returns nothing useful
      console.log('OCR.space failed or returned no useful data, falling back to local OCR...');
      return await fallbackToLocalOCR(imageDataUrl);
      
    } catch (error) {
      console.error('=== OCR Error ===', error);
      
      // If it's a file size error, show specific message
      if (error.message && error.message.includes('File size exceeds')) {
        toast.error('Снимката е твърде голяма. Моля опитайте с по-малка снимка.');
        throw new Error('Снимката е твърде голяма за обработка.');
      }
      
      // Fallback to local Tesseract on any error
      console.log('Falling back to local OCR due to error...');
      try {
        return await fallbackToLocalOCR(imageDataUrl);
      } catch (fallbackError) {
        console.error('Fallback OCR also failed:', fallbackError);
        throw new Error('Всички OCR методи се провалиха. Моля опитайте с по-ясна снимка.');
      }
    }
  };

  const fallbackToLocalOCR = async (imageDataUrl: string) => {
    const { createWorker } = await import('tesseract.js');
    let worker: any = null;
    
    try {
      console.log('Creating Tesseract worker...');
      worker = await createWorker(['eng'], 1, {
        logger: (m: any) => {
          console.log('Tesseract progress:', m);
          if (m.status === 'recognizing text' && m.progress) {
            const progress = Math.round(m.progress * 100);
            console.log(`Local OCR Progress: ${progress}%`);
          }
        }
      });
      console.log('Local OCR worker created successfully');
      
      console.log('Starting local image recognition...');
      const { data: { text } } = await worker.recognize(imageDataUrl);
      console.log('=== LOCAL OCR TEXT RESULT ===');
      console.log('Raw OCR text:', text);
      console.log('Text length:', text.length);
      console.log('=============================');
      
      if (!text || text.trim().length === 0) {
        console.log('Local OCR returned empty text');
        return null;
      }
      
        // Extract both nutritional information and product name
        const extractedData = extractNutritionalDataFromTable(text);
        const productName = extractProductName(text);
      
      console.log('=== LOCAL EXTRACTION RESULTS ===');
      console.log('Extracted nutrition data:', extractedData);
      console.log('Extracted product name:', productName);
      console.log('================================');
      
      // Check if we found anything useful
      const hasNutrition = extractedData.calories_per_100g > 0 || 
                          extractedData.protein_per_100g > 0 || 
                          extractedData.carbs_per_100g > 0 || 
                          extractedData.fat_per_100g > 0;
      
      if (hasNutrition || (productName && productName.length > 2)) {
        return {
          ...extractedData,
          name: productName
        };
      } else {
        console.log('No useful data extracted from local OCR');
        return null;
      }
    } finally {
      if (worker) {
        console.log('Terminating local OCR worker...');
        try {
          await worker.terminate();
          console.log('Local OCR worker terminated successfully');
        } catch (terminateError) {
          console.error('Error terminating worker:', terminateError);
        }
      }
    }
  };

  const extractProductName = (text: string) => {
    console.log('=== EXTRACTING PRODUCT NAME ===');
    const lines = text.split('\n').map(line => line.trim()).filter(line => line.length > 2);
    console.log('Text lines for product name:', lines);
    
    // Look for product name patterns
    for (let i = 0; i < Math.min(lines.length, 15); i++) {
      const line = lines[i];
      console.log(`Checking line ${i}: "${line}"`);
      
      // Skip lines that look like nutritional info
      if (/\d+.*(?:kcal|cal|calories|protein|carbs|fat|fiber|г|гр|энерг)/i.test(line)) {
        console.log(`Skipping nutritional line: ${line}`);
        continue;
      }
      
      // Skip lines with mostly numbers or symbols
      if (/^[\d\s\-\.,\/%]+$/.test(line)) {
        console.log(`Skipping numeric line: ${line}`);
        continue;
      }
      
      // Skip lines that are too short or too long
      if (line.length < 3 || line.length > 60) {
        console.log(`Skipping line (length ${line.length}): ${line}`);
        continue;
      }
      
      // Skip common label words
      if (/^(?:nutrition|ingredients|съставки|хранителна|стойност|per|на|100|г|гр|таблица|table|facts|information)$/i.test(line)) {
        console.log(`Skipping label word: ${line}`);
        continue;
      }
      
      // Skip lines that start with "per" or contain only weights/measures
      if (/^(?:per|на)\s+\d+/i.test(line) || /^\d+\s*(?:г|гр|g|ml|mg)$/i.test(line)) {
        console.log(`Skipping measurement line: ${line}`);
        continue;
      }
      
      // This looks like a product name
      if (line.length >= 3 && line.length <= 60) {
        console.log(`Found product name: "${line}"`);
        return line;
      }
    }
    
    console.log('No product name found');
    return '';
  };

  // New improved parser for table-style OCR results
  const extractNutritionalDataFromTable = (text: string) => {
    console.log('=== PARSING TABLE-STYLE OCR ===');
    const lines = text.split(/[\r\n]+/).map(line => line.trim()).filter(line => line.length > 0);
    console.log('Text lines:', lines);
    
    let nutrition = {
      calories_per_100g: 0,
      protein_per_100g: 0,
      carbs_per_100g: 0,
      fat_per_100g: 0,
      fiber_per_100g: 0,
    };
    
    // Find nutrient names and their corresponding values
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].toLowerCase();
      
      // Look for Energy/Calories
      if ((line.includes('energy') || line.includes('енерг')) && !nutrition.calories_per_100g) {
        const calorieValue = findNearbyValue(lines, i, ['kcal', 'cal', 'кал'], 100, 600);
        if (calorieValue > 0) {
          nutrition.calories_per_100g = calorieValue;
          console.log(`Found calories: ${calorieValue}`);
        }
      }
      
      // Look for Protein (but NOT "protein powder" or similar)
      if (line.includes('protein') && !line.includes('powder') && !nutrition.protein_per_100g) {
        const proteinValue = findNearbyValue(lines, i, ['g', 'г'], 0, 100);
        if (proteinValue > 0) {
          nutrition.protein_per_100g = proteinValue;
          console.log(`Found protein: ${proteinValue}`);
        }
      }
      
      // Look for Carbohydrates (not sugars!)
      if ((line.includes('carbohydrat') || line.includes('въглехидрат')) && 
          !line.includes('sugar') && !line.includes('захар') && !nutrition.carbs_per_100g) {
        const carbValue = findNearbyValue(lines, i, ['g', 'г'], 0, 100);
        if (carbValue > 0) {
          nutrition.carbs_per_100g = carbValue;
          console.log(`Found carbs: ${carbValue}`);
        }
      }
      
      // Look for Fat (but not saturated fat)
      if (line.includes('fat') && !line.includes('saturate') && !line.includes('наситен') && !nutrition.fat_per_100g) {
        const fatValue = findNearbyValue(lines, i, ['g', 'г'], 0, 50);
        if (fatValue > 0) {
          nutrition.fat_per_100g = fatValue;
          console.log(`Found fat: ${fatValue}`);
        }
      }
      
      // Look for Fiber/Fibre
      if ((line.includes('fiber') || line.includes('fibre') || line.includes('фибр')) && 
          !line.includes('saturate') && !nutrition.fiber_per_100g) {
        const fiberValue = findNearbyValue(lines, i, ['g', 'г'], 0, 30);
        if (fiberValue > 0) {
          nutrition.fiber_per_100g = fiberValue;
          console.log(`Found fiber: ${fiberValue}`);
        }
      }
    }
    
    console.log('Final nutrition data:', nutrition);
    return nutrition;
  };
  
  const findNearbyValue = (lines: string[], startIndex: number, units: string[], min: number, max: number): number => {
    // First check the same line
    const sameLineValue = extractNumberFromLine(lines[startIndex], units);
    if (sameLineValue >= min && sameLineValue <= max) return sameLineValue;
    
    // Then check next 3 lines
    for (let i = startIndex + 1; i < Math.min(startIndex + 4, lines.length); i++) {
      const value = extractNumberFromLine(lines[i], units);
      if (value >= min && value <= max) return value;
    }
    
    // Finally check previous line (in case nutrient name comes after value)
    if (startIndex > 0) {
      const prevValue = extractNumberFromLine(lines[startIndex - 1], units);
      if (prevValue >= min && prevValue <= max) return prevValue;
    }
    
    return 0;
  };
  
  const findNutrientValue = (lines: string[], startIndex: number, units: string[]): number => {
    // Look in the current line first
    const currentValue = extractNumberFromLine(lines[startIndex], units);
    if (currentValue > 0) return currentValue;
    
    // Look in next 3 lines
    for (let i = startIndex + 1; i < Math.min(startIndex + 4, lines.length); i++) {
      const value = extractNumberFromLine(lines[i], units);
      if (value > 0) return value;
    }
    
    return 0;
  };
  
  const extractNumberFromLine = (line: string, units: string[]): number => {
    // Handle OCR errors like "2.og" -> "2.0g", "o.4g" -> "0.4g"
    const cleanLine = line.replace(/o(\d)/g, '0$1').replace(/(\d)o/g, '$10');
    
    for (const unit of units) {
      // Look for patterns like "352kcal", "2.5g", "0.4g"
      const patterns = [
        new RegExp(`(\\d+(?:[.,]\\d+)?)\\s*${unit}`, 'i'),
        new RegExp(`(\\d+(?:[.,]\\d+)?)${unit}`, 'i'),
        new RegExp(`${unit}\\s*(\\d+(?:[.,]\\d+)?)`, 'i'),
      ];
      
      for (const pattern of patterns) {
        const match = cleanLine.match(pattern);
        if (match && match[1]) {
          const value = parseFloat(match[1].replace(',', '.'));
          if (value > 0 && value < 1000) { // Reasonable range
            return value;
          }
        }
      }
    }
    
    return 0;
  };

  // Fallback to original parser for simple text
  const extractNutritionalData = (text: string) => {
    const normalizedText = text.toLowerCase();
    
    const patterns = {
      calories: [
        /energy[:\s]*(\d+(?:[.,]\d+)?)\s*(?:kcal|cal|calories?)/i,
        /(\d+(?:[.,]\d+)?)\s*(?:kcal|cal|calories?)/i,
        /calories?[:\s]*(\d+(?:[.,]\d+)?)/i,
        /per\s*100g?.*?energy[:\s]*(\d+(?:[.,]\d+)?)\s*(?:kcal|cal)/i,
        /per\s*100g?.*?(\d+(?:[.,]\d+)?)\s*(?:kcal|cal)/i,
        /(?:енерг[ия]*|калории|кал)\s*[:\-]?\s*(\d+(?:[.,]\d+)?)\s*(?:kcal|кал|кj)?/i,
        /(\d+(?:[.,]\d+)?)\s*(?:kcal|кал|калории)/i,
      ],
      protein: [
        /protein[:\s]*(\d+(?:[.,]\d+)?)\s*g?/i,
        /(\d+(?:[.,]\d+)?)\s*g?\s*protein/i,
        /per\s*100g?.*?protein[:\s]*(\d+(?:[.,]\d+)?)\s*g?/i,
        /per\s*100g?.*?(\d+(?:[.,]\d+)?)\s*g?\s*protein/i,
        /(?:протеин|белтъци|белтък)\s*[:\-]?\s*(\d+(?:[.,]\d+)?)\s*г?/i,
        /(\d+(?:[.,]\d+)?)\s*г?\s*(?:протеин|protein|белтък)/i,
      ],
      carbs: [
        /carbohydrat[es]*[:\s]*(\d+(?:[.,]\d+)?)\s*g?/i,
        /carbs?[:\s]*(\d+(?:[.,]\d+)?)\s*g?/i,
        /(\d+(?:[.,]\d+)?)\s*g?\s*carbohydrat[es]*/i,
        /(\d+(?:[.,]\d+)?)\s*g?\s*carbs?/i,
        /per\s*100g?.*?carbohydrat[es]*[:\s]*(\d+(?:[.,]\d+)?)\s*g?/i,
        /per\s*100g?.*?carbs?[:\s]*(\d+(?:[.,]\d+)?)\s*g?/i,
        /(?:въглехидрати|carbohydrate|карбохидрати|углехидрати)\s*[:\-]?\s*(\d+(?:[.,]\d+)?)\s*г?/i,
        /(\d+(?:[.,]\d+)?)\s*г?\s*(?:въглехидрати|carbohydrate)/i,
      ],
      fat: [
        /total\s*fat[:\s]*(\d+(?:[.,]\d+)?)\s*g?/i,
        /fat[:\s]*(\d+(?:[.,]\d+)?)\s*g?/i,
        /(\d+(?:[.,]\d+)?)\s*g?\s*fat/i,
        /per\s*100g?.*?fat[:\s]*(\d+(?:[.,]\d+)?)\s*g?/i,
        /per\s*100g?.*?(\d+(?:[.,]\d+)?)\s*g?\s*fat/i,
        /(?:мазнини|fat|жир|масло)\s*[:\-]?\s*(\d+(?:[.,]\d+)?)\s*г?/i,
        /(\d+(?:[.,]\d+)?)\s*г?\s*(?:мазнини|fat|жир)/i,
      ],
      fiber: [
        /fiber[:\s]*(\d+(?:[.,]\d+)?)\s*g?/i,
        /fibre[:\s]*(\d+(?:[.,]\d+)?)\s*g?/i,
        /dietary\s*fiber[:\s]*(\d+(?:[.,]\d+)?)\s*g?/i,
        /(\d+(?:[.,]\d+)?)\s*g?\s*fiber/i,
        /(\d+(?:[.,]\d+)?)\s*g?\s*fibre/i,
        /per\s*100g?.*?fiber[:\s]*(\d+(?:[.,]\d+)?)\s*g?/i,
        /per\s*100g?.*?fibre[:\s]*(\d+(?:[.,]\d+)?)\s*g?/i,
        /(?:фибри|fiber|фибър|влакна)\s*[:\-]?\s*(\d+(?:[.,]\d+)?)\s*г?/i,
        /(\d+(?:[.,]\d+)?)\s*г?\s*(?:фибри|fiber|влакна)/i,
      ],
    };

    const extractValue = (patternsArray: RegExp[]) => {
      for (const pattern of patternsArray) {
        const match = normalizedText.match(pattern);
        if (match && match[1]) {
          return parseFloat(match[1].replace(',', '.'));
        }
      }
      return 0;
    };

    return {
      calories_per_100g: extractValue(patterns.calories),
      protein_per_100g: extractValue(patterns.protein),
      carbs_per_100g: extractValue(patterns.carbs),
      fat_per_100g: extractValue(patterns.fat),
      fiber_per_100g: extractValue(patterns.fiber),
    };
  };

  return {
    extractNutritionFromImage,
  };
};