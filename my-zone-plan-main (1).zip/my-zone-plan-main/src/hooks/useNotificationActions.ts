import { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useHydration } from './useHydration';
import { useHabitSessions } from './useHabitSessions';
import { useHabits } from './useHabits';
import { toast } from './use-toast';

export const useNotificationActions = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { addIntake } = useHydration();
  const { startSessionMutation } = useHabitSessions();
  const { habits } = useHabits();

  useEffect(() => {
    const urlParams = new URLSearchParams(location.search);
    const action = urlParams.get('action');

    if (!action) return;

    const handleAction = async () => {
      try {
        switch (action) {
          case 'add_water': {
            const ml = parseInt(urlParams.get('ml') || '0');
            if (ml > 0) {
              addIntake({ volume_ml: ml });
              toast({
                title: "Вода добавена",
                description: `Добавени ${ml}мл вода`,
              });
            }
            break;
          }

          case 'start_habit': {
            const habitId = urlParams.get('habit_id');
            if (habitId) {
              // Find the habit to get its details
              const habit = habits?.find(h => h.id === habitId);
              if (habit) {
                startSessionMutation.mutate({ habitId });
                toast({
                  title: "Навик стартиран",
                  description: `Започна ${habit.name}`,
                });
                // Navigate to habits page to show the timer
                navigate('/habits');
              }
            }
            break;
          }

          case 'open_hydration': {
            navigate('/');
            break;
          }

          default:
            console.log('Unknown notification action:', action);
        }
      } catch (error) {
        console.error('Error handling notification action:', error);
        toast({
          title: "Грешка",
          description: "Неуспешно изпълнение на действието",
          variant: "destructive",
        });
      } finally {
        // Clean up URL parameters
        const newUrl = new URL(window.location.href);
        newUrl.search = '';
        window.history.replaceState({}, '', newUrl.toString());
      }
    };

    handleAction();
  }, [location.search, addIntake, startSessionMutation, habits, navigate]);
};