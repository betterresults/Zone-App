import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { toast } from '@/hooks/use-toast';
import { useScheduledNotifications } from './useScheduledNotifications';
import { useEffect } from 'react';

export interface FastingSession {
  id: string;
  user_id: string;
  start_at: string;
  end_at?: string;
  target_hours?: number;
  note?: string;
  created_at: string;
  updated_at: string;
}

export const useFasting = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { createNotification, cancelNotifications } = useScheduledNotifications();

  // Real-time subscription for fasting sessions
  useEffect(() => {
    if (!user?.id) return;

    const channel = supabase
      .channel('fasting-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'fasting_sessions',
          filter: `user_id=eq.${user.id}`
        },
        () => {
          queryClient.invalidateQueries({ queryKey: ['fasting'] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, queryClient]);

  const { data: activeFast, isLoading } = useQuery({
    queryKey: ['fasting', 'active', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      
      const { data, error } = await supabase
        .from('fasting_sessions')
        .select('*')
        .eq('user_id', user.id)
        .is('end_at', null)
        .maybeSingle();

      if (error) throw error;
      return data as FastingSession | null;
    },
    enabled: !!user?.id,
    refetchInterval: 30000, // Refetch every 30 seconds for live timer
  });

  const { data: recentSessions = [] } = useQuery({
    queryKey: ['fasting', 'recent', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const { data, error } = await supabase
        .from('fasting_sessions')
        .select('*')
        .eq('user_id', user.id)
        .not('end_at', 'is', null)
        .order('start_at', { ascending: false })
        .limit(10);

      if (error) throw error;
      return data as FastingSession[];
    },
    enabled: !!user?.id,
  });

  const startFastMutation = useMutation({
    mutationFn: async ({ target_hours, note }: { target_hours?: number; note?: string }) => {
      if (!user?.id) throw new Error('User not authenticated');
      
      const { data, error } = await supabase
        .from('fasting_sessions')
        .insert({
          user_id: user.id,
          target_hours,
          note,
          start_at: new Date().toISOString(),
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['fasting'] });
      
      // Schedule notification if target hours are set
      if (data.target_hours && user?.id) {
        const notificationTime = new Date(new Date(data.start_at).getTime() + data.target_hours * 60 * 60 * 1000);
        const customTitle = `🎉 ${data.target_hours}ч фастинг завършен!`;
        const customMessage = `Честито! Успешно завърши фастинг от ${data.target_hours} часа. Време е да нарушиш поста с полезна храна! 💪`;
        
        createNotification({
          user_id: user.id,
          notification_type: 'event',
          reference_id: `fasting_${data.id}`,
          scheduled_for: notificationTime.toISOString(),
          title: customTitle,
          message: customMessage,
        });
      }
      
      toast({
        title: "Започнат фастинг",
        description: "Фастинг сесията е започната успешно.",
      });
    },
    onError: () => {
      toast({
        title: "Грешка",
        description: "Неуспешно започване на фастинг.",
        variant: "destructive",
      });
    },
  });

  const endFastMutation = useMutation({
    mutationFn: async (sessionId: string) => {
      const { data, error } = await supabase
        .from('fasting_sessions')
        .update({ end_at: new Date().toISOString() })
        .eq('id', sessionId)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['fasting'] });
      
      // Cancel any pending notifications for this fasting session
      cancelNotifications(`fasting_${data.id}`);
      
      toast({
        title: "Завършен фастинг",
        description: "Фастинг сесията е завършена успешно.",
      });
    },
    onError: () => {
      toast({
        title: "Грешка",
        description: "Неуспешно завършване на фастинг.",
        variant: "destructive",
      });
    },
  });

  const getCurrentFastingTime = () => {
    if (!activeFast) return 0;
    const startTime = new Date(activeFast.start_at).getTime();
    const currentTime = Date.now();
    return Math.max(0, currentTime - startTime);
  };

  const formatFastingTime = (milliseconds: number) => {
    const hours = Math.floor(milliseconds / (1000 * 60 * 60));
    const minutes = Math.floor((milliseconds % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((milliseconds % (1000 * 60)) / 1000);
    return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  return {
    activeFast,
    recentSessions,
    isLoading,
    startFast: startFastMutation.mutate,
    endFast: endFastMutation.mutate,
    isStarting: startFastMutation.isPending,
    isEnding: endFastMutation.isPending,
    getCurrentFastingTime,
    formatFastingTime,
  };
};