import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { format, startOfWeek, getDay } from 'date-fns';
import { toast } from 'sonner';
import { useQueryClient } from '@tanstack/react-query';

interface PlannedMeal {
  id: string;
  meal_type: string;
  product_id?: string;
  recipe_id?: string;
  dish_id?: string;
  servings: number;
  grams?: number;
  notes?: string;
  is_completed?: boolean;
  completed_at?: string;
  products?: {
    name: string;
    calories_per_100g: number;
    protein_per_100g: number;
    carbs_per_100g: number;
    fat_per_100g: number;
  };
  recipes?: {
    name: string;
    servings: number;
    recipe_ingredients: Array<{
      grams: number;
      products: {
        calories_per_100g: number;
        protein_per_100g: number;
        carbs_per_100g: number;
        fat_per_100g: number;
      };
    }>;
  };
  dishes?: {
    name: string;
    dish_ingredients: Array<{
      grams: number;
      products: {
        calories_per_100g: number;
        protein_per_100g: number;
        carbs_per_100g: number;
        fat_per_100g: number;
      };
    }>;
  };
}

export const usePlannedMeals = (date: Date = new Date()) => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [plannedMeals, setPlannedMeals] = useState<PlannedMeal[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchPlannedMeals = async () => {
    if (!user) return;
    
    setLoading(true);

    try {
      // Get the start of the week for the given date
      const weekStart = startOfWeek(date, { weekStartsOn: 1 }); // Monday = 1
      const dayOfWeek = getDay(date) === 0 ? 6 : getDay(date) - 1; // Convert Sunday=0 to Sunday=6, Monday=1 to Monday=0

      const { data, error } = await supabase
        .from('weekly_meal_plans')
        .select(`
          id,
          meal_type,
          product_id,
          recipe_id,
          dish_id,
          servings,
          grams,
          notes,
          is_completed,
          completed_at,
          products (
            name,
            calories_per_100g,
            protein_per_100g,
            carbs_per_100g,
            fat_per_100g
          ),
          recipes (
            name,
            servings,
            recipe_ingredients (
              grams,
              products (
                calories_per_100g,
                protein_per_100g,
                carbs_per_100g,
                fat_per_100g
              )
            )
          ),
          dishes (
            name,
            dish_ingredients (
              grams,
              products (
                calories_per_100g,
                protein_per_100g,
                carbs_per_100g,
                fat_per_100g
              )
            )
          )
        `)
        .eq('user_id', user.id)
        .eq('week_start_date', format(weekStart, 'yyyy-MM-dd'))
        .eq('day_of_week', dayOfWeek); // Show both completed and non-completed for toggle functionality

      if (error) {
        console.error('Supabase error:', error);
        throw error;
      }

      setPlannedMeals(data || []);
    } catch (error) {
      console.error('Error fetching planned meals:', error);
      // Don't throw, just log and continue
      setPlannedMeals([]);
    } finally {
      setLoading(false);
    }
  };

  const togglePlannedMeal = async (plannedMeal: PlannedMeal) => {
    if (!user) return;

    try {
      const isCurrentlyCompleted = plannedMeal.is_completed;
      
      if (isCurrentlyCompleted) {
        // If completed, uncomplete it - remove from actual meals and mark as not completed
        // Find and delete the corresponding meal
        let deleteQuery = supabase
          .from('meals')
          .delete()
          .eq('user_id', user.id)
          .eq('date', format(date, 'yyyy-MM-dd'))
          .eq('meal_type', plannedMeal.meal_type as 'breakfast' | 'lunch' | 'dinner' | 'snack');

        if (plannedMeal.product_id) {
          deleteQuery = deleteQuery.eq('product_id', plannedMeal.product_id);
        } else {
          deleteQuery = deleteQuery.is('product_id', null);
        }
        if (plannedMeal.recipe_id) {
          deleteQuery = deleteQuery.eq('recipe_id', plannedMeal.recipe_id);
        } else {
          deleteQuery = deleteQuery.is('recipe_id', null);
        }
        if (plannedMeal.dish_id) {
          deleteQuery = deleteQuery.eq('dish_id', plannedMeal.dish_id);
        } else {
          deleteQuery = deleteQuery.is('dish_id', null);
        }

        const { error: deleteMealError } = await deleteQuery;

        if (deleteMealError) throw deleteMealError;

        // Mark planned meal as not completed
        const { error: updateError } = await supabase
          .from('weekly_meal_plans')
          .update({
            is_completed: false,
            completed_at: null
          })
          .eq('id', plannedMeal.id);

        if (updateError) throw updateError;
      } else {
        // If not completed, complete it - add to actual meals and mark as completed
        const { error: mealError } = await supabase
          .from('meals')
          .insert({
            user_id: user.id,
            date: format(date, 'yyyy-MM-dd'),
            meal_type: plannedMeal.meal_type as 'breakfast' | 'lunch' | 'dinner' | 'snack',
            product_id: plannedMeal.product_id || null,
            recipe_id: plannedMeal.recipe_id || null,
            dish_id: plannedMeal.dish_id || null,
            servings: plannedMeal.servings,
            grams: plannedMeal.grams || null,
            notes: plannedMeal.notes || null,
            is_consumed: true
          });

        if (mealError) throw mealError;

        // Mark planned meal as completed
        const { error: updateError } = await supabase
          .from('weekly_meal_plans')
          .update({
            is_completed: true,
            completed_at: new Date().toISOString()
          })
          .eq('id', plannedMeal.id);

        if (updateError) throw updateError;
        
        toast.success('Храненето е добавено!');
      }

      // Refetch planned meals to update the UI
      fetchPlannedMeals();
      
      // Invalidate today's meals cache to refresh the progress
      queryClient.invalidateQueries({ queryKey: ['today-meals-with-dishes'] });
      
    } catch (error) {
      console.error('Error toggling planned meal:', error);
      toast.error('Грешка при промяна на храненето');
    }
  };

  const addPlannedMealToActual = async (plannedMeal: PlannedMeal) => {
    // Deprecated - use togglePlannedMeal instead
    return togglePlannedMeal(plannedMeal);
  };

  const calculateMealNutrition = (meal: PlannedMeal) => {
    let nutrition = { calories: 0, protein: 0, carbs: 0, fat: 0 };

    if (meal.products) {
      const ratio = (meal.grams || 100) / 100;
      nutrition.calories = meal.products.calories_per_100g * ratio;
      nutrition.protein = meal.products.protein_per_100g * ratio;
      nutrition.carbs = meal.products.carbs_per_100g * ratio;
      nutrition.fat = meal.products.fat_per_100g * ratio;
    } else if (meal.recipes) {
      meal.recipes.recipe_ingredients?.forEach((ingredient) => {
        const ratio = ingredient.grams / 100;
        const servingRatio = (meal.servings || 1) / meal.recipes!.servings;
        nutrition.calories += ingredient.products.calories_per_100g * ratio * servingRatio;
        nutrition.protein += ingredient.products.protein_per_100g * ratio * servingRatio;
        nutrition.carbs += ingredient.products.carbs_per_100g * ratio * servingRatio;
        nutrition.fat += ingredient.products.fat_per_100g * ratio * servingRatio;
      });
    } else if (meal.dishes) {
      meal.dishes.dish_ingredients?.forEach((ingredient) => {
        const ratio = ingredient.grams / 100;
        const servingRatio = meal.servings || 1;
        nutrition.calories += ingredient.products.calories_per_100g * ratio * servingRatio;
        nutrition.protein += ingredient.products.protein_per_100g * ratio * servingRatio;
        nutrition.carbs += ingredient.products.carbs_per_100g * ratio * servingRatio;
        nutrition.fat += ingredient.products.fat_per_100g * ratio * servingRatio;
      });
    }

    return nutrition;
  };

  const getMealName = (meal: PlannedMeal): string => {
    if (meal.products) return meal.products.name;
    if (meal.recipes) return meal.recipes.name;
    if (meal.dishes) return meal.dishes.name;
    return 'Неизвестно ястие';
  };

  useEffect(() => {
    fetchPlannedMeals();
  }, [user, date]);

  // Realtime updates for weekly planned meals
  useEffect(() => {
    if (!user?.id) return;

    const channel = supabase
      .channel('weekly-plans-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'weekly_meal_plans',
          filter: `user_id=eq.${user.id}`
        },
        async (payload) => {
          console.log('Weekly meal plans change detected:', payload);
          // Refetch planned meals and invalidate all related queries
          await fetchPlannedMeals();
          await queryClient.invalidateQueries({ queryKey: ['weeklyMealPlans'] });
          await queryClient.invalidateQueries({ queryKey: ['planned-meals'] });
          await queryClient.refetchQueries({ queryKey: ['weeklyMealPlans'] });
          await queryClient.refetchQueries({ queryKey: ['planned-meals'] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, date, queryClient]);

  return {
    plannedMeals,
    loading,
    togglePlannedMeal,
    addPlannedMealToActual, // Keep for backward compatibility
    calculateMealNutrition,
    getMealName,
    refetch: fetchPlannedMeals
  };
};