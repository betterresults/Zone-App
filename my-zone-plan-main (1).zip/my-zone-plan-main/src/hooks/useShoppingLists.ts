import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { useEffect } from 'react';

export interface ShoppingListItem {
  id: string;
  shopping_list_id: string;
  product_id: string;
  quantity_grams: number;
  estimated_packages: number;
  is_purchased: boolean;
  is_available: boolean;
  notes?: string;
  created_at: string;
  updated_at: string;
  product?: {
    id: string;
    name: string;
    package_size_grams?: number;
    package_size_unit?: string;
    category?: string;
    custom_category?: string;
    image_url?: string;
  };
}

export interface ShoppingList {
  id: string;
  user_id: string;
  name: string;
  week_start_date: string;
  week_end_date: string;
  total_items_count: number;
  completed_items_count: number;
  is_completed: boolean;
  is_template: boolean;
  template_name?: string;
  is_archived: boolean;
  archived_at?: string;
  created_at: string;
  updated_at: string;
  items?: ShoppingListItem[];
}

export const useShoppingLists = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  // Real-time subscription for shopping lists
  useEffect(() => {
    if (!user?.id) return;

    const channel = supabase
      .channel('shopping-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'shopping_lists',
          filter: `user_id=eq.${user.id}`
        },
        () => {
          queryClient.invalidateQueries({ queryKey: ['shopping-lists'] });
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'shopping_list_items'
        },
        () => {
          queryClient.invalidateQueries({ queryKey: ['shopping-lists'] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, queryClient]);

  const {
    data: shoppingLists,
    isLoading,
    error,
  } = useQuery({
    queryKey: ['shopping-lists', user?.id],
    queryFn: async () => {
      if (!user?.id) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('shopping_lists')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Fetch items separately for each list
      const listsWithItems = await Promise.all(
        (data || []).map(async (list) => {
          const { data: items, error: itemsError } = await supabase
            .from('shopping_list_items')
            .select('*')
            .eq('shopping_list_id', list.id);

          if (itemsError) throw itemsError;

          const itemsWithProducts = await Promise.all(
            (items || []).map(async (item) => {
              const { data: product } = await supabase
                .from('products')
                .select('id, name, package_size_grams, package_size_unit, category, image_url')
                .eq('id', item.product_id)
                .single();

              return {
                ...item,
                product: product || undefined
              };
            })
          );

          return {
            ...list,
            items: itemsWithProducts
          };
        })
      );

      return listsWithItems as ShoppingList[];
    },
    enabled: !!user?.id,
  });

  const createShoppingListMutation = useMutation({
    mutationFn: async (listData: {
      name: string;
      week_start_date: string;
      week_end_date: string;
      items: Array<{
        product_id: string;
        quantity_grams: number;
        estimated_packages: number;
      }>;
    }) => {
      if (!user?.id) throw new Error('User not authenticated');

      // Create the shopping list
      const { data: shoppingList, error: listError } = await supabase
        .from('shopping_lists')
        .insert({
          user_id: user.id,
          name: listData.name,
          week_start_date: listData.week_start_date,
          week_end_date: listData.week_end_date,
        })
        .select()
        .single();

      if (listError) throw listError;

      // Add items to the shopping list
      if (listData.items.length > 0) {
        const { error: itemsError } = await supabase
          .from('shopping_list_items')
          .insert(
            listData.items.map(item => ({
              shopping_list_id: shoppingList.id,
              product_id: item.product_id,
              quantity_grams: item.quantity_grams,
              estimated_packages: item.estimated_packages,
            }))
          );

        if (itemsError) throw itemsError;
      }

      return shoppingList;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['shopping-lists'] });
      toast.success('Списъкът за пазаруване е създаден успешно!');
    },
    onError: (error) => {
      console.error('Error creating shopping list:', error);
      toast.error('Грешка при създаване на списъка');
    },
  });

  const updateShoppingListItemMutation = useMutation({
    mutationFn: async (params: {
      itemId: string;
      updates: Partial<Pick<ShoppingListItem, 'quantity_grams' | 'estimated_packages' | 'is_purchased' | 'is_available' | 'notes'>>;
    }) => {
      const { error } = await supabase
        .from('shopping_list_items')
        .update(params.updates)
        .eq('id', params.itemId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['shopping-lists'] });
    },
    onError: (error) => {
      console.error('Error updating shopping list item:', error);
      toast.error('Грешка при обновяване на артикула');
    },
  });

  const deleteShoppingListItemMutation = useMutation({
    mutationFn: async (itemId: string) => {
      const { error } = await supabase
        .from('shopping_list_items')
        .delete()
        .eq('id', itemId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['shopping-lists'] });
      toast.success('Артикулът е премахнат от списъка');
    },
    onError: (error) => {
      console.error('Error deleting shopping list item:', error);
      toast.error('Грешка при премахване на артикула');
    },
  });

  const deleteShoppingListMutation = useMutation({
    mutationFn: async (listId: string) => {
      const { error } = await supabase
        .from('shopping_lists')
        .delete()
        .eq('id', listId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['shopping-lists'] });
      toast.success('Списъкът за пазаруване е изтрит');
    },
    onError: (error) => {
      console.error('Error deleting shopping list:', error);
      toast.error('Грешка при изтриване на списъка');
    },
  });

  const saveAsTemplateMutation = useMutation({
    mutationFn: async (params: { listId: string; templateName: string }) => {
      const { error } = await supabase
        .from('shopping_lists')
        .update({ 
          name: `[ШАБЛОН] ${params.templateName}` 
        })
        .eq('id', params.listId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['shopping-lists'] });
      toast.success('Шаблонът е запазен!');
    },
    onError: (error) => {
      console.error('Error saving template:', error);
      toast.error('Грешка при запазване на шаблона');
    },
  });

  const archiveShoppingListMutation = useMutation({
    mutationFn: async (listId: string) => {
      const { error } = await supabase
        .from('shopping_lists')
        .update({ 
          name: `[АРХИВ] ${shoppingLists.find(l => l.id === listId)?.name || 'Списък'}` 
        })
        .eq('id', listId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['shopping-lists'] });
      toast.success('Списъкът е архивиран');
    },
    onError: (error) => {
      console.error('Error archiving list:', error);
      toast.error('Грешка при архивиране на списъка');
    },
  });

  const createFromTemplateMutation = useMutation({
    mutationFn: async (params: {
      templateId: string;
      name: string;
      week_start_date: string;
      week_end_date: string;
    }) => {
      if (!user?.id) throw new Error('User not authenticated');

      // Get template data
      const { data: template, error: templateError } = await supabase
        .from('shopping_lists')
        .select(`
          *,
          items:shopping_list_items(*)
        `)
        .eq('id', params.templateId)
        .single();

      if (templateError) throw templateError;

      // Create new list
      const { data: newList, error: listError } = await supabase
        .from('shopping_lists')
        .insert({
          user_id: user.id,
          name: params.name,
          week_start_date: params.week_start_date,
          week_end_date: params.week_end_date,
        })
        .select()
        .single();

      if (listError) throw listError;

      // Copy items from template
      if (template.items && Array.isArray(template.items) && template.items.length > 0) {
        const { error: itemsError } = await supabase
          .from('shopping_list_items')
          .insert(
            template.items.map((item: any) => ({
              shopping_list_id: newList.id,
              product_id: item.product_id,
              quantity_grams: item.quantity_grams,
              estimated_packages: item.estimated_packages,
              is_purchased: false,
              is_available: false,
            }))
          );

        if (itemsError) throw itemsError;
      }

      return newList;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['shopping-lists'] });
      toast.success('Списък създаден от шаблон!');
    },
    onError: (error) => {
      console.error('Error creating from template:', error);
      toast.error('Грешка при създаване от шаблон');
    },
  });

  return {
    shoppingLists: shoppingLists || [],
    isLoading,
    error,
    createShoppingListMutation,
    updateShoppingListItemMutation,
    deleteShoppingListItemMutation,
    deleteShoppingListMutation,
    saveAsTemplateMutation,
    archiveShoppingListMutation,
    createFromTemplateMutation,
  };
};

export const useWeeklyMenuIngredients = (weekStartDate: Date) => {
  const { user } = useAuth();

  return useQuery({
    queryKey: ['weekly-menu-ingredients', user?.id, format(weekStartDate, 'yyyy-MM-dd')],
    queryFn: async () => {
      if (!user?.id) throw new Error('User not authenticated');

      const weekStart = format(weekStartDate, 'yyyy-MM-dd');
      
      // Get all weekly meal plans for the week
      const { data: weeklyPlans, error } = await supabase
        .from('weekly_meal_plans')
        .select(`
          *,
          recipe:recipes(
            *,
            ingredients:recipe_ingredients(
              *,
              product:products(*)
            )
          ),
          product:products(*),
          dish:dishes(
            *,
            ingredients:dish_ingredients(
              *,
              product:products(*)
            )
          )
        `)
        .eq('user_id', user.id)
        .eq('week_start_date', weekStart);

      if (error) throw error;

      // Calculate required ingredients
      const ingredientMap = new Map<string, {
        product_id: string;
        product: any;
        total_grams: number;
      }>();

      weeklyPlans.forEach(plan => {
        const servings = plan.servings || 1;
        
        if (plan.recipe && plan.recipe.ingredients) {
          plan.recipe.ingredients.forEach((ingredient: any) => {
            const totalGrams = ingredient.grams * servings;
            const existing = ingredientMap.get(ingredient.product_id);
            
            if (existing) {
              existing.total_grams += totalGrams;
            } else {
              ingredientMap.set(ingredient.product_id, {
                product_id: ingredient.product_id,
                product: ingredient.product,
                total_grams: totalGrams,
              });
            }
          });
        } else if (plan.dish && plan.dish.ingredients) {
          plan.dish.ingredients.forEach((ingredient: any) => {
            // Dishes don't have servings property like recipes do
            const totalGrams = ingredient.grams * servings;
            const existing = ingredientMap.get(ingredient.product_id);
            
            if (existing) {
              existing.total_grams += totalGrams;
            } else {
              ingredientMap.set(ingredient.product_id, {
                product_id: ingredient.product_id,
                product: ingredient.product,
                total_grams: totalGrams,
              });
            }
          });
        } else if (plan.product) {
          const totalGrams = plan.grams || 100;
          const existing = ingredientMap.get(plan.product_id!);
          
          if (existing) {
            existing.total_grams += totalGrams;
          } else {
            ingredientMap.set(plan.product_id!, {
              product_id: plan.product_id!,
              product: plan.product,
              total_grams: totalGrams,
            });
          }
        }
      });

      const itemsById = Array.from(ingredientMap.values());

      // Merge items with the same product name (handles duplicates like Avocado with different IDs)
      const byNameMap = new Map<string, { product_id: string; product: any; total_grams: number }>();
      itemsById.forEach((ingredient) => {
        const key = ingredient.product?.name?.toLowerCase().trim() || ingredient.product_id;
        const existing = byNameMap.get(key);
        if (existing) {
          existing.total_grams += ingredient.total_grams;
        } else {
          byNameMap.set(key, { ...ingredient });
        }
      });

      return Array.from(byNameMap.values()).map(ingredient => {
        const packageSize = ingredient.product.package_size_grams || 1000;
        const estimatedPackages = Math.ceil(ingredient.total_grams / packageSize);
        
        return {
        product_id: ingredient.product_id,
        product: ingredient.product,
        quantity_grams: ingredient.total_grams,
        estimated_packages: estimatedPackages,
        };
      });
    },
    enabled: !!user?.id,
  });
};