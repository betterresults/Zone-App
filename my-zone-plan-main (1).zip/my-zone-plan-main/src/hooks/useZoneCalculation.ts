import { useMemo } from 'react';

export interface ZoneBlocks {
  protein: number;
  carbs: number;
  fat: number;
}

export interface NutritionData {
  protein: number;
  carbs: number;
  fiber: number;
  fat: number;
  calories: number;
}

export interface ZoneCalculation extends ZoneBlocks {
  blocks: number; // Total Zone blocks (minimum of the three macronutrients)
  ratio: string;
  isInZone: boolean;
  calories: number;
  netCarbs: number;
  excessCarbs: number;
  excessFat: number;
  status: string;
}

export const useZoneCalculation = (hiddenFatMode: boolean = false) => {
  const zoneConfig = useMemo(() => ({
    proteinPerBlock: 7,
    carbsPerBlock: 9, // net carbs
    fatPerBlock: 1.5, // 1.5g added fats per block due to hidden fats in foods
  }), []);

  const calculateZoneBlocks = (nutrition: NutritionData): ZoneCalculation => {
    const netCarbs = Math.max(0, nutrition.carbs - nutrition.fiber);
    
    const blocks: ZoneBlocks = {
      protein: nutrition.protein / zoneConfig.proteinPerBlock,
      carbs: nutrition.carbs / zoneConfig.carbsPerBlock, // Use total carbs like Cook page
      fat: nutrition.fat / zoneConfig.fatPerBlock,
    };

    // Calculate minimum blocks first
    const minBlocks = Math.min(blocks.protein, blocks.carbs, blocks.fat);
    const maxBlocks = Math.max(blocks.protein, blocks.carbs, blocks.fat);
    
    // Calculate excess nutrients
    const excessCarbs = Math.max(0, blocks.carbs - minBlocks);
    const excessFat = Math.max(0, blocks.fat - minBlocks);

    // Zone статус се базира на съотношението между протеин, въглехидрати и мазнини
    const proteinCarbsRatio = Math.min(blocks.protein, blocks.carbs) / Math.max(blocks.protein, blocks.carbs);
    const isProteinCarbsBalanced = proteinCarbsRatio >= 0.8;
    
    // Determine zone status
    let status = "";
    let isInZone = false;
    
    if (isProteinCarbsBalanced) {
      const avgProteinCarbs = (blocks.protein + blocks.carbs) / 2;
      const fatDeviation = Math.abs(blocks.fat - avgProteinCarbs) / avgProteinCarbs;
      
      if (fatDeviation <= 0.3) {
        isInZone = true;
        status = "В зоната";
      } else if (blocks.fat > avgProteinCarbs) {
        isInZone = true;
        status = "В зоната с нерегулирани мазнини";
      } else {
        isInZone = false;
        status = "Недостатъчно мазнини";
      }
    } else {
      isInZone = false;
      if (blocks.protein > blocks.carbs * 1.5) {
        status = "Прекалено много протеин";
      } else if (blocks.carbs > blocks.protein * 1.5) {
        status = "Прекалено много въглехидрати";
      } else {
        status = "Близо до зоната";
      }
    }

    const ratioString = `${blocks.protein.toFixed(1)}:${blocks.carbs.toFixed(1)}:${blocks.fat.toFixed(1)}`;

    return {
      ...blocks,
      blocks: minBlocks,
      ratio: ratioString,
      isInZone,
      calories: nutrition.calories,
      netCarbs,
      excessCarbs,
      excessFat,
      status,
    };
  };

  const combineNutrition = (items: NutritionData[]): NutritionData => {
    return items.reduce((total, item) => ({
      protein: total.protein + item.protein,
      carbs: total.carbs + item.carbs,
      fiber: total.fiber + item.fiber,
      fat: total.fat + item.fat,
      calories: total.calories + item.calories,
    }), {
      protein: 0,
      carbs: 0,
      fiber: 0,
      fat: 0,
      calories: 0,
    });
  };

  const scaleNutrition = (nutrition: NutritionData, multiplier: number): NutritionData => {
    return {
      protein: nutrition.protein * multiplier,
      carbs: nutrition.carbs * multiplier,
      fiber: nutrition.fiber * multiplier,
      fat: nutrition.fat * multiplier,
      calories: nutrition.calories * multiplier,
    };
  };

  return {
    calculateZoneBlocks,
    combineNutrition,
    scaleNutrition,
    zoneConfig,
  };
};