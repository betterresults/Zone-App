import { useState, useEffect } from 'react';
import { useAuth } from './useAuth';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useActivityTracker } from './useActivityTracker';

export interface MilestoneProgress {
  current: number;
  target: number;
  nextReward: string;
  completed: number;
}

export interface EarnedReward {
  id: string;
  description: string;
  earnedAt: string;
  value: string;
}

export interface ReferralData {
  referralLink: string;
  totalReferrals: number;
  clicks: number;
  milestoneProgress: MilestoneProgress;
  earnedRewards: EarnedReward[];
}

const CACHE_KEY = 'myzone_referral_cache';
const CACHE_DURATION = 10 * 60 * 1000; // 10 minutes

interface CachedData {
  data: ReferralData;
  timestamp: number;
}

export const useReferral = () => {
  const { user } = useAuth();
  const { trackActivity } = useActivityTracker();
  const [referralData, setReferralData] = useState<ReferralData | null>(null);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasInitialized, setHasInitialized] = useState(false);

  const getCachedData = (): ReferralData | null => {
    if (!user?.id) return null;
    
    try {
      const cached = localStorage.getItem(`${CACHE_KEY}_${user.id}`);
      if (!cached) return null;
      
      const parsedCache: CachedData = JSON.parse(cached);
      const isValid = Date.now() - parsedCache.timestamp < CACHE_DURATION;
      
      if (isValid) {
        return parsedCache.data;
      } else {
        localStorage.removeItem(`${CACHE_KEY}_${user.id}`);
        return null;
      }
    } catch {
      return null;
    }
  };

  const setCachedData = (data: ReferralData) => {
    if (!user?.id) return;
    
    try {
      const cacheData: CachedData = {
        data,
        timestamp: Date.now()
      };
      localStorage.setItem(`${CACHE_KEY}_${user.id}`, JSON.stringify(cacheData));
    } catch {
      // Ignore cache errors
    }
  };

  const fetchReferralData = async (useCache = true) => {
    if (!user?.email || hasInitialized) {
      return;
    }

    // Load from cache first if available
    if (useCache) {
      const cachedData = getCachedData();
      if (cachedData) {
        setReferralData(cachedData);
        setHasInitialized(true);
        setLoading(false);
        return; // Use cache and don't fetch fresh data
      }
    }

    // Prevent multiple simultaneous calls
    if (loading) {
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const { data, error: functionError } = await supabase.functions.invoke(
        'partnero-referral/get-milestone-progress',
        {
          body: { userId: user.id }
        }
      );

      if (functionError) {
        throw new Error(functionError.message);
      }

      setReferralData(data);
      setCachedData(data); // Cache the fresh data
    } catch (err) {
      console.error('Error fetching referral data:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch referral data');
      
      // If we have cached data, keep showing it
      if (!referralData) {
        const cachedData = getCachedData();
        if (cachedData) {
          setReferralData(cachedData);
        }
      }
    } finally {
      setLoading(false);
      setHasInitialized(true);
    }
  };

  const generateReferralLink = async () => {
    if (!user?.email) return '';

    setGenerating(true);
    setError(null);

    try {
      const { data, error: functionError } = await supabase.functions.invoke(
        'partnero-referral/get-referral-link',
        {
          body: { userId: user.id, email: user.email }
        }
      );

      if (functionError) {
        throw new Error(functionError.message);
      }

      const key = data?.referralKey;
      const built = key ? `${window.location.origin}/?ref=${key}` : '';
      const link = data?.referralLink || built;
      if (link) {
        const updatedData = referralData ? { ...referralData, referralLink: link } : {
          referralLink: link,
          totalReferrals: 0,
          clicks: 0,
          milestoneProgress: { current: 0, target: 3, nextReward: '1 безплатен месец', completed: 0 },
          earnedRewards: []
        };
        setReferralData(updatedData);
        
        // Update cache with new link
        setCachedData(updatedData);
        
        // Track activity
        trackActivity('referral', 'generate_referral_link', 'Генериран реферал линк', { link });
      } else {
        setError('Неуспешно генериране на линк. Моля, опитайте отново.');
      }

      return link;
    } catch (err) {
      console.error('Error generating referral link:', err);
      setError(err instanceof Error ? err.message : 'Неуспешно генериране на линк');
      return '';
    } finally {
      setGenerating(false);
    }
  };

  const copyReferralLink = async () => {
    const link = referralData?.referralLink || await generateReferralLink();
    if (link) {
      try {
        await navigator.clipboard.writeText(link);
        toast.success('Линкът е копиран!', {
          duration: 1000,
          position: 'bottom-center',
          style: {
            background: 'hsl(var(--success))',
            color: 'hsl(var(--success-foreground))',
            border: '1px solid hsl(var(--success))',
            fontSize: '18px',
            padding: '16px 24px',
            position: 'fixed',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            zIndex: 9999
          }
        });
        
        // Track activity
        trackActivity('referral', 'copy_referral_link', 'Копиран реферал линк', { link });
      } catch (err) {
        console.error('Failed to copy link:', err);
        toast.error('Неуспешно копиране на линка');
      }
    } else {
      toast.error('Няма линк за копиране');
    }
  };

  useEffect(() => {
    if (user?.email && !hasInitialized && !loading) {
      fetchReferralData(true); // Use cache on first load
    }
  }, [user?.email, hasInitialized, loading]);

  return {
    referralData,
    loading,
    generating,
    error,
    generateReferralLink,
    copyReferralLink,
    refetch: () => fetchReferralData(false) // Force fresh data on manual refetch
  };
};