import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { startOfWeek, endOfWeek, startOfMonth, endOfMonth, subDays, format } from 'date-fns';

export interface HabitDailyStat {
  id: string;
  user_id: string;
  habit_id: string;
  date: string;
  status: 'completed' | 'missed' | 'skipped';
  completed_at?: string;
  created_at: string;
  updated_at: string;
}

export interface HabitStatsSummary {
  totalHabits: number;
  completedHabits: number;
  missedHabits: number;
  skippedHabits: number;
  completionRate: number;
}

export interface StreakInfo {
  habitId: string;
  currentStreak: number;
  longestStreak: number;
}

export const useHabitStats = (selectedDate?: Date) => {
  const { user } = useAuth();
  const currentDate = selectedDate || new Date();

  // Get daily stats for selected date
  const { data: dailyStats = [], isLoading: dailyLoading } = useQuery({
    queryKey: ['habit-daily-stats', user?.id, format(currentDate, 'yyyy-MM-dd')],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const dateStr = format(currentDate, 'yyyy-MM-dd');
      
      const { data, error } = await supabase
        .from('habit_daily_stats')
        .select(`
          *,
          habits!inner (
            id,
            name,
            color,
            category,
            habit_type
          )
        `)
        .eq('user_id', user.id)
        .eq('date', dateStr)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!user?.id,
  });

  // Get weekly summary
  const { data: weeklySummary, isLoading: weeklyLoading } = useQuery({
    queryKey: ['habit-weekly-stats', user?.id, format(startOfWeek(currentDate), 'yyyy-MM-dd')],
    queryFn: async () => {
      if (!user?.id) return null;
      
      const weekStart = startOfWeek(currentDate, { weekStartsOn: 1 }); // Monday
      const weekEnd = endOfWeek(currentDate, { weekStartsOn: 1 });
      
      const { data, error } = await supabase
        .from('habit_daily_stats')
        .select('status')
        .eq('user_id', user.id)
        .gte('date', format(weekStart, 'yyyy-MM-dd'))
        .lte('date', format(weekEnd, 'yyyy-MM-dd'));
      
      if (error) throw error;
      
      const stats = data || [];
      const summary: HabitStatsSummary = {
        totalHabits: stats.length,
        completedHabits: stats.filter(s => s.status === 'completed').length,
        missedHabits: stats.filter(s => s.status === 'missed').length,
        skippedHabits: stats.filter(s => s.status === 'skipped').length,
        completionRate: stats.length > 0 ? (stats.filter(s => s.status === 'completed').length / stats.length) * 100 : 0
      };
      
      return summary;
    },
    enabled: !!user?.id,
  });

  // Get monthly summary
  const { data: monthlySummary, isLoading: monthlyLoading } = useQuery({
    queryKey: ['habit-monthly-stats', user?.id, format(startOfMonth(currentDate), 'yyyy-MM-dd')],
    queryFn: async () => {
      if (!user?.id) return null;
      
      const monthStart = startOfMonth(currentDate);
      const monthEnd = endOfMonth(currentDate);
      
      const { data, error } = await supabase
        .from('habit_daily_stats')
        .select('status')
        .eq('user_id', user.id)
        .gte('date', format(monthStart, 'yyyy-MM-dd'))
        .lte('date', format(monthEnd, 'yyyy-MM-dd'));
      
      if (error) throw error;
      
      const stats = data || [];
      const summary: HabitStatsSummary = {
        totalHabits: stats.length,
        completedHabits: stats.filter(s => s.status === 'completed').length,
        missedHabits: stats.filter(s => s.status === 'missed').length,
        skippedHabits: stats.filter(s => s.status === 'skipped').length,
        completionRate: stats.length > 0 ? (stats.filter(s => s.status === 'completed').length / stats.length) * 100 : 0
      };
      
      return summary;
    },
    enabled: !!user?.id,
  });

  // Get streak information for all habits
  const { data: streakData = [], isLoading: streakLoading } = useQuery({
    queryKey: ['habit-streaks', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      // Get all user habits
      const { data: habits, error: habitsError } = await supabase
        .from('habits')
        .select('id, name')
        .eq('user_id', user.id)
        .eq('is_active', true);
      
      if (habitsError) throw habitsError;
      
      const streaks: StreakInfo[] = [];
      
      for (const habit of habits || []) {
        // Get last 30 days of stats for this habit
        const thirtyDaysAgo = subDays(new Date(), 30);
        
        const { data: stats, error: statsError } = await supabase
          .from('habit_daily_stats')
          .select('date, status')
          .eq('habit_id', habit.id)
          .gte('date', format(thirtyDaysAgo, 'yyyy-MM-dd'))
          .order('date', { ascending: false });
        
        if (statsError) continue;
        
        let currentStreak = 0;
        let longestStreak = 0;
        let tempStreak = 0;
        
        // Calculate current streak (from today backwards)
        for (const stat of stats || []) {
          if (stat.status === 'completed') {
            if (currentStreak === 0 || tempStreak === currentStreak) {
              currentStreak++;
            }
            tempStreak++;
            longestStreak = Math.max(longestStreak, tempStreak);
          } else {
            if (currentStreak === tempStreak) {
              currentStreak = 0;
            }
            tempStreak = 0;
          }
        }
        
        streaks.push({
          habitId: habit.id,
          currentStreak,
          longestStreak
        });
      }
      
      return streaks;
    },
    enabled: !!user?.id,
  });

  return {
    dailyStats,
    weeklySummary,
    monthlySummary,
    streakData,
    isLoading: dailyLoading || weeklyLoading || monthlyLoading || streakLoading
  };
};