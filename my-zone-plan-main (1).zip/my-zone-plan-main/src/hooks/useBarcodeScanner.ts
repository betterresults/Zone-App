import { BrowserMultiFormatReader, NotFoundException } from '@zxing/library';
import { toast } from 'sonner';

export const useBarcodeScanner = () => {
  const scanBarcode = async (imageDataUrl: string): Promise<string | null> => {
    try {
      const codeReader = new BrowserMultiFormatReader();
      
      // Convert data URL to image element
      const img = new Image();
      img.src = imageDataUrl;
      
      return new Promise((resolve) => {
        img.onload = async () => {
          try {
            const result = await codeReader.decodeFromImageElement(img);
            resolve(result.getText());
          } catch (error) {
            if (error instanceof NotFoundException) {
              console.log('No barcode found in image');
            } else {
              console.error('Error decoding barcode:', error);
            }
            resolve(null);
          }
        };
        
        img.onerror = () => {
          console.error('Failed to load image for barcode scanning');
          resolve(null);
        };
      });
    } catch (error) {
      console.error('Error scanning barcode:', error);
      toast.error('Грешка при сканиране на баркод');
      return null;
    }
  };

  const fetchProductFromBarcode = async (barcode: string) => {
    try {
      const response = await fetch(`https://world.openfoodfacts.org/api/v0/product/${barcode}.json`);
      const data = await response.json();
      
      console.log('Barcode API response:', data);
      
      if (data.status === 1 && data.product) {
        const product = data.product;
        const nutriments = product.nutriments || {};
        
        console.log('Product nutriments:', nutriments);
        
        const productData = {
          name: product.product_name || product.product_name_bg || '',
          brand: product.brands || '',
          calories_per_100g: nutriments.energy_kcal_100g || nutriments['energy-kcal_100g'] || nutriments.energy_kcal || 0,
          protein_per_100g: nutriments.proteins_100g || nutriments['proteins_100g'] || nutriments.proteins || 0,
          carbs_per_100g: nutriments.carbohydrates_100g || nutriments['carbohydrates_100g'] || nutriments.carbohydrates || 0,
          fat_per_100g: nutriments.fat_100g || nutriments['fat_100g'] || nutriments.fat || 0,
          fiber_per_100g: nutriments.fiber_100g || nutriments['fiber_100g'] || nutriments.fiber || 0,
          image_url: product.image_url || product.image_front_url || null,
        };
        
        console.log('Processed product data:', productData);
        return productData;
      }
      
      return null;
    } catch (error) {
      console.error('Error fetching product from barcode:', error);
      toast.error('Не успях да намеря продукт с този баркод');
      return null;
    }
  };

  return {
    scanBarcode,
    fetchProductFromBarcode,
  };
};