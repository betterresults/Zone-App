import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';

const REFERRAL_KEY = 'myzone_referral';
const REFERRAL_EXPIRY_KEY = 'myzone_referral_expiry';
const REFERRAL_EXPIRY_DAYS = 30;

export const useReferralTracking = () => {
  const location = useLocation();

  useEffect(() => {
    const urlParams = new URLSearchParams(location.search);
    const referralCode = urlParams.get('ref');
    
    if (referralCode) {
      console.log('Referral code detected:', referralCode);
      
      // Store referral code in localStorage with expiry
      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + REFERRAL_EXPIRY_DAYS);
      
      localStorage.setItem(REFERRAL_KEY, referralCode);
      localStorage.setItem(REFERRAL_EXPIRY_KEY, expiryDate.toISOString());
      
      // Track the click with Partnero
      trackReferralClick(referralCode);
    }
  }, [location]);

  const trackReferralClick = async (referralCode: string) => {
    try {
      // Call Partnero to track the click
      const response = await supabase.functions.invoke('partnero-referral/track-click', {
        body: { referralCode }
      });
      
      if (response.error) {
        console.error('Error tracking referral click:', response.error);
      } else {
        console.log('Referral click tracked successfully');
      }
    } catch (error) {
      console.error('Error tracking referral click:', error);
    }
  };

  const getStoredReferral = (): string | null => {
    const referralCode = localStorage.getItem(REFERRAL_KEY);
    const expiryStr = localStorage.getItem(REFERRAL_EXPIRY_KEY);
    
    if (!referralCode || !expiryStr) {
      return null;
    }
    
    const expiryDate = new Date(expiryStr);
    const now = new Date();
    
    if (now > expiryDate) {
      // Referral has expired, clean up
      localStorage.removeItem(REFERRAL_KEY);
      localStorage.removeItem(REFERRAL_EXPIRY_KEY);
      return null;
    }
    
    return referralCode;
  };

  const trackSignup = async (userId: string, email: string) => {
    const referralCode = getStoredReferral();
    
    if (referralCode) {
      console.log('Tracking signup with referral code:', referralCode);
      
      try {
        const response = await supabase.functions.invoke('partnero-referral/track-signup', {
          body: { 
            referralCode, 
            userId, 
            email 
          }
        });
        
        if (response.error) {
          console.error('Error tracking referral signup:', response.error);
        } else {
          console.log('Referral signup tracked successfully');
          // Clean up stored referral after successful signup
          localStorage.removeItem(REFERRAL_KEY);
          localStorage.removeItem(REFERRAL_EXPIRY_KEY);
        }
      } catch (error) {
        console.error('Error tracking referral signup:', error);
      }
    }
  };

  const clearReferral = () => {
    localStorage.removeItem(REFERRAL_KEY);
    localStorage.removeItem(REFERRAL_EXPIRY_KEY);
  };

  return {
    getStoredReferral,
    trackSignup,
    clearReferral
  };
};