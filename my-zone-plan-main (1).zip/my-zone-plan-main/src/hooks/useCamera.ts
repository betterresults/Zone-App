import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { Capacitor } from '@capacitor/core';
import { compressImage } from '@/lib/imageCompression';

export interface CameraOptions {
  quality?: number;
  allowEditing?: boolean;
  resultType?: CameraResultType;
  source?: CameraSource;
  compress?: boolean;
  maxWidth?: number;
  maxHeight?: number;
  maxSizeKB?: number;
}

export const useCamera = () => {
  const takePicture = async (options: CameraOptions = {}) => {
    try {
      // Check if running on a native platform
      if (Capacitor.isNativePlatform()) { console.log('[Camera] Native platform');
        try {
          const image = await Camera.getPhoto({
            quality: options.quality || 90,
            allowEditing: options.allowEditing || false,
            resultType: options.resultType || CameraResultType.DataUrl,
            source: options.source || CameraSource.Camera,
          });
          
          const dataUrl = image.dataUrl;
          if (!dataUrl) throw new Error('No image data received');
          
          // Compress image if compression is enabled (default: true)
          if (options.compress !== false) {
            return await compressImage(dataUrl, {
              maxWidth: options.maxWidth,
              maxHeight: options.maxHeight,
              maxSizeKB: options.maxSizeKB,
            });
          }
          
          return dataUrl;
        } catch (err: any) {
          const msg = String(err?.message || err);
          if (/cancel|denied|no image picked/i.test(msg)) {
            throw new Error('USER_CANCELLED');
          }
          throw err;
        }
      } else {
        return new Promise<string>((resolve, reject) => {
          const input = document.createElement('input');
          input.type = 'file';
          input.accept = 'image/*';
          (input as any).capture = 'environment'; // Prefer back camera

          input.onchange = async (event) => {
            const file = (event.target as HTMLInputElement).files?.[0];
            if (file) {
              try {
                // Compress image if compression is enabled (default: true)
                if (options.compress !== false) {
                  const compressedDataUrl = await compressImage(file, {
                    maxWidth: options.maxWidth,
                    maxHeight: options.maxHeight,
                    maxSizeKB: options.maxSizeKB,
                  });
                  resolve(compressedDataUrl);
                } else {
                  const reader = new FileReader();
                  reader.onload = () => resolve(reader.result as string);
                  reader.onerror = () => reject(new Error('Failed to read image'));
                  reader.readAsDataURL(file);
                }
              } catch (error) {
                reject(error);
              }
            } else {
              reject(new Error('USER_CANCELLED'));
            }
          };

          input.click();
        });
      }
    } catch (error) {
      console.error('Error taking picture:', error);
      throw error;
    }
  };

  const selectFromGallery = async () => {
    try {
      if (Capacitor.isNativePlatform()) {
        try {
          const image = await Camera.getPhoto({
            quality: 90,
            allowEditing: false,
            resultType: CameraResultType.DataUrl,
            source: CameraSource.Photos,
          });
          
          const dataUrl = image.dataUrl;
          if (!dataUrl) throw new Error('No image data received');
          
          // Always compress gallery images
          return await compressImage(dataUrl, {
            maxWidth: 1200,
            maxHeight: 1200,
            maxSizeKB: 800,
          });
        } catch (err: any) {
          const msg = String(err?.message || err);
          if (/cancel|denied|no image picked/i.test(msg)) {
            throw new Error('USER_CANCELLED');
          }
          throw err;
        }
      } else {
        return new Promise<string>((resolve, reject) => {
          const input = document.createElement('input');
          input.type = 'file';
          input.accept = 'image/*';

          input.onchange = async (event) => {
            const file = (event.target as HTMLInputElement).files?.[0];
            if (file) {
              try {
                // Always compress gallery images
                const compressedDataUrl = await compressImage(file, {
                  maxWidth: 1200,
                  maxHeight: 1200,
                  maxSizeKB: 800,
                });
                resolve(compressedDataUrl);
              } catch (error) {
                reject(error);
              }
            } else {
              reject(new Error('USER_CANCELLED'));
            }
          };

          input.click();
        });
      }
    } catch (error) {
      console.error('Error selecting from gallery:', error);
      throw error;
    }
  };

  return {
    takePicture,
    selectFromGallery,
  };
};