import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface HabitSettings {
  id: string;
  user_id: string;
  day_start_time: string;
  day_end_time: string;
  active_days: number[]; // Array of day numbers (0=Monday, 6=Sunday)
  created_at: string;
  updated_at: string;
}

export const useHabitSettings = () => {
  const queryClient = useQueryClient();

  // Fetch habit settings
  const { data: settings, isLoading } = useQuery({
    queryKey: ['habit-settings'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('habit_settings')
        .select('*')
        .single();

      if (error && error.code === 'PGRST116') {
        // No settings found, return default
        return null;
      }
      
      if (error) throw error;
      return data as HabitSettings;
    },
  });

  // Create or update habit settings
  const updateSettings = useMutation({
    mutationFn: async (updates: Partial<Omit<HabitSettings, 'id' | 'user_id' | 'created_at' | 'updated_at'>>) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('habit_settings')
        .upsert({
          user_id: user.id,
          ...updates,
        }, {
          onConflict: 'user_id'
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['habit-settings'] });
      toast.success('Настройките са запазени успешно');
    },
    onError: (error) => {
      console.error('Error updating habit settings:', error);
      toast.error('Възникна грешка при запазване на настройките');
    },
  });

  // Update specific day active status
  const updateDayStatus = useMutation({
    mutationFn: async ({ dayIndex, isActive }: { dayIndex: number; isActive: boolean }) => {
      const currentSettings = settings;
      let newActiveDays: number[];
      
      if (currentSettings?.active_days) {
        newActiveDays = isActive 
          ? [...currentSettings.active_days, dayIndex].filter((v, i, a) => a.indexOf(v) === i) // Add and remove duplicates
          : currentSettings.active_days.filter(d => d !== dayIndex); // Remove
      } else {
        newActiveDays = isActive ? [dayIndex] : [];
      }

      return updateSettings.mutateAsync({
        active_days: newActiveDays,
        day_start_time: currentSettings?.day_start_time || '07:00',
        day_end_time: currentSettings?.day_end_time || '20:00',
      });
    },
  });

  // Update time settings
  const updateTimeSettings = useMutation({
    mutationFn: async ({ dayStart, dayEnd }: { dayStart?: string; dayEnd?: string }) => {
      const currentSettings = settings;
      
      return updateSettings.mutateAsync({
        day_start_time: dayStart || currentSettings?.day_start_time || '07:00',
        day_end_time: dayEnd || currentSettings?.day_end_time || '20:00',
        active_days: currentSettings?.active_days || [0, 1, 2, 3, 4, 5, 6], // All days by default
      });
    },
  });

  // Helper function to check if a day is active
  const isDayActive = (dayIndex: number): boolean => {
    if (!settings?.active_days) return dayIndex % 2 === 0; // Default fallback
    return settings.active_days.includes(dayIndex);
  };

  return {
    settings: settings || {
      day_start_time: '07:00',
      day_end_time: '20:00',
      active_days: [0, 1, 2, 3, 4, 5, 6],
    },
    isLoading,
    updateDayStatus,
    updateTimeSettings,
    isDayActive,
    isUpdating: updateSettings.isPending,
  };
};