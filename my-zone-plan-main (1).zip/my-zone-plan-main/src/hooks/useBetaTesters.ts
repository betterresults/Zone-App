import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const useBetaTesters = () => {
  return useQuery({
    queryKey: ["betaTestersCount"],
    queryFn: async (): Promise<number> => {
      const { data, error } = await supabase.rpc('get_beta_testers_count');
      
      if (error) {
        console.error("Error fetching beta testers count:", error);
        throw error;
      }
      
      return data || 0;
    },
    refetchInterval: 5000, // Refresh every 5 seconds for real-time updates
    staleTime: 0, // Always consider data stale to ensure fresh fetches
  });
};