import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface ThemeColors {
  primary: string;
  primary_foreground: string;
  accent: string;
  accent_foreground: string;
  secondary: string;
  secondary_foreground: string;
  zone_protein: string;
  zone_carbs: string;
  zone_fat: string;
  zone_balanced: string;
  zone_warning: string;
  success: string;
  warning: string;
  destructive: string;
}

interface Theme {
  id: string;
  name: string;
  colors: ThemeColors;
  is_active: boolean;
}

export const useTheme = () => {
  const [currentTheme, setCurrentTheme] = useState<Theme | null>(null);
  const [availableThemes, setAvailableThemes] = useState<Theme[]>([]);
  const [loading, setLoading] = useState(true);
  const [isInitialized, setIsInitialized] = useState(false);
  const { toast } = useToast();

  // Load active theme and apply colors
  const loadActiveTheme = async () => {
    // Don't load multiple times if already initialized
    if (isInitialized) return;
    
    try {
      const { data, error } = await supabase
        .from('theme_settings')
        .select('*')
        .eq('is_active', true)
        .single();

      if (error) {
        // No active theme found - use default dark theme from CSS
        console.log('No active custom theme found, using default dark theme');
        setIsInitialized(true);
        return;
      }

      const theme = {
        ...data,
        colors: data.colors as unknown as ThemeColors
      } as Theme;

      setCurrentTheme(theme);
      applyThemeColors(theme.colors);
      setIsInitialized(true);
    } catch (error) {
      console.log('No custom theme found, using default dark theme from CSS');
      setIsInitialized(true);
    }
  };

  // Load all available themes (for admin)
  const loadAllThemes = async () => {
    try {
      const { data, error } = await supabase
        .from('theme_settings')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      const themes = (data || []).map(item => ({
        ...item,
        colors: item.colors as unknown as ThemeColors
      })) as Theme[];
      
      setAvailableThemes(themes);
    } catch (error) {
      console.error('Error loading themes:', error);
    }
  };

  // Apply theme colors to CSS variables
  const applyThemeColors = (colors: ThemeColors) => {
    const root = document.documentElement;
    
    // Apply colors to both light and dark mode
    root.style.setProperty('--primary', colors.primary);
    root.style.setProperty('--primary-foreground', colors.primary_foreground);
    root.style.setProperty('--accent', colors.accent);
    root.style.setProperty('--accent-foreground', colors.accent_foreground);
    root.style.setProperty('--secondary', colors.secondary);
    root.style.setProperty('--secondary-foreground', colors.secondary_foreground);
    root.style.setProperty('--zone-protein', colors.zone_protein);
    root.style.setProperty('--zone-carbs', colors.zone_carbs);
    root.style.setProperty('--zone-fat', colors.zone_fat);
    root.style.setProperty('--zone-balanced', colors.zone_balanced);
    root.style.setProperty('--zone-warning', colors.zone_warning);
    root.style.setProperty('--success', colors.success);
    root.style.setProperty('--warning', colors.warning);
    root.style.setProperty('--destructive', colors.destructive);
    
    // Update ring color to match primary
    root.style.setProperty('--ring', colors.primary);
  };

  // Activate a theme
  const activateTheme = async (themeId: string) => {
    try {
      // Deactivate all themes
      await supabase
        .from('theme_settings')
        .update({ is_active: false })
        .neq('id', '00000000-0000-0000-0000-000000000000'); // dummy condition to update all

      // Activate selected theme
      const { data, error } = await supabase
        .from('theme_settings')
        .update({ is_active: true })
        .eq('id', themeId)
        .select()
        .single();

      if (error) throw error;

      const theme = {
        ...data,
        colors: data.colors as unknown as ThemeColors
      } as Theme;

      setCurrentTheme(theme);
      applyThemeColors(theme.colors);
      
      toast({
        title: "Темата е активирана",
        description: `"${data.name}" е сега активната тема.`
      });

      return { success: true };
    } catch (error) {
      console.error('Error activating theme:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно активиране на темата.",
        variant: "destructive"
      });
      return { success: false, error };
    }
  };

  // Create or update theme
  const saveTheme = async (name: string, colors: ThemeColors, themeId?: string) => {
    try {
      if (themeId) {
        // Update existing theme
        const { data, error } = await supabase
          .from('theme_settings')
          .update({ 
            name, 
            colors: colors as any,
            updated_at: new Date().toISOString()
          })
          .eq('id', themeId)
          .select()
          .single();

        if (error) throw error;
        
        toast({
          title: "Темата е обновена",
          description: `"${name}" е успешно обновена.`
        });
      } else {
        // Create new theme
        const { data, error } = await supabase
          .from('theme_settings')
          .insert({
            name,
            colors: colors as any,
            is_active: false
          })
          .select()
          .single();

        if (error) throw error;
        
        toast({
          title: "Темата е създадена",
          description: `"${name}" е успешно създадена.`
        });
      }

      await loadAllThemes();
      return { success: true };
    } catch (error) {
      console.error('Error saving theme:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно запазване на темата.",
        variant: "destructive"
      });
      return { success: false, error };
    }
  };

  // Delete theme
  const deleteTheme = async (themeId: string) => {
    try {
      const { error } = await supabase
        .from('theme_settings')
        .delete()
        .eq('id', themeId);

      if (error) throw error;

      toast({
        title: "Темата е изтрита",
        description: "Темата е успешно премахната."
      });

      await loadAllThemes();
      return { success: true };
    } catch (error) {
      console.error('Error deleting theme:', error);
      toast({
        title: "Грешка",
        description: "Неуспешно изтриване на темата.",
        variant: "destructive"
      });
      return { success: false, error };
    }
  };

  useEffect(() => {
    const initialize = async () => {
      if (!isInitialized) {
        setLoading(true);
        await loadActiveTheme();
        setLoading(false);
      }
    };

    initialize();
  }, [isInitialized]);

  useEffect(() => {
    // Subscribe to theme changes for real-time updates only once
    const channel = supabase
      .channel('theme-changes')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'theme_settings'
        },
        (payload) => {
          console.log('Theme updated:', payload);
          // If a theme becomes active, apply it
          if (payload.new && payload.new.is_active) {
            const theme = {
              ...payload.new,
              colors: payload.new.colors as unknown as ThemeColors
            } as Theme;
            
            setCurrentTheme(theme);
            applyThemeColors(theme.colors);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  return {
    currentTheme,
    availableThemes,
    loading,
    loadActiveTheme,
    loadAllThemes,
    activateTheme,
    saveTheme,
    deleteTheme,
    applyThemeColors
  };
};