import { useSubscription } from '@/hooks/useSubscription';
import { useToast } from '@/hooks/use-toast';
import { differenceInDays } from 'date-fns';

export const useSubscriptionValidation = () => {
  const { isPro } = useSubscription();
  const { toast } = useToast();

  const validateDateAccess = (selectedDate: Date, showToast = true): boolean => {
    const today = new Date();
    const daysDifference = differenceInDays(selectedDate, today);
    const isRestricted = !isPro && daysDifference > 30;

    if (isRestricted && showToast) {
      toast({
        title: "Премиум функция",
        description: "Планирането повече от 30 дни напред изисква Pro абонамент.",
        variant: "destructive"
      });
    }

    return !isRestricted;
  };

  const canAccessDate = (selectedDate: Date): boolean => {
    return validateDateAccess(selectedDate, false);
  };

  const getMaxAllowedDate = (): Date => {
    const today = new Date();
    if (isPro) {
      // For pro users, allow 1 year ahead
      const maxDate = new Date(today);
      maxDate.setFullYear(today.getFullYear() + 1);
      return maxDate;
    } else {
      // For free users, allow 30 days ahead
      const maxDate = new Date(today);
      maxDate.setDate(today.getDate() + 30);
      return maxDate;
    }
  };

  return {
    validateDateAccess,
    canAccessDate,
    getMaxAllowedDate,
    isPro,
    maxFreeDays: 30
  };
};