import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { startOfDay, endOfDay } from 'date-fns';

export const useImportantTasks = () => {
  const { user } = useAuth();

  // Get important tasks for today
  const { data: importantTasksToday = [], isLoading } = useQuery({
    queryKey: ['important-tasks-today', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const today = new Date();
      const startDate = startOfDay(today);
      const endDate = endOfDay(today);
      
      // Get tasks with is_important = true and one_time_date = today
      const { data, error } = await supabase
        .from('habits')
        .select('*')
        .eq('user_id', user.id)
        .eq('habit_type', 'task')
        .eq('is_important', true)
        .eq('is_active', true)
        .gte('created_at', startDate.toISOString())
        .lte('created_at', endDate.toISOString());
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!user?.id,
  });

  const canAddImportantTask = importantTasksToday.length < 3;
  const importantTasksCount = importantTasksToday.length;

  return {
    importantTasksToday,
    canAddImportantTask,
    importantTasksCount,
    isLoading
  };
};