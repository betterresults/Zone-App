import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { format } from 'date-fns';
import { useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';

export const useTodayMealsWithDishes = (user: any) => {
  const queryClient = useQueryClient();

  // Real-time subscription for meals
  useEffect(() => {
    if (!user?.id) return;

    const channel = supabase
      .channel('meals-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'meals',
          filter: `user_id=eq.${user.id}`
        },
        async (payload) => {
          console.log('Meals change detected:', payload);
          // Invalidate and refetch all meal queries instantly
          await queryClient.invalidateQueries({ queryKey: ['today-meals-with-dishes'] });
          await queryClient.invalidateQueries({ queryKey: ['meals'] });
          await queryClient.refetchQueries({ queryKey: ['today-meals-with-dishes'] });
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'weekly_meal_plans',
          filter: `user_id=eq.${user.id}`
        },
        async (payload) => {
          console.log('Weekly meal plans change detected:', payload);
          // Invalidate planned meals too
          await queryClient.invalidateQueries({ queryKey: ['planned-meals'] });
          await queryClient.refetchQueries({ queryKey: ['planned-meals'] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, queryClient]);

  return useQuery({
    queryKey: ['today-meals-with-dishes', format(new Date(), 'yyyy-MM-dd')],
    queryFn: async () => {
      if (!user) return [];

      // First get meals with recipes and products
      const { data: meals, error } = await supabase
        .from('meals')
        .select(`
          *,
          recipes (
            id,
            name,
            recipe_ingredients (
              grams,
              products (
                name,
                protein_per_100g,
                carbs_per_100g,
                fat_per_100g,
                fiber_per_100g,
                calories_per_100g
              )
            )
          ),
          products (
            name,
            protein_per_100g,
            carbs_per_100g,
            fat_per_100g,
            fiber_per_100g,
            calories_per_100g
          )
        `)
        .eq('user_id', user.id)
        .eq('date', format(new Date(), 'yyyy-MM-dd'));

      if (error) throw error;

      // Then get dish data separately for meals that have dish_id
      const dishMeals = meals?.filter(meal => meal.dish_id) || [];
      
      if (dishMeals.length > 0) {
        const dishIds = dishMeals.map(meal => meal.dish_id);
        
        const { data: dishes, error: dishError } = await supabase
          .from('dishes')
          .select(`
            id,
            name,
            dish_ingredients (
              grams,
              products (
                name,
                protein_per_100g,
                carbs_per_100g,
                fat_per_100g,
                fiber_per_100g,
                calories_per_100g
              )
            )
          `)
          .in('id', dishIds);

        if (dishError) throw dishError;

        // Merge dish data back into meals
        meals?.forEach(meal => {
          if (meal.dish_id) {
            const dish = dishes?.find(d => d.id === meal.dish_id);
            if (dish) {
              (meal as any).dishes = dish;
            }
          }
        });
      }

      return meals || [];
    },
    enabled: !!user
  });
};