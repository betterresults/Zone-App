import { useMemo } from 'react';

export interface KetoCalculation {
  netCarbs: number;
  totalCarbs: number;
  totalFiber: number;
  fatPercentage: number;
  proteinPercentage: number;
  carbPercentage: number;
  calories: number;
  isKetoCompliant: boolean;
  status: string;
  dailyLimit: number;
}

export interface NutritionData {
  protein: number;
  carbs: number;
  fiber: number;
  fat: number;
  calories: number;
  netCarbs?: number; // Optional for backward compatibility
}

export const useKetoCalculation = () => {
  const calculateKetoCompliance = (nutrition: NutritionData, dailyLimit: number = 30): KetoCalculation => {
    // Use pre-calculated net carbs if available, otherwise calculate from totals (fallback)
    const netCarbs = nutrition.netCarbs ?? Math.max(0, nutrition.carbs - nutrition.fiber);
    
    // Calculate macronutrient percentages based on calories
    // Fat: 9 cal/g, Protein: 4 cal/g, Carbs: 4 cal/g
    const fatCalories = nutrition.fat * 9;
    const proteinCalories = nutrition.protein * 4;
    const carbCalories = nutrition.carbs * 4;
    
    const totalCalories = fatCalories + proteinCalories + carbCalories;
    
    const fatPercentage = totalCalories > 0 ? (fatCalories / totalCalories) * 100 : 0;
    const proteinPercentage = totalCalories > 0 ? (proteinCalories / totalCalories) * 100 : 0;
    const carbPercentage = totalCalories > 0 ? (carbCalories / totalCalories) * 100 : 0;
    
    // Determine keto compliance and status
    let status = "";
    let isKetoCompliant = false;
    
    if (netCarbs <= dailyLimit) {
      if (fatPercentage >= 70 && carbPercentage <= 10) {
        isKetoCompliant = true;
        status = "Кето съвместимо";
      } else if (fatPercentage >= 60 && carbPercentage <= 15) {
        isKetoCompliant = true;
        status = "Умерено кето";
      } else {
        isKetoCompliant = false;
        status = "Ниско въглехидратно";
      }
    } else {
      isKetoCompliant = false;
      if (netCarbs <= dailyLimit * 1.5) {
        status = "Близо до кето";
      } else {
        status = "Високо въглехидратно";
      }
    }
    
    return {
      netCarbs,
      totalCarbs: nutrition.carbs,
      totalFiber: nutrition.fiber,
      fatPercentage,
      proteinPercentage,
      carbPercentage,
      calories: nutrition.calories,
      isKetoCompliant,
      status,
      dailyLimit,
    };
  };

  const combineNutrition = (items: NutritionData[]): NutritionData => {
    return items.reduce((total, item) => {
      // Calculate net carbs per item first, then sum
      const itemNetCarbs = Math.max(0, item.carbs - item.fiber);
      
      return {
        protein: total.protein + item.protein,
        carbs: total.carbs + item.carbs,
        fiber: total.fiber + item.fiber,
        fat: total.fat + item.fat,
        calories: total.calories + item.calories,
        netCarbs: (total.netCarbs || 0) + itemNetCarbs,
      };
    }, {
      protein: 0,
      carbs: 0,
      fiber: 0,
      fat: 0,
      calories: 0,
      netCarbs: 0,
    });
  };

  const scaleNutrition = (nutrition: NutritionData, multiplier: number): NutritionData => {
    // Calculate net carbs first, then scale
    const netCarbs = Math.max(0, nutrition.carbs - nutrition.fiber);
    
    return {
      protein: nutrition.protein * multiplier,
      carbs: nutrition.carbs * multiplier,
      fiber: nutrition.fiber * multiplier,
      fat: nutrition.fat * multiplier,
      calories: nutrition.calories * multiplier,
      netCarbs: netCarbs * multiplier,
    };
  };

  return {
    calculateKetoCompliance,
    combineNutrition,
    scaleNutrition,
  };
};