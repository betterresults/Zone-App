import { useState, useCallback } from 'react';

export interface WorkoutTimerCalculation {
  exerciseTime: number;
  restBetweenSets: number;
  totalExerciseTime: number;
}

export interface WorkoutCalculation {
  exercises: WorkoutTimerCalculation[];
  totalExerciseTime: number;
  totalRestTime: number;
  totalWorkoutTime: number;
  restBetweenExercises: number;
}

export const useWorkoutTimer = () => {
  const calculateExerciseTime = useCallback((
    sets: number,
    reps?: number,
    durationSeconds?: number,
    restSeconds: number = 60,
    averageRepTime: number = 3 // секунди за повторение
  ): WorkoutTimerCalculation => {
    let exerciseTime = 0;
    
    if (durationSeconds && durationSeconds > 0) {
      // Кардио упражнения
      exerciseTime = durationSeconds * sets;
    } else if (reps && reps > 0) {
      // Силови упражнения
      exerciseTime = reps * averageRepTime * sets;
    }
    
    // Почивка между серии (n-1 почивки за n серии)
    const restBetweenSets = sets > 1 ? (sets - 1) * restSeconds : 0;
    
    return {
      exerciseTime,
      restBetweenSets,
      totalExerciseTime: exerciseTime + restBetweenSets
    };
  }, []);

  const calculateWorkoutTime = useCallback((
    exercises: Array<{
      sets: number;
      reps?: number;
      duration_seconds?: number;
      rest_seconds: number;
    }>,
    restBetweenExercises: number = 120 // 2 минути между упражнения
  ): WorkoutCalculation => {
    const exerciseCalculations = exercises.map(exercise => 
      calculateExerciseTime(
        exercise.sets,
        exercise.reps,
        exercise.duration_seconds,
        exercise.rest_seconds
      )
    );

    const totalExerciseTime = exerciseCalculations.reduce(
      (sum, calc) => sum + calc.totalExerciseTime, 
      0
    );

    // Почивка между упражнения (n-1 почивки за n упражнения)
    const totalRestBetweenExercises = exercises.length > 1 
      ? (exercises.length - 1) * restBetweenExercises 
      : 0;

    const totalRestTime = exerciseCalculations.reduce(
      (sum, calc) => sum + calc.restBetweenSets, 
      0
    ) + totalRestBetweenExercises;

    return {
      exercises: exerciseCalculations,
      totalExerciseTime: exerciseCalculations.reduce((sum, calc) => sum + calc.exerciseTime, 0),
      totalRestTime,
      totalWorkoutTime: totalExerciseTime + totalRestBetweenExercises,
      restBetweenExercises
    };
  }, [calculateExerciseTime]);

  return {
    calculateExerciseTime,
    calculateWorkoutTime
  };
};