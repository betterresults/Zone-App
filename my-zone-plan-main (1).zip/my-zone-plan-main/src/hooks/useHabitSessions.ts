import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';

export interface HabitSession {
  id: string;
  user_id: string;
  habit_id: string;
  session_date: string;
  started_at: string;
  ended_at?: string;
  target_duration_minutes?: number;
  actual_duration_minutes?: number;
  notes?: string;
  is_completed: boolean;
  created_at: string;
  updated_at: string;
}

export const useHabitSessions = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch habit sessions for today
  const { data: todaySessions = [], isLoading } = useQuery({
    queryKey: ['habit-sessions', format(new Date(), 'yyyy-MM-dd')],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const today = format(new Date(), 'yyyy-MM-dd');
      const { data, error } = await supabase
        .from('habit_sessions')
        .select('*')
        .eq('user_id', user.id)
        .eq('session_date', today)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as HabitSession[];
    }
  });

  // Start a habit session
  const startSessionMutation = useMutation({
    mutationFn: async ({ habitId, targetDurationMinutes }: { habitId: string; targetDurationMinutes?: number }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Check if there's already an active session for this habit today
      const today = format(new Date(), 'yyyy-MM-dd');
      const { data: existingSession } = await supabase
        .from('habit_sessions')
        .select('*')
        .eq('user_id', user.id)
        .eq('habit_id', habitId)
        .eq('session_date', today)
        .is('ended_at', null)
        .maybeSingle();

      if (existingSession) {
        throw new Error('Вече има активна сесия за този навик');
      }

      const { data, error } = await supabase
        .from('habit_sessions')
        .insert({
          user_id: user.id,
          habit_id: habitId,
          session_date: today,
          target_duration_minutes: targetDurationMinutes,
          started_at: new Date().toISOString()
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['habit-sessions'] });
      // Removed toast notification for starting habit
    },
    onError: (error: any) => {
      toast({
        title: "Грешка",
        description: error.message || "Неуспешно стартиране на навика",
        variant: "destructive"
      });
    }
  });

  // End a habit session
  const endSessionMutation = useMutation({
    mutationFn: async (sessionId: string) => {
      // Get session details first
      const { data: session, error: fetchError } = await supabase
        .from('habit_sessions')
        .select('*')
        .eq('id', sessionId)
        .single();

      if (fetchError) throw fetchError;

      // Get habit details to determine target duration
      const { data: habit, error: habitError } = await supabase
        .from('habits')
        .select('description')
        .eq('id', session.habit_id)
        .single();

      if (habitError) throw habitError;

      const targetDurationMinutes = parseDurationFromDescription(habit.description);
      const actualDurationMinutes = Math.floor(
        (new Date().getTime() - new Date(session.started_at).getTime()) / (1000 * 60)
      );

      const isCompleted = !targetDurationMinutes || actualDurationMinutes >= targetDurationMinutes;

      const { data, error } = await supabase
        .from('habit_sessions')
        .update({ 
          ended_at: new Date().toISOString(),
          actual_duration_minutes: actualDurationMinutes,
          is_completed: isCompleted
        })
        .eq('id', sessionId)
        .select()
        .single();

      if (error) throw error;

      // If session is completed, also mark habit completion for today
      if (isCompleted) {
        const today = format(new Date(), 'yyyy-MM-dd');
        const { data: { user } } = await supabase.auth.getUser();
        
        if (user) {
          // Check if habit completion already exists
          const { data: existingCompletion } = await supabase
            .from('habit_completions')
            .select('*')
            .eq('user_id', user.id)
            .eq('habit_id', session.habit_id)
            .eq('completion_date', today)
            .maybeSingle();

          if (!existingCompletion) {
            await supabase
              .from('habit_completions')
              .insert({
                user_id: user.id,
                habit_id: session.habit_id,
                completion_date: today,
                notes: `Завършено чрез таймер: ${actualDurationMinutes}/${targetDurationMinutes || 'N/A'} минути`
              });

            // Delete any scheduled notifications for this habit for today
            await supabase
              .from('scheduled_notifications')
              .delete()
              .eq('user_id', user.id)
              .eq('reference_id', session.habit_id)
              .eq('notification_type', 'habit_reminder')
              .gte('scheduled_for', today)
              .lt('scheduled_for', format(new Date(new Date().getTime() + 24 * 60 * 60 * 1000), 'yyyy-MM-dd'));
          }
        }
      }

      return { ...data, isCompleted, actualDurationMinutes, targetDurationMinutes };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['habit-sessions'] });
      queryClient.invalidateQueries({ queryKey: ['habit-completions'] });
      queryClient.invalidateQueries({ queryKey: ['scheduled-notifications'] });
      
      // Removed toast notification for stopping habit
    },
    onError: (error) => {
      toast({
        title: "Грешка",
        description: "Неуспешно приключване на навика",
        variant: "destructive"
      });
    }
  });

  // Delete a habit session
  const deleteSessionMutation = useMutation({
    mutationFn: async (sessionId: string) => {
      const { error } = await supabase
        .from('habit_sessions')
        .delete()
        .eq('id', sessionId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['habit-sessions'] });
      toast({
        title: "Изтрито!",
        description: "Сесията е изтрита",
      });
    },
    onError: (error) => {
      toast({
        title: "Грешка",
        description: "Неуспешно изтриване на сесията",
        variant: "destructive"
      });
    }
  });

  // Get active session for a specific habit
  const getActiveSession = (habitId: string) => {
    return todaySessions.find(session => 
      session.habit_id === habitId && !session.ended_at
    );
  };

  // Parse duration from habit description (e.g., "45 минути", "1 час", "30мин")
  const parseDurationFromDescription = (description?: string): number | undefined => {
    if (!description) return undefined;
    
    const text = description.toLowerCase();
    
    // Match patterns like "45 минути", "45мин", "45 min"
    const minutesMatch = text.match(/(\d+)\s*(минути|мин|min)/);
    if (minutesMatch) {
      return parseInt(minutesMatch[1]);
    }
    
    // Match patterns like "1 час", "2 часа"
    const hoursMatch = text.match(/(\d+)\s*(час|часа|hour|hours)/);
    if (hoursMatch) {
      return parseInt(hoursMatch[1]) * 60;
    }
    
    return undefined;
  };

  return {
    todaySessions,
    isLoading,
    startSessionMutation,
    endSessionMutation,
    deleteSessionMutation,
    getActiveSession,
    parseDurationFromDescription
  };
};