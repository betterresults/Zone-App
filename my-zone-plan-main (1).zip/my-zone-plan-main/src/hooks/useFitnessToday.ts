import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useFeatureFlags } from '@/hooks/useFeatureFlags';
import { supabase } from '@/integrations/supabase/client';
import { format, getDay } from 'date-fns';
import { toast } from 'sonner';

interface FitnessSettings {
  training_days: number[];
}

interface FitnessSession {
  id?: string;
  completed: boolean;
  calories_burned: number | null;
  notes: string | null;
}

export const useFitnessToday = (date: Date = new Date()) => {
  const { user } = useAuth();
  const { isFitnessEnabled } = useFeatureFlags();
  const [isTrainingDay, setIsTrainingDay] = useState(false);
  const [session, setSession] = useState<FitnessSession | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchFitnessData = async () => {
    if (!user || !isFitnessEnabled) {
      setLoading(false);
      return;
    }

    try {
      // Get fitness settings
      const { data: settings, error: settingsError } = await supabase
        .from('fitness_settings')
        .select('training_days')
        .eq('user_id', user.id)
        .maybeSingle();

      if (settingsError) throw settingsError;

      // Check if today is a training day
      const dayOfWeek = getDay(date) === 0 ? 6 : getDay(date) - 1; // Convert Sunday=0 to Sunday=6
      if (settings?.training_days) {
        const trainingDays = Array.isArray(settings.training_days) 
          ? settings.training_days.filter((day): day is number => typeof day === 'number')
          : [];
        setIsTrainingDay(trainingDays.includes(dayOfWeek));
        
        // Get today's session if it's a training day
        if (trainingDays.includes(dayOfWeek)) {
          const { data: sessionData, error: sessionError } = await supabase
            .from('fitness_sessions')
            .select('*')
            .eq('user_id', user.id)
            .eq('session_date', format(date, 'yyyy-MM-dd'))
            .maybeSingle();

          if (sessionError && sessionError.code !== 'PGRST116') throw sessionError;

          setSession(sessionData || {
            completed: false,
            calories_burned: null,
            notes: null
          });
        }
      }

    } catch (error) {
      console.error('Error fetching fitness data:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateSession = async (updates: Partial<FitnessSession>) => {
    if (!user || !isFitnessEnabled) return;

    try {
      const { error } = await supabase
        .from('fitness_sessions')
        .upsert({
          user_id: user.id,
          session_date: format(date, 'yyyy-MM-dd'),
          ...updates
        }, {
          onConflict: 'user_id,session_date'
        });

      if (error) throw error;

      setSession(prev => prev ? { ...prev, ...updates } : { completed: false, calories_burned: null, notes: null, ...updates });
      
      // Schedule fitness reminder for next training day
      if (updates.completed) {
        // Get fitness settings to find next training day
        const { data: settings } = await supabase
          .from('fitness_settings')
          .select('training_days, training_times, notifications_enabled, notification_minutes')
          .eq('user_id', user.id)
          .single();

        if (settings?.notifications_enabled && settings?.training_days && settings?.training_times) {
          // Schedule fitness notifications via edge function
          try {
            const { error: scheduleError } = await supabase.functions.invoke('schedule-fitness-notifications', {
              body: { 
                userId: user.id,
                trainingDays: settings.training_days,
                trainingTimes: settings.training_times,
            notificationMinutes: (settings as any).notification_minutes || 30
              }
            });
            
            if (scheduleError) {
              console.error('Error scheduling fitness notifications:', scheduleError);
            }
          } catch (error) {
            console.error('Error calling schedule-fitness-notifications:', error);
          }
        }
      }
    } catch (error) {
      console.error('Error updating fitness session:', error);
      toast.error('Грешка при обновяване на тренировката');
    }
  };

  useEffect(() => {
    if (isFitnessEnabled) {
      fetchFitnessData();
    } else {
      setLoading(false);
    }
  }, [user, date, isFitnessEnabled]);

  return {
    isTrainingDay,
    session,
    loading,
    updateSession,
    refetch: fetchFitnessData
  };
};