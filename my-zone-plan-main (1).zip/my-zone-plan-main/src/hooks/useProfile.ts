import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { toast } from 'sonner';

export interface UserProfile {
  id: string;
  user_id: string;
  email: string | null;
  display_name: string | null;
  first_name: string | null;
  last_name: string | null;
  phone: string | null;
  height_cm: number | null;
  weight_kg: number | null;
  age: number | null;
  gender: 'male' | 'female' | null;
  activity_level: 'sedentary' | 'light' | 'moderate' | 'very_active' | 'extra_active' | null;
  daily_blocks: number | null;
  calculated_at: string | null;
  created_at: string;
  updated_at: string;
  daily_water_goal_ml?: number;
  fasting_goal_hours?: number;
  hydration_enabled?: boolean;
  fasting_enabled?: boolean;
  fitness_enabled?: boolean;
  zone_enabled?: boolean;
  keto_enabled?: boolean;
  daily_carbs_limit?: number;
  daily_calorie_target?: number;
  weight_goal?: 'lose' | 'maintain' | 'gain' | null;
  training_days?: number[];
  push_notifications_enabled?: boolean;
}

export interface ZoneCalculationParams {
  height_cm: number;
  weight_kg: number;
  age: number;
  gender: 'male' | 'female';
  activity_level: 'sedentary' | 'light' | 'moderate' | 'very_active' | 'extra_active';
  weight_goal: 'lose' | 'maintain' | 'gain';
}

export const useProfile = () => {
  const { user } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(() => {
    // Try to load from cache on mount
    const cached = localStorage.getItem(`profile_${user?.id}`);
    return cached ? JSON.parse(cached) : null;
  });
  const [loading, setLoading] = useState(true);

  const fetchProfile = async () => {
    if (!user?.id) {
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) throw error;
      
      const profileData = data as UserProfile;
      setProfile(profileData);
      
      // Cache profile data
      if (profileData) {
        localStorage.setItem(`profile_${user.id}`, JSON.stringify(profileData));
      }
    } catch (error: any) {
      console.error('Error fetching profile:', error);
      // Only show error if it's not a network issue
      if (!error?.message?.includes('Failed to fetch')) {
        toast.error('Грешка при зареждане на профила');
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, [user?.id]);

  const calculateZoneBlocks = (params: ZoneCalculationParams): number => {
    const { height_cm, weight_kg, age, gender, activity_level, weight_goal } = params;

    // Base blocks according to Zone Diet standards
    let baseBlocks: number;
    if (gender === 'male') {
      baseBlocks = 14; // Average male
    } else {
      baseBlocks = 11; // Average female
    }

    // Adjust for body weight (Zone Diet considers lean body mass but we'll use total weight as approximation)
    const weightFactor = weight_kg / (gender === 'male' ? 80 : 65); // Average weights
    baseBlocks = Math.round(baseBlocks * weightFactor);

    // Activity level adjustments
    const activityAdjustments = {
      sedentary: 0.9,      // Reduce blocks for sedentary
      light: 1.0,          // Standard
      moderate: 1.1,       // Slight increase
      very_active: 1.25,   // Higher needs for very active
      extra_active: 1.4    // Highest for extreme activity
    };

    baseBlocks = Math.round(baseBlocks * activityAdjustments[activity_level]);
    
    // Adjust based on weight goal
    switch (weight_goal) {
      case 'lose':
        // For weight loss, reduce by 10%
        baseBlocks = Math.round(baseBlocks * 0.9);
        break;
      case 'gain':
        // For weight gain, increase by 15%
        baseBlocks = Math.round(baseBlocks * 1.15);
        break;
      case 'maintain':
      default:
        // Keep calculated amount
        break;
    }

    // Reasonable limits: minimum 10 blocks, maximum 25 blocks
    return Math.max(10, Math.min(25, baseBlocks));
  };

  const updateZoneSettings = async (params: ZoneCalculationParams) => {
    if (!user?.id || !profile) return;

    try {
      const calculatedBlocks = calculateZoneBlocks(params);
      
      const { error } = await supabase
        .from('profiles')
        .update({
          height_cm: params.height_cm,
          weight_kg: params.weight_kg,
          age: params.age,
          gender: params.gender,
          activity_level: params.activity_level,
          daily_blocks: calculatedBlocks,
          calculated_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .eq('user_id', user.id);

      if (error) throw error;

      // Update local state
      setProfile(prev => prev ? {
        ...prev,
        ...params,
        daily_blocks: calculatedBlocks,
        calculated_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      } : null);

      toast.success(`Вашите Zone настройки са запазени! Препоръчани блокове: ${calculatedBlocks}`);
      return calculatedBlocks;
    } catch (error) {
      console.error('Error updating zone settings:', error);
      toast.error('Грешка при запазване на настройките');
      throw error;
    }
  };

  const updateProfile = async (updates: Partial<UserProfile>) => {
    if (!user?.id || !profile) return;

    try {
      const updatedProfile = { ...profile, ...updates, updated_at: new Date().toISOString() };
      
      // Optimistic update
      setProfile(updatedProfile);
      localStorage.setItem(`profile_${user.id}`, JSON.stringify(updatedProfile));

      const { error } = await supabase
        .from('profiles')
        .update({
          ...updates,
          updated_at: new Date().toISOString()
        })
        .eq('user_id', user.id);

      if (error) throw error;
    } catch (error: any) {
      console.error('Error updating profile:', error);
      // Revert on error
      await fetchProfile();
      if (!error?.message?.includes('Failed to fetch')) {
        toast.error('Грешка при обновяване на профила');
      }
      throw error;
    }
  };

  return {
    profile,
    loading,
    updateZoneSettings,
    updateProfile,
    calculateZoneBlocks,
    refetch: fetchProfile
  };
};