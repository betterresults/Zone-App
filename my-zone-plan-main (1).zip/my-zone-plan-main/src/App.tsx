import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarInset, SidebarTrigger } from "@/components/ui/sidebar";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "@/components/providers/ThemeProvider";
import Index from "./pages/Index";
import Landing from "./pages/Landing";
import Auth from "./pages/Auth";
import BetaSignup from "./pages/BetaSignup";
import BetaWelcome from "./pages/BetaWelcome";
import Feedback from "./pages/Feedback";
import AdminFeedback from "./pages/admin/AdminFeedback";
import Admin from "./pages/Admin";
import AdminProducts from "./pages/admin/AdminProducts";
import AdminRecipes from "./pages/admin/AdminRecipes";
import AdminDishes from "./pages/admin/AdminDishes";
import AdminUsers from "./pages/admin/AdminUsers";
import AdminSettings from "./pages/admin/AdminSettings";
import Products from "./pages/Products";
import Cook from "./pages/Cook";
import Recipes from "./pages/Recipes";
import Meals from "./pages/Meals";
import Calendar from "./pages/Calendar";
import Settings from "./pages/Settings";
import Information from "./pages/Information";
import NotFound from "./pages/NotFound";
import WeeklyMenu from "./pages/WeeklyMenu";
import Fitness from "./pages/Fitness";
import Habits from "./pages/Habits";
import Referral from "./pages/Referral";
import ShoppingLists from "./pages/ShoppingLists";
import { AppSidebar } from "./components/layout/AppSidebar";
import ProtectedRoute from "./components/layout/ProtectedRoute";
import { InstallPrompt } from "./components/ui/install-prompt";
import { useAuth } from "./hooks/useAuth";
import { useNotificationActions } from "./hooks/useNotificationActions";
import OneSignalProvider from "./components/notifications/OneSignalProvider";
import NotificationsOnboarding from "./components/notifications/NotificationsOnboarding";

const queryClient = new QueryClient();

const AppContent = () => {
  const { isAuthenticated, loading } = useAuth();
  useNotificationActions(); // Handle notification actions from URL params
  const isAdmin = false;

  if (loading) {
    console.log('Auth loading...');
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-6 h-6 bg-primary rounded-md flex items-center justify-center animate-pulse">
          <span className="text-white font-bold text-sm">Z</span>
        </div>
      </div>
    );
  }

  console.log('Auth state:', { isAuthenticated, loading });

  if (!isAuthenticated) {
    console.log('Rendering unauthenticated routes');
    return (
      <div className="min-h-screen bg-background">
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/information" element={<Information />} />
          <Route path="/auth" element={<Auth />} />
          <Route path="/beta-signup" element={<BetaSignup />} />
          <Route path="/beta-welcome" element={<BetaWelcome />} />
          <Route path="*" element={<Landing />} />
        </Routes>
      </div>
    );
  }

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-background">
        <AppSidebar />
        <SidebarInset className="flex-1">
          {/* Header with sidebar trigger */}
          <header
            className="relative flex h-16 shrink-0 items-center justify-between px-4 overflow-x-hidden
            before:content-[''] before:absolute before:bottom-0 before:h-px before:bg-border
            before:left-[calc(var(--sidebar-width)*-1)] before:w-[calc(100%+var(--sidebar-width))]
            peer-data-[state=collapsed]:before:left-[calc(var(--sidebar-width-icon)*-1)]
            peer-data-[state=collapsed]:before:w-[calc(100%+var(--sidebar-width-icon))]"
          >
            <SidebarTrigger className="-ml-1" />
            <div className="flex items-center gap-2">
              <span className="text-xl font-bold text-primary">MyZone</span>
              <div className="w-6 h-6 bg-primary rounded-md flex items-center justify-center">
                <span className="text-white font-bold text-sm">Z</span>
              </div>
            </div>
          </header>
          
          <main className="flex-1">
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/auth" element={<Index />} />
              <Route path="/beta-signup" element={<BetaSignup />} />
              <Route path="/beta-welcome" element={<BetaWelcome />} />
              <Route path="/admin" element={<Admin />} />
              <Route path="/admin/products" element={<AdminProducts />} />
              <Route path="/admin/recipes" element={<AdminRecipes />} />
              <Route path="/admin/dishes" element={<AdminDishes />} />
              <Route path="/admin/users" element={<AdminUsers />} />
              <Route path="/admin/settings" element={<AdminSettings />} />
              <Route path="/admin/feedback" element={<AdminFeedback />} />
              <Route path="/cook" element={<Cook />} />
              <Route path="/products" element={<Products />} />
              <Route path="/recipes" element={<Recipes />} />
              <Route path="/meals" element={<Meals />} />
              <Route path="/calendar" element={<Calendar />} />
              <Route path="/habits" element={<Habits />} />
              <Route path="/weekly-menu" element={<WeeklyMenu />} />
              <Route path="/shopping-lists" element={<ShoppingLists />} />
              <Route path="/fitness" element={<Fitness />} />
              <Route path="/feedback" element={<Feedback />} />
              <Route path="/referral" element={<Referral />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/information" element={<Information />} />
              
              <Route path="*" element={<NotFound />} />
            </Routes>
          </main>
        </SidebarInset>
      </div>
      
    </SidebarProvider>
  );
};

const App = () => (
  <BrowserRouter>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <ThemeProvider>
          {/* ... keep existing code (providers and global UI) */}
          <Toaster />
          <Sonner />
          <AppContent />
          <InstallPrompt />
          <OneSignalProvider />
          <NotificationsOnboarding />
        </ThemeProvider>
      </TooltipProvider>
    </QueryClientProvider>
  </BrowserRouter>
);

export default App;
