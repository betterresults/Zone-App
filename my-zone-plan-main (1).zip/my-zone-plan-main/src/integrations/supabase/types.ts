export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.4"
  }
  public: {
    Tables: {
      beta_feedback: {
        Row: {
          admin_notes: string | null
          category: string | null
          created_at: string | null
          description: string
          feedback_type: Database["public"]["Enums"]["feedback_type"]
          id: string
          priority: Database["public"]["Enums"]["feedback_priority"] | null
          status: Database["public"]["Enums"]["feedback_status"] | null
          title: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          admin_notes?: string | null
          category?: string | null
          created_at?: string | null
          description: string
          feedback_type: Database["public"]["Enums"]["feedback_type"]
          id?: string
          priority?: Database["public"]["Enums"]["feedback_priority"] | null
          status?: Database["public"]["Enums"]["feedback_status"] | null
          title: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          admin_notes?: string | null
          category?: string | null
          created_at?: string | null
          description?: string
          feedback_type?: Database["public"]["Enums"]["feedback_type"]
          id?: string
          priority?: Database["public"]["Enums"]["feedback_priority"] | null
          status?: Database["public"]["Enums"]["feedback_status"] | null
          title?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      calendar_events: {
        Row: {
          all_day: boolean
          color: string | null
          created_at: string
          description: string | null
          end_time: string | null
          event_date: string
          event_type: string
          id: string
          reminder_enabled: boolean | null
          reminder_minutes_before: number | null
          start_time: string | null
          status: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          all_day?: boolean
          color?: string | null
          created_at?: string
          description?: string | null
          end_time?: string | null
          event_date: string
          event_type?: string
          id?: string
          reminder_enabled?: boolean | null
          reminder_minutes_before?: number | null
          start_time?: string | null
          status?: string
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          all_day?: boolean
          color?: string | null
          created_at?: string
          description?: string | null
          end_time?: string | null
          event_date?: string
          event_type?: string
          id?: string
          reminder_enabled?: boolean | null
          reminder_minutes_before?: number | null
          start_time?: string | null
          status?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      dish_ingredients: {
        Row: {
          created_at: string
          dish_id: string
          grams: number
          id: string
          product_id: string
        }
        Insert: {
          created_at?: string
          dish_id: string
          grams?: number
          id?: string
          product_id: string
        }
        Update: {
          created_at?: string
          dish_id?: string
          grams?: number
          id?: string
          product_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "dish_ingredients_dish_id_fkey"
            columns: ["dish_id"]
            isOneToOne: false
            referencedRelation: "dishes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "dish_ingredients_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      dishes: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_public: boolean | null
          meal_type: Database["public"]["Enums"]["meal_type"]
          name: string
          source_recipe_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_public?: boolean | null
          meal_type?: Database["public"]["Enums"]["meal_type"]
          name: string
          source_recipe_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_public?: boolean | null
          meal_type?: Database["public"]["Enums"]["meal_type"]
          name?: string
          source_recipe_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "dishes_source_recipe_id_fkey"
            columns: ["source_recipe_id"]
            isOneToOne: false
            referencedRelation: "recipes"
            referencedColumns: ["id"]
          },
        ]
      }
      email_logs: {
        Row: {
          created_at: string
          email_content: string | null
          email_type: string
          error_message: string | null
          id: string
          recipient_email: string
          recipient_user_id: string | null
          sent_at: string
          sent_by: string
          status: string
          subject: string
          template_type: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          email_content?: string | null
          email_type?: string
          error_message?: string | null
          id?: string
          recipient_email: string
          recipient_user_id?: string | null
          sent_at?: string
          sent_by: string
          status?: string
          subject: string
          template_type?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          email_content?: string | null
          email_type?: string
          error_message?: string | null
          id?: string
          recipient_email?: string
          recipient_user_id?: string | null
          sent_at?: string
          sent_by?: string
          status?: string
          subject?: string
          template_type?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      email_templates: {
        Row: {
          created_at: string
          created_by: string
          id: string
          is_active: boolean
          template_content: string
          template_name: string
          template_subject: string
          template_type: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by: string
          id?: string
          is_active?: boolean
          template_content: string
          template_name: string
          template_subject: string
          template_type?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string
          id?: string
          is_active?: boolean
          template_content?: string
          template_name?: string
          template_subject?: string
          template_type?: string
          updated_at?: string
        }
        Relationships: []
      }
      exercises: {
        Row: {
          category: string
          created_at: string
          created_by: string | null
          description: string | null
          difficulty_level: string | null
          equipment: string | null
          id: string
          image_url: string | null
          instructions: string | null
          is_public: boolean | null
          muscle_groups: string[] | null
          name: string
          tips: string | null
          updated_at: string
          video_url: string | null
        }
        Insert: {
          category?: string
          created_at?: string
          created_by?: string | null
          description?: string | null
          difficulty_level?: string | null
          equipment?: string | null
          id?: string
          image_url?: string | null
          instructions?: string | null
          is_public?: boolean | null
          muscle_groups?: string[] | null
          name: string
          tips?: string | null
          updated_at?: string
          video_url?: string | null
        }
        Update: {
          category?: string
          created_at?: string
          created_by?: string | null
          description?: string | null
          difficulty_level?: string | null
          equipment?: string | null
          id?: string
          image_url?: string | null
          instructions?: string | null
          is_public?: boolean | null
          muscle_groups?: string[] | null
          name?: string
          tips?: string | null
          updated_at?: string
          video_url?: string | null
        }
        Relationships: []
      }
      fasting_sessions: {
        Row: {
          created_at: string
          end_at: string | null
          id: string
          note: string | null
          start_at: string
          target_hours: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          end_at?: string | null
          id?: string
          note?: string | null
          start_at?: string
          target_hours?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          end_at?: string | null
          id?: string
          note?: string | null
          start_at?: string
          target_hours?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      favorite_portions: {
        Row: {
          created_at: string
          grams: number
          id: string
          portion_name: string
          product_id: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          grams: number
          id?: string
          portion_name: string
          product_id: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          grams?: number
          id?: string
          portion_name?: string
          product_id?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "favorite_portions_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      fitness_sessions: {
        Row: {
          calories_burned: number | null
          completed: boolean
          created_at: string
          id: string
          notes: string | null
          session_date: string
          updated_at: string
          user_id: string
        }
        Insert: {
          calories_burned?: number | null
          completed?: boolean
          created_at?: string
          id?: string
          notes?: string | null
          session_date?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          calories_burned?: number | null
          completed?: boolean
          created_at?: string
          id?: string
          notes?: string | null
          session_date?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      fitness_settings: {
        Row: {
          created_at: string
          id: string
          notification_minutes: number | null
          notifications_enabled: boolean | null
          rest_between_exercises_seconds: number | null
          training_days: Json
          training_days_per_week: number
          training_times: Json
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          notification_minutes?: number | null
          notifications_enabled?: boolean | null
          rest_between_exercises_seconds?: number | null
          training_days?: Json
          training_days_per_week?: number
          training_times?: Json
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          notification_minutes?: number | null
          notifications_enabled?: boolean | null
          rest_between_exercises_seconds?: number | null
          training_days?: Json
          training_days_per_week?: number
          training_times?: Json
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      habit_completions: {
        Row: {
          completed_at: string
          completion_date: string
          created_at: string
          habit_id: string
          id: string
          notes: string | null
          user_id: string
        }
        Insert: {
          completed_at?: string
          completion_date?: string
          created_at?: string
          habit_id: string
          id?: string
          notes?: string | null
          user_id: string
        }
        Update: {
          completed_at?: string
          completion_date?: string
          created_at?: string
          habit_id?: string
          id?: string
          notes?: string | null
          user_id?: string
        }
        Relationships: []
      }
      habit_daily_stats: {
        Row: {
          completed_at: string | null
          created_at: string
          date: string
          habit_id: string
          id: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          date: string
          habit_id: string
          id?: string
          status: string
          updated_at?: string
          user_id: string
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          date?: string
          habit_id?: string
          id?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      habit_day_overrides: {
        Row: {
          created_at: string
          habit_id: string
          id: string
          new_time: string | null
          override_date: string
          override_type: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          habit_id: string
          id?: string
          new_time?: string | null
          override_date: string
          override_type: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          habit_id?: string
          id?: string
          new_time?: string | null
          override_date?: string
          override_type?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      habit_sessions: {
        Row: {
          actual_duration_minutes: number | null
          created_at: string
          ended_at: string | null
          habit_id: string
          id: string
          is_completed: boolean
          notes: string | null
          session_date: string
          started_at: string
          target_duration_minutes: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          actual_duration_minutes?: number | null
          created_at?: string
          ended_at?: string | null
          habit_id: string
          id?: string
          is_completed?: boolean
          notes?: string | null
          session_date?: string
          started_at?: string
          target_duration_minutes?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          actual_duration_minutes?: number | null
          created_at?: string
          ended_at?: string | null
          habit_id?: string
          id?: string
          is_completed?: boolean
          notes?: string | null
          session_date?: string
          started_at?: string
          target_duration_minutes?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      habit_settings: {
        Row: {
          active_days: Json
          created_at: string
          day_end_time: string
          day_start_time: string
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          active_days?: Json
          created_at?: string
          day_end_time?: string
          day_start_time?: string
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          active_days?: Json
          created_at?: string
          day_end_time?: string
          day_start_time?: string
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      habits: {
        Row: {
          category: string | null
          color: string | null
          created_at: string
          description: string | null
          duration_minutes: number | null
          fitness_template_id: string | null
          habit_type: Database["public"]["Enums"]["habit_type"]
          id: string
          is_active: boolean | null
          is_important: boolean | null
          name: string
          one_time_date: string | null
          reminder_enabled: boolean | null
          reminder_minutes_before: number | null
          reminder_time: string | null
          repeat_days: Json
          streak_count: number | null
          time_of_day: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          category?: string | null
          color?: string | null
          created_at?: string
          description?: string | null
          duration_minutes?: number | null
          fitness_template_id?: string | null
          habit_type?: Database["public"]["Enums"]["habit_type"]
          id?: string
          is_active?: boolean | null
          is_important?: boolean | null
          name: string
          one_time_date?: string | null
          reminder_enabled?: boolean | null
          reminder_minutes_before?: number | null
          reminder_time?: string | null
          repeat_days?: Json
          streak_count?: number | null
          time_of_day?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          category?: string | null
          color?: string | null
          created_at?: string
          description?: string | null
          duration_minutes?: number | null
          fitness_template_id?: string | null
          habit_type?: Database["public"]["Enums"]["habit_type"]
          id?: string
          is_active?: boolean | null
          is_important?: boolean | null
          name?: string
          one_time_date?: string | null
          reminder_enabled?: boolean | null
          reminder_minutes_before?: number | null
          reminder_time?: string | null
          repeat_days?: Json
          streak_count?: number | null
          time_of_day?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "habits_fitness_template_id_fkey"
            columns: ["fitness_template_id"]
            isOneToOne: false
            referencedRelation: "fitness_settings"
            referencedColumns: ["id"]
          },
        ]
      }
      hydration_intakes: {
        Row: {
          beverage_type: Database["public"]["Enums"]["hydration_beverage_type"]
          created_at: string
          id: string
          intake_at: string
          note: string | null
          product_id: string | null
          updated_at: string
          user_id: string
          volume_ml: number
        }
        Insert: {
          beverage_type?: Database["public"]["Enums"]["hydration_beverage_type"]
          created_at?: string
          id?: string
          intake_at?: string
          note?: string | null
          product_id?: string | null
          updated_at?: string
          user_id: string
          volume_ml: number
        }
        Update: {
          beverage_type?: Database["public"]["Enums"]["hydration_beverage_type"]
          created_at?: string
          id?: string
          intake_at?: string
          note?: string | null
          product_id?: string | null
          updated_at?: string
          user_id?: string
          volume_ml?: number
        }
        Relationships: [
          {
            foreignKeyName: "hydration_intakes_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      meals: {
        Row: {
          created_at: string
          date: string
          dish_id: string | null
          grams: number | null
          id: string
          is_consumed: boolean
          meal_type: Database["public"]["Enums"]["meal_type"]
          notes: string | null
          product_id: string | null
          recipe_id: string | null
          servings: number | null
          updated_at: string
          user_id: string
          week_start_date: string | null
        }
        Insert: {
          created_at?: string
          date?: string
          dish_id?: string | null
          grams?: number | null
          id?: string
          is_consumed?: boolean
          meal_type: Database["public"]["Enums"]["meal_type"]
          notes?: string | null
          product_id?: string | null
          recipe_id?: string | null
          servings?: number | null
          updated_at?: string
          user_id: string
          week_start_date?: string | null
        }
        Update: {
          created_at?: string
          date?: string
          dish_id?: string | null
          grams?: number | null
          id?: string
          is_consumed?: boolean
          meal_type?: Database["public"]["Enums"]["meal_type"]
          notes?: string | null
          product_id?: string | null
          recipe_id?: string | null
          servings?: number | null
          updated_at?: string
          user_id?: string
          week_start_date?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "meals_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "meals_recipe_id_fkey"
            columns: ["recipe_id"]
            isOneToOne: false
            referencedRelation: "recipes"
            referencedColumns: ["id"]
          },
        ]
      }
      notification_templates: {
        Row: {
          created_at: string
          id: string
          is_active: boolean | null
          message_template: string
          template_name: string
          template_type: string
          time_of_day: string | null
          title_template: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_active?: boolean | null
          message_template: string
          template_name: string
          template_type: string
          time_of_day?: string | null
          title_template: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          is_active?: boolean | null
          message_template?: string
          template_name?: string
          template_type?: string
          time_of_day?: string | null
          title_template?: string
          updated_at?: string
        }
        Relationships: []
      }
      products: {
        Row: {
          barcode: string | null
          brand: string | null
          calories_per_100g: number
          carbs_per_100g: number
          category: Database["public"]["Enums"]["product_category"] | null
          created_at: string
          custom_category: string | null
          custom_icon: string | null
          default_serving_grams: number | null
          fat_per_100g: number
          fiber_per_100g: number
          id: string
          image_url: string | null
          is_public: boolean | null
          name: string
          package_size_grams: number | null
          package_size_unit: string | null
          package_unit_type: string
          protein_per_100g: number
          updated_at: string
          user_id: string | null
        }
        Insert: {
          barcode?: string | null
          brand?: string | null
          calories_per_100g?: number
          carbs_per_100g?: number
          category?: Database["public"]["Enums"]["product_category"] | null
          created_at?: string
          custom_category?: string | null
          custom_icon?: string | null
          default_serving_grams?: number | null
          fat_per_100g?: number
          fiber_per_100g?: number
          id?: string
          image_url?: string | null
          is_public?: boolean | null
          name: string
          package_size_grams?: number | null
          package_size_unit?: string | null
          package_unit_type?: string
          protein_per_100g?: number
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          barcode?: string | null
          brand?: string | null
          calories_per_100g?: number
          carbs_per_100g?: number
          category?: Database["public"]["Enums"]["product_category"] | null
          created_at?: string
          custom_category?: string | null
          custom_icon?: string | null
          default_serving_grams?: number | null
          fat_per_100g?: number
          fiber_per_100g?: number
          id?: string
          image_url?: string | null
          is_public?: boolean | null
          name?: string
          package_size_grams?: number | null
          package_size_unit?: string | null
          package_unit_type?: string
          protein_per_100g?: number
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          activity_level: string | null
          age: number | null
          blocked: boolean | null
          blocked_at: string | null
          blocked_by: string | null
          blocked_reason: string | null
          calculated_at: string | null
          created_at: string
          daily_blocks: number | null
          daily_calorie_target: number | null
          daily_carbs_limit: number | null
          daily_water_goal_ml: number
          display_name: string | null
          email: string | null
          fasting_enabled: boolean
          fasting_goal_hours: number
          first_name: string | null
          fitness_enabled: boolean
          gender: string | null
          height_cm: number | null
          hidden_fat_mode: boolean | null
          hydration_enabled: boolean
          id: string
          keto_enabled: boolean
          last_name: string | null
          partnero_customer_id: string | null
          phone: string | null
          push_notifications_enabled: boolean | null
          updated_at: string
          user_id: string
          weight_goal: string | null
          weight_kg: number | null
          zone_enabled: boolean
        }
        Insert: {
          activity_level?: string | null
          age?: number | null
          blocked?: boolean | null
          blocked_at?: string | null
          blocked_by?: string | null
          blocked_reason?: string | null
          calculated_at?: string | null
          created_at?: string
          daily_blocks?: number | null
          daily_calorie_target?: number | null
          daily_carbs_limit?: number | null
          daily_water_goal_ml?: number
          display_name?: string | null
          email?: string | null
          fasting_enabled?: boolean
          fasting_goal_hours?: number
          first_name?: string | null
          fitness_enabled?: boolean
          gender?: string | null
          height_cm?: number | null
          hidden_fat_mode?: boolean | null
          hydration_enabled?: boolean
          id?: string
          keto_enabled?: boolean
          last_name?: string | null
          partnero_customer_id?: string | null
          phone?: string | null
          push_notifications_enabled?: boolean | null
          updated_at?: string
          user_id: string
          weight_goal?: string | null
          weight_kg?: number | null
          zone_enabled?: boolean
        }
        Update: {
          activity_level?: string | null
          age?: number | null
          blocked?: boolean | null
          blocked_at?: string | null
          blocked_by?: string | null
          blocked_reason?: string | null
          calculated_at?: string | null
          created_at?: string
          daily_blocks?: number | null
          daily_calorie_target?: number | null
          daily_carbs_limit?: number | null
          daily_water_goal_ml?: number
          display_name?: string | null
          email?: string | null
          fasting_enabled?: boolean
          fasting_goal_hours?: number
          first_name?: string | null
          fitness_enabled?: boolean
          gender?: string | null
          height_cm?: number | null
          hidden_fat_mode?: boolean | null
          hydration_enabled?: boolean
          id?: string
          keto_enabled?: boolean
          last_name?: string | null
          partnero_customer_id?: string | null
          phone?: string | null
          push_notifications_enabled?: boolean | null
          updated_at?: string
          user_id?: string
          weight_goal?: string | null
          weight_kg?: number | null
          zone_enabled?: boolean
        }
        Relationships: []
      }
      recipe_ingredients: {
        Row: {
          created_at: string
          grams: number
          id: string
          product_id: string
          recipe_id: string
        }
        Insert: {
          created_at?: string
          grams?: number
          id?: string
          product_id: string
          recipe_id: string
        }
        Update: {
          created_at?: string
          grams?: number
          id?: string
          product_id?: string
          recipe_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "recipe_ingredients_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "recipe_ingredients_recipe_id_fkey"
            columns: ["recipe_id"]
            isOneToOne: false
            referencedRelation: "recipes"
            referencedColumns: ["id"]
          },
        ]
      }
      recipe_ratings: {
        Row: {
          comment: string | null
          created_at: string
          id: string
          rating: number
          recipe_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          comment?: string | null
          created_at?: string
          id?: string
          rating: number
          recipe_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          comment?: string | null
          created_at?: string
          id?: string
          rating?: number
          recipe_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "recipe_ratings_recipe_id_fkey"
            columns: ["recipe_id"]
            isOneToOne: false
            referencedRelation: "recipes"
            referencedColumns: ["id"]
          },
        ]
      }
      recipes: {
        Row: {
          created_at: string
          description: string | null
          id: string
          image_urls: string[] | null
          instructions: string | null
          is_keto_friendly: boolean | null
          is_public: boolean | null
          is_zone_compliant: boolean | null
          meal_type: Database["public"]["Enums"]["meal_type"] | null
          name: string
          servings: number
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          image_urls?: string[] | null
          instructions?: string | null
          is_keto_friendly?: boolean | null
          is_public?: boolean | null
          is_zone_compliant?: boolean | null
          meal_type?: Database["public"]["Enums"]["meal_type"] | null
          name: string
          servings?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          image_urls?: string[] | null
          instructions?: string | null
          is_keto_friendly?: boolean | null
          is_public?: boolean | null
          is_zone_compliant?: boolean | null
          meal_type?: Database["public"]["Enums"]["meal_type"] | null
          name?: string
          servings?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      scheduled_notifications: {
        Row: {
          created_at: string
          id: string
          is_sent: boolean | null
          message: string
          notification_type: string
          reference_id: string
          scheduled_for: string
          sent_at: string | null
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_sent?: boolean | null
          message: string
          notification_type: string
          reference_id: string
          scheduled_for: string
          sent_at?: string | null
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_sent?: boolean | null
          message?: string
          notification_type?: string
          reference_id?: string
          scheduled_for?: string
          sent_at?: string | null
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      shopping_list_items: {
        Row: {
          created_at: string
          estimated_packages: number | null
          id: string
          is_available: boolean | null
          is_purchased: boolean | null
          notes: string | null
          product_id: string
          quantity_grams: number
          shopping_list_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          estimated_packages?: number | null
          id?: string
          is_available?: boolean | null
          is_purchased?: boolean | null
          notes?: string | null
          product_id: string
          quantity_grams: number
          shopping_list_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          estimated_packages?: number | null
          id?: string
          is_available?: boolean | null
          is_purchased?: boolean | null
          notes?: string | null
          product_id?: string
          quantity_grams?: number
          shopping_list_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      shopping_lists: {
        Row: {
          archived_at: string | null
          completed_items_count: number | null
          created_at: string
          id: string
          is_archived: boolean | null
          is_completed: boolean | null
          is_template: boolean | null
          name: string
          template_name: string | null
          total_items_count: number | null
          updated_at: string
          user_id: string
          week_end_date: string
          week_start_date: string
        }
        Insert: {
          archived_at?: string | null
          completed_items_count?: number | null
          created_at?: string
          id?: string
          is_archived?: boolean | null
          is_completed?: boolean | null
          is_template?: boolean | null
          name: string
          template_name?: string | null
          total_items_count?: number | null
          updated_at?: string
          user_id: string
          week_end_date: string
          week_start_date: string
        }
        Update: {
          archived_at?: string | null
          completed_items_count?: number | null
          created_at?: string
          id?: string
          is_archived?: boolean | null
          is_completed?: boolean | null
          is_template?: boolean | null
          name?: string
          template_name?: string | null
          total_items_count?: number | null
          updated_at?: string
          user_id?: string
          week_end_date?: string
          week_start_date?: string
        }
        Relationships: []
      }
      subscribers: {
        Row: {
          created_at: string
          email: string
          id: string
          stripe_customer_id: string | null
          subscribed: boolean
          subscription_end: string | null
          subscription_source: string | null
          subscription_tier: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          stripe_customer_id?: string | null
          subscribed?: boolean
          subscription_end?: string | null
          subscription_source?: string | null
          subscription_tier?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          stripe_customer_id?: string | null
          subscribed?: boolean
          subscription_end?: string | null
          subscription_source?: string | null
          subscription_tier?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      theme_settings: {
        Row: {
          colors: Json
          created_at: string
          created_by: string | null
          id: string
          is_active: boolean
          name: string
          updated_at: string
        }
        Insert: {
          colors?: Json
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean
          name: string
          updated_at?: string
        }
        Update: {
          colors?: Json
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      user_activities: {
        Row: {
          activity_category: string
          activity_data: Json | null
          activity_description: string
          activity_type: string
          created_at: string
          id: string
          ip_address: string | null
          user_agent: string | null
          user_id: string
        }
        Insert: {
          activity_category: string
          activity_data?: Json | null
          activity_description: string
          activity_type: string
          created_at?: string
          id?: string
          ip_address?: string | null
          user_agent?: string | null
          user_id: string
        }
        Update: {
          activity_category?: string
          activity_data?: Json | null
          activity_description?: string
          activity_type?: string
          created_at?: string
          id?: string
          ip_address?: string | null
          user_agent?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_activities_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["user_id"]
          },
        ]
      }
      user_activity: {
        Row: {
          activity_date: string
          activity_type: string
          created_at: string
          id: string
          user_id: string
        }
        Insert: {
          activity_date?: string
          activity_type: string
          created_at?: string
          id?: string
          user_id: string
        }
        Update: {
          activity_date?: string
          activity_type?: string
          created_at?: string
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      user_habit_categories: {
        Row: {
          color: string
          created_at: string
          icon: string
          id: string
          is_default: boolean
          name: string
          updated_at: string
          user_id: string
        }
        Insert: {
          color?: string
          created_at?: string
          icon?: string
          id?: string
          is_default?: boolean
          name: string
          updated_at?: string
          user_id: string
        }
        Update: {
          color?: string
          created_at?: string
          icon?: string
          id?: string
          is_default?: boolean
          name?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_preferences: {
        Row: {
          created_at: string
          id: string
          preference_key: string
          preference_value: Json
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          preference_key: string
          preference_value: Json
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          preference_key?: string
          preference_value?: Json
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          role: Database["public"]["Enums"]["user_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          role?: Database["public"]["Enums"]["user_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          role?: Database["public"]["Enums"]["user_role"]
          user_id?: string
        }
        Relationships: []
      }
      weekly_meal_plans: {
        Row: {
          completed_at: string | null
          created_at: string
          day_of_week: number
          dish_id: string | null
          grams: number | null
          id: string
          is_completed: boolean
          meal_group_id: string | null
          meal_type: Database["public"]["Enums"]["meal_type"]
          notes: string | null
          product_id: string | null
          recipe_id: string | null
          servings: number | null
          updated_at: string
          user_id: string
          week_start_date: string
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          day_of_week: number
          dish_id?: string | null
          grams?: number | null
          id?: string
          is_completed?: boolean
          meal_group_id?: string | null
          meal_type: Database["public"]["Enums"]["meal_type"]
          notes?: string | null
          product_id?: string | null
          recipe_id?: string | null
          servings?: number | null
          updated_at?: string
          user_id: string
          week_start_date: string
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          day_of_week?: number
          dish_id?: string | null
          grams?: number | null
          id?: string
          is_completed?: boolean
          meal_group_id?: string | null
          meal_type?: Database["public"]["Enums"]["meal_type"]
          notes?: string | null
          product_id?: string | null
          recipe_id?: string | null
          servings?: number | null
          updated_at?: string
          user_id?: string
          week_start_date?: string
        }
        Relationships: [
          {
            foreignKeyName: "weekly_meal_plans_dish_id_fkey"
            columns: ["dish_id"]
            isOneToOne: false
            referencedRelation: "dishes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "weekly_meal_plans_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "weekly_meal_plans_recipe_id_fkey"
            columns: ["recipe_id"]
            isOneToOne: false
            referencedRelation: "recipes"
            referencedColumns: ["id"]
          },
        ]
      }
      weekly_menu_templates: {
        Row: {
          created_at: string
          id: string
          template_data: Json
          template_name: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          template_data: Json
          template_name: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          template_data?: Json
          template_name?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      weight_history: {
        Row: {
          created_at: string
          id: string
          notes: string | null
          recorded_at: string
          updated_at: string
          user_id: string
          weight_kg: number
        }
        Insert: {
          created_at?: string
          id?: string
          notes?: string | null
          recorded_at?: string
          updated_at?: string
          user_id: string
          weight_kg: number
        }
        Update: {
          created_at?: string
          id?: string
          notes?: string | null
          recorded_at?: string
          updated_at?: string
          user_id?: string
          weight_kg?: number
        }
        Relationships: []
      }
      workout_exercises: {
        Row: {
          created_at: string
          distance_meters: number | null
          duration_seconds: number | null
          exercise_id: string
          exercise_order: number | null
          fitness_session_id: string | null
          id: string
          notes: string | null
          reps: number | null
          rest_seconds: number | null
          sets: number | null
          updated_at: string
          user_id: string
          weight_kg: number | null
        }
        Insert: {
          created_at?: string
          distance_meters?: number | null
          duration_seconds?: number | null
          exercise_id: string
          exercise_order?: number | null
          fitness_session_id?: string | null
          id?: string
          notes?: string | null
          reps?: number | null
          rest_seconds?: number | null
          sets?: number | null
          updated_at?: string
          user_id: string
          weight_kg?: number | null
        }
        Update: {
          created_at?: string
          distance_meters?: number | null
          duration_seconds?: number | null
          exercise_id?: string
          exercise_order?: number | null
          fitness_session_id?: string | null
          id?: string
          notes?: string | null
          reps?: number | null
          rest_seconds?: number | null
          sets?: number | null
          updated_at?: string
          user_id?: string
          weight_kg?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "workout_exercises_exercise_id_fkey"
            columns: ["exercise_id"]
            isOneToOne: false
            referencedRelation: "exercises"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workout_exercises_fitness_session_id_fkey"
            columns: ["fitness_session_id"]
            isOneToOne: false
            referencedRelation: "fitness_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      calculate_recipe_keto_friendly: {
        Args: { recipe_id_param: string }
        Returns: boolean
      }
      calculate_recipe_zone_compliance: {
        Args: { recipe_id_param: string }
        Returns: boolean
      }
      get_admin_stats: {
        Args: Record<PropertyKey, never>
        Returns: Json
      }
      get_beta_testers_count: {
        Args: Record<PropertyKey, never>
        Returns: number
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["user_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_admin: {
        Args: { _user_id: string }
        Returns: boolean
      }
      is_user_active: {
        Args: { user_uuid: string }
        Returns: boolean
      }
      make_user_admin: {
        Args: { user_email: string }
        Returns: undefined
      }
      sync_dish_from_recipe: {
        Args: { dish_id: string; recipe_id: string }
        Returns: undefined
      }
      trigger_daily_habits_processing: {
        Args: Record<PropertyKey, never>
        Returns: Json
      }
      update_event_status: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
    }
    Enums: {
      feedback_priority: "low" | "medium" | "high" | "critical"
      feedback_status: "new" | "in_progress" | "resolved" | "closed"
      feedback_type: "like" | "dislike" | "bug" | "improvement" | "other"
      habit_type: "habit" | "task"
      hydration_beverage_type:
        | "water"
        | "tea"
        | "coffee"
        | "juice"
        | "soup"
        | "other"
        | "milk"
      meal_type: "breakfast" | "lunch" | "dinner" | "snack" | "combination"
      product_category:
        | "protein"
        | "carbs"
        | "fats"
        | "vegetables"
        | "fruits"
        | "dairy"
        | "grains"
        | "legumes"
        | "nuts"
        | "spices"
        | "other"
        | "cooked"
      user_role: "user" | "admin"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      feedback_priority: ["low", "medium", "high", "critical"],
      feedback_status: ["new", "in_progress", "resolved", "closed"],
      feedback_type: ["like", "dislike", "bug", "improvement", "other"],
      habit_type: ["habit", "task"],
      hydration_beverage_type: [
        "water",
        "tea",
        "coffee",
        "juice",
        "soup",
        "other",
        "milk",
      ],
      meal_type: ["breakfast", "lunch", "dinner", "snack", "combination"],
      product_category: [
        "protein",
        "carbs",
        "fats",
        "vegetables",
        "fruits",
        "dairy",
        "grains",
        "legumes",
        "nuts",
        "spices",
        "other",
        "cooked",
      ],
      user_role: ["user", "admin"],
    },
  },
} as const
