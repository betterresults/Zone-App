import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.e945dcd9239c4bd4b548b61cc904d241',
  appName: 'my-zone-plan',
  webDir: 'dist',
  server: {
    url: 'https://e945dcd9-239c-4bd4-b548-b61cc904d241.lovableproject.com?forceHideBadge=true',
    cleartext: true
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: '#ffffff',
      showSpinner: false
    },
    PushNotifications: {
      presentationOptions: ["badge", "sound", "alert"]
    }
  }
};

export default config;